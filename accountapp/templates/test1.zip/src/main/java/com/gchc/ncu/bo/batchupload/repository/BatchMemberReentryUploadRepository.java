package com.gchc.ncu.bo.batchupload.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.domains.PaginationRequest;

import com.gchc.ncu.bo.batchupload.models.BatchMemberReentryUploadResultModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadCustomerReentryModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadReentryDownloadRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadReentryErrorRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadResultRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadReentryExcelModel;

@Mapper
public interface BatchMemberReentryUploadRepository {

	void updateClcoAempReenBlkRegTmpUploadYn(Map<String, Object> map);

	List<BatchMemberUploadCustomerReentryModel> getClcoAempReenBlkRegTmpForUpdate(Map<String, Object> map);

	int getAempReenBlkRegTmpNextSeq(Map<String, Object> map);

	void updateClcoAempReenBlkRegTmp(BatchMemberUploadCustomerReentryModel c);

	void updateClcoAempReenBlkRegTmpValidate(Map<String, Object> map);

	void updateClcoAempReenBlkRegTmpUid(Map<String, Object> map);

	void updateClcoAempReenBlkRegTmpValidate2(Map<String, Object> map);

	BatchMemberReentryUploadResultModel getClcoAempReenBlkRegTmpResult(BatchMemberUploadResultRequestModel in);

	void updateClcoAempReenBlkRegTmpRemove(Map<String, Object> map);

	void updateClcoAempReenBlkRegTmpInit(BatchMemberUploadResultRequestModel in);

	PaginationList<BatchMemberUploadCustomerReentryModel> getClcoAempReenBlkRegTmp(@Param("model") BatchMemberUploadReentryErrorRequestModel in, PaginationRequest paginationRequest);

	List<BatchUploadReentryExcelModel> getClcoAempReenBlkRegTmpExcelList(
		BatchMemberUploadReentryDownloadRequestModel in);

	List<BatchUploadReentryExcelModel> getClcoAempReenBlkRegTmpTestExcelList(
		BatchMemberUploadReentryDownloadRequestModel in);

	void updateMbrClcoRltnRestore(BatchMemberUploadResultRequestModel in);

	void insertMbrClcoRltnChgRecsRestore(BatchMemberUploadResultRequestModel in);

	void updateMbrBsplHisRestore(BatchMemberUploadResultRequestModel in);

	void updateMbrBscMbrTyCd(BatchMemberUploadResultRequestModel in);

	void insertMbrChgRecs(BatchMemberUploadResultRequestModel in);

	void updateMbrClcoRltnQuit(BatchMemberUploadResultRequestModel in);

	void insertMbrClcoRltnChgRecsQuit(BatchMemberUploadResultRequestModel in);

	void updateMbrBsplHisQuit(BatchMemberUploadResultRequestModel in);

	void updateClcoAempReenBlkRegTmpRegist(BatchMemberUploadResultRequestModel in);

	void updateClcoAempReenBlkRegTmpRemoveAll(BatchMemberUploadReentryErrorRequestModel in);

	List<BatchUploadReentryExcelModel> getClcoAempReenBlkRegTmpExcelList2(Map<String, Object> map);

}
