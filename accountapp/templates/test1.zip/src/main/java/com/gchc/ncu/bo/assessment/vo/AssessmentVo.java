package com.gchc.ncu.bo.assessment.vo;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.gchc.ncu.bo.assessment.models.AssessmentFileModel;
import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.AssessmentTargetModel;
import com.gchc.ncu.bo.assessment.models.AssessmentQuestionModel;
import com.gchc.ncu.bo.assessment.models.AssessmentScoreModel;
import com.gchc.ncu.bo.assessment.models.AssessmentStatusModel;
import com.gsitm.ustra.java.mvc.rest.model.RestVo;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class AssessmentVo extends RestVo {

	private int								yr;				//기준년도
	private int								cuiAsmTgtId;
	private int								cuiAsmId;

	private AssessmentModel					info;
	private List<AssessmentTargetModel>		targetList;
	private List<AssessmentTargetModel>		targetHistoryList;

	private List<AssessmentQuestionModel> 	qstRspnExmList;
	private List<AssessmentQuestionModel> 	qstExmList;

	private List<AssessmentScoreModel>		asmRsltList;
	private List<AssessmentScoreModel>		yrScrList;
	private List<AssessmentFileModel>		fileList;

	private List<AssessmentQuestionTypeVo>	qstTyList;
	private Double							level;

}