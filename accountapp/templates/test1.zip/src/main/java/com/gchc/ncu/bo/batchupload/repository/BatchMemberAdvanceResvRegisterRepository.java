package com.gchc.ncu.bo.batchupload.repository;

import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadAdvanceResvModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadAdvanceResvSelectItemModel;
import com.gchc.ncu.bo.batchupload.models.ResvInfoModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface BatchMemberAdvanceResvRegisterRepository {




	int updateClcoAempBlkRegTmpRegistTypeForAdre(Map<String, Object> params);

	void updateClcoBlkRegTmpIdForAdre(Map<String, Object> params);

	void updateClcoBlkRegTmpUpldStForAdre(Map<String, Object> params);

	void updateClcoBlkRegTmpId2ForAdre(Map<String, Object> params);

	void insertMbrBscForAdre(Map<String, Object> params);

	void insertMbrAddInfDtlForAdre(Map<String, Object> params);

	void updateMbrAddInfDtlForAdre(Map<String, Object> params);

	void updateClcoBlkRegTmpUpldSt3ForAdre(Map<String, Object> params);

	void insertMbrClcoRltnForAdre(Map<String, Object> params);

	void insertMbrClcoRltnChgRecsForAdre(Map<String, Object> params);

	void updateClcoBlkRegTmpUpldSt2ForAdre(Map<String, Object> params);

	void updateClcoBlkRegTmpUpdYnForAdre(Map<String, Object> params);

	void insertMbrChgRecsMblForAdre(Map<String, Object> params);

	void insertMbrChgRecsEmlForAdre(Map<String, Object> params);

	void insertMbrChgRecsNmForAdre(Map<String, Object> params);

	void insertMbrChgRecsBrdtForAdre(Map<String, Object> params);

	void insertMbrChgRecsSexForAdre(Map<String, Object> params);

	void insertMbrChgRecsIdForAdre(Map<String, Object> params);

	void updateMbrBscForAdre(Map<String, Object> params);

	void updateMbrClcoRltnForAdre(Map<String, Object> params);

	void insertMbrClcoRltnChgRecs2ForAdre(Map<String, Object> params);

	void insertMbrHthSvcInfHisForAdre(Map<String, Object> params);

	void insertHthRistAsmCuRltnForAdre(Map<String, Object> params);

	void insertMbrBsplHisForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpTgtIdForAdre(Map<String, Object> params);

	void insertCuTgtHisForAdre(Map<String, Object> params);

	void updateCuTgtHisExcuYnForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpTgtId2ForAdre(Map<String, Object> params);

	void updateExtrHndlMttrResvTgtDeleteForAdre(Map<String, Object> params);

	void updateExtrHndlMttrResvTgtDelete2ForAdre(Map<String, Object> params);

	void insertExtrHndlMttrResvTgtRecsForAdre(Map<String, Object> params);

	void insertExtrHndlMttrResvTgtForAdre(Map<String, Object> params);

	void insertExtrHndlMttrResvTgt2ForAdre(Map<String, Object> params);

	void insertExtrHndlMttrResvTgtRecs2ForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpTgtrIdForAdre(Map<String, Object> params);

	void insertCuTgtrHisForAdre(Map<String, Object> params);

	void insertCuTgtrRecsForAdre(Map<String, Object> params);

	void updateCuTgtrHisForAdre(Map<String, Object> params);

	void updateCuTgtrHisInfoForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpVcnTgtrIdForAdre(Map<String, Object> params);

	//void insertVcnTgtrBsc(Map<String, Object> params);

	void insertVcnTgtrChgRecsForAdre(Map<String, Object> params);

	void updateVcnTgtrBscForAdre(Map<String, Object> params);

	void updateVcnTgtrBscInfoForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpSpsrTgtrIdForAdre(Map<String, Object> params);

	void insertCuTgtrHisSpsrForAdre(Map<String, Object> params);

	void insertCuTgtrRecsSpsrForAdre(Map<String, Object> params);

	void updateCuTgtrHisSpsrForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpSpsrVcnTgtrIdForAdre(Map<String, Object> params);

	void insertVcnTgtrChgRecsSpsrForAdre(Map<String, Object> params);

	void updateVcnTgtrBscSpsrForAdre(Map<String, Object> params);

	void updateMbrClcoRltn2ForAdre(Map<String, Object> params);

	void insertMbrClcoRltnChgRecs3ForAdre(Map<String, Object> params);

	void updateMbrBsplHisForAdre(Map<String, Object> params);

	void updateMbrAddInfDtl2ForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpInfoForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpRegistForAdre(Map<String, Object> params);

	void insertExtrHndlMttrForAdre(Map<String, Object> params);

	void deleteMbrBsplHisForAdre(Map<String, Object> params);

	void insertMbrSpfnSyntInfBscForAdre(Map<String, Object> params);

	void updateMbrSpfnSyntInfBscForAdre(Map<String, Object> params);

	void insertMbrSpfnSyntInfBscSpsrForAdre(Map<String, Object> params);

	void updateMbrSpfnSyntInfBscSpsrForAdre(Map<String, Object> params);

	List<BatchMemberUploadAdvanceResvModel> selectClcoAempAdreBlkRegTempRegistWithCapa(Map<String, Object> params);

	List<Map<String, Object>> selectPkgTyItmDtlBasic(Integer pkgTyId);

	void updateClcoAempAdreBlkRegTmpCapaError(BatchMemberUploadAdvanceResvModel aemp);

	void insertAempResvForAdre(Map<String, Object> params);

	void insertSpsrResvForAdre(Map<String, Object> param);

	void insertCustInfEmpRecsForTgtForAdre(Map<String, Object> params);

	void insertCustInfEmpRecsForAdre(Map<String, Object> params);

	void insertCustInfEmpRecsFmlyInitForAdre(Map<String, Object> params);

	void deleteClcoAempBlkRegTmpSpsrTgtrForAdre(Map<String, Object> params);

	void insertCustInfEmpRecsForSpsrForAdre(Map<String, Object> params);

    List<BatchUploadAdvanceResvSelectItemModel> selectPkgTyItmDtlItmIds(Map<String, Object> params);

	void updateClcoAempBlkRegTmpUpldStPrevForAdre(Map<String, Object> params);

	void updateClcoBlkRegTmpIdUpdYnForAdre(Map<String, Object> params);

	void updateClcoAempBlkRegTmpRegistWithBatch(Map<String, Object> params);

	List<ResvInfoModel> selectClcoAempAdreBlkRegTempResvInfo(BatchMemberUploadAdvanceResvModel aemp);

	List<ResvInfoModel> selectClcoAempAdreBlkRegTempSpsrResvInfo(BatchMemberUploadAdvanceResvModel aemp);
}
