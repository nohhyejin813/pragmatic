package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.NtrtPgmBscModel;
import com.gchc.ncu.bo.care.models.NtrtPgmDtlModel;
import com.gchc.ncu.bo.care.service.NutritionProgramService;
import com.gchc.ncu.bo.care.vo.NutritionProgramVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/nutrition/program")
@RequiredArgsConstructor
public class NutritionProgramController {

	private final NutritionProgramService programService;

	@GetMapping("/list")
	public List<NtrtPgmBscModel> list(@ModelAttribute NutritionProgramVo criteria) {
		return programService.getProgramList(criteria);
	}

	@GetMapping("/detail")
	public NtrtPgmBscModel detail(@ModelAttribute NtrtPgmBscModel criteria) {
		return programService.getProgramDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid NtrtPgmBscModel model) {
		programService.saveProgram(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<NtrtPgmBscModel> list) {
		programService.deleteProgram(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/mission/list")
	public List<NtrtPgmDtlModel> missionList(@ModelAttribute NutritionProgramVo criteria) {
		return programService.getProgramMissionList(criteria);
	}

	@GetMapping("/mission/detail")
	public NtrtPgmDtlModel missionDetail(@ModelAttribute NtrtPgmDtlModel criteria) {
		return programService.getProgramMissionDetail(criteria);
	}

	@PostMapping("/mission/save")
	public RestResult<?> saveMission(@RequestBody @Valid NtrtPgmDtlModel model) {
		programService.saveProgramMission(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/mission/delete")
	public RestResult<?> deleteMission(@RequestBody List<NtrtPgmDtlModel> list) {
		programService.deleteProgramMission(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
