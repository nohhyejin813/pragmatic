package com.gchc.ncu.bo.admin.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gchc.ncu.bo.assessment.models.SatisfactionDegreeModel;
import com.gchc.ncu.bo.comm.models.NcuPageableVo;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AdminModel extends NcuPageableVo {

//	private int			clcoSvcTyCd; 	// 기관타입코드
//	private String		clcoSvcTyNm;	// 기관타입이름
//	private int			totalReservationValue; // 에버헬스 전체값
//	private double		emptyResrESRVATION_VALUE;
//
	private int grdSpCd;
	private String grdSpNm;
	private int clcoSvcTyCd;
	private String clcoSvcTyNm;
	private int totalReservationValue;
	private int emptyResrvationValue;
	private int emptyResrvationRate;
	private int reservationCompleteValue;
	private int reservationCompleteRate;
	private int reservationFinalizationValue;
	private int reservationFinalizationRate;
	private int reservationFixeNoCheckedValue;
	private int reservationFixeNoCheckedRate;
	private int checkupCompleteValue;
	private int checkupCompleteRate;
	private int resultNotInsertedValue;
	private int empTotalReservationValue;
	private int empEmptyResrvationValue;
	private int empEmptyResrvationRate;
	private int empReservationCompleteValue;
	private int empReservationCompleteRate;
	private int empCheckupCompleteValue;
	private int empCheckupCompleteRate;


//	   CLCO_SVC_TY_CD
//       ,  CLCO_SVC_TY_NM
//       , TOTAL_RESERVATION_VALUE
//       , EMPTY_RESRVATION_VALUE /*미예약*/
//       , EMPTY_RESRVATION_RATE
//       , Reservation_Complete_Value /*예약완료*/
//       , Reservation_Complete_RATE
//       , CHECKUP_COMPLETE_VALUE /* 검진완료 */
//       , CHECKUP_COMPLETE_RATE
//       , EMP_TOTAL_RESERVATION_VALUE
//       , EMP_EMPTY_RESRVATION_VALUE /*미예약*/
//       , EMP_EMPTY_RESRVATION_RATE
//       , EMP_Reservation_Complete_Value /*예약완료*/
//       , EMP_Reservation_Complete_RATE
//       , EMP_CHECKUP_COMPLETE_VALUE /* 검진완료 */
//       , EMP_CHECKUP_COMPLETE_RATE
}
