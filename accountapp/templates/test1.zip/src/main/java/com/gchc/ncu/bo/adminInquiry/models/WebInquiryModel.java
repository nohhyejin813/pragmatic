package com.gchc.ncu.bo.adminInquiry.models;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import com.gchc.ncu.bo.checkup.models.CategoryModel;

/**
 * @FileName : InquiryModel.java
 * @date : 2021. 9. 13
 * @author : gs_tehan
 * @프로그램 설명 : 1:1 문의 Model
 * @변경이력 :
 */
@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class WebInquiryModel extends UstraManagementBaseModel {

	@ApiModelProperty(value = "uid")
	private Integer uid;
	@ApiModelProperty(value = "1대1문의아이디")
	private Integer otoId;
//	@ApiModelProperty(value = "문의회원아이디")
//	private Integer inqyUid;
	@ApiModelProperty(value = "문의유형코드", example="INQY_TY_CD-14: 검진문의,15: 내정보,16: 공동인증서,17: 서비스,18: 오류/제안,19: 기타")
	private String inqyTyCd;
	@ApiModelProperty(value = "문의유형코드명")
	private String inqyTyNm;
	@ApiModelProperty(value = "문의제목")
	private String inqyTitl;
	@ApiModelProperty(value = "문의내용")
	private String inqyCont;
	@ApiModelProperty(value = "문의처리상태코드")
	private String inqyPrcsStCd;
	@ApiModelProperty(value = "질문 첨부파일")
	private String atchFiles;

	@ApiModelProperty(value = "답변 아이디")
	private Integer answId;
	@ApiModelProperty(value = "담당자아이디")
	private Integer chrgrId;
	@ApiModelProperty(value = "담당자명")
	private String chrgrNm;
	@ApiModelProperty(value = "답변내용")
	private String answCont;
	@ApiModelProperty(value = "답변 최초등록일시")
	private String answrFrstRegDtm;

	// 2022-02-23 첨부파일, 이미지파일 구분 작업
	@ApiModelProperty(value = "답변 첨부파일아이디")
	private Integer answAtchFileId;
	@ApiModelProperty(value = "답변 첨부파일")
	private String answAtchFiles;
	@ApiModelProperty(value = "답변 첨부파일이름")
	private String answAtchFilesNm;
	@ApiModelProperty(value = "답변 첨부파일 그룹아이디")
	private String answAtchFilesGrpId;
	@ApiModelProperty(value = "답변 첨부파일아이디")
	private Integer answAtchImgFileId;
	@ApiModelProperty(value = "답변 첨부이미지파일")
	private String answAtchImgFiles;


	//HMS 추가사용정보
	@ApiModelProperty(value = "작성자명")
	private String nm;

	@ApiModelProperty(value = "문의상세코드", example="INQY_DTL_CD-11:가입 문의")
	private String inqyDtlCd;
	@ApiModelProperty(value = "문의상세코드명")
	private String inqyDtlNm;

	// 비회원 문의내역등록 관련 추가 정보 20211110
	@ApiModelProperty(value = "이메일주소")
	private String emlAdr;
	@ApiModelProperty(value = "휴대전화번호")
	private String mblNo;
	@ApiModelProperty(value = "생년월일")
	private String brdt;
	@ApiModelProperty(value = "성별코드")
	private String sexCd;

	@ApiModelProperty(value = "최초등록자이름")
	private String frstRegrNm;
	@ApiModelProperty(value = "최종수정자이름")
	private String lastUpdrNm;
	@ApiModelProperty(value = "최초등록자아이디")
	private String frstRegrId;
	@ApiModelProperty(value = "최종수정자아이디")
	private String lastUpdrId;
	@ApiModelProperty(value = "회사명")
	private String clcoNm;
	@ApiModelProperty(value = "최초등록자유형코드")
	private String frstRegrTyCd;
	@ApiModelProperty(value = "수정자등록유형코드")
	private String lastUpdrTyCd;
}