package com.gchc.ncu.bo.batchupload.models;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gchc.ncu.bo.comm.models.NcuModel;


/**
 * @FileName : BatchAdvanceResvExcelModel.java
 * @date : 2022. 06. 10
 * @author : 이광희
 * @프로그램 설명 : 선예약 일괄업로드 Service
 * @변경이력 :
 */

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchAdvanceResvExcelModel extends NcuModel {

	private Integer clcoId;
	private String yr;
	private Integer aempRegSeq;

	/*임직원-필수정보*/
	private String clcoCode; 		//고객사코드
	private String aempNm;			//임직원이름
	private String corpSpfnVal;		//임직원회사지원금
	private String aempCuGrdNm;		//임직원등급
	private String aempVcnGrdNm;		//임직원등급
	private String aempBrdt;		//임직원생년월일
	private String mblNo;			//임직원핸드폰번호


	/*임직원-선예약정보*/
	private String cuiNm;			//임직원검진기관명
	private String pkgNm;			//임직원패키지명
	private String tn1ResvApplDt;		//임직원예약신청일1차
	private String tn1ResvTmcRngVal;	//임직원예약신청시간1차
	private String tn2ResvApplDt;		//임직원예약신청일2차
	private String tn2ResvTmcRngVal;	//임직원예약신청시간2차
	private String pkgTyNm;			//임직원패키지항목명


	/*임직원-부가정보*/
	private String emlAdr;			//임직원이메일
	private String excuYn;			//임원여부(Y/N)
	private String nhicSuptTgtYn;	//건강보험공단지원대상여부(Y/N)
	private String spcuTgtYn;		//특수검진대상여부(Y/N)
	private String extrMttrNm1;		//특수물질(1차)
	private String extrMttrNm2;		//특수물질(2차)
	private String deptNm1;			//부서1
	private String deptNm2;			//부서2
	private String deptNm3;			//부서3
	private String jbgdNm;			//직급
	private String aempId;			//사번
	private String wrplTlno;		//직장전화
	private String wrplZpcd;
	private String wrplBscAdr;
	private String wrplDtlAdr;
	private String hsTlno;
	private String hsZpcd;
	private String hsBscAdr;
	private String hsDtlAdr;
	private String encmDt;			//입사일


	/*가족-기본정보*/
	private String spsrNm;			//가족이름
	private String spsrCuGrdNm;		//가족등급
	private String spsrVcnGrdNm;		//가족등급
	private String spsrBrdt;		//가족생년월일
	private String spsrCorpSpfn;	//가족회사지원금
	private String spsrNo;			//가족연락처
	private String spsrCmt;			//가족비고


	/*가족-선예약정보*/
	private String spsrCuiNm;		//가족검진센터
	private String spsrPkgNm;		//가족선택패키지명
	private String tn1SpsrResvApplDt;		//임직원예약신청일1차
	private String tn1SpsrResvTmcRngVal;	//임직원예약신청시간1차
	private String tn2SpsrResvApplDt;		//임직원예약신청일2차
	private String tn2SpsrResvTmcRngVal;	//임직원예약신청시간2차
	private String spsrPkgTyNm;


	/*임직원-기등록정보*/
	private String oldAempNm;
	private String oldAempId;
	private String oldAempBrdt;
	private String oldAempSexCd;


	private String BsplNm;			//사업장
	private String upldErrVal;		//에러코드

	List<BatchUploadAdvanceResvSelectItemModel> slctItmList;

	List<BatchUploadAdvanceResvSelectItemModel> spsrSlctItmList;

	public String getSlctItmString(String examKdCd) {

		if( CollectionUtils.isEmpty(slctItmList) )
			return "";
		return slctItmList.stream().filter(itm->itm.getExamKdCd().equals(examKdCd)).map(itm->itm.getExamItmNm()).collect(Collectors.joining(","));
	}

	public String getSpsrSlctItmString(String examKdCd) {

		if( CollectionUtils.isEmpty(spsrSlctItmList) )
			return "";
		return spsrSlctItmList.stream().filter(itm->itm.getExamKdCd().equals(examKdCd)).map(itm->itm.getExamItmNm()).collect(Collectors.joining(","));
	}

}
