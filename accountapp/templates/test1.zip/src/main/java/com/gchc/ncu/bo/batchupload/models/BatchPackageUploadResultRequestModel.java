package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuPageableVo;

@Getter
@Setter
public class BatchPackageUploadResultRequestModel extends NcuPageableVo {

	Integer clcoId;

	Integer yr;

	Integer cuiId;

	Integer mngrId;

	String state;

	Integer xclShtNo;
}
