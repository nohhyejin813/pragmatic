package com.gchc.ncu.bo.batchupload.utils;

import com.gchc.ncu.bo.checkupinst.vo.CapaVo;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@UtilityClass
public class BatchCapaUtils {

    public boolean isClose(List<CapaVo> capaList, Integer itmId, String tmcRngCd) {

        return capaList.stream()
                .anyMatch(each->each.getItmId() != null &&
                        each.getItmId().equals(itmId) &&
                        ("12".equals(tmcRngCd) ? each.getCapaAm() <= 0 : each.getCapaPm() <= 0));
    }

    public boolean isClose(List<CapaVo> capaList, String capaTyCd, String tmcRngCd) {

        return capaList.stream()
                .anyMatch(each-> StringUtils.isNotEmpty(each.getCapaTyCd()) &&
                        each.getCapaTyCd().equals(capaTyCd) &&
                        ("12".equals(tmcRngCd) ? each.getCapaAm() <= 0 : each.getCapaPm() <= 0));
    }
}
