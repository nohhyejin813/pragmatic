package com.gchc.ncu.bo.care.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.management.models.UstraFileModel;

import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.models.ActPgmBscModel;
import com.gchc.ncu.bo.care.models.CareCodeModel;
import com.gchc.ncu.bo.care.models.CareDssCdModel;
import com.gchc.ncu.bo.care.models.DssLibBscModel;
import com.gchc.ncu.bo.care.models.DwCnntScwdDatBscModel;
import com.gchc.ncu.bo.care.models.HospMdspDeptDtlModel;
import com.gchc.ncu.bo.care.models.NtrtMsnBscModel;
import com.gchc.ncu.bo.care.models.NtrtPgmBscModel;
import com.gchc.ncu.bo.care.models.PoisTyBscModel;
import com.gchc.ncu.bo.care.repository.CareCommonRepository;
import com.gchc.ncu.bo.care.vo.ExcelDwldLogVo;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogService;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;

@Service
@RequiredArgsConstructor
public class CareCommonService {

	private final XlsDownloadRecordService xlsDownloadRecordServicce;
	private final UsrInnfActiLogService usrInnfActiLogService;

	private final CareCommonRepository careCommonRepository;

	public List<CareCodeModel> getCodeList() {
		return careCommonRepository.getCodeList();
	}

	public List<CareDssCdModel> getDiseaseList(CareDssCdModel model) {
		return careCommonRepository.selectDiseaseList(model);
	}

	public List<ActMsnBscModel> getActivityMissionList() {
		return careCommonRepository.selectActivityMissionList();
	}

	public List<ActPgmBscModel> getActivityProgramList() {
		return careCommonRepository.selectActivityProgramList();
	}

	public List<NtrtMsnBscModel> getNutritionMissionList() {
		return careCommonRepository.selectNutritionMissionList();
	}

	public List<NtrtPgmBscModel> getNutritionProgramList() {
		return careCommonRepository.selectNutritionProgramList();
	}

	public List<PoisTyBscModel> getAddictionTypeList() {
		return careCommonRepository.selectAddictionTypeList();
	}

	public List<HospMdspDeptDtlModel> getMdspDeptList() {
		return careCommonRepository.selectMdspDeptList();
	}

	public List<DssLibBscModel> getDiseaseLibList(String dssNm) {
		DssLibBscModel model = new DssLibBscModel();
		model.setDssNm(dssNm);

		return careCommonRepository.selectDiseaseLibList(model);
	}

	public List<DwCnntScwdDatBscModel> getContentCategory() {
		return careCommonRepository.selectContentCategory();
	}

	public List<DwCnntScwdDatBscModel> getContentList(DwCnntScwdDatBscModel model) {
		return careCommonRepository.selectContentList(model);
	}

	public List<Map<String, Object>> getTermsList(Map<String, Object> model) {
		return careCommonRepository.selectTermsList(model);
	}

	public List<Map<String, Object>> getSurveyList(Map<String, Object> model) {
		return careCommonRepository.selectSurveyList(model);
	}

	public List<Map<String, Object>> getClientList(Map<String, Object> model) {
		return careCommonRepository.selectClientList(model);
	}

	public void setExcelDownloadLog(ExcelDwldLogVo criteria) {
		UsrInnfActiLogModel innfActirecord = new UsrInnfActiLogModel();

		innfActirecord.setActiLogDvCd("40");
		innfActirecord.setPfrmNm(criteria.getDwldInfo().get("dwldPageNm") + " - 엑셀 다운로드");
		innfActirecord.setMenuNm(criteria.getDwldInfo().get("dwldPagePath"));
		innfActirecord.setPfrmCont(criteria.getDwldInfo().get("dwldPageNm") + " - 엑셀 다운로드");
		innfActirecord.setCustNm(criteria.getDwldInfo().get("dwldAccess"));

		usrInnfActiLogService.insert(innfActirecord);

		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm(criteria.getDwldInfo().get("dwldPageNm"));
		record.setDwldPageUrl(criteria.getDwldInfo().get("dwldPageUrl"));
		record.setDwldCont(criteria.getDwldInfo().get("dwldContents"));
		record.setDwldMemo(criteria.getDwldInfo().get("dwldMemo"));
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(Integer.parseInt(criteria.getDwldInfo().get("dwldCount")));
		record.setDwldRsnCd(criteria.getDwldInfo().get("dwldRsnCd"));
		record.setCustNm(criteria.getDwldInfo().get("dwldAccess"));
		record.setDwldActiCont(criteria.getDwldInfo().get("dwldPageNm") + " 엑셀 다운로드");

		xlsDownloadRecordServicce.insert(record);
	}

	public String copyUploadedFile(String fileId) {
		Map<String, Object> params = new HashedMap<>();

		params.put("fileId", null);
		params.put("targetFileId", fileId);

		careCommonRepository.insertUploadedFile(params);

		return params.get("fileId").toString();
	}

	public void updateImgFrmwFileId(UstraFileModel model) {
		if(model != null) {
			careCommonRepository.updateUploadedFile(model);
		}
	}

	public void removeImgFrmwFileId(Map<String, Object> model) {
		careCommonRepository.deleteUploadedFile(model);
	}

	public List<UstraFileModel> selectUploadedFile(UstraFileModel model) {
		return careCommonRepository.selectUploadedFile(model);
	}

	public void insertUploadedFileNoSQ(UstraFileModel ustraFileMode) {
		careCommonRepository.insertUploadedFileNoSQ(ustraFileMode);
	}


}
