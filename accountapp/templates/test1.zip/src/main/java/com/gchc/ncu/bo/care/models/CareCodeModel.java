package com.gchc.ncu.bo.care.models;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CareCodeModel extends UstraManagementBaseModel {

	private String grpCd;
	private String grpNm;
	private String dtlCd;
	private String cdNm;
	private String srtNo;
	private String etc1;
	private String etc2;
	private String etc3;
	private String etc4;
	private String etc5;

}
