package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.microsoft.sqlserver.jdbc.StringUtils;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.ChrcBscModel;
import com.gchc.ncu.bo.care.models.ChrcDtlModel;
import com.gchc.ncu.bo.care.repository.CsttMateRepository;
import com.gchc.ncu.bo.care.vo.CsttMateVo;

@Service
@RequiredArgsConstructor
public class CsttMateService {

	private final CsttMateRepository csttMateRepository;

	public List<ChrcBscModel> getCsttMateBsc(CsttMateVo criteria) {
		return csttMateRepository.selectCsttMateBsc(criteria);
	}

	public List<ChrcDtlModel> getCsttMateDtl(CsttMateVo criteria) {
		return csttMateRepository.selectCsttMateDtl(criteria);
	}

	public void updateCsttMateBsc(ChrcBscModel model) {
		csttMateRepository.updateCsttMateBsc(model);
	}

	public void saveCsttMateDtl(ChrcDtlModel model) {
		if(StringUtils.isEmpty(model.getChrcDtlId())) {
			csttMateRepository.insertCsttMateDtl(model);
		} else {
			csttMateRepository.updateCsttMateDtl(model);
		}
	}

	public void deleteCsttMateDtl(List<ChrcDtlModel> list) {
		for(ChrcDtlModel model : list) {
			csttMateRepository.deleteCsttMateDtl(model);
		}
	}


}
