package com.gchc.ncu.bo.challenge.auth.repository;

import com.gchc.ncu.bo.challenge.auth.models.AuthBoardModel;
import com.gchc.ncu.bo.challenge.auth.models.AuthBoardSearchModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/***
 * 고객사 신청현황 목록
 * @FileName : ChronicStatusRepository.java
 * @date : 2022. 11. 07
 * @author : gcjclee2
 * @프로그램 설명 :
 */

@Mapper
public interface AuthBoardRepository {

	// 카테고리목록
	List<AuthBoardModel> getCategoryList(AuthBoardModel model);
	// 차수목록
	List<AuthBoardModel> getOnoList(AuthBoardModel model);
	// 인증목록
	List<AuthBoardModel> getAuthBrdList(AuthBoardSearchModel model);
	// 모아보기
	List<AuthBoardModel> getAuthListPopup(AuthBoardSearchModel model);
	// 상세보기
	AuthBoardModel getAuthBrdDetail(AuthBoardSearchModel model);

	int addAuthBrdReply(AuthBoardModel model);

	List<AuthBoardModel> getAuthBrdReplyList(AuthBoardModel model);

	int deleteAuthBrdReply(AuthBoardModel model);

	List<AuthBoardModel> getDclList(AuthBoardModel model);

	int updateHidden(Map<String, Object> paramMap);

	int updateAuthority(Map<String, Object> paramMap);
	int updateCertiCount(Map<String, Object> paramMap);
	int updateRepair(Map<String, Object> paramMap);
	int getCategoryCount(AuthBoardModel model);

}
