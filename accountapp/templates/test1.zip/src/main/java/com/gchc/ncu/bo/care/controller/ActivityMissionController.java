package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.service.ActivityMissionService;
import com.gchc.ncu.bo.care.vo.ActivityMissionVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/bo/care/activity/mission")
@RequiredArgsConstructor
@Slf4j
public class ActivityMissionController {

	private final ActivityMissionService missionService;

	@GetMapping("/list")
	public List<ActMsnBscModel> list(@ModelAttribute ActivityMissionVo criteria) {
		LOGGER.debug("care > activity > mission > getList");

		return missionService.getActivityMissionList(criteria);
	}

	@GetMapping("/detail")
	public ActMsnBscModel detail(@ModelAttribute ActMsnBscModel criteria) {
		LOGGER.debug("care > activity > mission > getDetail");

		return missionService.getActivityMissionDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid ActMsnBscModel model) {
		missionService.saveActivityMissionBase(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<ActMsnBscModel> list) {
		missionService.deleteActivityMissionBase(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
