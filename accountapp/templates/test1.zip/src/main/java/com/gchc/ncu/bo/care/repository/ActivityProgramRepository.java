package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.ActPgmBscModel;
import com.gchc.ncu.bo.care.models.ActPgmDtlModel;
import com.gchc.ncu.bo.care.vo.ActivityProgramVo;

@Mapper
public interface ActivityProgramRepository {

	List<ActPgmBscModel> selectProgramList(ActivityProgramVo criteria);
	ActPgmBscModel selectProgramDetail(ActPgmBscModel criteria);
	void insertProgram(ActPgmBscModel model);
	void updateProgram(ActPgmBscModel model);
	void deleteProgram(ActPgmBscModel model);

	List<ActPgmDtlModel> selectProgramMissionList(ActivityProgramVo criteria);
	ActPgmDtlModel selectProgramMissionDetail(ActPgmDtlModel criteria);
	void insertProgramMission(ActPgmDtlModel model);
	void updateProgramMission(ActPgmDtlModel model);
	void deleteProgramMission(ActPgmDtlModel model);

	void deleteProgramMissionByActPgmId(int actPgmId);

}
