package com.gchc.ncu.bo.batchupload.comm;

import java.util.Map;

public class SearchMapContextHolder {

	private static final ThreadLocal<Map<String, Object>> contextHolder = new ThreadLocal<Map<String, Object>>();

	public static Map<String, Object> get() {

		return contextHolder.get();
	}

	public static void set(Map<String, Object> data) {

		contextHolder.set(data);
	}

	public static void clear() {

		if( get() != null )
			contextHolder.remove();
	}
}
