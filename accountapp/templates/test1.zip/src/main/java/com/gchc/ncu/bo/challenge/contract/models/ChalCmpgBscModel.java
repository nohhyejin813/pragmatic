package com.gchc.ncu.bo.challenge.contract.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

@Data
@EqualsAndHashCode(callSuper=false)
public class ChalCmpgBscModel extends UstraManagementBaseModel {

	private Integer cmpgId;
	@NotNull(message = "캠페인계약ID는 필수값입니다.")
	private Integer cmpgCtraId;
	@NotNull(message = "캠페인종류는 필수값입니다.")
	private String cmpgKdCd;
	private Integer ono;
	private String pgrsSrtDt;
	private String pgrsEndDt;
	private Integer pgrsDays;
	private String cmpgStCd;
	private String cmpgStNm;
	private Integer tgtrCnt;
	private Integer ptcprCnt;
	private Integer ptcprCmplPcnt;
	private Integer ptcprAvgStpCnt;
	private Double ptcprPgrsRt;
	private Double ptcprCmplRt;
	private String cmplDt;
	private Integer useYn;
	private Integer teamExpoYn;

	private String rowStatus;

	private String cmpgNm;
	private Integer clcoId;
	private String clcoNm;
	private String bsplNm;
	private Integer goalStpCnt;
	private String cmpnWayCd;
	private String titl;
	private String prtcTgtCont;
	private String prtcMthCont;
	private String pctnCont;
	private Integer ptcprTeamCnt;
	private Integer totTeamCnt;
	private Integer thmId;
	private String athoCrteTm;
	private Integer goalAthoCnt;
	private Integer srtBfGuidYn;
	private Integer srtBfGuidCrteDays;
	private String chalCatCd;
	private String chalCatNm;
	private String chalThmNm;

	private String athoMthExFileId1;
	private String athoMthExFileId2;
	private String noauExFileId1;
	private String noauExFileId2;
	private String chalGuidWrdsCont;
	private Integer athoFileCnt;
	private Integer noauFileCnt;
	private String cnntRegId1;
	private String cnntRegId2;
	private String cnntRegId3;
	private String cnntRegId4;
	private String cnntRegNm1;
	private String cnntRegNm2;
	private String cnntRegNm3;
	private String cnntRegNm4;
	private Integer cnntRegCnt;


	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;
	private String frstNm;
	private String lastNm;
	private String[] cmpgIdList;
	private String cmpgIds;

	private String[] cmpgCtraIdList;
	private String cmpgCtraIds;

	private String ctraSrtDt;
	private String ctraEndDt;




}
