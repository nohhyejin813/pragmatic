package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchMemberUploadReentryDownloadRequestModel {

	private String yr;

	private String clcoId;

	private String mngrId;

	private String fileGrpId;

	private String fileId;

	private int fileNo;

	private String resultFlag;	// 엑셀 업로드결과 구분 (0:전체, 1:성공, 2:에러)

	private String excelFileName;
}
