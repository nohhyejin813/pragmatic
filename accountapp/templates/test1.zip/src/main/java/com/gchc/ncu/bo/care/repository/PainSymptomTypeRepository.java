package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.NrsnClsfBscModel;
import com.gchc.ncu.bo.care.vo.PainSymptomTypeVo;

@Mapper
public interface PainSymptomTypeRepository {

	List<NrsnClsfBscModel> selectSymptomTypeList(PainSymptomTypeVo criteria);
	NrsnClsfBscModel selectSymptomTypeDetail(NrsnClsfBscModel criteria);
	void insertSymptomType(NrsnClsfBscModel model);
	void updateSymptomType(NrsnClsfBscModel model);
	void deleteSymptomType(NrsnClsfBscModel model);
	int selectUsedSymptomTypeCount(NrsnClsfBscModel model);

}
