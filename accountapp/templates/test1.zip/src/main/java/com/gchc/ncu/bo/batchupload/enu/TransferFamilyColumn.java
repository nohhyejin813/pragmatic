package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum TransferFamilyColumn implements BatchUploadColumn {

	AEMP_NM("임직원이름", "AempNm"),

	AEMP_ID("임직원사번", "AempId"),

	FMLY_NM1("가족1이름", "TnsfTgtFmlyNm1"),

	FMLY_BRDT1("가족1생년월일", "TnsfTgtFmlyBrdt1"),

	FMLY_NM2("가족2이름", "TnsfTgtFmlyNm2"),

	FMLY_BRDT2("가족2생년월일", "TnsfTgtFmlyBrdt2"),

	FMLY_NM3("가족3이름", "TnsfTgtFmlyNm3"),

	FMLY_BRDT3("가족3생년월일", "TnsfTgtFmlyBrdt3"),

	FMLY_NM4("가족4이름", "TnsfTgtFmlyNm4"),

	FMLY_BRDT4("가족4생년월일", "TnsfTgtFmlyBrdt4"),

	FMLY_NM5("가족5이름", "TnsfTgtFmlyNm5"),

	FMLY_BRDT5("가족5생년월일", "TnsfTgtFmlyBrdt5"),

	FMLY_NM6("가족6이름", "TnsfTgtFmlyNm6"),

	FMLY_BRDT6("가족6생년월일", "TnsfTgtFmlyBrdt6"),

	FMLY_NM7("가족7이름", "TnsfTgtFmlyNm7"),

	FMLY_BRDT7("가족7생년월일", "TnsfTgtFmlyBrdt7"),

	FMLY_NM8("가족8이름", "TnsfTgtFmlyNm8"),

	FMLY_BRDT8("가족8생년월일", "TnsfTgtFmlyBrdt8"),

	FMLY_NM9("가족9이름", "TnsfTgtFmlyNm9"),

	FMLY_BRDT9("가족9생년월일", "TnsfTgtFmlyBrdt9"),

	FMLY_NM10("가족10이름", "TnsfTgtFmlyNm10"),

	FMLY_BRDT10("가족10생년월일", "TnsfTgtFmlyBrdt10")

	;

	private String title;

	private String field;

	TransferFamilyColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
