package com.gchc.ncu.bo.batchupload.models;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchUploadCompanyContractModel extends UstraManagementBaseModel {
	/* T_CLCO_CTRA_HIS [헬스케어_고객사계약내역] */
	@ApiModelProperty(value="매니저아이디")
	private Integer usrId;
	@ApiModelProperty(value="고객사계약아이디")
	private Integer clcoCtraId;
	@ApiModelProperty(value="고객사아이디")
	private Integer clcoId;
	@ApiModelProperty(value="년도")
	private String yr;
	@ApiModelProperty(value="계약일자")
	private String ctraDt;
	@ApiModelProperty(value="계약시작일자")
	private String ctraSrtDt;
	@ApiModelProperty(value="계약종료일자")
	private String ctraEndDt;
	@ApiModelProperty(value="검진실시시작일자")
	private String cuImplSrtDt;
	@ApiModelProperty(value="검진실시종료일자")
	private String cuImplEndDt;
	@ApiModelProperty(value="예약시작일자")
	private String resvSrtDt;
	@ApiModelProperty(value="예약종료일자")
	private String resvEndDt;
	@ApiModelProperty(value="결과서비스여부")
	private Integer rsltSvcYn;
	@ApiModelProperty(value="증진서비스여부")
	private Integer incsSvcYn;
	@ApiModelProperty(value="추가지원금")
	private Integer addSpfn;
	@ApiModelProperty(value="건강보험공단차감여부")
	private Integer nhicSubtYn;
	@ApiModelProperty(value="패키지금액옵션구분코드")
	private String pkgAmtOptnDvCd;
	@ApiModelProperty(value="서비스수수료")
	private Integer svcFee;
	@ApiModelProperty(value="기타메모")
	private String etcMemo;
	@ApiModelProperty(value="서비스수수료종류코드")
	private String svcFeeKdCd;
	@ApiModelProperty(value="직원1명당수수료")
	private Integer empPer1Fee;
	@ApiModelProperty(value="임원1명당수수료")
	private Integer excuPer1Fee;
	@ApiModelProperty(value="고객사메모")
	private String clcoMemo;
	@ApiModelProperty(value="상위패키지선택가능여부")
	private Integer uprPkgSlctPsblYn;
	@ApiModelProperty(value="결과동의팝업노출여부")
	private Integer rsltAgPpupExpoYn;
	@ApiModelProperty(value="건강습관평가필수진행여부")
	private Integer hraEsnPgrsYn;
	@ApiModelProperty(value="우울척도평가필수진행여부")
	private Integer dprsCritAsmEsnPgrsYn;
	@ApiModelProperty(value="미지원등급검진실시시작일자")
	private String unspGrdCuImplSrtDt;
	@ApiModelProperty(value="미지원등급검진실시종료일자")
	private String unspGrdCuImplEndDt;
	@ApiModelProperty(value="미지원등급검진예약시작일자")
	private String unspGrdCuResvSrtDt;
	@ApiModelProperty(value="미지원등급검진예약종료일자")
	private String unspGrdCuResvEndDt;
	@ApiModelProperty(value="특수검진옵션여부")
	private Integer spcuOptnYn;
	@ApiModelProperty(value="맞춤백신사용여부")
	private Integer cstmVcnUseYn;
	@ApiModelProperty(value="맞춤검진사용여부")
	private Integer cstmCuUseYn;
	@ApiModelProperty(value="건강습관평가사용여부")
	private Integer hraUseYn;
	@ApiModelProperty(value="우울척도사용여부")
	private Integer dprsCritUseYn;
	@ApiModelProperty(value="직무스트레스검사사용여부")
	private Integer jbdStrsExamUseYn;
	@ApiModelProperty(value="직무스트레스검사필수여부")
	private Integer jbdStrsExamEsnYn;
	@ApiModelProperty(value="뇌심혈관계검사사용여부")
	private Integer bcsExamUseYn;
	@ApiModelProperty(value="뇌심혈관계검사필수여부")
	private Integer bcsExamEsnYn;
	@ApiModelProperty(value="마음검진사용여부")
	private Integer mncuUseYn;
	@ApiModelProperty(value="지원금양도구분코드")
	private String spfnTnsfDvCd;
	@ApiModelProperty(value="양도대상자선택범위코드")
	private String tnsfTgtrSlctRngCd;
	@ApiModelProperty(value="보건관리자동의여부")
	private Integer hlcrMngrAgrYn;
	@ApiModelProperty(value="마음검진심리상담소선택여부")
	private Integer mncuPccSlctYn;
	@ApiModelProperty(value="가족검진사용여부")
	private Integer fmcuUseYn;
	@ApiModelProperty(value="자동연장적용여부")
	private Integer autoExtnAplcYn;
	@ApiModelProperty(value="계약담당자이름")
	private String ctraChrgrNm;
	@ApiModelProperty(value="사후관리대사증후군포함여부")
	private Integer epfMngMtsyInclYn;
	@ApiModelProperty(value="사후관리뇌심혈관계상담여부")
	private Integer epfMngBcsCnslYn;
	@ApiModelProperty(value="사후관리암예방그룹여부")
	private Integer epfMngCncrPvntGrpYn;
	@ApiModelProperty(value="임원검진사용여부")
	private Integer excuCuUseYn;
	@ApiModelProperty(value="특수검진사용여부")
	private Integer spcuUseYn;
	@ApiModelProperty(value="특수물질내용")
	private String extrMttrCont;
	@ApiModelProperty(value="사후관리대사증후군횟수")
	private Integer epfMngMtsyCnt;
	@ApiModelProperty(value="마음검진필수여부")
	private Integer mncuEsnYn;
	@ApiModelProperty(value="마음검진선택여부")
	private Integer mncuSlctYn;
	@ApiModelProperty(value="추천백신사용여부")
	private Integer rcmnVcnUseYn;
	@ApiModelProperty(value="지원금분할사용여부")
	private Integer spfnSpltUseYn;
	@ApiModelProperty(value="분할지원금")
	private Integer spltSpfn;
	@ApiModelProperty(value="가족분할지원금")
	private Integer fmlySpltSpfn;
	@ApiModelProperty(value="분할대상사용자직접등록노출")
	private Integer spltTgtUsrDrcRegExpoYn;
	@ApiModelProperty(value="건강평가보고서이메일발송기능사용여부")
	private Integer harEmlSndFncUseYn;
	@ApiModelProperty(value="사후관리서비스유선상담제외여부")
	private Integer epfMngSvcWirCnslExcsYn;
	@ApiModelProperty(value="본인지원금선택여부")
	private Integer selfSpfnSlctYn;
	@ApiModelProperty(value="유소견관리메뉴노출여부")
	private Integer abnfMngMenuExpoYn;
	@ApiModelProperty(value="가족검진수수료")
	private Integer fmcuFee;
	@ApiModelProperty(value="배우자서비스수수료")
	private Integer spsrSvcFee;
	@ApiModelProperty(value="퇴직자서비스수수료")
	private Integer retrSvcFee;
	@ApiModelProperty(value="임직원서비스수수료")
	private Integer aempSvcFee;
	@ApiModelProperty(value="패키지서비스수수료여부")
	private Integer pkgSvcFeeYn;
	@ApiModelProperty(value="검진기관수수료여부")
	private Integer cuiFeeYn;
	@ApiModelProperty(value="연회비사용여부")
	private Integer afeeUseYn;
	@ApiModelProperty(value="미지원등급검진실시기간동일여부")
	private Integer unspGrdCuImplPridSameYn;
	@ApiModelProperty(value="특수검진분리예약사용여부")
	private Integer spcuSprtResvUseYn;
	@ApiModelProperty(value="지원금이월사용여부")
	private Integer spfnCyfwUseYn;
	@ApiModelProperty(value="생체나이서비스신청여부")
	private Integer lvbdAgSvcApplYn;
	@ApiModelProperty(value="정산유형코드")
	private String exclTyCd;
	@ApiModelProperty(value="정산월")
	private String exclMm;
	@ApiModelProperty(value="정산시기구분코드")
	private String exclTimDvCd;
	@ApiModelProperty(value="정산메모")
	private String exclMemo;
	@ApiModelProperty(value="계약메모")
	private String ctraMemo;
	@ApiModelProperty(value="예약종료안내팝업노출여부")
	private Integer resvEndGuidPpupExpoYn;
	@ApiModelProperty(value="예약종료일별도사용여부")
	private Integer resvEndDdSuseUseYn;
	@ApiModelProperty(value="예약종료팝업노출세팅명")
	private String resvEndPpupExpoStngNm;
	@ApiModelProperty(value="군분류적용여부")
	private Integer grclAplcYn;
	@ApiModelProperty(value="삭제여부")
	private Integer delYn;

	@ApiModelProperty(value="최초등록일시")
	private String frstRegDtm;
	@ApiModelProperty(value="최초등록자유형코드")
	private String frstRegrTyCd;
	@ApiModelProperty(value="최초등록자 ID")
	private String frstRegrId;
	@ApiModelProperty(value="최종수정일시")
	private String lastUpdDtm;
	@ApiModelProperty(value="최종수정자유형코드")
	private String lastUpdrTyCd;
	@ApiModelProperty(value="최종수정자 ID")
	private String lastUpdrId;

	/* T_EASY_CLCO_CTRA_HIS [헬스케어_검진이지고객사계약내역] */
	// private Integer clcoCtraId;
	// private Integer clcoId;
	// private Integer yr;
	@ApiModelProperty(value="사업장기능사용여부")
	private Integer bsplFncUseYn;
	@ApiModelProperty(value="사업장기능전년도사용여부 CUSTOM COLUMN")
	private Integer bsplFncPrvYrUseYn;
	@ApiModelProperty(value="가족지원여부")
	private Integer fmlySuptYn;
	@ApiModelProperty(value="설정저장단계")
	private Integer stupStrgStp;
	// private String etcMemo;
	@ApiModelProperty(value="건강보험공단대상여부")
	private Integer nhicTgtYn;
	@ApiModelProperty(value="검진기관더보기세팅여부")
	private Integer cuiMrvwStngYn;
	@ApiModelProperty(value="엑셀업로드여부")
	private Integer xclUpldYn;
	@ApiModelProperty(value="법인카드번호")
	private String corpCardNo;
	@ApiModelProperty(value="검사대상자인원수")
	private Integer cuTgtrPcnt;
	@ApiModelProperty(value="출장검진여부")
	private Integer bstrCuYn;
	@ApiModelProperty(value="가족추가가능여부")
	private Integer fmlyAddPsblYn;
}
