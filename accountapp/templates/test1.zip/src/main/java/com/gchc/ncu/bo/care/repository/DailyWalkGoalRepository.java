package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.models.GoalStpCntBscModel;
import com.gchc.ncu.bo.care.vo.DailyWalkGoalVo;

@Mapper
public interface DailyWalkGoalRepository {

	List<ActMsnBscModel> selectDailyWalkGoalList(DailyWalkGoalVo criteria);
	void saveDailyWalkGoal(GoalStpCntBscModel model);
	void deleteDailyWalkGoal(GoalStpCntBscModel model);

}
