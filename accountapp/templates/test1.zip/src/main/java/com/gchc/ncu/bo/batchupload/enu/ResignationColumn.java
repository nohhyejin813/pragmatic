package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum ResignationColumn implements BatchUploadColumn {

	CLCO_NM("고객사"		, "ClcoNm"		),
	AEMP_NM("이름"			, "AempNm"		),
	AEMP_ID("사번"			, "AempId"		);
	//Rsnt_Date("퇴사일"		,"RsntDate"	);
	String title;	// 제목
	String field;	// 필드명

	ResignationColumn(String title, String field) {
		this.title = title;
		this.field = field;
	}
}
