package com.gchc.ncu.bo.care.models;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class SrvyQstHisModel {


	private Integer srvyQstId;
	private Integer srvyQstThmAreaId;
	private String srvyQstCont;
	private String srvyAddDesc;
	private String qstAnswBscTyCd;
	private String qstAnswExtrTyCd;
	private Integer answMltiSlctPsblYn;
	private Integer allwPsblMxScr;
	private Integer qstExpoOrd;
	private Integer useYn;
	private String crasVal;
	private Integer answMltiSlctPsblQty;
	private Integer qstScrRt;
	private String chrnDssMealItmCd;
	private String lastUpdrId;
	private String qstNoExpoVal;

}
