package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.HthQizBscModel;
import com.gchc.ncu.bo.care.repository.HealthQuizRepository;
import com.gchc.ncu.bo.care.vo.HealthQuizVo;

@Service
@RequiredArgsConstructor
public class HealthQuizService {

	private final HealthQuizRepository repository;

	public List<HthQizBscModel> getHealthQuizList(HealthQuizVo in) {
		return repository.selectHealthQuizList(in);
	}

	public HthQizBscModel getHealthQizDetail(HealthQuizVo in) {
		return repository.selectHealthQizDetail(in);
	}

	public int saveQuiz(HthQizBscModel model) {
		int result = 0;

		if(model.getHthQizId() != null) {
			result = repository.updateHealthQuiz(model);
		} else {
			int overlap = 0;

			overlap = repository.selectOverlapDate(model);

			if(overlap > 0) {
				overlap = -1;
				return overlap;
			}

			result = repository.insertHealthQuiz(model);
		}

		return result;

	}

	@Transactional
	public void deleteHealthQuiz(List<HthQizBscModel> list) {
		if (list != null) {
			for (HthQizBscModel model : list) {
				repository.deleteHealthQuiz(model);
			}
		}
	}

}
