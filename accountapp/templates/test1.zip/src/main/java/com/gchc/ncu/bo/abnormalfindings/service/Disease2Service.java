package com.gchc.ncu.bo.abnormalfindings.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.gchc.common.model.GchcPaginationRequest.GchcOrder;
import com.gchc.ncu.bo.abnormalfindings.models.Disease2Model;
import com.gchc.ncu.bo.abnormalfindings.repository.Disease2Repository;
import com.gchc.ncu.bo.abnormalfindings.vo.Disease2Vo;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogService;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;
import com.gchc.ncu.bo.comm.util.GchcGridUtil;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;
import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.domains.PaginationRequest.Order;
import com.gsitm.ustra.java.data.domains.PaginationRequest.OrderDirection;
import com.gsitm.ustra.java.data.mybatis.pagination.domain.Paginator;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 유소견관리 > 검진결과:유소견관리(신)
 *
 * @since	2021.11.22
 * @author 	gs_tskwon@gchealthcare.com
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class Disease2Service {

	@Autowired
	private Disease2Repository disease2Repository;

	@Autowired
	private XlsDownloadRecordService xlsDownloadRecordService;

	@Autowired
	private UsrInnfActiLogService usrInnfActiLogService;

	private static final Map<Order, List<Order>> ORD_MAP_LIST = new HashMap<>();
	static {
		ORD_MAP_LIST.put(GchcOrder.of("frstRegDtm", OrderDirection.DESC), Arrays.asList(GchcOrder.of("FRST_REG_DTM", OrderDirection.DESC)));
	}

	/**
     * 유소견관리(신)  - 목록조회
     */
	public List<Disease2Model> getDisease2List(Disease2Vo model) {
		List<Disease2Model> dataList = new ArrayList<Disease2Model>();

		model.setOrderName(GchcGridUtil.getCamalToLarge("ROW_NUM", model.getOrderName()));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("model", model);
		paramMap.put("currentPage", model.getCurrentPage());
		paramMap.put("pageSize", model.getPageSize());
		paramMap.put("order", model.getOrderName());
		paramMap.put("orderDirection", model.getOrderDirection().toString());

		List<Disease2Model> list = disease2Repository.getDisease2List(paramMap);


		if(list.size() > 1 ) {
			UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
			usrInfomodel.setActiLogDvCd("40");	//로깅 유형
			usrInfomodel.setMenuNm("유소견 관리 > 유소견관리(신) ");	//메뉴명
			usrInfomodel.setPfrmNm("유소견관리(신) 목록 ");	//실행명
			usrInfomodel.setPfrmCont(list.get(0).getBsplNm()+" 고객사 유소견관리(신) 목록 조회");	//실행 내용
			usrInfomodel.setInnfVwCnt(list.get(0).totalItemCount.intValue());	//조회 건수
			if(list.size() == 1) {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid().toString());	//고객명
			}else {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid() + "등 " + list.size() +"건");	//고객명
			}
			usrInnfActiLogService.insert(usrInfomodel);
		}

		int count = list != null && list.size() > 0 ? list.get(0).getTotalItemCount() : 0;
		dataList = new PaginationList<Disease2Model>(list, new Paginator(model.getCurrentPage(), model.getPageSize(), count));

		if(list != null && list.size() > 0) {
			UstraMaskingUtils.maskTextFields(dataList);
		}


		return dataList;
	}

//  Local grid페이지 사용시
//	public List<Disease2Model> getDisease2List(Disease2Model model) {
//		List<Disease2Model> resultList = new ArrayList<Disease2Model>();
//		int currentPage = model.getCurrentPage();
//		model.setCurrentPage(0); // 전체목록 검색
//		List<Disease2Model> list = disease2Repository.getDisease2List(model);
//		int count = list.size() > 0 ? list.get(0).getTotalItemCount() : 0;
//
//		model.setCurrentPage(currentPage);
//		resultList = new PaginationList<Disease2Model>(list, new Paginator(model.getCurrentPage(), model.getPageSize(), count));
//	}

	public List<Disease2Model> getDisease2ListForExcel(Disease2Vo model) {
		List<Disease2Model>  dataList = disease2Repository.getDisease2ListForExcel(model);

		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm("유소견관리 > 검진결과:유소견관리(신) > 엑셀 다운로드");
		record.setDwldPageUrl(model.getDwldPageUrl());
		record.setDwldCont("No, 생성일, 고객명, 성별, 생일, 고객사명, 사번, 검진일, 뇌/심위험군, 검진결과, SBP, DBP, 혈당, TC, HDL, LDL, TGB, BMI, 신장, 체중, 허리둘레,  AST, ALT, rGTP");
		record.setDwldMemo(model.getDwldMemo()); // 메모
		record.setDwldRsnCd(model.getDwldRsnCd()); // 다운로드 사유 코드
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(dataList.size() ); //개인정보 Download 건수.
		record.setCustNm("UID : " + dataList.get(0).getUid() + "등  " + dataList.size() + "건"+"(고객사 : "+dataList.get(0).getClcoNm()+")");

		xlsDownloadRecordService.insert(record);

		return dataList;
	}
}
