package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.CmpgBscModel;
import com.gchc.ncu.bo.care.models.CmpgCmpnDtlModel;
import com.gchc.ncu.bo.care.models.CmpgCtraBscModel;
import com.gchc.ncu.bo.care.models.CmpgNtfcBscModel;
import com.gchc.ncu.bo.care.models.CmpgNtfcDtlModel;
import com.gchc.ncu.bo.care.models.CmpgTeamRecsModel;
import com.gchc.ncu.bo.care.models.MbrCmpgRecsModel;
import com.gchc.ncu.bo.care.repository.CareCampaignRepository;
import com.gchc.ncu.bo.care.vo.CareCampaignVo;

@Service
@RequiredArgsConstructor
public class CareCampaignService {

	private final CareCampaignRepository campaignRepository;
	private final CareCommApiService careCommApiService;

	public List<CmpgCtraBscModel> getCampaignContractList(CareCampaignVo vo) {
		return campaignRepository.selectCampaignContractList(vo);
	}

	public CmpgCtraBscModel getCampaignContract(CareCampaignVo vo) {
		return campaignRepository.selectCampaignContract(vo);
	}

	public void setCampaignContract(CmpgCtraBscModel model) {
		int checkClientCount = campaignRepository.selectCampaignClientCount(model);

		if (checkClientCount >= 1) {
			String checkContractMessage = "이미 계약된 고객사 또는 사업장 입니다.";

			if (model.getBsplId() == null) {
				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, checkContractMessage);
			}

			int checkWorkplaceCount = campaignRepository.selectCampaignWorkplaceCount(model);

			if (checkWorkplaceCount >= 1) {
				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, checkContractMessage);
			}
		}


		if (model.getCmpgCtraId() == null) {
			campaignRepository.insertCampaignContract(model);
		} else {
			campaignRepository.updateCampaignContract(model);
		}
	}

	@Transactional
	public void removeCampaignContract(List<CmpgCtraBscModel> models) {
		for (CmpgCtraBscModel model : models) {
			int usedCount = campaignRepository.selectUsedCampaignContractCount(model.getCmpgCtraId());

			if (usedCount > 0) {
				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "회원 활동 이력이 존재하는 캠페인 계약입니다.");
			}

			CareCampaignVo vo = new CareCampaignVo();
			vo.setCmpgCtraId(model.getCmpgCtraId());

			List<CmpgBscModel> getTermList = getContractTermList(vo);

			for (CmpgBscModel termModel : getTermList) {
				campaignRepository.deleteCampaignRewardByCmpgId(termModel.getCmpgId());
				campaignRepository.deleteCampaignNotificationByCmpgId(termModel.getCmpgId());
				campaignRepository.deleteContractTerm(termModel.getCmpgId());
			}

			campaignRepository.deleteCampaignContract(model.getCmpgCtraId());
		}
	}

	public List<CmpgBscModel> getContractTermList(CareCampaignVo vo) {
		return campaignRepository.selectContractTermList(vo);
	}

	@Transactional
	public void setCampaignContractTerm(List<CmpgBscModel> models) {
		for (CmpgBscModel model : models) {
			if (model.getRowStatus().equals("D")) {
				int checkCount = campaignRepository.selectUsedCampaignMemberCount(model.getCmpgId());

				if (checkCount > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "회원 활동 이력이 존재하는 캠페인입니다.");
				}

				campaignRepository.deleteContractTerm(model.getCmpgId());
			} else {
				int checkCount = campaignRepository.selectOverlappedDateCount(model);

				if (checkCount > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "캠페인 차수 목록을 재조회 후 중복된 진행기간을 확인해 주세요.");
				}

				if (model.getCmpgId() == null || model.getRowStatus().equals("C")) {
					campaignRepository.insertContractTerm(model);
				} else {
					campaignRepository.updateContractTerm(model);
				}
			}
		}
	}

	public List<CmpgNtfcDtlModel> getContractNoticeList(CareCampaignVo vo) {
		return campaignRepository.selectContractNoticeList(vo);
	}

	@Transactional
	public void setCampaignContractNotice(List<CmpgNtfcDtlModel> models) {
		for (CmpgNtfcDtlModel model : models) {
			if (model.getRowStatus().equals("D")) {
				campaignRepository.deleteContractNotice(model.getNtfcId());
			} else if (model.getCmpgId() == null || model.getRowStatus().equals("C")) {
				campaignRepository.insertContractNotice(model);
			} else {
				campaignRepository.updateContractNotice(model);
			}
		}
	}

	public List<CmpgCmpnDtlModel> getCampaignRewardList(CareCampaignVo vo) {
		return campaignRepository.selectCampaignRewardList(vo);
	}

	@Transactional
	public void setCampaignReward(List<CmpgCmpnDtlModel> models) {
		for (CmpgCmpnDtlModel model : models) {
			if (model.getRowStatus().equals("D")) {
				campaignRepository.deleteCampaignReward(model.getCmpgCmpnId());
			} else if (model.getCmpgCmpnId() == null || model.getRowStatus().equals("C")) {
				campaignRepository.insertCampaignReward(model);
			} else {
				campaignRepository.updateCampaignReward(model);
			}
		}
	}

	public List<MbrCmpgRecsModel> getCampaignRewardMemberList(CareCampaignVo vo) {
		List<MbrCmpgRecsModel> list = campaignRepository.selectCampaignRewardMemberList(vo);

//		UstraMaskingUtils.maskTextFields(list);

		return list;
	}

	@Transactional
	public void setCampaignRewardConfirm(CareCampaignVo vo) {
		CmpgCtraBscModel contractModel = getCampaignContract(vo);

		if (contractModel.getCmpnWayCd().equals("10")) {
			campaignRepository.updateCampaignRewardConfirmForRank(vo);
		} else if (contractModel.getCmpnWayCd().equals("20")) {
			List<CmpgCmpnDtlModel> getRewardList = getCampaignRewardList(vo);

			for (CmpgCmpnDtlModel model : getRewardList) {
				campaignRepository.updateCampaignRewardConfirmForDraw(model);
			}
		}

		campaignRepository.updateCampaignRewardAfterWork(vo);
	}

	@Transactional
	public void setCampaignRewardCancel(CareCampaignVo vo) {
		campaignRepository.updateCampaignRewardMemberCancel(vo);
		campaignRepository.updateCampaignRewardCancel(vo);
	}

	@Transactional
	public void setCampaignRewardPrize(List<MbrCmpgRecsModel> models) {
		for (MbrCmpgRecsModel model : models) {
			campaignRepository.updateCampaignRewardPrize(model);
		}
	}

	public List<CmpgBscModel> getOperManagementList(CareCampaignVo vo) {
		return campaignRepository.selectOperManagementList(vo);
	}

	public CmpgBscModel getOperManagementDetail(CareCampaignVo vo) {
		return campaignRepository.selectOperManagementDetail(vo);
	}

	public List<MbrCmpgRecsModel> getOperManagementPeople(CareCampaignVo vo) {
		return campaignRepository.selectOperManagementPeople(vo);
	}

	public List<MbrCmpgRecsModel> getOperNoenterPeople(CareCampaignVo vo) {
		return campaignRepository.selectOperNoenterPeople(vo);
	}

	public List<MbrCmpgRecsModel> getOperPersonDetail(CareCampaignVo vo) {
		return campaignRepository.selectOperPersonDetail(vo);
	}

	public void getCampaignReset(CareCampaignVo vo) {
		careCommApiService.batchCareCampaign(vo.getCmpgId());
	}

	public List<CmpgNtfcBscModel> getCampaignNoticeList(CareCampaignVo vo) {
		return campaignRepository.selectCampaignNoticeList(vo);
	}

	public CmpgNtfcBscModel getCampaignNotice(CareCampaignVo vo) {
		return campaignRepository.selectCampaignNotice(vo);
	}

	public void setCampaignNotice(CmpgNtfcBscModel model) {
		if (model.getMsgId() == null) {
			campaignRepository.insertCampaignNotice(model);
		} else {
			campaignRepository.updateCampaignNotice(model);
		}
	}

	@Transactional
	public void removeCampaignNotice(List<CmpgNtfcBscModel> models) {
		for (CmpgNtfcBscModel model : models) {
			campaignRepository.deleteCampaignNotice(model.getMsgId());
		}
	}

	public List<CmpgTeamRecsModel> getOperationDetailTeam(CareCampaignVo vo) {
		return campaignRepository.selectOperationDetailTeam(vo);
	}

	public List<CmpgTeamRecsModel> getOperTeamPersonDetail(CareCampaignVo vo) {
		return campaignRepository.selectOperTeamPersonDetail(vo);
	}

	public void setTeamInfoUpdate(CareCampaignVo vo) {
		campaignRepository.updateCampaignTeamInfoUpdate(vo);
	}

	public CmpgBscModel getOperationTeamCount(CareCampaignVo vo) {
		return campaignRepository.selectOperationTeamCount(vo);
	}

	public void insertRestriction(CareCampaignVo vo) {
		campaignRepository.deleteMbrCmpgRecs(vo);
		campaignRepository.insertRestriction(vo);
	}

	public void deleteRestriction(CareCampaignVo vo) {
		campaignRepository.deleteRestriction(vo);
	}

}
