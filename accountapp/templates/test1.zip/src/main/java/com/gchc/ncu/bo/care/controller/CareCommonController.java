package com.gchc.ncu.bo.care.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.models.ActPgmBscModel;
import com.gchc.ncu.bo.care.models.CareCodeModel;
import com.gchc.ncu.bo.care.models.CareDssCdModel;
import com.gchc.ncu.bo.care.models.DssLibBscModel;
import com.gchc.ncu.bo.care.models.DwCnntScwdDatBscModel;
import com.gchc.ncu.bo.care.models.HospMdspDeptDtlModel;
import com.gchc.ncu.bo.care.models.NtrtMsnBscModel;
import com.gchc.ncu.bo.care.models.NtrtPgmBscModel;
import com.gchc.ncu.bo.care.models.PoisTyBscModel;
import com.gchc.ncu.bo.care.service.CareCommonService;
import com.gchc.ncu.bo.care.vo.ExcelDwldLogVo;
import com.gsitm.ustra.java.management.models.UstraFileModel;
import com.gsitm.ustra.java.management.services.UstraFileService;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/care/common")
public class CareCommonController {

	private final CareCommonService commonService;
	private final UstraFileService fileService;

	@GetMapping("/code/list")
	public List<CareCodeModel> getCodeList() {
		LOGGER.debug("care > common > getCodeList");

		return commonService.getCodeList();
	}

	@GetMapping("/disease/list")
	public List<CareDssCdModel> getDiseaseList(@ModelAttribute CareDssCdModel model) {
		return commonService.getDiseaseList(model);
	}

	@GetMapping("/activity/mission/list")
	public List<ActMsnBscModel> getActivityMissionList() {
		return commonService.getActivityMissionList();
	}

	@GetMapping("/activity/program/list")
	public List<ActPgmBscModel> getActivityProgramList() {
		return commonService.getActivityProgramList();
	}

	@GetMapping("/nutrition/mission/list")
	public List<NtrtMsnBscModel> getNutritionMissionList() {
		return commonService.getNutritionMissionList();
	}

	@GetMapping("/nutrition/program/list")
	public List<NtrtPgmBscModel> getNutritionProgramList() {
		return commonService.getNutritionProgramList();
	}

	@GetMapping("/addiction/type/list")
	public List<PoisTyBscModel> getAddictionTypeList() {
		return commonService.getAddictionTypeList();
	}

	@GetMapping("/icon/{fileId}")
	public void getImageLoad(@PathVariable String fileId, HttpServletResponse response) {
		List<UstraFileModel> fileList = fileService.getFiles(fileId, 1);

		if (fileList != null && fileList.size() == 1) {
			UstraFileModel file = fileList.get(0);

			String filePath = file.getSvPath();
			String fileName = file.getFileNm();
			String fileFmtCont = file.getFileFmtCont();

			if (fileFmtCont.equals("jpg")) {
				fileFmtCont = "jpge";
			}

			File f = new File(filePath + fileName);
			byte[] pb = new byte[(int) f.length()];

			FileInputStream fis = null;

			try {
				fis = new FileInputStream(f);
				fis.read(pb);
			} catch (IOException e) {
				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, e.getMessage());
			} finally {
				if (fis != null) {
					try {
						fis.close();
					} catch (IOException e) {
						throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, e.getMessage());
					}
				}
			}

			response.setIntHeader("Content-length", pb.length);
			response.setContentType("image/" + fileFmtCont);

			OutputStream os = null;

			try {
				os = response.getOutputStream();
				os.write(pb, 0, pb.length);
			} catch (IOException e) {
				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, e.getMessage());
			} finally {
				try {
					os.close();
				} catch (IOException e) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, e.getMessage());
				}
			}
		}
	}


	@GetMapping("/mdsp/dept/list")
	public List<HospMdspDeptDtlModel> getMdspDeptList() {
		return commonService.getMdspDeptList();
	}

	@GetMapping("/disease/lib/list")
	public List<DssLibBscModel> getDiseaseLibList(@RequestParam(name = "keyword", required = false) String dssNm) {
		return commonService.getDiseaseLibList(dssNm);
	}

	@GetMapping("/content/category")
	public List<DwCnntScwdDatBscModel> getContentCategory() {
		return commonService.getContentCategory();
	}

	@GetMapping("/content/list")
	public List<DwCnntScwdDatBscModel> getContentList(@ModelAttribute DwCnntScwdDatBscModel model) {
		return commonService.getContentList(model);
	}

	@GetMapping("/terms/list")
	public List<Map<String, Object>> getTermsList(@RequestParam HashMap<String, Object> model) {
		return commonService.getTermsList(model);
	}

	@GetMapping("/survey/list")
	public List<Map<String, Object>> getSurveyList(@ModelAttribute HashMap<String, Object> model) {
		return commonService.getSurveyList(model);
	}

	@GetMapping("/client/list")
	public List<Map<String, Object>> getClientList(@RequestParam HashMap<String, Object> model) {
		return commonService.getClientList(model);
	}

	@PostMapping("/excel/download/log")
	public RestResult<?> setExcelDownloadLog(@RequestBody ExcelDwldLogVo vo) {
		commonService.setExcelDownloadLog(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
