package com.gchc.ncu.bo.batchupload.models;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;

import com.gchc.ncu.bo.batchupload.annotation.BulkInsert;
import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
public class BatchMemberUploadCustomerModel extends NcuModel {

	@BulkInsert(1)
	@ApiModelProperty(value="고객사아이디 NN")
	private Integer clcoId;

	private Integer uid;

	@BulkInsert(2)
	@ApiModelProperty(value="년도 NN")
    private Integer yr;

	private String regDvVal;

	private Integer regOptnYn1;

	private Integer regOptnYn2;

	@BulkInsert(3)
	@UstraExcelCellInfo(col = 0, header = "이름", required = false)
	@ApiModelProperty(value="[중복체크] 임직원 이름")
	private String aempNm;

	@BulkInsert(4)
	@UstraExcelCellInfo(col = 1, header = "검진등급", required = false)
	@ApiModelProperty(value="임직원 검진등급명")
	private String aempCuGrdNm;

	@BulkInsert(5)
	@ApiModelProperty(value="임직원 검진등급 ID")
	private Integer aempCuGrdId;

	@BulkInsert(6)
	@UstraExcelCellInfo(col = 2, header = "백신등급", required = false)
	@ApiModelProperty(value="임직원 백신등급명")
	private String aempVcnGrdNm;

	@BulkInsert(7)
	@ApiModelProperty(value="임직원 백신등급 ID")
	private Integer aempVcnGrdId;

	@BulkInsert(8)
	@UstraExcelCellInfo(col = 3, header = "사번", required = false)
	@ApiModelProperty(value="임직원 ID")
	private String aempId;

	@BulkInsert(9)
	@UstraExcelCellInfo(col = 4, header = "임원여부", required = false)
	@ApiModelProperty(value="임원여부")
	private Integer excuYn;

	@BulkInsert(10)
	@UstraExcelCellInfo(col = 5, header = "생년월일", required = false)
	@ApiModelProperty(value="[중복체크] 임직원생년월일")
	private String aempBrdt;

	@BulkInsert(11)
	@ApiModelProperty(value="[중복체크] 임직원성별코드")
	private String aempSexCd;

	@BulkInsert(12)
	@UstraExcelCellInfo(col = 6, header = "입사일자", required = false)
	@ApiModelProperty(value="입사일자")
	private String encmDt;

	@BulkInsert(13)
	@UstraExcelCellInfo(col = 7, header = "패키지명", required = false)
	@ApiModelProperty(value="패키지명")
	private String pkgNm;

	@BulkInsert(14)
	@UstraExcelCellInfo(col = 8, header = "지원금", required = false)
	@ApiModelProperty(value="회사지원금")
	private String corpSpfnVal;	// 회사지원금 corpSpfn(Integer) -> corpSpfnVal(String) 20211220

	@BulkInsert(15)
	@UstraExcelCellInfo(col = 9, header = "건강보험공단지원대상여부", required = false)
	@ApiModelProperty(value="건강보험공단지원대상여부")
	private Integer nhicSuptTgtYn;

	@BulkInsert(16)
	@UstraExcelCellInfo(col = 10, header = "특수검진대상여부", required = false)
	@ApiModelProperty(value="특수검진대상여부")
	private Integer spcuTgtYn;

	@BulkInsert(17)
	@UstraExcelCellInfo(col = 11, header = "특수물질명(1차)", required = false)
	@ApiModelProperty(value="특수물질명1")
	private String extrMttrNm1;

	@BulkInsert(18)
	@UstraExcelCellInfo(col = 12, header = "특수물질명(2차)", required = false)
	@ApiModelProperty(value="특수물질명2")
	private String extrMttrNm2;

	@BulkInsert(19)
	@UstraExcelCellInfo(col = 13, header = "이메일", required = false)
	@ApiModelProperty(value="이메일주소")
	private String emlAdr;

	@BulkInsert(20)
	@UstraExcelCellInfo(col = 14, header = "휴대전화번호", required = false)
	@ApiModelProperty(value="[중복체크] 휴대전화번호")
	private String mblNo;

	@BulkInsert(21)
	@UstraExcelCellInfo(col = 15, header = "배우자명", required = false)
	@ApiModelProperty(value="배우자명")
	private String spsrNm;

	@BulkInsert(22)
	@UstraExcelCellInfo(col = 16, header = "배우자검진등급명", required = false)
	@ApiModelProperty(value="배우자검진등급명")
	private String spsrCuGrdNm;

	@BulkInsert(23)
	@ApiModelProperty(value="배우자검진등급 ID")
	private Integer spsrCuGrdId;

	@BulkInsert(24)
	@UstraExcelCellInfo(col = 17, header = "배우자백신등급명", required = false)
	@ApiModelProperty(value="배우자백신등급명")
	private String spsrVcnGrdNm;

	@BulkInsert(25)
	@ApiModelProperty(value="배우자백신등급 ID")
	private Integer spsrVcnGrdId;

	@BulkInsert(26)
	@ApiModelProperty(value="배우자생년월일")
	private String spsrBrdt;

	@BulkInsert(27)
	@ApiModelProperty(value="배우자성별코드")
	private String spsrSexCd;

	@BulkInsert(28)
	@UstraExcelCellInfo(col = 18, header = "배우자회사지원금", required = false)
	@ApiModelProperty(value="배우자회사지원금")
	private String spsrCorpSpfn;

	@BulkInsert(29)
	@UstraExcelCellInfo(col = 19, header = "배우자검진패키지", required = false)
	@ApiModelProperty(value="배우자패키지명")
	private String spsrPkgNm;

	@BulkInsert(30)
	@UstraExcelCellInfo(col = 20, header = "사업장", required = false)
	@ApiModelProperty(value="사업장명")
	private String bsplNm;

	@BulkInsert(31)
	@ApiModelProperty(value="사업장 ID")
	private Integer bsplId;

	@BulkInsert(32)
	@UstraExcelCellInfo(col = 21, header = "부서1", required = false)
	@ApiModelProperty(value="부서명1 기본값 '미등록'")
	private String deptNm1;

	@BulkInsert(33)
	@UstraExcelCellInfo(col = 22, header = "부서2", required = false)
	@ApiModelProperty(value="부서명2")
	private String deptNm2;

	@BulkInsert(34)
	@UstraExcelCellInfo(col = 23, header = "부서3", required = false)
	@ApiModelProperty(value="부서명3")
	private String deptNm3;

	@ApiModelProperty(value="직급명 기본값 '미등록'")
	@UstraExcelCellInfo(col = 24, header = "직급", required = false)
	@BulkInsert(35)
	private String jbgdNm;

	@BulkInsert(36)
	@UstraExcelCellInfo(col = 25, header = "직장전화번호", required = false)
	@ApiModelProperty(value="직장전화번호")
	private String wrplTlno;

	@BulkInsert(37)
	@UstraExcelCellInfo(col = 26, header = "직장우편번호", required = false)
	@ApiModelProperty(value="직장우편번호")
	private String wrplZpcd;

	@BulkInsert(38)
	@UstraExcelCellInfo(col = 27, header = "직장기본주소", required = false)
	@ApiModelProperty(value="직장기본주소")
	private String wrplBscAdr;

	@BulkInsert(39)
	@UstraExcelCellInfo(col = 28, header = "직장상세주소", required = false)
	@ApiModelProperty(value="직장상세주소")
	private String wrplDtlAdr;

	@BulkInsert(40)
	@UstraExcelCellInfo(col = 29, header = "자택전화번호", required = false)
	@ApiModelProperty(value="자택전화번호")
	private String hsTlno;

	@BulkInsert(41)
	@UstraExcelCellInfo(col = 30, header = "자택우편번호", required = false)
	@ApiModelProperty(value="자택우편번호")
	private String hsZpcd;

	@BulkInsert(42)
	@UstraExcelCellInfo(col = 31, header = "자택기본주소", required = false)
	@ApiModelProperty(value="자택기본주소")
	private String hsBscAdr;

	@BulkInsert(43)
	@UstraExcelCellInfo(col = 32, header = "자택상세주소", required = false)
	@ApiModelProperty(value="자택상세주소")
	private String hsDtlAdr;

	@BulkInsert(44)
	@ApiModelProperty(value="임직원등록일련번호 NN")
	private Integer aempRegSeq;

	@BulkInsert(45)
	@ApiModelProperty(value="업로드상태값 기본값 0")
	private Integer upldStVal;

	@BulkInsert(46)
	@ApiModelProperty(value="업로드오류값")
	private String upldErrVal;

	@BulkInsert(47)
	@ApiModelProperty(value="관리자 ID NN")
	private Integer mngrId;

	@BulkInsert(48)
	@UstraExcelCellInfo(col = 33, header = "근무부서명", required = false)
	@ApiModelProperty(value="근무부서명")
	private String workDeptNm;

	@BulkInsert(49)
	@UstraExcelCellInfo(col = 34, header = "라인명", required = false)
	@ApiModelProperty(value="라인명")
	private String lineNm;

	@BulkInsert(50)
	@UstraExcelCellInfo(col = 35, header = "작업명", required = false)
	@ApiModelProperty(value="작업명")
	private String jobNm;

	@BulkInsert(51)
	@UstraExcelCellInfo(col = 36, header = "캠페인팀", required = false)
	@ApiModelProperty(value="캠페인팀")
	private String teamNm;

	private String custMemo;

	// rollback으로 인한 주석처리
	private String athoKvl;

	@ApiModelProperty(value="연관임직원 이름")
	private String oldAempNm;

	@ApiModelProperty(value="연관임직원 사번")
	private String oldAempId;

	@ApiModelProperty(value="연관임직원 생년월일")
	private String oldAempBrdt;

	@ApiModelProperty(value="연관임직원 성별코드")
	private String oldAempSexCd;

}
