package com.gchc.ncu.bo.batchupload.utils;

import com.gchc.ncu.bo.batchupload.annotation.BulkInsert;
import com.gchc.ncu.bo.comm.util.NcuAuthenticationUtils;
import com.gchc.ncu.bo.config.authentication.NcuAdminUser;
import com.gsitm.ustra.java.core.utils.UstraJsonUtils;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@UtilityClass

public class BatchUploadUtils {

	private String _ent(Object src) {

		if( ObjectUtils.isEmpty(src) )
			return null;
		return src.toString().trim();
	}

	public String toString(Object src) {

		if( src == null )
			return "";
		return src.toString();
	}

	public int getCurrentMngrId() {

		return Optional.ofNullable(NcuAuthenticationUtils.getCurrentUser()).map(NcuAdminUser::getMngrId).orElse(0);
	}


	public String autoFixRvs(String src) {

		return src.replace("㈜", "(주)")
			.replace("©", "(c)")
			.replace("€", "(e)")
			.replace("㉿", "(ks)")
			.replace("®", "(r)")
			.replace("☎", "(tel)")
			.replace("™", "(tm)");
	}

	String mergedStr(Object model) {

		return Arrays.asList(model.getClass().getDeclaredFields()).stream()
			.filter(f->f.getAnnotation(BulkInsert.class) != null)
			.map(f->new AbstractMap.SimpleEntry<>(f.getAnnotation(BulkInsert.class).value(), f))
			.sorted((e1, e2)->Integer.compare(e1.getKey(), e2.getKey()))
			.map(entry->{

				try {
					entry.getValue().setAccessible(true);
					return toString(entry.getValue().get(model));
				}
				catch( Exception e ) {
					LOGGER.debug(e.getMessage());
				}
				return "";
			})
			.collect(Collectors.joining(";"));
	}

	public <T> List<String> bulkMergedInsert(List<T> models, int index, int count) {

		return models.subList(index, Math.min(index + count, models.size())).stream()
			.map(r->mergedStr(r))
			.collect(Collectors.toList());
	}

	public <T> List<T> bulkInsert(List<T> models, int index, int count) {

		return new ArrayList<>(models.subList(index, Math.min(index + count, models.size())));
	}

	public <T> T copy(T target, Object src) {

		if( ObjectUtils.isEmpty(src) )
			return target;

		Arrays.asList(src.getClass().getDeclaredMethods()).stream()
		.filter(m->m.getName().startsWith("get"))
		.forEach(m->{

			try {

				Method outMethod = target.getClass().getMethod("set" + m.getName().substring(3), m.getReturnType());
				outMethod.setAccessible(true);
				if( m.getReturnType() == String.class || outMethod.getParameterTypes()[0] == String.class )
					outMethod.invoke(target, _ent(m.invoke(src)));
				else
					outMethod.invoke(target, m.invoke(src));
			}
			catch( NoSuchMethodException e ) {

				try {

					Method outMethod = target.getClass().getMethod("set" + m.getName().substring(3), Integer.class);
					outMethod.setAccessible(true);

					String value = m.invoke(src).toString().replace(",", "");
					if( NumberUtils.isCreatable(value.replace(",", "")) )
						outMethod.invoke(target, NumberUtils.toInt(value));
					else if( strIn(value, "Y", "N") )
						outMethod.invoke(target, "Y".equals(value) ? 1 : 0);
				}
				catch( Exception e2 ) {
				}
			}
			catch( Exception e ) {
			}
		});

		return target;
	}

	String keyToEntry(Map<String, String> table, Map<String, Object> header, String key) {

		String entry = table.entrySet().stream()
			.filter(e->e.getKey().replace(" ", "").equals(header.get(key).toString().replace(" ", "")))
			.map(e->e.getValue())
			.findFirst().orElse("");

		if( StringUtils.isEmpty(entry) )
			LOGGER.debug("cannot found entry - ", header.get(key));

		return entry;
	}

	public <T> T map(Map<String, Object> src, Map<String, Object> header, Map<String, String> table, Class<T> clazz) {

		try {

			T target = clazz.newInstance();
			if( ObjectUtils.isEmpty(src) )
				return target;

			src.entrySet().stream()
			.filter(e->ObjectUtils.isNotEmpty(header.get(e.getKey())) && hdrIn(header.get(e.getKey()).toString(), table.keySet()))
			.forEach(e->{

				try {

					Method outMethod = target.getClass().getMethod("set" + keyToEntry(table, header, e.getKey()), e.getValue().getClass());
					outMethod.setAccessible(true);
					if( e.getValue().getClass() == String.class || outMethod.getParameterTypes()[0] == String.class )
						outMethod.invoke(target, _ent(e.getValue()));
					else
						outMethod.invoke(target, e.getValue());
				}
				catch( NoSuchMethodException ex ) {

					try {

						Method outMethod = target.getClass().getMethod("set" + keyToEntry(table, header, e.getKey()), Integer.class);
						outMethod.setAccessible(true);

						String value = e.getValue().toString().replace(",", "");
						if( NumberUtils.isCreatable(value) )
							outMethod.invoke(target, NumberUtils.toInt(value));
						else if( strIn(value, "Y", "N") )
							outMethod.invoke(target, "Y".equals(value) ? 1 : 0);
					}
					catch( Exception ex2 ) {}
				}
				catch( Exception ex ) {}
			});

			return target;
		}
		catch( Exception e ) {}

		return null;
	}

	public <T> T map(Object src, Class<T> clazz) {

		try {

			T out = clazz.newInstance();
			return copy(out, src);
		}
		catch( Exception e ) {

			LOGGER.debug(ExceptionUtils.getStackTrace(e));
		}

		return null;
	}

	public Map<String, String> parseParameter(Object src) {

		Map<String, String> params = new HashMap<>();
		if( src == null )
			return params;

		String param = src.toString();
		String[] paramArr = param.split("\\,");
		for( String p : paramArr ) {

			String[] kvs = p.split("\\=");
			if( kvs.length != 2 )
				continue;
			params.put(kvs[0], kvs[1]);
		}
		return params;
	}

	public boolean isEmptyMap(Map<String, Object> map) {

		if( ObjectUtils.isEmpty(map) )
			return true;
		return !map.keySet().stream().anyMatch(k->ObjectUtils.isNotEmpty(map.get(k)));
	}

	public boolean isEmptyRow(Object src) {

		if( src instanceof Map<?, ?> )
			return ((Map<?, ?>)src).values().stream().allMatch(v->ObjectUtils.isEmpty(v));

		return Arrays.asList(src.getClass().getDeclaredMethods()).stream()
			.filter(m->m.getName().startsWith("get"))
			.allMatch(m->{

				m.setAccessible(true);
				try {

					return ObjectUtils.isEmpty(m.invoke(src));
				}
				catch( Exception e ) {

					LOGGER.debug(ExceptionUtils.getStackTrace(e));
				}

				return true;
			});
	}

	public boolean strNotIn(String src, String...targets) {

		return !strIn(src, targets);
	}

	public boolean strNotIn(String src, List<String> targets) {

		return !strIn(src, targets);
	}

	public boolean strIn(String src, List<String> targets) {

		return targets.contains(src);
	}

	public String strCut(String src, int length) {

		if( StringUtils.isNotEmpty(src) && src.length() > length )
			return src.substring(0, length);
		return src;
	}

	private boolean hdrIn(String src, Set<String> headers) {

		boolean ret = headers.stream()
			.filter(h->h.replace(" ", "").equals(src.replace(" ", "")))
			.count() > 0;

		if( !ret )
			LOGGER.debug("hdrIn failed - ", src);

		return ret;
	}

	public boolean hdrIn(String src, Collection<Object> headers) {

		return headers.stream().filter(h->h.toString().replace(" ", "").equals(src.replace(" ", ""))).count() > 0;
	}

	public boolean strIn(String src, String...targets) {

		return Arrays.asList(targets).contains(src);
	}

	public boolean numIn(Integer src, int min, int max) {

		if( src == null )
			return false;
		if( src < min )
			return false;
		if( src > max )
			return false;

		return true;
	}

	public boolean numIn(String src, int min, int max) {

		if( StringUtils.isEmpty(src) )
			return false;
		if( !NumberUtils.isCreatable(src) )
			return false;
		if( NumberUtils.toInt(src) < min )
			return false;
		if( NumberUtils.toInt(src) > max )
			return false;

		return true;
	}

	public int getSexNum(String src, boolean young) {

		if( "남".equals(src) || "1".equals(src) || "3".equals(src) )
			return young ? 3 : 1;
		if( "여".equals(src) || "2".equals(src) || "4".equals(src) )
			return young ? 4 : 2;

		return NumberUtils.toInt(src);
	}

	public boolean checkDt(String src) {

		if( src.length() != 10 )
			return false;

		try {

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			format.setLenient(false);
			format.parse(src);
			return true;
		}
		catch( Exception e ) {

			LOGGER.debug(e.getMessage());
		}

		return false;
	}

	public boolean checkBrdt(String src) {

		if( StringUtils.isEmpty(src) )
			return true;
		if( src.length() != 11 )
			return false;

		return checkDt(src.substring(0, 10));
	}

	public String formattedBrdt(String src) {

		if( StringUtils.isEmpty(src) )
			return null;

		src = makeBrdt(src);

		if( StringUtils.isEmpty(src) || !NumberUtils.isDigits(src.replace("-", "")) )
			return null;

		if( src.length() > 11 )
			return src.substring(0, 11);

		return src;
	}

	public String makeDt(String src) {

		if( StringUtils.isEmpty(src) )
			return src;

		src = src.replace("-", "");
		src = src.replace(" ", "");
		src = src.replace("/", "");
		src = src.replace(".", "");

		// SPARROW 1490477,1490478 NULL_RETURN
		if( StringUtils.isEmpty(src) )
			return "";

		if( NumberUtils.isDigits(src) ) {

			if( src.length() == 8 )
				return src.substring(0, 4) + "-" + src.substring(4, 6) + "-" + src.substring(6, 8);
			else if( src.length() == 6 ) {

				String strYear = src.substring(0, 2);
				int currentYear = Calendar.getInstance().get(Calendar.YEAR) % 100;
				strYear = (NumberUtils.toInt(strYear) < currentYear ? "20" : "19") + strYear;

				return strYear + "-" + src.substring(2, 4) + "-" + src.substring(4, 6);
			}
		}

		return src;
	}

	public String makeBrdt(String src) {

		if( StringUtils.isEmpty(src) )
			return src;

		src = src.trim();

		boolean young = false;
		String sexStr = src.substring(src.length() - 1, src.length());
		String birthStr = makeDt(src.substring(0, src.length() - 1));

		if( birthStr.length() > 3 && NumberUtils.toInt(birthStr.substring(0, 4)) > 1999 )
			young = true;

		return birthStr + getSexNum(sexStr, young);
	}

	public String makePhone(String src) {

		if( StringUtils.isEmpty(src) )
			return src;

		String ret = src.replace(".", "");
		ret = ret.replace("-", "");
		if( NumberUtils.isDigits(src) ) {

			if( ret.length() == 12 )
				return ret.substring(0, 4) + "-" + ret.substring(4, 8) + "-" + ret.substring(8);
			else if( ret.length() == 11 )
				return ret.substring(0, 3) + "-" + ret.substring(3, 7) + "-" + ret.substring(7);
			else if( ret.length() == 10 )
				return ret.substring(0, 2) + "-" + ret.substring(2, 6) + "-" + ret.substring(6);
			else if( ret.length() == 9 )
				return ret.substring(0, 2) + "-" + ret.substring(2, 5) + "-" + ret.substring(5);
		}

		return src;
	}

	public int charCount(String str, String... ch) {

		if( ch == null || ch.length == 0 )
			return 0;

		int cnt = 0;
		for( int i=0; i<str.length(); i++ ) {

			for( int j=0; j<ch.length; j++ ) {

				if( ch[j].equals(str.substring(i, i + 1)) )
					cnt++;
			}
		}

		return cnt;
	}

	public boolean isPhone(String src) {

		if( StringUtils.isEmpty(src) )
			return true;

		if( charCount(src, "-") != 2 )
			return false;

		if( !NumberUtils.isDigits(src.replace("-", "")) )
			return false;

		// AS-IS는 14자리에 대해 오류 처리 되었으나 0505-1234-1234 존재할 수 있어 15자리 부터 오류 처리
		if( src.length() > 14 )
			return false;

		return true;
	}

	public String toJsonString(Object src) {

		try {

			return UstraJsonUtils.serialize(src);
		}
		catch( IOException e ) {
			return "";
		}
	}
}
