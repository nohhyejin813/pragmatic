package com.gchc.ncu.bo.batchupload.comm;

import java.util.List;

import com.gchc.ncu.bo.batchupload.models.PackageBasicModel;

// #5497
public class PackageContextHolder {

	private static final ThreadLocal<List<PackageBasicModel>> contextHolder = new ThreadLocal<List<PackageBasicModel>>();

	public static List<PackageBasicModel> get() {

		return contextHolder.get();
	}

	public static PackageBasicModel get(String packageName) {

		return get().stream().filter(p->p.getPkgNm().equals(packageName)).findFirst().orElse(null);
	}

	public static void set(List<PackageBasicModel> data) {

		contextHolder.set(data);
	}

	public static void clear() {

		if( get() != null )
			contextHolder.remove();
	}
}
