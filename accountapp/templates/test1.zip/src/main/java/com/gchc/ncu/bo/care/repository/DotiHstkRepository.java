package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.DotiHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.DotiHstkBscModel;
import com.gchc.ncu.bo.care.vo.DotiHstkVo;

@Mapper
public interface DotiHstkRepository {

	List<DotiHstkBscModel> selectDotiHstkList(DotiHstkVo criteria);
	DotiHstkBscModel selectDotiHstkDetail(DotiHstkBscModel criteria);
	void insertDotiHstk(DotiHstkBscModel model);
	void updateDotiHstk(DotiHstkBscModel model);
	void deleteDotiHstk(DotiHstkBscModel model);

	List<DotiHstkAnswDtlModel> selectDotiHstkAnswerList(DotiHstkBscModel criteria);
	void saveDotiHstkAnswer(DotiHstkAnswDtlModel model);
	void deleteDotiHstkAnswer(int dotiHstkId);

}
