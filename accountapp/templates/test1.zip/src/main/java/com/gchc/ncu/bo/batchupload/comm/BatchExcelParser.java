package com.gchc.ncu.bo.batchupload.comm;

import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.usermodel.XSSFComment;

import java.util.ArrayList;
import java.util.List;

public class BatchExcelParser implements SheetContentsHandler {

	private List<RowInfo> rows;

	private int curCol;
	private List<String> row;

	public BatchExcelParser() {

		this.rows = new ArrayList<>();
	}

	@Override
	public void startRow(int rowNum) {

		this.row = new ArrayList<>();
	}

	@Override
	public void endRow(int rowNum) {

		RowInfo ri = new RowInfo();
		ri.setRow(rowNum);
		ri.setObject(this.row);
		ri.setParsed(true);

		this.rows.add(ri);
	}

	@Override
	public void cell(String columnName, String value, XSSFComment comment) {

		// 사용하지 않는 코드로 주석 처리
		// SPARROW 1490479 FORBIDDEN_ASSIGN_LITERAL
//		int iCol = (new CellReference(columnName)).getCol();
//		if( curCol > iCol )
//			curCol = -1;
//		int emptyCol = iCol - curCol - 1;
//
//		for( int i=0; i < emptyCol; i++ ) {
//			this.row.add("");
//		}
//
//		curCol = iCol;
//		this.row.add(value);
	}

	public List<RowInfo> getRows() {

		return this.rows;
	}
}
