package com.gchc.ncu.bo.admin.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

import com.gsitm.ustra.java.mvc.rest.model.RestVo;


@Data
@EqualsAndHashCode(callSuper=false)
public class AdminVo extends RestVo {

}
