package com.gchc.ncu.bo.care.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.NrsnDssEpidDtlModel;
import com.gchc.ncu.bo.care.repository.PainDiseaseEpidemicRepository;
import com.gchc.ncu.bo.care.vo.PainDiseaseEpidemicVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PainDiseaseEpidemicService {

	private final PainDiseaseEpidemicRepository painDiseaseEpidemicRepository;

	public List<NrsnDssEpidDtlModel> getPainDiseaseEpidemicList(PainDiseaseEpidemicVo criteria) {
		return painDiseaseEpidemicRepository.selectPainDiseaseEpidemicList(criteria);
	}

	public List<NrsnDssEpidDtlModel> getPainDiseaseEpidemicMonthList(NrsnDssEpidDtlModel criteria) {
		return painDiseaseEpidemicRepository.selectPainDiseaseEpidemicMonthList(criteria);
	}

	@Transactional
	public void savePainDiseaseEpidemicMonth(int nrsnDssId, @Valid List<NrsnDssEpidDtlModel> list) {
		painDiseaseEpidemicRepository.deletePainDiseaseEpidemicMonth(nrsnDssId);

		if (list != null) {
			for (NrsnDssEpidDtlModel model : list) {
				painDiseaseEpidemicRepository.insertPainDiseaseEpidemicMonth(model);
			}
		}
	}

}
