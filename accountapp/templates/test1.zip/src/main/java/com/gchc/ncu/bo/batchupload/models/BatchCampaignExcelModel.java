package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchCampaignExcelModel extends NcuModel {
	/** 엑셀다운로드 **/
	private String clcoNm;		// 고객사
	private String aempNm;		// 이름
	private String aempId;		// 사번
	private String workDeptNm;	// 근무부서
	private String lineNm;		// 라인
	private String jobNm;		// 작업
	private String teamNm;		// 캠페인팀
	private String errMsg;		// 오류내용

}
