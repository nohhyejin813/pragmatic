package com.gchc.ncu.bo.admin.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;
import com.gchc.ncu.bo.comm.service.AccessControlService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.admin.models.AdminModel;
import com.gchc.ncu.bo.admin.models.AdminOpenPopupModel;
import com.gchc.ncu.bo.admin.models.AdminProgressModel;
import com.gchc.ncu.bo.admin.models.ClientMiniModel;
import com.gchc.ncu.bo.admin.models.ClientPaymentModel;
import com.gchc.ncu.bo.admin.service.AdminService;
import com.gchc.ncu.bo.comm.code.NcuResponseCode;
import com.gchc.ncu.bo.member.models.ClientModel;

/**
 * 메인화면 Controller
 *
 * @author 2021.12.09 목 /Kim Hyun-Soo
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/admin/")
@Api(tags="메인화면")
public class AdminController {

    private final AdminService adminService;

    private final AccessControlService accessControlService;

	/**
	 * 어떠케어 메인 그래프 데이터조회
	 */
    @ApiOperation(value="어떠케어 그래프데이터 조회", notes="어떠케어 그래프데이터 조회")
	@GetMapping("/howcare/graph")
	public List<AdminModel> getHowcareMainGraphData() {
		return adminService.getHowcareMainGraphData();
	}


	/**
	 * 어떠케어 메인 그래프 데이터조회
	 */
	@ApiOperation(value="메인 기관관리자 그래프데이터 조회", notes="메인 기관관리자 그래프데이터 조회")
	@GetMapping("/main-inst/graph/{cuiId}")
	public List<AdminModel> getMainInstGraphData(@PathVariable Integer cuiId) {
		return adminService.getMainInstGraphData(cuiId);
	}

	/**
	 * 고객사 관리자 그래프 데이터조회
	 */
	@ApiOperation(value="고객사 관리자 그래프 데이터조회", notes="고객사 관리자 그래프 데이터조회")
	@GetMapping("/checkupinst/graph/{clcoId}")
	public List<AdminModel> getCheckupinstGraphData(@PathVariable Integer clcoId) {
		accessControlService.validateClcoId(clcoId);

		return adminService.getCheckupinstGraphData(clcoId);
	}


	@ApiOperation(value="메인화면 - 고객사 기본 정보 조회", notes="메인화면 - 고객사 기본 정보를 반환한다.")
	@GetMapping("/clients/easy/{id}")
	public ClientModel getEasyClient(@PathVariable Integer id) {
		accessControlService.validateClcoId(id);

		ClientModel clientModel = new ClientModel();
		clientModel.setClcoId(id);
		return adminService.getEasyClient(clientModel);
	}

	@ApiOperation(value="메인화면 - 진행도 플래그 조회", notes="메인화면 - 진행도 플래그 조회")
	@GetMapping("/progress-flag/{clcoId}")
	public AdminProgressModel getAdminProgressFlag(@PathVariable Integer clcoId) {
		accessControlService.validateClcoId(clcoId);

		return adminService.getAdminProgressFlag(clcoId);
	}

	@ApiOperation(value="오픈하기 팝업 데이터 조회", notes="오픈하기 팝업 데이터 조회")
	@GetMapping("/open-popup-data/{clcoId}")
	public AdminOpenPopupModel getOpenPopupData(@PathVariable Integer clcoId) {
		accessControlService.validateClcoId(clcoId);

		return adminService.getOpenPopupData(clcoId);
	}

	@ApiOperation(value="오픈하기 팝업 데이터 추가 조회", notes="오픈하기 팝업 데이터 조회")
	@GetMapping("/open-add-popup-data/{clcoId}")
	public AdminOpenPopupModel getOpenAddPopupData(@PathVariable Integer clcoId) {
		return adminService.getOpenAddPopupData(clcoId);
	}


	@ApiOperation(value="오픈하기 - flag수정", notes="오픈하기 - flag수정")
	@PostMapping("/modify/clco-open-flag/")
	public ResponseCode modClcoOpenFlag(@RequestBody AdminProgressModel model) {
		int clcoId = model.getClcoId();
		if(adminService.modClcoOpenFlag(clcoId) != 1) {
			return NcuResponseCode.BIZ_LITE_OPEN_MESSAGE_FAIL;
		}
		return NcuResponseCode.MESSAGE_SUCCESS;
	}


	@GetMapping("/client-list/{yr}")
	public RestResult<List<ClientMiniModel>> getClientList(@PathVariable Integer yr) {
		final List<ClientMiniModel> resultList = adminService.getClientList(yr);
		return GchcRestResult.of(resultList);
	}

	@GetMapping("/open-client-notice-data/{cuiId}/{yr}")
	public List<ClientMiniModel> getOpenClientNoticeData(@PathVariable Integer cuiId, @PathVariable Integer yr) {
		return adminService.getOpenClientNoticeData(cuiId, yr);
	}

	@GetMapping("/open-client-payment-data/{cuiId}")
	public ClientPaymentModel getOpenClientPaymentData(@PathVariable Integer cuiId) throws Exception {
		return adminService.getOpenClientPaymentData(cuiId);
	}

	@PostMapping("/open-client-payment-approval/")
	public ClientPaymentModel exeOpenClientPaymentApproval(@RequestBody ClientPaymentModel model) {
		ClientPaymentModel rsVal = null;
		String resCode = "";

		try {
			rsVal = adminService.exeOpenClientPaymentApproval(model);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			resCode = "9998";
		} catch (Exception e) {
			e.printStackTrace();
			resCode = "9999";
		}
		if (rsVal == null) {
			rsVal = new ClientPaymentModel();
			rsVal.setAuthResultMsg("정상적인 요청이 아닙니다. 고객센터에 문의해주세요.");
			rsVal.setAuthResultCode(resCode);
		}

		return rsVal;
	}
}
