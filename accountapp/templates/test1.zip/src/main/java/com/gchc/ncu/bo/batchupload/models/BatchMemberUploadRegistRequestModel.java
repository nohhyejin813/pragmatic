package com.gchc.ncu.bo.batchupload.models;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BatchMemberUploadRegistRequestModel {

	Integer clcoId;

	Integer yr;

	Integer mngrId;

	String regDvVal;

	boolean cuTgtrUpdYn;

	boolean vcnTgtrUpdYn;

	boolean spcuMttr1UpdYn;

	boolean spcuMttr2UpdYn;

	boolean fmlyUpdYn;

	boolean fmlyInitYn;

	List<BatchMemberUploadCustomerModel> list;

	Integer upldStVal;
}
