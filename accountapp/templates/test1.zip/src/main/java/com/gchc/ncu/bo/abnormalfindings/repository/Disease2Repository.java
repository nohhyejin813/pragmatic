package com.gchc.ncu.bo.abnormalfindings.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gchc.ncu.bo.abnormalfindings.models.Disease2Model;
import com.gchc.ncu.bo.abnormalfindings.vo.Disease2Vo;
import com.gsitm.ustra.java.data.domains.PaginationList;

/**
 * 유소견관리(신)
 *
 * @since	2021.11.22
 * @author 	gs_tskwon@gchealthcare.com
 */
@Mapper
public interface Disease2Repository {

	/**
     * 유소견관리(신)  - 목록조회
     */
	List<Disease2Model> getDisease2List(Map<String, Object> model);

	List<Disease2Model> getDisease2ListForExcel(@Param("model") Disease2Vo model);

}
