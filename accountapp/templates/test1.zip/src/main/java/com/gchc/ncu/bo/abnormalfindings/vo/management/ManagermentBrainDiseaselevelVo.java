package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;


@Getter
@Setter
@ToString
public class ManagermentBrainDiseaselevelVo extends GchcVo
{
	@ApiModelProperty(value="유저 UID", example = "56790")
	private Integer uid;

	@ApiModelProperty(value="조회할 연도", example = "2020")
	private String yr;
}
