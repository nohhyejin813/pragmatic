package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Getter
@Setter
public class BatchUploadMultiFamilyExcelModel extends UstraManagementBaseModel {

	@UstraExcelCellInfo(col = 0, header = "임직원이름", required = false)
	private String aempNm;

	@UstraExcelCellInfo(col = 1, header = "사번", required = false)
	private String aempId;

	@UstraExcelCellInfo(col = 2, header = "가족이름1", required = false)
	private String fmlyNm1;

	@UstraExcelCellInfo(col = 3, header = "가족생년월일1", required = false)
	private String fmlyBrdt1;

	@UstraExcelCellInfo(col = 4, header = "가족이름2", required = false)
	private String fmlyNm2;

	@UstraExcelCellInfo(col = 5, header = "가족생년월일2", required = false)
	private String fmlyBrdt2;

	@UstraExcelCellInfo(col = 6, header = "가족이름3", required = false)
	private String fmlyNm3;

	@UstraExcelCellInfo(col = 7, header = "가족생년월일3", required = false)
	private String fmlyBrdt3;

	@UstraExcelCellInfo(col = 8, header = "가족이름4", required = false)
	private String fmlyNm4;

	@UstraExcelCellInfo(col = 9, header = "가족생년월일4", required = false)
	private String fmlyBrdt4;

	@UstraExcelCellInfo(col = 10, header = "가족이름5", required = false)
	private String fmlyNm5;

	@UstraExcelCellInfo(col = 11, header = "가족생년월일5", required = false)
	private String fmlyBrdt5;

	@UstraExcelCellInfo(col = 12, header = "가족이름6", required = false)
	private String fmlyNm6;

	@UstraExcelCellInfo(col = 13, header = "가족생년월일6", required = false)
	private String fmlyBrdt6;

	@UstraExcelCellInfo(col = 14, header = "가족이름7", required = false)
	private String fmlyNm7;

	@UstraExcelCellInfo(col = 15, header = "가족생년월일7", required = false)
	private String fmlyBrdt7;

	@UstraExcelCellInfo(col = 16, header = "가족이름8", required = false)
	private String fmlyNm8;

	@UstraExcelCellInfo(col = 17, header = "가족생년월일8", required = false)
	private String fmlyBrdt8;

	@UstraExcelCellInfo(col = 18, header = "가족이름9", required = false)
	private String fmlyNm9;

	@UstraExcelCellInfo(col = 19, header = "가족생년월일9", required = false)
	private String fmlyBrdt9;

	@UstraExcelCellInfo(col = 20, header = "가족이름10", required = false)
	private String fmlyNm10;

	@UstraExcelCellInfo(col = 21, header = "가족생년월일10", required = false)
	private String fmlyBrdt10;
}
