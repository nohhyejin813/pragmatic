package com.gchc.ncu.bo.care.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
public class MindCardVo extends UstraManagementBaseModel {

	private String midCardId;
	private Integer affiYn;
	private Integer useYn;

}
