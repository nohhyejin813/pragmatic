package com.gchc.ncu.bo.challenge.reward.processor;

import com.gchc.ncu.bo.batchupload.comm.BatchException;
import com.gchc.ncu.bo.batchupload.exception.BatchRestResult;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.challenge.reward.service.RewardService;
import com.gsitm.ustra.java.data.file.processor.convert.ExcelDataPostProcessor;
import com.gsitm.ustra.java.data.file.processor.convert.ExcelFileToDataProcessConverter.Option;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component("rewardUploadProcessor")
public class RewardUploadProcessor implements ExcelDataPostProcessor<Map<String, Object>> {

	@Autowired
	private RewardService service;

	@Override
	public Object doProcess(Option<Map<String, Object>> option, List<Map<String, Object>> excelReadDatas, List<RowInfo> converted) {
			Map<String, String> params = BatchUploadUtils.parseParameter(option.getExcelDataPostProcessorParameter());

			// 보상방식코드
			int cmpgId = Integer.parseInt(params.get("cmpgId"));

			try {
				// 파일 업로드
				return service.uploadReward(converted, cmpgId);
			}catch( BatchException e ){
				LOGGER.debug(ExceptionUtils.getStackTrace(e));
				return BatchRestResult.of(e.getCode(), e.getMessage());
			}
	}
}
