package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.CampaignColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.repository.BatchCampaignUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @FileName : BatchCampaignUploadService.java
 * @date : 2023. 02. 01
 * @author : hykim
 * @프로그램 설명 : 부가정보변경 일괄업로드 Service
 * @변경이력 :
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class BatchCampaignUploadService {

	private final BatchCampaignUploadRepository repository;

	/**
	 * 양식 다운로드
	 */
	public List<BatchCampaignExcelModel> getSampleDownloadExcel() {
		return Arrays.asList(new BatchCampaignExcelModel());
	}

	/**
	 * 부가정보 일괄업로드 처리.
	 */
	@Transactional
	public BatchCampaignUploadResultModel uploadCampaign(List<RowInfo> converted, Integer clcoId, Integer yr, Integer uploadFlag) {

		// 헤더 체크
		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();

		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

		String missed = BatchUploadColumn.stream(CampaignColumn.class)
			.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
			.findFirst()
			.map(BatchUploadColumn::getTitle)
			.orElse(null);
		if( StringUtils.isNotEmpty(missed) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

		// 빈 ROW 삭제 및 값 설정
		List<BatchUploadCampaignExcelModel> updateList = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
			.map(r->{
				BatchUploadCampaignExcelModel c = BatchUploadUtils.map(
					(Map<String, Object>)r.getObject(), headerRow,
					BatchUploadColumn.table(CampaignColumn.class), BatchUploadCampaignExcelModel.class);
				return c;
			})
			.filter(c->!isEmptyRow(c))
			.collect(Collectors.toList());

		// 중복값 처리
		Set<String> set = new HashSet<String>();
		for (int i = 0; i < updateList.size(); i++) {
			for (int j = 0; j < i; j++) {
				// 중복 검사
				if (updateList.get(i).getAempId().equals(updateList.get(j).getAempId())) {
					set.add(String.valueOf(updateList.get(i).getAempId()));
					break;
				}
			}
		}

		// HashSet to List
		List<String> aempIdList = new ArrayList<>(set);

		int totalCount 	= 0;	// 전체 업로드 건수
		int normalCount = 0;	// 수정 등록 건수
		int errorCount 	= 0;	// 오류 건수

		totalCount = updateList.size();

		List<Map<String, Object>> errList = new ArrayList<Map<String, Object>>();

		BatchCampaignUploadResultModel model = new BatchCampaignUploadResultModel();

		String frstRegrTyCd = model.getFrstRegrTyCd();	// 최초등록자유형코드
		String frstRegrId 	= model.getFrstRegrId();	// 최초등록자아이디
		String lastUpdrTyCd = model.getLastUpdrTyCd();	// 최종수정자아이디
		String lastUpdrId 	= model.getLastUpdrId();	// 최종수정자유형코드
		String errMsg 		= "";						// 오류내용

		// 근골격계 or 캠페인팀 업로드
		for ( int i = 0 ; i < updateList.size(); i++ ){
			String clcoNm		= updateList.get(i).getClcoNm();		// 고객사
			String aempNm		= updateList.get(i).getAempNm();		// 이름
			String empno		= updateList.get(i).getAempId();		// 사번
			String workDeptNm 	= updateList.get(i).getWorkDeptNm();	// 근무부서
			String lineNm 		= updateList.get(i).getLineNm();		// 라인
			String jobNm 		= updateList.get(i).getJobNm();			// 작업
			String teamNm 		= updateList.get(i).getTeamNm();		// 캠페인팀

			String erronYn = "N";

			for ( int k = 0 ; k < aempIdList.size(); k++ ){

				String tempEmpno = String.valueOf(aempIdList.get(k));

				if( tempEmpno.equals(empno)){
					erronYn = "Y";
				}
			}

			if( "Y".equals(erronYn) ){

				errorCount++;

				HashMap<String, Object> result = new HashMap<>();

				errMsg = "중복된 사번 입니다.";

				result.put("clcoNm"		, clcoNm		);
				result.put("aempNm"		, aempNm		);
				result.put("aempId"		, empno			);
				result.put("workDeptNm"	, workDeptNm	);
				result.put("lineNm"		, lineNm		);
				result.put("jobNm"		, jobNm			);
				result.put("teamNm"		, teamNm		);
				result.put("errMsg"		, errMsg		);

				errList.add(result);

				continue;
			}

			HashMap<String, Object> param = new HashMap<>();

			param.put("clcoId"		, clcoId		);
			param.put("yr"			, yr			);
			param.put("empno"		, empno			);
			param.put("workDeptNm"	, workDeptNm	);
			param.put("lineNm"		, lineNm		);
			param.put("jobNm"		, jobNm			);
			param.put("teamNm"		, teamNm		);
			param.put("frstRegrTyCd", frstRegrTyCd	);
			param.put("frstRegrId"	, frstRegrId	);
			param.put("lastUpdrTyCd", lastUpdrTyCd	);
			param.put("lastUpdrId"	, lastUpdrId	);

			// uploadFlag: 0 근골격계, 1 캠페인팀
			if( uploadFlag == 0 ){
				/** 근골격계 **/
				param.put("clcoId"		, clcoId		);
				param.put("yr"			, yr			);
				param.put("empno"		, empno			);
				param.put("workDeptNm"	, workDeptNm	);
				param.put("lineNm"		, lineNm		);
				param.put("jobNm"		, jobNm			);
				param.put("frstRegrTyCd", frstRegrTyCd	);
				param.put("frstRegrId"	, frstRegrId	);
				param.put("lastUpdrTyCd", lastUpdrTyCd	);
				param.put("lastUpdrId"	, lastUpdrId	);

				// 근무부서 등록여부
				int workDeptNmCnt = repository.getCmpgWorkDeptNmRegYn(param);

				if( workDeptNmCnt == 0  ){
					// 근무부서 등록
					repository.insertCmpgWorkDeptNm(param);
				}

				// 라인 등록여부
				int lineCnt = repository.getCmpgLineRegYn(param);

				if( lineCnt == 0 ){
					// 라인등록
					repository.insertCmpgLine(param);
				}

				// 작업 등록여부
				int jobCnt = repository.getCmpgJobRegYn(param);

				if( jobCnt == 0 ){
					// 작업등록
					repository.insertCmpgJob(param);
				}

				// 검진대상내역확인
				String uid = repository.getCuTgtHisYn(param);

				if( !"".equals(uid) && uid != null ){
					param.put("uid", uid);

					// 회원근골격부서내역등록여부
					int cmpgMbrMuscDeptHisCnt = repository.getCmpgMbrMuscDeptHisYn(param);

					if( cmpgMbrMuscDeptHisCnt == 0 ){
						repository.insertCmpgMbrMuscDeptHis(param);
					}else{
						repository.updateCmpgMbrMuscDeptHis(param);
					}
					normalCount++;

				}else{
					errorCount++;

					HashMap<String, Object> result = new HashMap<>();

					errMsg = "유효한 사번이 아닙니다.";

					result.put("clcoNm"		, clcoNm		);
					result.put("aempNm"		, aempNm		);
					result.put("aempId"		, empno			);
					result.put("workDeptNm"	, workDeptNm	);
					result.put("lineNm"		, lineNm		);
					result.put("jobNm"		, jobNm			);
					result.put("teamNm"		, teamNm		);
					result.put("errMsg"		, errMsg		);

					errList.add(result);
				}
			}else{
				/** 걷기캠페인-팀전 **/

				// 고객사팀기본 등록여부
				int teamIdCnt = repository.getClcoTeamBscRegYn(param);

				// 고객사팀기본 등록
				if( teamIdCnt == 0 ){
					repository.insertClcoTeamBsc(param);
				}

				// 회원고객사관계 팀아이디 변경
				int successCnt = repository.updateCmpgTeamId(param);

				if( successCnt == 0 ){
					errorCount++;

					HashMap<String, Object> result = new HashMap<>();

					errMsg = "유효한 사번이 아닙니다.";

					result.put("clcoNm"		, clcoNm		);
					result.put("aempNm"		, aempNm		);
					result.put("aempId"		, empno			);
					result.put("workDeptNm"	, workDeptNm	);
					result.put("lineNm"		, lineNm		);
					result.put("jobNm"		, jobNm			);
					result.put("teamNm"		, teamNm		);
					result.put("errMsg"		, errMsg		);

					errList.add(result);

				}else{
					normalCount++;
				}
			}
		}

		model.setErrorList(errList);		// 오류목록
		model.setTotalCount(totalCount);	// 전체건수
		model.setNormalCount(normalCount);	// 수정등록건수
		model.setErrorCount(errorCount);	// 오류건수
		model.setSuccess("0000");			// 성공여부

		return model;
	}

	/**
	 * NULL행 체크
	 */
	boolean isEmptyRow(BatchUploadCampaignExcelModel c) {
		return StringUtils.isEmpty(c.getClcoNm()) && StringUtils.isEmpty(c.getAempNm()) && StringUtils.isEmpty(c.getAempId());
	}
}
