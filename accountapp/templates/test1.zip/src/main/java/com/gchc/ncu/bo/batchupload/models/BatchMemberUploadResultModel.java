package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchMemberUploadResultModel {

	Integer totalCnt;

	Integer normalCnt;

	Integer newCnt;

	Integer errorCnt;

	Integer dupCnt;

	Integer dmcyCnt;

	Integer missingCnt;

	Integer etcCnt;

	boolean regOptnYn1;

	boolean regOptnYn2;

	String regDvVal;
}
