package com.gchc.ncu.bo.assessment.models;

import java.util.Date;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentStatusModel extends UstraManagementBaseModel {
	/* T_EASY_CUI_ASM_MNG_BSC [헬스케어_검진이지검진기관평가관리기본] */

	private int			cuiAsmId; 		//검진기관평가아이디
	private String		yr; 			//년도
	private String		asmSrtDt; 		//평가시작일자
	private String		asmEndDt; 		//평가종료일자
	private boolean		qstnRegCmplYn; 	//문항등록완료여부
	private boolean		wholCuiTgtYn; 	//전체검진기관대상여부
	private String		slctCuiLstCont; //선택검진기관목록내용
	private String[]	cuiIdList; 		//선택검진기관목록내용

	private int			delYn; 			//삭제여부
	private String 		frstRegDtm; 	//최초등록일시
	private String 		frstRegrTyCd; 	//최초등록자유형코드
	private String 		frstRegrId; 	//최초등록자아이디
	private String 		lastUpdDtm; 	//최종수정일시
	private String 		lastUpdrTyCd;	//최종수정자유형코드
	private String 		lastUpdrId;		//최종수정자아이디

}
