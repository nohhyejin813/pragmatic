package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.NrsnClsfBscModel;
import com.gchc.ncu.bo.care.repository.PainSymptomTypeRepository;
import com.gchc.ncu.bo.care.vo.PainSymptomTypeVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PainSymptomTypeService {

	private final PainSymptomTypeRepository symptomTypeRepository;

	public List<NrsnClsfBscModel> getSymptomTypeList(PainSymptomTypeVo criteria) {
		return symptomTypeRepository.selectSymptomTypeList(criteria);
	}

	public NrsnClsfBscModel getSymptomTypeDetail(NrsnClsfBscModel criteria) {
		return symptomTypeRepository.selectSymptomTypeDetail(criteria);
	}

	@Transactional
	public void saveSymptomType(NrsnClsfBscModel model) {
		if (StringUtils.isEmpty(model.getNrsnClsfId())) {
			symptomTypeRepository.insertSymptomType(model);
		} else {
			symptomTypeRepository.updateSymptomType(model);
		}
	}

	@Transactional
	public void deleteSymptomType(List<NrsnClsfBscModel> list) {
		if (list != null) {
			for (NrsnClsfBscModel model : list) {
				if (symptomTypeRepository.selectUsedSymptomTypeCount(model) > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "이미 사용 중인 항목입니다.[" + model.getNrsnClsfNm() + "]");
				}

				symptomTypeRepository.deleteSymptomType(model);
			}
		}
	}

}
