package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.ResignationColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.BatchResignationExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchResignationUploadResultModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadResignationExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadTgtrModel;
import com.gchc.ncu.bo.batchupload.repository.BatchResignationUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.member.models.MemberClcoRltnModel;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @FileName : BatchCampaignUploadService.java
 * @date : 2023. 02. 01
 * @author : hykim
 * @프로그램 설명 : 부가정보변경 일괄업로드 Service
 * @변경이력 :
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class BatchResignationUploadService {

	private final BatchResignationUploadRepository repository;

	/**
	 * 양식 다운로드
	 */
	public List<BatchResignationExcelModel> getSampleDownloadExcel() {
		return Arrays.asList(new BatchResignationExcelModel());
	}

	/**
	 * 퇴사정보 일괄업로드 처리
	 */
	@Transactional
	public BatchResignationUploadResultModel uploadResignation(List<RowInfo> converted, Integer clcoId, Integer yr, Integer uploadFlag) {
		// 헤더 체크
		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();

		SimpleDateFormat dtFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat newDdtFormat = new SimpleDateFormat("yyyy-MM-dd");

		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

		String missed = BatchUploadColumn.stream(ResignationColumn.class)
				.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
				.findFirst()
				.map(BatchUploadColumn::getTitle)
				.orElse(null);
		if( StringUtils.isNotEmpty(missed) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

		// 빈 ROW 삭제 및 값 설정
		List<BatchUploadResignationExcelModel> updateList = converted.subList(1, converted.size()).stream()
				.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
				.map(r->{
					BatchUploadResignationExcelModel c = BatchUploadUtils.map(
							(Map<String, Object>)r.getObject(), headerRow,
							BatchUploadColumn.table(ResignationColumn.class), BatchUploadResignationExcelModel.class);
					return c;
				})
				.filter(c->!isEmptyRow(c))
				.collect(Collectors.toList());

		int totalCount 	= 0;	// 전체 업로드 건수
		int normalCount = 0;	// 정상 등록 건수
		int errorCount 	= 0;	// 오류 건수

		totalCount = updateList.size();

		//정상 리스트
		List<Map<String, Object>> normalList = new ArrayList<Map<String, Object>>();

		//오류 리스트
		List<Map<String, Object>> errList = new ArrayList<Map<String, Object>>();

		BatchResignationUploadResultModel model = new BatchResignationUploadResultModel();

		String frstRegrTyCd = model.getFrstRegrTyCd();	// 최초등록자유형코드
		String frstRegrId 	= model.getFrstRegrId();	// 최초등록자아이디
		String lastUpdrTyCd = model.getLastUpdrTyCd();	// 최종수정자아이디
		String lastUpdrId 	= model.getLastUpdrId();	// 최종수정자유형코드
		String errMsg 		= "";	// 오류내용

		for ( int i = 0 ; i < updateList.size(); i++ ){

			String clcoNm		= updateList.get(i).getClcoNm();		// 고객사
			String aempNm		= updateList.get(i).getAempNm();		// 이름
			String empno		= updateList.get(i).getAempId();		// 사번

			HashMap<String, Object> param = new HashMap<>();

			param.put("clcoId"		, clcoId		);
			param.put("yr"			, yr			);
			param.put("empno"		, empno			);
			param.put("aempNm"		, aempNm		);
			param.put("frstRegrTyCd", frstRegrTyCd	);
			param.put("frstRegrId"	, frstRegrId	);
			param.put("lastUpdrTyCd", lastUpdrTyCd	);
			param.put("lastUpdrId"	, lastUpdrId	);

			// 고객사에 등록되어 있는 임직원인지 확인
			String uid = repository.getAempInformation(param);

			param.put("uid"	, uid);

			// #14875 퇴사자일괄반영기능 by 양재환 2023-05-25
			// 임직원 및 가족중 한명이라도 예약건이 있는 경우를 조회
			int resvCount = repository.getAempReservationCount(param);

			// 검진대상자 예약정보 조회
			List<BatchUploadTgtrModel> tgtrList = repository.getAempReservationInfo(param);

			// 예약정보가 있거나 예약정보가 없는 임직원 정보 조회
			BatchUploadTgtrModel aempInfoList = repository.getAempInfo(param);

			if (uid == null) {
				errorCount++;

				HashMap<String, Object> result = new HashMap<>();

				// #15823 [QA] 퇴사- 기존 퇴사반영자의 경우 오류 목록 문구 수정 요청 by 양재환 2023-06-20일
				errMsg = "해당 연도 고객사에 등록되어 있는 임직원이 아닙니다.";

				result.put("clcoNm"				, clcoNm			);					// 고객사명
				result.put("bsplNm"				, ""				);					// 사업장명
				result.put("mbrGrdNm"			, ""				);					// 등급명
				result.put("empNo"				, empno				);					// 사번
				result.put("tgtrNm"				, ""				);					// 검진대상자명
				result.put("tgtrbrdt"			, ""				);					// 검진대상자 생년월일
				result.put("aempNm"				, aempNm			);					// 임직원 이름
				result.put("aempBrdt"			, ""				);					// 임직원 생년월일
				result.put("corpSpfn"			, ""				);					// 회사 지원금
				result.put("pkgNm"				, ""				);					// 지원패키지명
				result.put("resvStCd"			, ""				);					// 예약상태
				result.put("cuiNm"				, ""				);					// 검진센터명
				result.put("pkgTyNm"			, ""				);					// 예약한패키지명
				result.put("cmplDtm"			, ""				);					// 검진 완료일
				result.put("resvFnlzDt"			, ""				);					// 예약 확정일
				result.put("tn1ResvApplDt"		, ""				);					// 1차 예약 신청일
				result.put("tn2ResvApplDt"		, ""				);					// 2차 예약 신청일
				result.put("frstResvDt"			, ""				);					// 예약 신청일
				result.put("firstaempNm"		, ""				);					// 직원명(최초)
				result.put("errMsg"				, errMsg);
				errList.add(result);
			}

			else if (!"".equals(uid) && uid != null) {

				int hffcStcd = repository.getAempHffcStcd(param);

				if (hffcStcd == 3){
					errorCount++;

					HashMap<String, Object> result = new HashMap<>();

					errMsg = "퇴직상태 임직원입니다.";

					result.put("clcoNm"				, clcoNm			);					// 고객사명
					result.put("bsplNm"				, ""				);					// 사업장명
					result.put("mbrGrdNm"			, ""				);					// 등급명
					result.put("empNo"				, empno				);					// 사번
					result.put("tgtrNm"				, ""				);					// 검진대상자명
					result.put("tgtrbrdt"			, ""				);					// 검진대상자 생년월일
					result.put("aempNm"				, aempNm			);					// 임직원 이름
					result.put("aempBrdt"			, ""				);					// 임직원 생년월일
					result.put("corpSpfn"			, ""				);					// 회사 지원금
					result.put("pkgNm"				, ""				);					// 지원패키지명
					result.put("resvStCd"			, ""				);					// 예약상태
					result.put("cuiNm"				, ""				);					// 검진센터명
					result.put("pkgTyNm"			, ""				);					// 예약한패키지명
					result.put("cmplDtm"			, ""				);					// 검진 완료일
					result.put("resvFnlzDt"			, ""				);					// 예약 확정일
					result.put("tn1ResvApplDt"		, ""				);					// 1차 예약 신청일
					result.put("tn2ResvApplDt"		, ""				);					// 2차 예약 신청일
					result.put("frstResvDt"			, ""				);					// 예약 신청일
					result.put("firstaempNm"		, ""				);					// 직원명(최초)
					result.put("errMsg"				, errMsg);
					errList.add(result);
				}

				// #14875 퇴사자일괄반영기능 by 양재환 2023-05-25
				// 임직원 포함 한명이라도 예약중이면 임직원, 가족 정보를 리스트로 뽑는다.
				else if (resvCount > 0) {
					// #15670 [QA] 가족이 예약신청 상태일때 임직원 일괄업로드로 퇴사시 정상 등록에 카운트 올라가는 오류 by 양재환 2023-06-13
					errorCount++;
					for (int j = 0 ; j < tgtrList.size(); j++) {
//						if (tgtrList.get(j).isSelfYn() == true) {
//							errorCount++;
//						}

						HashMap<String, Object> result = new HashMap<>();

						errMsg = tgtrList.get(j).getErrmsg();

						result.put("clcoNm"				, clcoNm							);		// 고객사명
						result.put("bsplNm"				, tgtrList.get(j).getBsplNm()		);		// 사업장명
						result.put("mbrGrdNm"			, tgtrList.get(j).getMbrGrdNm()		);		// 등급명
						result.put("empNo"				, empno								);		// 사번
						result.put("tgtrNm"				, tgtrList.get(j).getTgtrNm()		);		// 검진대상자명
						result.put("tgtrbrdt"			, tgtrList.get(j).getTgtrbrdt()		);		// 검진대상자 생년월일
						result.put("aempNm"				, aempNm							);		// 임직원 이름
						result.put("aempBrdt"			, tgtrList.get(j).getAempBrdt()		);		// 임직원 생년월일
						result.put("corpSpfn"			, tgtrList.get(j).getCorpSpfn()		);		// 회사 지원금
						result.put("pkgNm"				, tgtrList.get(j).getPkgNm()		);		// 지원패키지명
						result.put("resvStCd"			, tgtrList.get(j).getResvStCd()		);		// 예약상태
						result.put("cuiNm"				, tgtrList.get(j).getCuiNm()		);		// 검진센터명
						result.put("pkgTyNm"			, tgtrList.get(j).getPkgTyNm()		);		// 예약한패키지명
						result.put("cmplDtm"			, tgtrList.get(j).getCmplDtm()		);		// 검진 완료일
						result.put("resvFnlzDt"			, tgtrList.get(j).getResvFnlzDt()	);		// 예약 확정일
						result.put("tn1ResvApplDt"		, tgtrList.get(j).getTn1ResvApplDt());		// 1차 예약 신청일
						result.put("tn2ResvApplDt"		, tgtrList.get(j).getTn2ResvApplDt());		// 2차 예약 신청일
						result.put("frstResvDt"			, tgtrList.get(j).getFrstResvDt()	);		// 예약 신청일
						result.put("firstaempNm"		, tgtrList.get(j).getFirstaempNm()	);		// 직원명(최초)
						result.put("errMsg"				, errMsg);
						errList.add(result);
					}
				}
				// 정상 내용 리스트 추가
				else if (aempInfoList != null) {
					HashMap<String, Object> result = new HashMap<>();
					result.put("clcoNm"						, clcoNm							);    // 고객사명
					result.put("bsplNm"						, aempInfoList.getBsplNm()			);    // 사업장명
					result.put("mbrGrdNm"					, aempInfoList.getMbrGrdNm()		);    // 등급명
					result.put("empNo"						, empno								);    // 사번
					result.put("tgtrNm"						, aempInfoList.getTgtrNm()			);    // 검진대상자명
					result.put("tgtrbrdt"					, aempInfoList.getTgtrbrdt()		);    // 검진대상자 생년월일
					result.put("aempNm"						, aempNm							);    // 임직원 이름
					result.put("aempBrdt"					, aempInfoList.getAempBrdt()		);    // 임직원 생년월일
					result.put("corpSpfn"					, aempInfoList.getCorpSpfn()		);    // 회사 지원금
					result.put("pkgNm"						, aempInfoList.getPkgNm()			);    // 지원패키지명
					result.put("resvStCd"					, aempInfoList.getResvStCd()		);    // 예약상태
					result.put("cuiNm"						, aempInfoList.getCuiNm()			);    // 검진센터명
					result.put("pkgTyNm"					, aempInfoList.getPkgTyNm()			);    // 예약한패키지명
					result.put("cmplDtm"					, aempInfoList.getCmplDtm()			);    // 검진 완료일
					result.put("resvFnlzDt"					, aempInfoList.getResvFnlzDt()		);    // 예약 확정일
					result.put("tn1ResvApplDt"				, aempInfoList.getTn1ResvApplDt()	);    // 1차 예약 신청일
					result.put("tn2ResvApplDt"				, aempInfoList.getTn2ResvApplDt()	);    // 2차 예약 신청일
					result.put("frstResvDt"					, aempInfoList.getFrstResvDt()		);    // 예약 신청일
					result.put("firstaempNm"				, aempInfoList.getFirstaempNm()		);    // 직원명(최초)
					normalList.add(result);
					repository.updateAempResignation(param);
				}
			}
		}

		normalCount = totalCount - errorCount;

		model.setNormalList(normalList);	// 정상목록
		model.setErrorList(errList);		// 오류목록
		model.setTotalCount(totalCount);	// 전체건수
		model.setNormalCount(normalCount);	// 정상등록건수
		model.setErrorCount(errorCount);	// 오류건수
		model.setSuccess("0000");			// 성공여부

		return model;
	}

	/**
	 * 일괄퇴사 리스트 #13314 신한은행 퇴사자 일괄 반영 요청 건 by 양재환 2023-03-09
	 */
	public List<MemberClcoRltnModel> getAempRsntList() {
		// 일괄퇴사 리스트
		List<MemberClcoRltnModel> getAempRsntList = repository.getAempRsntList();
		return getAempRsntList;
	}

	/**
	 * #14875 퇴사자일괄반영기능 by 양재환 2023-05-03
	 */
	public List<MemberClcoRltnModel> getAempRsntList2(int clcoId) {
		// 일괄퇴사 리스트
		List<MemberClcoRltnModel> getAempRsntList = repository.getAempRsntList2(clcoId);
		return getAempRsntList;
	}

	/**
	 * NULL행 체크
	 */
	boolean isEmptyRow(BatchUploadResignationExcelModel c) {
		return StringUtils.isEmpty(c.getClcoNm()) && StringUtils.isEmpty(c.getAempNm()) && StringUtils.isEmpty(c.getAempId());
	}
}
