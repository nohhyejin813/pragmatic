package com.gchc.ncu.bo.batchupload.comm;

import java.util.List;

import com.gchc.ncu.bo.batchupload.models.BsplModel;

public class BusinessPlaceContextHolder {

	private static final ThreadLocal<List<BsplModel>> contextHolder = new ThreadLocal<List<BsplModel>>();


	public static List<BsplModel> get() {

		return contextHolder.get();
	}

	public static BsplModel get(String bsplNm) {

		return get().stream().filter(g->g.getBsplNm().equals(bsplNm)).findFirst().orElse(null);
	}

	public static void set(List<BsplModel> data) {

		contextHolder.set(data);
	}

	public static void clear() {

		if( get() != null )
			contextHolder.remove();
	}

	public static String getDefault() {

		if( get() != null ) {

			if( get().size() > 1 )
				return null;
			return get().stream().filter(b->b.getHdqtYn() == 1).findFirst().map(BsplModel::getBsplNm).orElse(null);
		}

		return null;
	}
}
