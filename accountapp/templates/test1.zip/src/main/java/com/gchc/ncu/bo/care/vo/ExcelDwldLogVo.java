package com.gchc.ncu.bo.care.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Map;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
public class ExcelDwldLogVo extends UstraManagementBaseModel {

	private Map<String, String> dwldInfo;

}
