package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
public class BatchUploadResignationExcelModel extends NcuModel {

	private String excelFileName; // 다운로드 엑셀 파일명

	private Integer yr;		// 기준년도
	private Integer clcoId;	// 고객사ID
	private Integer row;	// 행

	@UstraExcelCellInfo(col = 0, header = "고객사", required = false)
	private String clcoNm;

	@UstraExcelCellInfo(col = 1, header = "이름", required = false)
	private String aempNm;

	@UstraExcelCellInfo(col = 2, header = "사번", required = false)
	private String aempId;

	@UstraExcelCellInfo(col = 3, header = "퇴사일", required = false)
	private String rsntDate;

	// 오류
	private List<String> error;
	private Integer errorCnt;

}
