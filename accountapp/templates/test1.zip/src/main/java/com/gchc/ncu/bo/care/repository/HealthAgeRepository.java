package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.DssHzrdCausGuidBscModel;
import com.gchc.ncu.bo.care.models.DssHzrdRecsDtlModel;
import com.gchc.ncu.bo.care.models.DssHzrdRecsModel;
import com.gchc.ncu.bo.care.models.MbrHthAgRecsModel;
import com.gchc.ncu.bo.care.vo.HealthAgeVo;

@Mapper
public interface HealthAgeRepository {

	List<MbrHthAgRecsModel> selectHealthAgeHisList(HealthAgeVo in);
	List<DssHzrdRecsModel> selectDiseaseRiskList(HealthAgeVo in);
	List<DssHzrdRecsDtlModel> selectDiseaseRiskDtl(HealthAgeVo in);

	List<DssHzrdCausGuidBscModel> selectBaseInfoList();

	int updateBaseInfo(DssHzrdCausGuidBscModel model);

}
