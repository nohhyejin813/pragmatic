package com.gchc.ncu.bo.care.models;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class SrvyQstThmAreaDtlModel {


	private Integer srvyQstThmAreaId;
	private Integer srvyId;
	private String thmAreaTitl;
	private String uprGuidCont;
	private String lwrnGuidCont;
	private Integer thmExpoOrd;

}
