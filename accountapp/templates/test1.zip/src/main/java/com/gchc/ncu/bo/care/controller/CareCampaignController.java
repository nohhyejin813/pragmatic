package com.gchc.ncu.bo.care.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.CmpgBscModel;
import com.gchc.ncu.bo.care.models.CmpgCmpnDtlModel;
import com.gchc.ncu.bo.care.models.CmpgCtraBscModel;
import com.gchc.ncu.bo.care.models.CmpgNtfcBscModel;
import com.gchc.ncu.bo.care.models.CmpgNtfcDtlModel;
import com.gchc.ncu.bo.care.models.CmpgTeamRecsModel;
import com.gchc.ncu.bo.care.models.MbrCmpgRecsModel;
import com.gchc.ncu.bo.care.service.CareCampaignService;
import com.gchc.ncu.bo.care.service.CareCommApiService;
import com.gchc.ncu.bo.care.vo.CareCampaignVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/care/campaign")
public class CareCampaignController {

	private final CareCampaignService campaignService;
	private final CareCommApiService careCommApiService;

	@GetMapping("/contract/list")
	public List<CmpgCtraBscModel> getCampaignContractList(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getCampaignContractList(vo);
	}

	@GetMapping("/contract/detail")
	public CmpgCtraBscModel getCampaignContract(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getCampaignContract(vo);
	}

	@PostMapping("/contract/save")
	public RestResult<?> setCampaignContract(@RequestBody CmpgCtraBscModel model) {
		campaignService.setCampaignContract(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/contract/remove")
	public RestResult<?> removeCampaignContract(@RequestBody List<CmpgCtraBscModel> models) {
		campaignService.removeCampaignContract(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/contract/term/list")
	public List<CmpgBscModel> getContractTermList(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getContractTermList(vo);
	}

	@PostMapping("/contract/term/save")
	public RestResult<?> setCampaignContractTerm(@RequestBody List<CmpgBscModel> models) {
		campaignService.setCampaignContractTerm(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/contract/notice/list")
	public List<CmpgNtfcDtlModel> getContractNoticeList(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getContractNoticeList(vo);
	}

	@PostMapping("/contract/notice/save")
	public RestResult<?> setCampaignContractNotice(@RequestBody List<CmpgNtfcDtlModel> models) {
		campaignService.setCampaignContractNotice(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/reward/list")
	public List<CmpgCmpnDtlModel> getCampaignRewardList(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getCampaignRewardList(vo);
	}

	@PostMapping("/reward/save")
	public RestResult<?> setCampaignReward(@RequestBody List<CmpgCmpnDtlModel> models) {
		campaignService.setCampaignReward(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/reward/member/list")
	public List<MbrCmpgRecsModel> getCampaignRewardMemberList(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getCampaignRewardMemberList(vo);
	}

	@PostMapping("/reward/confirm")
	public RestResult<?> setCampaignRewardConfirm(@RequestBody CareCampaignVo vo) {
		campaignService.setCampaignRewardConfirm(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/reward/cancel")
	public RestResult<?> setCampaignRewardCancel(@RequestBody CareCampaignVo vo) {
		campaignService.setCampaignRewardCancel(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/reward/prize")
	public RestResult<?> setCampaignRewardPrize(@RequestBody List<MbrCmpgRecsModel> models) {
		campaignService.setCampaignRewardPrize(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/operation-management/list")
	public List<CmpgBscModel> getOperManagementList(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperManagementList(vo);
	}

	@GetMapping("/operation-management/detail")
	public CmpgBscModel getOperManagementDetail(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperManagementDetail(vo);
	}

	@GetMapping("/operation-management/detail-people")
	public List<MbrCmpgRecsModel> getOperManagementPeople(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperManagementPeople(vo);
	}

	@GetMapping("/operation-management/noenter-people")
	public List<MbrCmpgRecsModel> getOperNoenterPeople(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperNoenterPeople(vo);
	}

	@GetMapping("/operation-management/person-detail")
	public List<MbrCmpgRecsModel> getOperPersonDetail(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperPersonDetail(vo);
	}

	@GetMapping("/operation-management/campaign-reset")
	public RestResult<?> getCampaignReset(@ModelAttribute CareCampaignVo vo) {
		campaignService.getCampaignReset(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/notice/list")
	public List<CmpgNtfcBscModel> getCampaignNoticeList(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getCampaignNoticeList(vo);
	}

	@GetMapping("/notice/detail")
	public CmpgNtfcBscModel getCampaignNotice(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getCampaignNotice(vo);
	}

	@PostMapping("/notice/save")
	public RestResult<?> setCampaignNotice(@RequestBody CmpgNtfcBscModel model) {
		campaignService.setCampaignNotice(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/notice/remove")
	public RestResult<?> removeCampaignNotice(@RequestBody List<CmpgNtfcBscModel> models) {
		campaignService.removeCampaignNotice(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/batch/sendMsg")
	public RestResult<?> batchCareCampaignSendMsg() {
		RestResult<Map<String, Integer>> retMap = careCommApiService.batchCareCampaignSendMsg();
		return GchcRestResult.of(retMap);
	}

	@GetMapping("/operation-management/detail-team")
	public List<CmpgTeamRecsModel> getOperationDetailTeam(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperationDetailTeam(vo);
	}

	@GetMapping("/operation-management/team-person-detail")
	public List<CmpgTeamRecsModel> getOperTeamPersonDetail(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperTeamPersonDetail(vo);
	}

	@PostMapping("/operation-management/team-info-update")
	public RestResult<?> setTeamInfoUpdate(@RequestBody CareCampaignVo vo) {
		campaignService.setTeamInfoUpdate(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/operation-management/detail-team-count")
	public CmpgBscModel getOperationTeamCount(@ModelAttribute CareCampaignVo vo) {
		return campaignService.getOperationTeamCount(vo);
	}

	@PostMapping("/restriction/insert")
	public RestResult<?> insertRestriction(@RequestBody CareCampaignVo vo) {
		campaignService.insertRestriction(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/restriction/delete")
	public RestResult<?> deleteRestriction(@RequestBody CareCampaignVo vo) {
		campaignService.deleteRestriction(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
