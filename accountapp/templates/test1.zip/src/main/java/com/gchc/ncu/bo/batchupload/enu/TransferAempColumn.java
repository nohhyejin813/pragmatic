package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum TransferAempColumn implements BatchUploadColumn {

	AEMP_NM("임직원이름", "AempNm"),

	AEMP_CU_GRD_NM("임직원등급", "AempGrdNm"),

	AEMP_ID("임직원사번", "AempId"),

	TNSF_YN("양도여부", "TnsfYn"),

	SPFN_TNSF_GRP_NM("양도그룹명", "SpfnTnsfGrpNm"),

	SLCT_SPFN_USE_YN("선택여부", "SlctSpfnUseYn"),

	SLCT_SPFN_SUPT_SLCT_GRP_NM("선택그룹명", "SlctSpfnSuptSlctGrpNm"),

	MLTI_YN("다중여부", "MltiYn"),

	PKG_NM("다중검진패키지", "PkgNm"),

	CORP_SPFN("다중지원금", "CorpSpfn"),

	MLTI_SLCT_TGTR_CNT("다중지원자수", "MltiSlctTgtrCnt"),

	FMLY_GRD_NM("가족등급", "FmlyGrdNm"),

	AEMP_DTL_REG_SEQ("MemberID", "AempDtlRegSeq")

	;

	String title;

	String field;

	TransferAempColumn(String title, String field) {

		this.title=  title;
		this.field = field;
	}
}
