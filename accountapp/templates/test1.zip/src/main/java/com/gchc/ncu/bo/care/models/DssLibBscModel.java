package com.gchc.ncu.bo.care.models;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DssLibBscModel extends UstraManagementBaseModel {

	private Integer dssLibId;
	private String dssNm;
	private String dssDfinCont;
	private String dssCausCont;
	private String dssSxCont;
	private String dssTxCont;
	private String dssDiagMthCont;
	private String dssLifeGuidCont;
	private String dssFaqCont;
	private String dssRelInfCont;

}
