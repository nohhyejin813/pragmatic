package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.AltActMsnBscModel;
import com.gchc.ncu.bo.care.service.DailyAltActivityService;
import com.gchc.ncu.bo.care.vo.DailyAltActivityVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/bo/care/daily/alt-activity")
@RequiredArgsConstructor
@Slf4j
public class DailyAltActivityController {

	private final DailyAltActivityService dailyAltActivityService;

	@GetMapping("/list")
	public List<AltActMsnBscModel> list(@ModelAttribute DailyAltActivityVo criteria) {
		return dailyAltActivityService.getDailyAltActivityList(criteria);
	}

	@GetMapping("/detail")
	public AltActMsnBscModel detail(@ModelAttribute AltActMsnBscModel criteria) {
		LOGGER.debug("care > activity > mission > getDetail");

		return dailyAltActivityService.getDailyAltActivityDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid AltActMsnBscModel model) {
		dailyAltActivityService.saveDailyAltActivity(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<AltActMsnBscModel> list) {
		dailyAltActivityService.deleteDailyAltActivity(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
