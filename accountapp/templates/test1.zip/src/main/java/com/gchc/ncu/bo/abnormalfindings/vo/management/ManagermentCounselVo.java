package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.gchc.common.model.GchcPageableVo;


/**
 * 유소견 상담 조회
 * @FileName : AbnormalFindingsCounselVo.java
 * @date : 2021. 8. 17
 * @author : spm
 * @프로그램 설명 :
 * @변경이력 :
 */

@Data
@Builder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentCounselVo extends GchcPageableVo{

	@ApiModelProperty(value="유저 UID")
	private Integer uid;

	@ApiModelProperty(value="고객사 아이디", example = "170")
	private Integer clcoId;

	private Integer deptId;

	@ApiModelProperty(value="", example = "1")
	private Integer isUbcareManager;

	@ApiModelProperty(value="", example = "1")
	private Integer abnfMngClco;


	@ApiModelProperty(value="연도", example = "2019")
	private String yr;


	@ApiModelProperty(value="검진 시작 일자", example = "2019-01-01") //CHECKUP_FROM_DATE
	private String cuFromDt;

	@ApiModelProperty(value="검진 종료 일자", example = "2019-12-31") //CHECKUP_TO_DATE
	private String cuToDt;


	@ApiModelProperty(value="상담 시작 일자", example = "20200819") //CONSULT_TO_DATE
	private String cnslFromDt;


	@ApiModelProperty(value="상담 종료 일자", example = "20210819") //CHECKUP_FROM_DATE
	private String cnslToDt;


	@ApiModelProperty(value="사업장 아이디", example="-1")
	private Integer bsplId;




	@ApiModelProperty(value="상담 제목")
	private Integer cnslTitl;


	@ApiModelProperty(value="상담 메모")
	private Integer abnfCnslMemo;



	@ApiModelProperty(value="구분값", example = "1")
	private Integer ty; //GUNBUN

	@ApiModelProperty(value="검색어")
	private String search; //검색어



	@ApiModelProperty(value="", example="1")
	private Integer status;




	@ApiModelProperty(value="관리자 아이디", example="-1")
	private Integer mngrId;

	@ApiModelProperty(value="다운로드 메모")
	private String dwldMemo;

	@ApiModelProperty(value="다운로드 사유코드")
	private String dwldRsnCd;

	@ApiModelProperty(value="다운로드 접근경로")
	private String dwldPageUrl;
}

