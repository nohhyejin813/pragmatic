package com.gchc.ncu.bo.care.models;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class SrvyBscModel {


	private Integer srvyId;
	private String srvyTyCd;
	private String srvyUtlzTskCd;
	private String srvyDwupStCd;
	private String srvyExpoTgtCd;
	private Integer srvyExpoTgtWholYn;
	private String srvyExpoSysDvCd;
	private String srvyTitl;
	private String srvyGuidCont;
	private Integer srvyPridRstrYn;
	private String srvySrtDt;
	private String srvyEndDt;
	private Integer useYn;
	private Integer srvyMngCuiId;
	private Integer srvyUtlzTskRelaKvl;
}
