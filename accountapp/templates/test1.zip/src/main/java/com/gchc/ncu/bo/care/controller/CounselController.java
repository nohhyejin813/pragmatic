package com.gchc.ncu.bo.care.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.MidCnslApplBscModel;
import com.gchc.ncu.bo.care.models.MidCnslCtraBscModel;
import com.gchc.ncu.bo.care.models.MidCnslTmcBscModel;
import com.gchc.ncu.bo.care.service.CareCommApiService;
import com.gchc.ncu.bo.care.service.CareCommonService;
import com.gchc.ncu.bo.care.service.CounselService;
import com.gchc.ncu.bo.care.vo.CounselVo;
import com.gchc.ncu.bo.care.vo.ExcelDwldLogVo;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/counsel")
@RequiredArgsConstructor
public class CounselController {

	private final CounselService counselService;
	private final CareCommonService careCommonService;
	private final CareCommApiService apiService;

	private final FileOperationManager fileOperationManager;

	@GetMapping("/schedule/list")
	public List<MidCnslTmcBscModel> getScheduleList(@ModelAttribute CounselVo criteria) {
		return counselService.getScheduleList(criteria);
	}

	@GetMapping("/schedule/detail")
	public MidCnslTmcBscModel getSchedule(@ModelAttribute MidCnslTmcBscModel criteria) {
		return counselService.getSchedule(criteria);
	}

	@PostMapping("/schedule/save")
	public RestResult<?> setSchedule(@RequestBody @Valid MidCnslTmcBscModel model) {
		counselService.setSchedule(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/schedule/remove")
	public RestResult<?> removeSchedule(@RequestBody List<MidCnslTmcBscModel> list) {
		counselService.removeSchedule(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/contract/list")
	public List<MidCnslCtraBscModel> getContractList(@ModelAttribute CounselVo criteria) {
		return counselService.getContractList(criteria);
	}

	@GetMapping("/contract/detail")
	public MidCnslCtraBscModel getContract(@ModelAttribute MidCnslCtraBscModel criteria) {
		return counselService.getContract(criteria);
	}

	@PostMapping("/contract/save")
	public RestResult<?> setContract(@RequestBody @Valid MidCnslCtraBscModel model) {
		counselService.setContract(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/contract/remove")
	public RestResult<?> removeContract(@RequestBody List<MidCnslCtraBscModel> list) {
		counselService.removeContract(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/application/list")
	public List<MidCnslApplBscModel> getApplicationList(@ModelAttribute CounselVo criteria) {
		return counselService.getApplicationList(criteria, true);
	}

	@PostMapping("/application/status/update")
	public RestResult<?> setApplicationStatus(@RequestBody @Valid List<MidCnslApplBscModel> list) {
		counselService.setApplicationStatus(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/application/check/conflict")
	public RestResult<Boolean> checkApplicationConflict(@RequestBody MidCnslApplBscModel model) {
		return GchcRestResult.of(counselService.checkApplicationConflict(model));
	}

	@PostMapping("/application/update")
	public RestResult<?> setApplication(@RequestBody @Valid MidCnslApplBscModel model) {
		counselService.setApplication(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/application/excel")
	public ResponseEntity<?> downloadApplicationExcel(HttpServletRequest request, HttpServletResponse response, @RequestBody CounselVo criteria) {
		ExcelDwldLogVo logVo = new ExcelDwldLogVo();
		logVo.setDwldInfo(criteria.getDwldInfo());

		careCommonService.setExcelDownloadLog(logVo);

		List<MidCnslApplBscModel> list = counselService.getApplicationList(criteria, false);

		return fileOperationManager.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(counselService.downloadApplicationExcel(list), counselService.downloadExcelDetail(criteria, list)), criteria.getDwldInfo().get("dwldPageNm") + ".xlsx", request, response)
				.build());
	}

	@PostMapping("/application/highRisk/excel")
	public ResponseEntity<?> downloadHighRiskExcel(HttpServletRequest request, HttpServletResponse response, @RequestBody CounselVo criteria) {
		return fileOperationManager.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(counselService.downloadHighRiskExcel(criteria)), criteria.getDwldInfo().get("dwldPageNm") + ".xlsx", request, response)
				.build());
	}

	@PostMapping("/guide")
	public RestResult<Integer> sendGuide(@RequestBody Integer[] contractIds) {
		int resultCount = 0;

		for (int id : contractIds) {
			resultCount += apiService.sendCounselGuide(id).getBody().get("SUCCESS");
		}

		return GchcRestResult.of(resultCount);
	}

	@GetMapping("/holiday/list")
	public List<String> getHolidayList() {
		return counselService.getHolidayList();
	}

	@PostMapping("/holiday/save")
	public RestResult<?> setHoliday(@RequestBody Map<String, Object> paramsMap) {
		counselService.setHoliday(paramsMap);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
