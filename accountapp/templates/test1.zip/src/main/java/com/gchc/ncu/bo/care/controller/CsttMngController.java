package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.CstmCuBscItmBscModel;
import com.gchc.ncu.bo.care.models.SsngCsttBscModel;
import com.gchc.ncu.bo.care.models.SsngCsttCuItmDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttUseDescDtlModel;
import com.gchc.ncu.bo.care.service.CsttMngService;
import com.gchc.ncu.bo.care.vo.CsttMngVo;

@RestController
@RequestMapping("/api/bo/care/constitution/mng")
@RequiredArgsConstructor
public class CsttMngController {

	private final CsttMngService MngService;

	@GetMapping("/base")
	public SsngCsttBscModel base(@ModelAttribute CsttMngVo criteria) {
		return MngService.getCsttMngBase(criteria);
	}

	@GetMapping("/searchDtl")
	public List<SsngCsttDtlModel> searchDtl(@ModelAttribute CsttMngVo criteria) {
		return MngService.searchDtl(criteria);
	}

	@GetMapping("/searchCuItemDtl")
	public List<SsngCsttCuItmDtlModel> searchCuItemDtl(@ModelAttribute CsttMngVo criteria) {
		return MngService.searchCuItemDtl(criteria);
	}

	@PostMapping("/saveBase")
	public RestResult<?> saveBase(@RequestBody SsngCsttBscModel model) {
		MngService.saveBase(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/saveDtlPop")
	public RestResult<?> saveDtlPop(@RequestBody SsngCsttDtlModel model) {
		MngService.saveDtlPop(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/detailDelete")
	public RestResult<?> deleteDetail(@RequestBody List<SsngCsttDtlModel> list) {
		MngService.deleteDetail(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/saveCuItm")
	public RestResult<?> saveCuItm(@RequestBody SsngCsttCuItmDtlModel model) {
		MngService.saveCuItm(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/deleteCuItm")
	public RestResult<?> deleteCuItm(@RequestBody List<SsngCsttCuItmDtlModel> list) {
		MngService.deleteCuItm(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/searchUseDescDtl")
	public List<SsngCsttUseDescDtlModel> searchUseDescDtl(@ModelAttribute CsttMngVo criteria) {
		return MngService.searchUseDescDtl(criteria);
	}

	@PostMapping("/saveUseDescDtl")
	public RestResult<?> saveUseDescDtl(@RequestBody SsngCsttUseDescDtlModel model) {
		MngService.saveUseDescDtl(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/deleteUseDescDtl")
	public RestResult<?> deleteUseDescDtl(@RequestBody List<SsngCsttUseDescDtlModel> list) {
		MngService.deleteUseDescDtl(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/searchCd")
	public List<CstmCuBscItmBscModel> searchCd() {
		return MngService.getSearchCd();
	}

}
