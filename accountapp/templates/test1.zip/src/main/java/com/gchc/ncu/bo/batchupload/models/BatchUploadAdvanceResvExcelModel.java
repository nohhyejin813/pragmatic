package com.gchc.ncu.bo.batchupload.models;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;


/**
 * @FileName : BatchUploadAdvanceResvExcelModel.java
 * @date : 2022. 06. 10
 * @author : 이광희
 * @프로그램 설명 : 선예약 일괄업로드 Service
 * @변경이력 :
 */

@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchUploadAdvanceResvExcelModel extends UstraManagementBaseModel {

	private String excelFileName; // 다운로드 엑셀 파일명

	private Integer yr;	// 기준년도
	private Integer clcoId;	// 고객사ID
	private String aempSexCd; // 성별
	private Integer row;


	/*임직원-필수정보*/
	@UstraExcelCellInfo(col = 0, header = "고객사코드", required = false)
	private String clcoCode;
	@UstraExcelCellInfo(col = 1, header = "임직원이름", required = false)
	private String aempNm;
	@UstraExcelCellInfo(col = 2, header = "임직원회사지원금", required = false)
	private String corpSpfnVal;
	@UstraExcelCellInfo(col = 3, header = "임직원등급", required = false)
	private String aempCuGrdNm;
	@UstraExcelCellInfo(col = 4, header = "임직원생년월일", required = false)
	private String aempBrdt;
	@UstraExcelCellInfo(col = 5, header = "임직원핸드폰번호", required = false)
	private String mblNo;


	/*임직원-선예약정보*/
	private String cuiNm;
	private String pkgNm;
	private String tn1ResvApplDt;
	private String tn1ResvTmcRngVal;
	private String tn2ResvApplDt;
	private String tn2ResvTmcRngVal;
	private String PkgTyNm;

	/*임직원-부가정보*/
	@UstraExcelCellInfo(col = 14, header = "임직원이메일", required = false)
	private String emlAdr;
	@UstraExcelCellInfo(col = 15, header = "임원여부(Y/N)", required = false)
	private String excuYn;
	@UstraExcelCellInfo(col = 16, header = "건강보험공단지원대상여부(Y/N)", required = false)
	private String nhicSuptTgtYn;
	@UstraExcelCellInfo(col = 17, header = "특수검진대상여부(Y/N)", required = false)
	private String spcuTgtYn;
	@UstraExcelCellInfo(col = 18, header = "특수물질(1차)", required = false)
	private String extrMttrNm1;
	@UstraExcelCellInfo(col = 19, header = "특수물질(2차)", required = false)
	private String extrMttrNm2;
	@UstraExcelCellInfo(col = 20, header = "부서", required = false)
	private String deptNm;
	@UstraExcelCellInfo(col = 21, header = "직급", required = false)
	private String jbgdNm;
	@UstraExcelCellInfo(col = 22, header = "사번", required = false)
	private String aempId;
	@UstraExcelCellInfo(col = 23, header = "직장전화", required = false)
	private String wrplTlno;
	@UstraExcelCellInfo(col = 24, header = "입사일", required = false)
	private String encmDt;
	@UstraExcelCellInfo(col = 25, header = "임직원비고", required = false)
	private String aempCmt;

	private String bsplNm;
	private Integer bsplId;

	/*가족-기본정보*/
	@UstraExcelCellInfo(col = 26, header = "가족이름", required = false)
	private String spsrNm;
	@UstraExcelCellInfo(col = 27, header = "가족등급", required = false)
	private String spsrCuGrdNm;
	@UstraExcelCellInfo(col = 28, header = "가족생년월일", required = false)
	private String spsrBrdt;
	@UstraExcelCellInfo(col = 29, header = "가족회사지원금", required = false)
	private String spsrCorpSpfn;
	@UstraExcelCellInfo(col = 30, header = "가족연락처", required = false)
	private String spsrNo;
	@UstraExcelCellInfo(col = 31, header = "가족비고", required = false)
	private String spsrCmt;


	/*가족-선예약정보*/
	private String spsrCuiNm;
	private String spsrPkgNm;
	private String tn1SpsrResvApplDt;
	private String tn1SpsrResvTmcRngVal;
	private String tn2SpsrResvApplDt;
	private String tn2SpsrResvTmcRngVal;
	private String spsrPkgTyNm;



	@UstraExcelCellInfo(col = 40, header = "임직원 등록 일련번호", required = false)
	private String aempRegSeq;

	// 오류
	private List<String> error;
	private Integer errorCnt;

	List<BatchUploadAdvanceResvSelectItemModel> slctItmList;
	List<BatchUploadAdvanceResvSelectItemModel> spsrSlctItmList;

}
