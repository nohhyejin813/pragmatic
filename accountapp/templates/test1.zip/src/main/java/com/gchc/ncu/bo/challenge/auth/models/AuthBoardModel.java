package com.gchc.ncu.bo.challenge.auth.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gchc.ncu.bo.comm.models.NcuModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;
import java.util.Map;

@Getter
@Setter
@ToString
public class AuthBoardModel extends NcuModel {

    private int uid;        // UID
    private int rn;         // NO
    private int cmpgId;     // 캠페인아이디
    private int postId;     // 게시글아이디
    private int clcoId;     // 고객사아이디
    private int bsplId;     // 사업장아이디
    private int ono;        // 차수
    private int rplyLvlCd;  // 댓글레벨코드

    private String crteYr;              // 기준년도
    private String chalCatCd;           // 챌린지카테고리코드
    private String catCd;               // 카테고리코드
    private String catNm;               // 카테고리명
    private String onoCd;               // 차수코드
    private String onoNm;               // 차수명
    private String dtlCd;               // 상세코드
    private String cdNm;                // 상세코드명
    private String chalThmNm;           // 챌린지주제명
    private String keywNm;              // 키워드명
    private String postCont;            // 내용
    private String totCnt;              // 인기수
    private String goodCnt;             // 응원해요수
    private String vwCnt;               // 조회수
    private String rplyCnt;             // 댓글수
    private String dclCnt;              // 신고수
    private String nm;                  // 작성자
    private String nknm;                // 닉네임
    private String hdenYn;              // 숨김여부
    private String athoYn;              // 인증여부
    private String regDtm;              // 등록일
    private String mngrYn;              // 관리자여부
    private String ptnrYn;              // 파트너여부
    private String clcoNm;              // 고객사명
    private String updDtm;              // 수정일
    private String searchCode;	        // 검색코드
    private String searchName;	        // 검색명
    private String boardState;          // 게시물상태
   	private String emlAdr;              // 이메일
   	private String mblNo;               // 휴대전화번호
   	private String delYn;               // 삭제여부
   	private String notiYn;              // 공지여부
    private String rplyId;              // 댓글아이디
   	private String rplyCont;            // 댓글내용
   	private String uprRplyId;           // 상위댓글아이디
   	private String imgFrmwFileGrpId;    // 이미지프레임워크파일그룹아이디
   	private String imgFrmwFileId;       // 이미지프레임워크파일아이디
   	private String imgFrmwFilePaths;    // 이미지프레임워크파일경로
   	private String rpsClcoNm;           // 대상대표고객사명
   	private String clcoCnt;             // 대상고객사수
   	private String empno;               // 사번
   	private String replyLikeCnt;        // 댓글좋아요개수
    private String dclTyCont;           // 신고유형
    private String pushType;            // 푸시타입

    private Map<String, String> dwldInfo;   // 엑셀다운로드

}
