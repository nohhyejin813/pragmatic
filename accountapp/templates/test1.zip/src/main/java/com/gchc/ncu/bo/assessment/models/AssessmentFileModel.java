package com.gchc.ncu.bo.assessment.models;

import java.util.Date;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentFileModel extends UstraManagementBaseModel {
	/* T_EASY_CUI_ASM_FILE_DTL [헬스케어_검진이지검진기관평가파일상세] */

	private int		cuiAsmTgtId;	// 검진기관평가대상아이디

	private int		cuiAsmFileId;	// 검진기관평가파일아이디
	private String 	fileNm;			// 파일명
	private String 	orgFileNm;			// 진짜 파일명
	private String  fileId;
	private int  	fileNo;
	private String	fileDesc;		// 파일 설명
	private String	fileFmtCont;	// 파일 형식 내용
	private String 	fileGrpId;

	/* T_SRVY_ANSW_BSC 헬스케어_설문답변기본 */
	private int		srvyAnswId;	// 검진기관평가아이디 // TOBE Table 구조 추적

//	private String 	filePath;		// 파일경로
//	private String 	fileTyCd;		// 파일유형코드

}
