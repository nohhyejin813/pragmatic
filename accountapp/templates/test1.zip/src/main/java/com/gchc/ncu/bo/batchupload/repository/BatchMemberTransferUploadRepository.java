package com.gchc.ncu.bo.batchupload.repository;

import com.gchc.ncu.bo.batchupload.models.*;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface BatchMemberTransferUploadRepository {

	/**
	 *
	 * 처리내용 : 고객사 계약 정보 조회
	 *
	 * @param map
	 * @return
	 */
	ClcoCtraTnsfInfoModel getClcoCtraInfo(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 양도 그룹 조회
	 *
	 * @param map
	 * @return
	 */

	List<SpfnGrpInfModel> getSpfnGrpList(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 선택 그룹 조회
	 *
	 * @param map
	 * @return
	 */

	List<SpfnGrpInfModel> getSpfnSlctGrpList(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 업로드 내역 초기화
	 *
	 * @param map
	 */

	void updateClcoAempDtlBlkRegTmpUploadYn(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 시퀃스 목록으로 DB 조회
	 *
	 * @param map
	 * @return
	 */

	List<BatchMemberUploadCustomerDetailModel> getClcoAempDtlBlkRegTmpForUpdate(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 배치 테이블 시퀀스 채번
	 *
	 * @param map
	 * @return
	 */

	int getAempDtlBlkRegTmpNextSeq(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 배치 테이블에 insert
	 *
	 * @param bulkInsert
	 */

	void insertClcoAempDtlBlkRegTmp(List<BatchMemberUploadCustomerDetailModel> bulkInsert);

	/**
	 *
	 * 처리내용 : 배치 테이블 update
	 *
	 * @param c
	 */

	void updateClcoAempDtlBlkRegTmp(BatchMemberUploadCustomerDetailModel c);

	/**
	 *
	 * 처리내용 : 중복 체크
	 *
	 * @param map
	 */

	void updateClcoAempDtlBlkRegTmpValidate(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 업로드 결과 조회
	 *
	 * @param in
	 * @return
	 */

	BatchMemberTransferUploadResultModel getClcoAempDtlBlkRegTmpResult(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 업로드 결과 조회
	 * @param in
	 *
	 * @param paginationRequest
	 * @return
	 */

	List<BatchMemberUploadCustomerDetailModel> getClcoAempDtlBlkRegTmp(@Param("model")BatchMemberUploadDetailErrorRequestModel in, PaginationRequest paginationRequest);

	/**
	 *
	 * 처리내용 : 업로드 내용 초기화
	 *
	 * @param in
	 */

	void updateClcoAempDtlBlkRegTmpInit(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 업로드 오류 항목 삭제
	 *
	 * @param map
	 */

	void updateClcoAempDtlBlkRegTmpRemove(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 업로드 내용 등록
	 *
	 * @param map
	 */

	void updateClcoAempDtlBlkRegTmpTgtId(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 검진 대상이 없는 경우 오류
	 *
	 * @param map
	 */

	void updateClcoAempDtlBlkRegTmpValidate2(Map<String, Object> map);


	void updateClcoAempDtlBlkRegTmpValidateGrd(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 이미 존재하는 가족 정보 체크
	 *
	 * @param map
	 */

	void updateClcoAempDtlBlkRegTmpValidate3(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 회원지원금종합정보기본 없는 경우 INSERT
	 *
	 * @param in
	 */

	void insertMbrSpfnSyntInfBsc(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 지원금 양도 그룹 설정정보 저장
	 *
	 * @param in
	 */

	void updateMbrSpfnSyntInfBscTnsfGrp(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 지원금 선택 그룹 설정정보 저장
	 *
	 * @param in
	 */

	void updateMbrSpfnSyntInfBscSlctGrp(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 회원지원금종합정보기본 이력 등록
	 *
	 * @param in
	 */

	void insertMbrSpfnSyntInfChgRecs(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 추가지원대상설정기본 없는 경우 INSERT
	 *
	 * @param in
	 */

	void insertCuTgtSpfnTgtHis(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 다중 지원 설정정보 저장
	 *
	 * @param in
	 */

	void updateCuTgtSpfnTgtHis(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 다중 지원 설정이력 저장
	 *
	 * @param in
	 */

	void insertCuTgtSpfnTgtChgRecs(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 대상자 등록
	 *
	 * @param in
	 */

	void insertCuTgtrHis(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 임시테이블 등록완료 처리
	 *
	 * @param in
	 */

	void updateClcoAempDtlBlkRegTmpRegist(BatchMemberUploadResultRequestModel in);

	List<BatchMemberUploadCustomerDetailModel> selectClcoAempDtlBlkRegTmpExcelList2(Map<String, Object> map);

	void updateClcoAempDtlBlkRegTmpRemoveAll(BatchMemberUploadDetailErrorRequestModel in);

	List<BatchMemberUploadCustomerDetailModel> selectClcoAempDtlBlkRegTmpExcelList(
		BatchMemberUploadReentryDownloadRequestModel in);

	void updateClcoAempDtlBlkRegTmpValidate4(Map<String, Object> map);
}
