package com.gchc.ncu.bo.care.models;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class HospMdspDeptDtlModel extends UstraManagementBaseModel {

	private Integer mdspDeptId;
	private String mdspDeptNm;
	private String dtlMdxmSubjNm;

}
