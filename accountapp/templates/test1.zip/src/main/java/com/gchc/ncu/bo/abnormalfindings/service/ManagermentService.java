package com.gchc.ncu.bo.abnormalfindings.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.gchc.common.model.GchcPaginationRequest.GchcOrder;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBoardInfoModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBusinessPlaceModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentCorporationNameModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentCounselModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentDepartmentNameModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentEnterPriseStatisticssAllModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentEnterPriseStatisticssModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentMngCounselHistoryModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentYearModel;
import com.gchc.ncu.bo.abnormalfindings.repository.ManagermentRepository;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBoardInfoVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBrainDiseaselevelVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBusinessPlaceVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentCorporationNameVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentCounselVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentDepartmentNameVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentDeptNmVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentEnterpriseStatisticssVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentMngCounselHistoryVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentYearVo;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogService;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;
import com.gchc.ncu.bo.comm.service.CommonService;
import com.gchc.ncu.bo.comm.util.GchcGridUtil;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;
import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.domains.PaginationRequest.Order;
import com.gsitm.ustra.java.data.domains.PaginationRequest.OrderDirection;
import com.gsitm.ustra.java.data.mybatis.pagination.domain.Paginator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 유소견 Service
 *
 * @author gs_shbaek@gchealthcare.com
 */

@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class ManagermentService
{
	private static final Map<Order, List<Order>> ORD_MAP_LIST = new HashMap<>();
	static {
		ORD_MAP_LIST.put(GchcOrder.of("frstRegDtm", OrderDirection.DESC), Arrays.asList(GchcOrder.of("FRST_REG_DTM", OrderDirection.DESC)));
	}

	@Autowired
	private ManagermentRepository managermentRepository;

	@Autowired
	private CommonService commonService;

	@Autowired
	private XlsDownloadRecordService xlsDownloadRecordService;

	@Autowired
	private UsrInnfActiLogService usrInnfActiLogService;


	public List<ManagermentYearModel> getCheckUpYear(ManagermentYearVo abnormalFindingsYearVO) {

		return managermentRepository.getCheckUpYear(abnormalFindingsYearVO);
	}



	public List<ManagermentCorporationNameModel> getCoporationNameList(ManagermentCorporationNameVo abnormalFindingsCorporationNameVo) {
		return managermentRepository.getCoporationNameList(abnormalFindingsCorporationNameVo);
	}



	public List<ManagermentBusinessPlaceModel> getBusinessPlaceList(ManagermentBusinessPlaceVo abnormalFindingsBusinessPlaceVo) {
		return managermentRepository.getBusinessPlaceList(abnormalFindingsBusinessPlaceVo);
	}




	public List<ManagermentDepartmentNameModel> getDepartmentNameList(ManagermentDepartmentNameVo abnormalFindingsDepartmentNameVo) {
		return managermentRepository.getDepartmentNameList(abnormalFindingsDepartmentNameVo);
	}




	/**
	 *
	 * 처리내용 :
	 *
	 * @param brainDiseaselevelVo
	 * @return
	 */
	public List<String> getBrainDiseaseLevel(ManagermentBrainDiseaselevelVo abnormalFindingsbrainDiseaselevelVo) {
		return managermentRepository.getBrainDiseaseLevel(abnormalFindingsbrainDiseaselevelVo);
	}



	public ManagermentBoardInfoModel getBoardInfo(ManagermentBoardInfoVo anbfBoardInfoVo) {
		return managermentRepository.getBoardInfo(anbfBoardInfoVo);
	}


	public List<ManagermentModel> getAbnormalFindingsList(ManagermentVo model) {

		List<ManagermentModel> dataList = new ArrayList<ManagermentModel>();

		model.setOrderName(GchcGridUtil.getCamalToLarge("ROW_NUM", model.getOrderName()));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("model", model);
		paramMap.put("currentPage", model.getCurrentPage());
		paramMap.put("pageSize", model.getPageSize());
		paramMap.put("order", model.getOrderName());
		paramMap.put("orderDirection", model.getOrderDirection().toString());

		managermentRepository.exeKeyOpen();
		List<ManagermentModel> list = managermentRepository.getAbnormalFindingsList(paramMap);


		if(list.size() > 0) {
			UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
			usrInfomodel.setActiLogDvCd("40");	//로깅 유형

			usrInfomodel.setMenuNm("유소견관리 > 유소견관리 > 유소견 현황(T) > 목록조회(M)");	//메뉴명
			usrInfomodel.setPfrmNm("유소견 현황 목록 조회");	//실행명
			usrInfomodel.setPfrmCont(list.get(0).getBsplNm()+" 고객사 " + "유소견 현황 목록 조회");	//실행 내용
			usrInfomodel.setInnfVwCnt(list.size());	//실행 내용
			if(list.size() == 1) {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid().toString());	//고객명
			}
			else {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid() + "등 " + list.size() +"건");	//고객명
			}
			usrInnfActiLogService.insert(usrInfomodel);
		}


		int count = list != null && list.size() > 0 ? list.get(0).getTotalCnt() : 0;
		dataList = new PaginationList<ManagermentModel>(list, new Paginator(model.getCurrentPage(), model.getPageSize(), count));

		if(dataList != null && dataList.size() > 0) {
			UstraMaskingUtils.maskTextFields(dataList);
		}

		return dataList;
	}

	public List<ManagermentModel> getAbnormalFindingsListExcel(ManagermentVo abnormalFindingsVo) {
		abnormalFindingsVo.setOrderName(GchcGridUtil.getCamalToLarge(abnormalFindingsVo.getOrderName()));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("model", abnormalFindingsVo);
		paramMap.put("currentPage", abnormalFindingsVo.getCurrentPage());
		paramMap.put("pageSize", abnormalFindingsVo.getPageSize());
		paramMap.put("order", abnormalFindingsVo.getOrderName());
		paramMap.put("orderDirection", abnormalFindingsVo.getOrderDirection().toString());


		managermentRepository.exeKeyOpen();
		List<ManagermentModel>  dataList = managermentRepository.getAbnormalFindingsListExcel(paramMap);
		managermentRepository.exeKeyClose();

		/*
		if(dataList != null && dataList.size() > 0) {
			UstraMaskingUtils.maskTextFields(dataList);
		}
		*/

		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm("유소견관리 > 유소견 관리 > 엑셀 다운로드");
		record.setDwldPageUrl(abnormalFindingsVo.getDwldPageUrl());
		record.setDwldCont("No, 등급, 이름, 사번, 생일, 검진센터, 검진일, 결과동의서, 제3자정보 동의, 유소견동의, 뇌심혈관위험도, 직무스트레스, 허리둘레, SBP, DBP, BST, SGOT, "
				+ "SGPT, yGTP, TC, TG, LDL, HDL, Hb, 요단백, Crea, GFR, 흉부Xray정면, 흉부Xray측면, 상담");

		record.setDwldMemo(abnormalFindingsVo.getDwldMemo()); // 메모
		record.setDwldRsnCd(abnormalFindingsVo.getDwldRsnCd()); // 다운로드 사유 코드
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(dataList.size() ); //개인정보 Download 건수.
		record.setCustNm("UID : " + dataList.get(0).getUid() + "등  " + dataList.size()+ "건");
		xlsDownloadRecordService.insert(record);


		return dataList;
	}




	public List<ManagermentEnterPriseStatisticssModel> getEnterpriseStatisticssList(ManagermentEnterpriseStatisticssVo abnormalFindingsEnterPriseStatisicsVo) {
		managermentRepository.exeKeyOpen();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
		abnormalFindingsEnterPriseStatisicsVo.setYr0(abnormalFindingsEnterPriseStatisicsVo.getYr());

		try
		{
			Date date = dateFormat.parse(abnormalFindingsEnterPriseStatisicsVo.getYr());
			date.setYear(date.getYear() - 1);
			abnormalFindingsEnterPriseStatisicsVo.setYr1(dateFormat.format(date));

			date.setYear(date.getYear() - 1);
			abnormalFindingsEnterPriseStatisicsVo.setYr2(dateFormat.format(date));
		}
		catch (Exception e) {

		}


		List<ManagermentEnterPriseStatisticssModel> dataInfoList = managermentRepository.getEnterpriseStatisticss(abnormalFindingsEnterPriseStatisicsVo);
		for(ManagermentEnterPriseStatisticssModel dataInfo : dataInfoList)
		{
			dataInfo.setNormalCntPer(String.format("%.2f", (double)(dataInfo.getNormalCnt() * 100) / dataInfo.getTotalCnt()));
			dataInfo.setCareCntPer(String.format("%.2f", (double)(dataInfo.getCareCnt() * 100) / dataInfo.getTotalCnt()));
			dataInfo.setWarningCntPer(String.format("%.2f", (double)(dataInfo.getWarningCnt() * 100) / dataInfo.getTotalCnt()));
		}

		managermentRepository.exeKeyClose();
		return dataInfoList;
	}



	public List<ManagermentEnterPriseStatisticssModel> getEnterpriseStatisticssAllList(ManagermentEnterpriseStatisticssVo abnormalFindingsEnterPriseStatisicsVo) {
		managermentRepository.exeKeyOpen();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
		abnormalFindingsEnterPriseStatisicsVo.setYr0(abnormalFindingsEnterPriseStatisicsVo.getYr());

		try
		{
			Date date = dateFormat.parse(abnormalFindingsEnterPriseStatisicsVo.getYr());
			date.setYear(date.getYear() - 1);
			abnormalFindingsEnterPriseStatisicsVo.setYr1(dateFormat.format(date));

			date.setYear(date.getYear() - 1);
			abnormalFindingsEnterPriseStatisicsVo.setYr2(dateFormat.format(date));
		}
		catch (Exception e) {

		}


		List<ManagermentEnterPriseStatisticssAllModel> dataInfoList = managermentRepository.getEnterpriseStatisticssAll(abnormalFindingsEnterPriseStatisicsVo);
	/*
		for(ManagermentEnterPriseStatisticssModel dataInfo : dataInfoList)
		{
			dataInfo.setNormalCntPer(String.format("%.2f", (double)(dataInfo.getNormalCnt() * 100) / dataInfo.getTotalCnt()));
			dataInfo.setCareCntPer(String.format("%.2f", (double)(dataInfo.getCareCnt() * 100) / dataInfo.getTotalCnt()));
			dataInfo.setWarningCntPer(String.format("%.2f", (double)(dataInfo.getWarningCnt() * 100) / dataInfo.getTotalCnt()));
		}
*/
		managermentRepository.exeKeyClose();

		return null;
	}


	public List<ManagermentCounselModel> getCounselList(ManagermentCounselVo abnormalFindingsCounselVo) {
		List<ManagermentCounselModel> dataList = new ArrayList<ManagermentCounselModel>();

		PaginationRequest pr = abnormalFindingsCounselVo.toPaginationRequest(ORD_MAP_LIST);
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("model", abnormalFindingsCounselVo);
		paramMap.put("currentPage", pr.getCurrentPage());
		paramMap.put("pageSize", pr.getPageSize());
		paramMap.put("order", pr.getOrders());

		List<ManagermentCounselModel> list = managermentRepository.getCounselList(paramMap);
		int count = list != null && list.size() > 0 ? list.get(0).getTotalCnt() : 0;
		dataList = new PaginationList<ManagermentCounselModel>(list, new Paginator(abnormalFindingsCounselVo.getCurrentPage(), abnormalFindingsCounselVo.getPageSize(), count));

		if(dataList != null && dataList.size() > 0) {
			UstraMaskingUtils.maskTextFields(dataList);
		}

		if(list != null && list.size() > 1) {
			UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
			usrInfomodel.setActiLogDvCd("40");	//로깅 유형

			usrInfomodel.setMenuNm("유소견관리 > 유소견관리 > 상담관리(T) > 목록조회(M)");	//메뉴명
			usrInfomodel.setPfrmNm("유소견 현황 상담관리 상세조회");	//실행명
			usrInfomodel.setPfrmCont(list.get(0).getBsplNm()+" 고객사 " + "유소견 현황 상담관리 목록조회");	//실행 내용
			usrInfomodel.setInnfVwCnt(list.size());	//실행 내용
			if(list.size() == 1) {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid().toString());	//고객명
			}else {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid() + "등 " + list.size() +"건");	//고객명
			}
			usrInnfActiLogService.insert(usrInfomodel);
		}
		return dataList;
	}


	public List<ManagermentCounselModel> getCounselListExcel(ManagermentCounselVo abnormalFindingsCounselVo) {
		abnormalFindingsCounselVo.setOrderName(GchcGridUtil.getCamalToLarge(abnormalFindingsCounselVo.getOrderName()));
		PaginationRequest pr = abnormalFindingsCounselVo.toPaginationRequest(ORD_MAP_LIST);
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("model", abnormalFindingsCounselVo);
		paramMap.put("order", pr.getOrders());
		List<ManagermentCounselModel> list = managermentRepository.getCounselList(paramMap);
		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm("유소견관리 > 유소견 관리 > 엑셀 다운로드");
		record.setDwldPageUrl(abnormalFindingsCounselVo.getDwldPageUrl());
		record.setDwldCont("No, 등급, 이름, 사번, 생일, 검진센터, 검진일, 결과동의서, 제3자정보 동의, 유소견동의, 뇌심혈관위험도, 직무스트레스, 허리둘레, SBP, DBP, BST, SGOT, "
				+ "SGPT, yGTP, TC, TG, LDL, HDL, Hb, 요단백, Crea, GFR, 흉부Xray정면, 흉부Xray측면, 상담");

		record.setDwldMemo(abnormalFindingsCounselVo.getDwldMemo()); // 메모
		record.setDwldRsnCd(abnormalFindingsCounselVo.getDwldRsnCd()); // 다운로드 사유 코드
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(list.size() ); //개인정보 Download 건수.
		record.setCustNm("UID : " + list.get(0).getUid() + "등  " + list.size() + "건");
		xlsDownloadRecordService.insert(record);

		return  managermentRepository.getCounselList(paramMap);
	}








	public List<ManagermentMngCounselHistoryModel> getMngCounselHistory(ManagermentMngCounselHistoryVo abnormalFindingsMngCounselHistoryVo){
		return managermentRepository.getMngCounselHistory(abnormalFindingsMngCounselHistoryVo);
	}


	public Integer insertMngCounselHistory(ManagermentMngCounselHistoryModel abnormalFindingsMngCounselHistoryModel){
		return managermentRepository.insertMngCounselHistory(abnormalFindingsMngCounselHistoryModel);
	}


	public Integer updateMngCounselHistory(ManagermentMngCounselHistoryModel abnormalFindingsMngCounselHistoryModel){
		return managermentRepository.updateMngCounselHistory(abnormalFindingsMngCounselHistoryModel);
	}


	public Integer deleteMngCounselHistory(ManagermentMngCounselHistoryModel abnormalFindingsMngCounselHistoryModel){
		return managermentRepository.deleteMngCounselHistory(abnormalFindingsMngCounselHistoryModel);
	}

	public String getDeptNm(ManagermentDeptNmVo abnormalFindingsDeptNmVo){
		return managermentRepository.getDeptNm(abnormalFindingsDeptNmVo);
	}

}
