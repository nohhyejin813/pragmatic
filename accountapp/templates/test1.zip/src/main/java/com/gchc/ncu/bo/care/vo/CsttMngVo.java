package com.gchc.ncu.bo.care.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
public class CsttMngVo extends UstraManagementBaseModel {

	private Integer ssngCsttDtlId;
	private Integer ssngCsttCd;

}
