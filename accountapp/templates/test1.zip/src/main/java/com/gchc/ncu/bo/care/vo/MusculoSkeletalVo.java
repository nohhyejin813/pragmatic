package com.gchc.ncu.bo.care.vo;

import com.gchc.common.model.GchcPageableVo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class MusculoSkeletalVo extends GchcPageableVo
{
	@ApiModelProperty(value="설문아이디", example = "1")
	private Integer srvyId;

	@ApiModelProperty(value="주제영역아이디", example = "1")
	private Integer srvyQstThmAreaId;

}



