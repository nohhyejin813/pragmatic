package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchVaccineTempModel {
	private int excelSameRnk;
	private int sameMemberRnk;
	private int vcnId;
	private int cuTgtrId;
	private int vcnTgtrId;
	private int vcnResvId;
	private String vcnResvStCd;
	private String upldErrVal;
	private String upldStVal;
	private int cuiId;
	private int clcoId;
	private int uid;
}
