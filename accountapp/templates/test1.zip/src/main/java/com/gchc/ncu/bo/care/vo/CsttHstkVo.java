package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CsttHstkVo extends UstraManagementBaseModel {

	private String hstkContNm;
	private int hstkId;
	private int qstNo;
	private String  qstCont;
	private int pageNo;
	private int mateRltnCd;
	private int useYn;
	private int hstkType;


}
