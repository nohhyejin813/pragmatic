package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import com.gchc.ncu.bo.batchupload.enu.PackageItemStatus;
import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PackageItemUploadItemModel extends NcuModel {

	int pkgItmUpldId;

	int pkgItmUpldBscId;

	int xclShtNo;

	int xclRowId;

	int xclComnId;

	String pkgItmAtriVal;

	int wrarCnt;

	String xclN1stCstrVal;

	String xclN2ndCstrVal;

	String xclN3rdCstrVal;

	String itmTyCd;

	String sexCd;

	int chexStupCnt;

	int itmPrc;

	int pkgItmUpldStVal;

	String pkgItmErrStVal;

	PackageItemStatus itemStatus;

	String etcDesc;
}
