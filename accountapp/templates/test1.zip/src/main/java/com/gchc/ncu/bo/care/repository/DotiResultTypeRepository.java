package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.DotiTyCdModel;
import com.gchc.ncu.bo.care.vo.DotiResultTypeVo;

@Mapper
public interface DotiResultTypeRepository {

	List<DotiTyCdModel> selectDotiResultTypeList(DotiResultTypeVo criteria);
	DotiTyCdModel selectDotiResultTypeDetail(DotiTyCdModel criteria);
	void saveDotiResultType(DotiTyCdModel model);
	void deleteDotiResultType(DotiTyCdModel model);

}
