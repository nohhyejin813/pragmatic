package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.NrsnClsfBscModel;
import com.gchc.ncu.bo.care.service.PainSymptomTypeService;
import com.gchc.ncu.bo.care.vo.PainSymptomTypeVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/pain/symptom-type")
@RequiredArgsConstructor
public class PainSymptomTypeController {

	private final PainSymptomTypeService painSymptomTypeService;

	@GetMapping("/list")
	public List<NrsnClsfBscModel> list(@ModelAttribute PainSymptomTypeVo criteria) {
		return painSymptomTypeService.getSymptomTypeList(criteria);
	}

	@GetMapping("/detail")
	public NrsnClsfBscModel detail(@ModelAttribute NrsnClsfBscModel criteria) {
		return painSymptomTypeService.getSymptomTypeDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid NrsnClsfBscModel model) {
		painSymptomTypeService.saveSymptomType(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<NrsnClsfBscModel> list) {
		painSymptomTypeService.deleteSymptomType(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
