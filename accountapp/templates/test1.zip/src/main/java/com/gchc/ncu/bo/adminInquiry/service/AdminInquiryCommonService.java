package com.gchc.ncu.bo.adminInquiry.service;

import static com.gchc.ncu.bo.checkup.enums.TargetSelectionRangeCode.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.microsoft.sqlserver.jdbc.StringUtils;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.message.model.MessageUnion;

import com.gchc.ncu.bo.adminInquiry.models.WebInquiryModel;
import com.gchc.ncu.bo.adminInquiry.repository.AdminInquiryRepository;
/**
 * 검진관리 공통 Service
 *
 * @FileName : CheckupCommonService.java
 * @date : 2021. 11. 22
 * @author : jcmyeong
 */
@Service
public class AdminInquiryCommonService {

	@Autowired
	private AdminInquiryRepository AdminInquiryRepository;

	/**
	 *
	 * 처리내용 : 1:1 문의 내역 등록
	 *
	 * @param vo - 1:1 문의 내역 등록 파라미터
	 */
	@Transactional
	public void insertAdminInquiry(@Valid WebInquiryModel vo) {
		Integer cnt = 0;

		cnt = AdminInquiryRepository.insertAdminInquiry(vo);

		if (cnt == 0) {
			throw GchcResponseCode.CANNOT_SAVE_RECORD.exception();
		}
	}
}
