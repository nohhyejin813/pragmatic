package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum CenterVaccineColumn implements BatchUploadColumn {

	CUI_NM("검진센터명", "CuiNm"),

	CLCO_NM("고객사명", "ClcoNm"),

	BSPL_NM("사업장명", "BsplNm"),

	VCN_NM("백신명", "VcnNm"),

	VCN_PRC("백신 소비자가", "VcnAmt"),

	VCN_DC_PRC("백신 할인가", "VcnDcAmt"),

	ETC_MSG_CONT("예약고객용 알림내용", "EtcMsgCont"),

	ID("VcnLibID", "CuiBlkVcnId")
	;
	private String title;

	private String field;

	CenterVaccineColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
