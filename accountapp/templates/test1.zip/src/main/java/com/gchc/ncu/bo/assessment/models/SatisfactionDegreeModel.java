package com.gchc.ncu.bo.assessment.models;

import com.gchc.ncu.bo.comm.models.NcuPageableVo;

import lombok.*;
import lombok.Builder.Default;
import lombok.experimental.SuperBuilder;

//@Data
@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class SatisfactionDegreeModel extends NcuPageableVo {

	// 목록
	private int 	rowNum;

	@Default private int 	yr = -1;    				//년도
	@Default private int		clcoId = - 1;				//고객사아이디
	private String	clcoNm;				//고객사명
	@Default private int 	cuiId = -1;    			//검진기관아이디
	private String 	cuiNm;    			//검진기관명
	private String 	cuiTyCd;    		//검진기관유형코드
	private String  cuiTyNm;            //검진기관명
	private String 	rgnNm1;    			//지역명1
	private String 	rgnNm2;    			//지역명2

	private double 	kndnStdgScrAvg;    	//친절만족도점수
	private double 	trsStdgScrAvg;    	//신뢰만족도점수
	private double 	fcltStdgScrAvg;    	//시설만족도점수
	private double 	examItmStdgScrAvg;  //검사항목만족도점수
	private double 	rcmnAvg;    		//추천점수
	private double 	rcmnPer;    		//추천퍼센트
	private double 	notRcmnPer;    		//비추천퍼센트

	private int 	partlnCnt;    		//참여자수
	private int 	targetCnt;    		//수검자수

	//상세 - T_CUI_STDG_INVS_BSC [헬스케어_검진기관만족도조사기본]
	private	int		cuiStdgSeq;			//검진기관만족도일련번호
	private	int		uid;				//회원아이디
	private	String	nm;					//회원명

	private String realNm;              // (실제(noMask)) 성명

	private String empno;               // 사번
	private	String	rcmnYn;				//추천여부
	private	int		kndnStdgScr;		//친절만족도점수
	private	int		trsStdgScr;			//신뢰만족도점수
	private	int		fcltStdgScr;		//시설만족도점수
	private	int		examItmStdgScr;		//검사항목만족도점수
	private	String	tgtYr;				//대상년도
	private	boolean	delOpinYn;			//삭제의견여부
	private	String	delRsn;				//삭제사유
	private	String	opinCont;			//의견내용
	private	String	comment;			//의견내용
	private	boolean	delYn;				//삭제여부

//	private	LocalDateTime	frstRegDtm;			/*최초등록일시*/
//	private	String	frstRegrTyCd;		/*최초등록자유형코드*/
//	private	String	frstRegrId;			/*최초등록자아이디*/
//	private	LocalDateTime	lastUpdDtm;			/*최종수정일시*/
//	private	String	lastUpdrTyCd;		/*최종수정자유형코드*/
//	private	String	lastUpdrId;			/*최종수정자아이디*/



	/* search parameter */
	@Default private String 	srchYr = "-1";    				//년도

	private String 	srchRgnNm1;    			//지역1
	private String 	srchRgnNm2;    			//지역2

	@Default private String	srchClcoId = "-1";				//고객사
	@Default private String	srchCuiId = "-1";				//검진기관

	private int		srchKndnStdgMinScr; 	//친절만족도점수(min)
	private int		srchKndnStdgMaxScr; 	//친절만족도점수(max)

	private int		srchTrsStdgMinScr; 		//신뢰만족도점수(min)
	private int		srchTrsStdgMaxScr; 		//신뢰만족도점수(max)

	private int		srchFcltStdgMinScr; 	//시설만족도점수(min)
	private int		srchFcltStdgMaxScr; 	//시설만족도점수(max)

	private int		srchExamItmStdgMinScr; 	//검사항목만족도점수(min)
	private int		srchExamItmStdgMaxScr; 	//검사항목만족도점수(max)
}
