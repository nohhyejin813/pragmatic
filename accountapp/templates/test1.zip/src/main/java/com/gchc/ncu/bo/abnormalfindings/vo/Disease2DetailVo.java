package com.gchc.ncu.bo.abnormalfindings.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Disease2DetailVo {


	/** SBP(수축기혈압) */
	private Float sbpS;
	private Float sbpE;

	/** DBP(이완기혈압) */
    private Float dbpS;
    private Float dbpE;

    /** 혈당 */
    private Float blsgS;
    private Float blsgE;

    /** TC(총콜레스테롤) */
    private Float tcS;
    private Float tcE;

    /** HDL */
    private Float hdlS;
    private Float hdlE;

    /** LDL */
    private Float ldlS;
    private Float ldlE;

    /** 중성지방 */
    private Float tgS;
    private Float tgE;

    private Float bmiS;
    private Float bmiE;

    /** 신장 */
    private Float heightS;
    private Float heightE;

    /** 체중 */
    private Float weightS;
    private Float weightE;

    /** 허리둘레 */
    private Float lmbcS;
    private Float lmbcE;

    /** AST */
    private Float astS;
    private Float astE;

    /** ALT */
    private Float altS;
    private Float altE;

    /** rGTP */
    private Float rgtpS;
    private Float rgtpE;
}
