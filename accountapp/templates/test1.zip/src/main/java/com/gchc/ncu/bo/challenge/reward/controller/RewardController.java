package com.gchc.ncu.bo.challenge.reward.controller;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.batchupload.controller.BatchXlsHistProcess;
import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.care.vo.CareCampaignVo;
import com.gchc.ncu.bo.challenge.reward.models.RewardExcelModel;
import com.gchc.ncu.bo.challenge.reward.models.RewardModel;
import com.gchc.ncu.bo.challenge.reward.service.RewardService;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/challenge/reward")
public class RewardController {

	private final RewardService service;

	@Autowired
	private FileOperationManager fileOperationManager;
	@Autowired
	private BatchXlsHistProcess batchXlsHistProcess;

	@GetMapping("/member/list")
	public List<RewardModel> getChallengeRewardMbrList(@ModelAttribute RewardModel vo) {
		return service.getChallengeRewardMbrList(vo);
	}

	@PostMapping("/confirm")
	public RestResult<?> setChallengeRewardConfirm(@RequestBody CareCampaignVo vo) {
		service.setChallengeRewardConfirm(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/sample-download-excel")
	@ApiOperation(value="파일업로드 양식 다운로드", notes="파일업로드 양식 다운로드")
	public ResponseEntity<?> downloadExcel(HttpServletRequest request, HttpServletResponse response) {
		return sampleConvertExcel(service.getSampleDownloadExcel(), request, response);
	}

	ResponseEntity<?> sampleConvertExcel(List<RewardExcelModel> model, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();

		for( int i = 0; i < model.size(); i++ ) {

			Map<String, Object> map = new TreeMap<>();

			// 리스트 셋팅
			RewardExcelModel exMap = model.get(i);

			// 사번
			map.put("col1", exMap.getEmpNo());

			list.add(map);
		}

		if( StringUtils.isNotEmpty(model.get(0).getEmpNo()) ) {

			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "인증챌린지 > 보상관리";
			String cont = "사번";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1", "사번"		),
				new UstraExcelCellInfoModel("col2", "보상내용"	)
			))
			.withSheetName("업로드정보");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "고객(일반)", request, response)
			.build());
	}

	@PostMapping("/download_excel")
	@ApiOperation(value = "엑셀다운로드", notes = "엑셀다운로드")
	public ResponseEntity<?> getExcelDownload(@RequestBody @Valid RewardModel model, HttpServletRequest request, HttpServletResponse response){
			return fileOperationManager.convert(DataToExcelWebResourceConverter
					.entityBuilder(Arrays.asList(service.getExcelDownload(model)), model.getDwldInfo().get("dwldPageNm") + ".xlsx", request, response)
					.build());
	}


	@PostMapping("/error-download-excel")
	@ApiOperation(value="오류목록 다운로드", notes="오류목록 다운로드")
	public ResponseEntity<?> downloadExcelCustomer(@RequestBody List<RewardModel> param, HttpServletRequest request, HttpServletResponse response) {
		return errorConvertExcel(param, request, response);
	}

	ResponseEntity<?> errorConvertExcel(List<RewardModel> errorList, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();

		for( int i = 0; i < errorList.size(); i++ ) {

			Map<String, Object> map = new TreeMap<>();

			// 리스트 셋팅
			RewardModel exMap = errorList.get(i);

			map.put("col1", exMap.getEmpno()); 	// 사번
			map.put("col2", exMap.getErrMsg());	// 오류내용

			/*
				map.put("col1", exMap.getRn()); 				// 번호
				map.put("col2", exMap.getNm()); 				// 이름
				map.put("col3", exMap.getEmpno()); 			// 사번
				map.put("col4", exMap.getUid());				// UID
				map.put("col5", exMap.getCluAgrDt());		// 신청일자
				map.put("col6", exMap.getAthoCmplCnt());		// 인증완료수
				map.put("col7", exMap.getCmpnCont());		// 보상내용
				map.put("col8", exMap.getCmpnContRecs());	// 보상이력
				map.put("col9", exMap.getErrMsg());			// 오류내용
			 */

			list.add(map);
		}

		if( StringUtils.isNotEmpty(errorList.get(0).getNm()) ) {
			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "인증챌린지 > 보상관리 > 보상대상자목록";
			//String cont = "번호, 이름, 사번, UID, 신청일자, 인증완료수, 보상내용, 보상이력, 오류내용";
			String cont = "사번, 오류내용";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;

		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
					new UstraExcelCellInfoModel("col1", "사번"		),
					new UstraExcelCellInfoModel("col2", "보상이력"	)
//				new UstraExcelCellInfoModel("col1"	, "번호"		),
//				new UstraExcelCellInfoModel("col2"	, "이름"		),
//				new UstraExcelCellInfoModel("col3"	, "사번"		),
//				new UstraExcelCellInfoModel("col4"	, "UID"		),
//				new UstraExcelCellInfoModel("col5"   	, "신청일자"	),
//				new UstraExcelCellInfoModel("col6"   	, "인증완료수"	),
//				new UstraExcelCellInfoModel("col7"   	, "보상내용"	),
//				new UstraExcelCellInfoModel("col8"   	, "보상이력"	)

			))
			.withSheetName("오류내용");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "오류내용", request, response)
			.build());
	}
}
