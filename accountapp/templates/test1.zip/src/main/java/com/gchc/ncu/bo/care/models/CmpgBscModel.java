package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CmpgBscModel extends UstraManagementBaseModel {

	private Integer cmpgId;
	@NotNull(message = "캠페인계약ID는 필수값입니다.")
	private Integer cmpgCtraId;
	@NotNull(message = "캠페인종류는 필수값입니다.")
	private String cmpgKdCd;
	private Integer ono;
	private String pgrsSrtDt;
	private String pgrsEndDt;
	private Integer pgrsDays;
	private String cmpgStCd;
	private String cmpgStNm;
	private Integer tgtrCnt;
	private Integer ptcprCnt;
	private Integer ptcprCmplPcnt;
	private Integer ptcprAvgStpCnt;
	private Double ptcprPgrsRt;
	private Double ptcprCmplRt;
	private String cmplDt;
	private Integer useYn;
	private Integer teamExpoYn;

	private String rowStatus;

	private String cmpgNm;
	private Integer clcoId;
	private String clcoNm;
	private String bsplNm;
	private Integer goalStpCnt;
	private String cmpnWayCd;
	private String titl;
	private String prtcTgtCont;
	private String prtcMthCont;
	private String pctnCont;
	private Integer ptcprTeamCnt;
	private Integer totTeamCnt;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
