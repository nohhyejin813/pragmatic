package com.gchc.ncu.bo.assessment.models;

import java.util.Date;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentQuestionModel extends UstraManagementBaseModel {
	private int		upQstId;
	private int		qstId;

	private int		cuiAsmTgtId;		//검진기관평가대상아이디
	private int 	cuiAsmId;    		//검진기관평가아이디

	/* T_EASY_CUI_ASM_QST_DTL [헬스케어_검진이지검진기관평가질문상세] */
	private int 	cuiAsmQstId;		//검진기관평가질문아이디
	private String 	qstTyNm;    		//질문유형명
	private String 	qstnCont;    		//문항내용
	private String 	qstnTyCd;    		//문항유형코드

	/* T_EASY_CUI_ASM_RSPN_DTL [헬스케어_검진이지검진기관평가응답상세]*/ // 이게안쓰는거임
	private int 	cuiAsmRspnId;		//검진기관평가응답아이디
	private String 	sbjtAnswCont;		//주관식답변내용
	private String 	objtAnswVal;		//객관식답변값
	private	int		rspnScr; 			//평가점수


	/*T_EASY_CUI_ASM_EXM_DTL [헬스케어_검진이지검진기관평가보기상세]*/
	private	int		cuiAsmExmId;		//검진기관평가보기아이디
	private	boolean	sbjtYn;				//여부
	private	String	exCont;				//내용
	private	int		exmScr;				//점수

	private boolean	delYn;

	private boolean	chkYn;

	private	boolean	inserted;
	private	boolean	updated;
	private	boolean	deleted;

	private int			srvyId; 		//설문아이디
	private int			answSrvyTgtId;	//답변설문대상 ID
	private int			answSrvyQstSlctItmId; // 객관식 답변 ( 문제 밑 항목 아이디를 저장)
	private int			srvyQstThmAreaId; // 주제아이디
//	private int			cuiAsmId; 				//검진기관평가아이디
	private int			srvyQstId;		//설문질문ID
	private String		thmAreaTitl;	//주제영역 제목
	private int			srvyQstNo;		//설문질문ID
	private int			srvyQstSlctItmId; //검진기관평가보기아이디
	private int			srvyQstSlctItmNo; //문제 내 선택항목 번호
	private String		srvyQstCont; 	//문항내용
	private String 		qstAnswBscTyCd;			//질문답변기본유형코드
	private int 		srvyAnswId;
	private String 		srvyAnswInptCont; // 주관식답변
	private int 		allwPsblMxScr;
	private int 		slctItmAllwScr;			//선택형 항목별 배점
	private String		slctItmCont;
	private boolean		slctItmAnswInptPsblYn; // 선택항목 답변입력여부
	private boolean		answMltiSlctPsblYn; // 중복 선택 여부

}
