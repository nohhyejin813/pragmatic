package com.gchc.ncu.bo.care.models;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
@SuperBuilder
@NoArgsConstructor
public class CstmCuBscItmBscModel extends UstraManagementBaseModel {

	private String cstmCuBscItmId;
	private String nm;
	private Integer catId;
	private Integer sortOrd;
	private Integer useYn;
	private Integer usePageExpoTvCd;
	private String usePageExpoCont;
	private String imgPath;
	private String imgPath2;
	private Integer sexCd;
	private Integer delYn;

}
