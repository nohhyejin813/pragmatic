package com.gchc.ncu.bo.abnormalfindings.models.management;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

/**
 * 유소견_관리_상담_내역(ABNF_MNG_CNSL_HIS)
 * @FileName : AbnfMngCounselHistoryModel.java
 * @date : 2021. 7. 30
 * @author : gs_shbaek@gchealthcare.com
 * @프로그램 설명 :
 * @변경이력 :
 */
@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentMngCounselHistoryModel extends UstraManagementBaseModel
{

	@ApiModelProperty(value="유소견상담아이디")
	private Integer abnfCnslId;

	@ApiModelProperty(value="유소견상담아이디 배열")
	private Integer[] abnfCnslIds;

	@ApiModelProperty(value="이름", example = "230787")
	private String nm;

	@ApiModelProperty(value="회원아이디", example = "230787")
	private Integer uid;

	@ApiModelProperty(value="생성회원아이디", example = "6347")
	private Integer crtUid;

	@ApiModelProperty(value="통화상담여부", example = "true")
	private Boolean curCnslYn;

	@ApiModelProperty(value="문자상담여부", example = "false")
	private Boolean charScslYn;

	@ApiModelProperty(value="이메일상담여부", example = "false")
	private Boolean emlCnslYn;

	@ApiModelProperty(value="방문상담여부", example = "false")
	private Boolean vstCnslYn;

	@ApiModelProperty(value="기타상담여부", example = "false")
	private Boolean etcCnslYn;

	@ApiModelProperty(value="뇌심혈관계상담여부", example = "false")
	private Boolean bcsCnslYn;

	@ApiModelProperty(value="비만상담여부", example = "false")
	private Boolean obstCnslYn;

	@ApiModelProperty(value="혈압상담여부", example = "false")
	private Boolean bpCnslYn;

	@ApiModelProperty(value="혈당상담여부", example = "false")
	private Boolean blsgCnslYn;

	@ApiModelProperty(value="간기능상담여부", example = "false")
	private Boolean lfcnCnslYn;

	@ApiModelProperty(value="이상지질혈증상담여부", example = "false")
	private Boolean dyspCnslYn;

	@ApiModelProperty(value="혈색소상담여부", example = "false")
	private Boolean hemoCnslYn;

	@ApiModelProperty(value="신장질환상담여부", example = "false")
	private Boolean htDssCnslYn;

	@ApiModelProperty(value="청력상담여부", example = "false")
	private Boolean hearCnslYn;

	@ApiModelProperty(value="흉부상담여부", example = "false")
	private Boolean thorCnslYn;


	@ApiModelProperty(value="진단혈압상담여부", example = "false")
	private Boolean diagBpCnslYn;

	@ApiModelProperty(value="진단당뇨상담여부", example = "false")
	private Boolean diagGlycCnslYn;


	@ApiModelProperty(value="상담일자" , example = "2021-08-10")
	private String cnslDt;

	@ApiModelProperty(value="상담시분", example = "21:10")
	private String cnslHm;

	@ApiModelProperty(value="상담 시(hour)", example = "09")
	private String cnslHour;

	@ApiModelProperty(value="상담 분(min)", example = "10")
	private String cnslMinute;

	@ApiModelProperty(value="상담제목", example = "유소견 상담 테스트")
	private String cnslTitl;

	@ApiModelProperty(value="측정내용", example = "유소견 측정 내용")
	private String msrCont;

	@ApiModelProperty(value="유소견상담메모", example = "test 메모")
	private String abnfCnslMemo;

	@ApiModelProperty(value="삭제여부")
	private Boolean delYn;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(value="최초등록일시")
	private String frstRegDtm;

	@ApiModelProperty(value="최초등록자유형코드", example = "A")
	private String frstRegrTyCd;

	@ApiModelProperty(value="최초등록자아이디", example = "MIG")
	private String frstRegrId;


	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(value="최종수정일시")
	private String lastUpdDtm;

	@ApiModelProperty(value="최종수정자유형코드", example = "A")
	private String lastUpdrTyCd;

	@ApiModelProperty(value="최종수정자아이디", example = "MIG")
	private String lastUpdrId;


}


