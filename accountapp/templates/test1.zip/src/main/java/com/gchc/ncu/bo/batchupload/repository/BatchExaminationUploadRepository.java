package com.gchc.ncu.bo.batchupload.repository;

import com.gchc.ncu.bo.batchupload.models.BatchExminationExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchExminationTempModel;
import com.gchc.ncu.bo.batchupload.models.ExaminationSrcModel;
import com.gchc.ncu.bo.inspection.models.InspectionUserModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BatchExaminationUploadRepository {

	Integer getMatchClcoId(String clcoNm);

	int getMatchClcoYn(ExaminationSrcModel src);

	int getMatchCuiYn(ExaminationSrcModel src);

	Integer getMatchCuiId(String cuiNm);

	List<InspectionUserModel> getExaminationUserMatch(ExaminationSrcModel src);

//	int insertExaminationBatch(ExaminationSrcModel src); // 이거 하다 중지.

	int insertCheckupExaminationBatch(ExaminationSrcModel src);

	List<BatchExminationTempModel> getBatchExaminationTempList(int mngrId);

	int updateExcelDupData(ExaminationSrcModel vo);

	int updateExcelDidntReserveUser(ExaminationSrcModel vo);

	int updateExcelRequestPakgesCheck(ExaminationSrcModel vo);

	int updateExcelDupNmCheck(ExaminationSrcModel vo);

	void insertResvSlctItmRecs(ExaminationSrcModel vo);

	void deleteResvSlctItmBsc(ExaminationSrcModel vo);

	int updateResvBsc(ExaminationSrcModel vo);

	void insertResvRecs(ExaminationSrcModel vo);

	void insertIsNotExResvBsc(ExaminationSrcModel vo);

	void insertCuTgtrHis(ExaminationSrcModel vo);

	void deleteErrorDataControl(ExaminationSrcModel vo);

	List<BatchExminationExcelModel> selectBlkUpldExamTmp(ExaminationSrcModel vo);

	List<BatchExminationExcelModel> getExaminationExcelList(ExaminationSrcModel src);

	int deleteSelectCheckup(ExaminationSrcModel src);

    void initExamination(ExaminationSrcModel vo);
}
