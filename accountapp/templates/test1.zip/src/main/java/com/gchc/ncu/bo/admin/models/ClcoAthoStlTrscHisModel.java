package com.gchc.ncu.bo.admin.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ClcoAthoStlTrscHisModel extends NcuModel {
	private int 	clcoId;
	private int 	clcoCtraId;
	private String 	trscYr;
	private String 	trscUniqDstgVal;
	private String 	clcoStlTrscDvCd;
	private String 	trscDatCont;
	private String 	stlStCd;
	private String 	stlTrscIdVal;
	private String 	stlMthNm;
	private String 	realStlTyCd;
	private String 	realStlAmt;

}
