package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.CareDssCdModel;
import com.gchc.ncu.bo.care.models.LifeStyleCdModel;
import com.gchc.ncu.bo.care.service.CareBaseService;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/care/base")
public class CareBaseController {

	private final CareBaseService careBaseService;

	@GetMapping("/disease-code/list")
	public List<CareDssCdModel> getCareDiseaseCodeList() {
		return careBaseService.getCareDiseaseCodeList();
	}

	@PostMapping("/disease-code/save")
	public RestResult<?> saveCareDiseaseCode(@RequestBody @Valid CareDssCdModel model) {
		careBaseService.saveCareDiseaseCode(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/life-style-code/list")
	public List<LifeStyleCdModel> getLifeStyleList() {
		return careBaseService.getLifeStyleCodeList();
	}

	@PostMapping("/life-style-code/save")
	public RestResult<?> saveLifeStyleCode(@RequestBody @Valid LifeStyleCdModel model) {
		careBaseService.saveLifeStyleCode(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
