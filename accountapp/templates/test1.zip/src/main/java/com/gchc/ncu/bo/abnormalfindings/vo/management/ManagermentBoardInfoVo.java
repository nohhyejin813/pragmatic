package com.gchc.ncu.bo.abnormalfindings.vo.management;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;



@Getter
@Setter
@ToString
public class ManagermentBoardInfoVo extends GchcVo
{

	@ApiModelProperty(value="", example = "1")
	private Integer isUbcareManager;




	@ApiModelProperty(value="조회할 연도", example = "2019")
	@NotNull
	private String yr;


	@ApiModelProperty(value="유소견 관리 고객사(0-X, 1-Y)", example = "1")
	private Integer abnfMngClco;


	@ApiModelProperty(value="검진 시작 일자", example = "2019-01-01") //CHECKUP_FROM_DATE
	private String cuFromDt;

	@ApiModelProperty(value="검진 종료 일자", example = "2019-12-31") //CHECKUP_TO_DATE
	private String cuToDt;


	@ApiModelProperty(value="상담 시작 일자", example = "") //CONSULT_TO_DATE
	private String cnslFromDt;


	@ApiModelProperty(value="상담 종료 일자", example = "") //CHECKUP_FROM_DATE
	private String cnslToDt;


	@ApiModelProperty(value="고객사 아이디", example = "1")
	private Integer clcoId;

	@ApiModelProperty(value="사업장 아이디", example = "200")
	private Integer bsplId;


	@ApiModelProperty(value="부서 아이디", example = "7")
	private Integer deptId;




	@ApiModelProperty(value="구분값", example = "1")
	private String ty; //GUNBUN

	@ApiModelProperty(value="검색어", example = "")
	private String search; //검색어

	@ApiModelProperty(value="매니저아이디(보통 고정)", example = "-1")
	private Integer mngrId;


	@ApiModelProperty(value="", example="1")
	private Integer status;
}



