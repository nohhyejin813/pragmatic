package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.SrvyBscModel;
import com.gchc.ncu.bo.care.models.SrvyQstHisModel;
import com.gchc.ncu.bo.care.models.SrvyQstThmAreaDtlModel;
import com.gchc.ncu.bo.care.vo.MusculoSkeletalVo;

@Mapper
public interface MusculoSkeletalRepository {

	List<SrvyBscModel> selectSrvyList();

	List<SrvyQstThmAreaDtlModel> selectThmAreaitemList(MusculoSkeletalVo criteria);

	List<SrvyQstThmAreaDtlModel> selectQutitemList(MusculoSkeletalVo criteria);

	void updateSrvyQstHis(SrvyQstHisModel model);

	//만성질환 설문설정관리 조회조건  조회
	List<SrvyBscModel> selectChronicSrvyList();
	//만성질환 설문설정관리 주제영역에 따른 질문정보  조회
	List<SrvyQstThmAreaDtlModel> selectChronicQutitemList(MusculoSkeletalVo criteria);
	//만성질환 질문정보 수정
	void updateChronicSrvyQstHis(SrvyQstHisModel model);

}
