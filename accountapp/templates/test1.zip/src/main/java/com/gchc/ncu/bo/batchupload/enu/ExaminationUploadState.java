package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum ExaminationUploadState {

    ALL("99"),

    SUCCESS("1"),

    ERROR("")

    ;
    private String value;

    ExaminationUploadState(String value) {
        this.value = value;
    }
}
