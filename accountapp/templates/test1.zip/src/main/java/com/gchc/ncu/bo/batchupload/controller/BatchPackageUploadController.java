package com.gchc.ncu.bo.batchupload.controller;

import com.gchc.common.exception.GchcException;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.service.BatchPackageUploadService;
import com.gchc.ncu.bo.packages.models.ExamItemModel;
import com.gchc.ncu.bo.packages.service.ExamItemService;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.file.model.FileConvertInput;
import com.gsitm.ustra.java.data.file.processor.convert.LocalExcelFileToDataConverter;
import com.gsitm.ustra.java.data.file.processor.convert.LocalExcelFileToMultipleSheetDataConverter;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.data.file.WebResourceAttachFileConverter;
import com.gsitm.ustra.java.mvc.data.file.WebResourceAttachFileConverter.Option;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Api(tags = "패키지일괄업로드 컨트롤러")
@RestController
@RequestMapping("/api/bo/batchupload")
public class BatchPackageUploadController {

	@Autowired private ResourceLoader resourceLoader;

	@Autowired BatchPackageUploadService service;

	private final ExamItemService examItemService;

	@Autowired private FileOperationManager fileOperationManager;

	@Autowired private BatchXlsHistProcess batchXlsHistProcess;



	@PostMapping("/package/upload")
	void upload(@RequestBody PackageItemUploadBasicModel in) throws IOException {

		// Excel convert
		FileConvertInput<LocalExcelFileToDataConverter.Option, List<RowInfo>> converter =
			LocalExcelFileToDataConverter.builder(in.getFileGrpId(), true, Map.class)
			.metaDataId(FileConvertInput.FileMetaId.builder().fileId(in.getFileId()).fileNos(Arrays.asList(in.getFileNo())).build())
			.build();
		List<RowInfo> converted = fileOperationManager.convert(converter);

		final int clcoId = in.getClcoId();
		final int yr = in.getYr();

		service.packageValidate(converted, clcoId, yr);
	}

	@PostMapping("/package/result")
	BatchPackageUploadResultModel packageUploadResult(@RequestBody BatchPackageUploadResultRequestModel in) {

		return service.packageUploadResult(in);
	}

	@PostMapping("/package/error-list")
	List<BatchPackageUploadModel> getPackageUploadErrorList(@RequestBody BatchPackageUploadResultRequestModel in) {

		return service.getPackageUploadErrorList(in);
	}

	@PostMapping("/package/init")
	void init(@RequestBody BatchPackageUploadResultRequestModel in) {

		service.packageInit(in);
	}

	@PostMapping("/package/regist")
	void regist(@RequestBody PackageItemUploadBasicModel in) {

		service.packageRegist(in);
	}

	@PostMapping("/package/remove")
	void delete(@RequestBody List<BatchPackageUploadModel> in) {

		service.packageRemove(in);
	}

	@PostMapping("/package/remove-all")
	void deleteAll(@RequestBody PackageItemUploadBasicModel in) {

		service.packageRemoveAll(in);
	}

	/**
	 * 패키지관리 - 패키지 엑셀다운로드 (전체,성공,오류)
	 *
	 * @param in 입력
	 * @return 출력
	 */
	@PostMapping("/package/download-excel-all")
	public ResponseEntity<?> downloadExcelAll(@RequestBody PackageItemUploadBasicModel in, HttpServletRequest request, HttpServletResponse response) {
		List<PackageUploadExcelModel> excelList = service.getPackageExcelList(in);

		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		String tagretUrl = request.getRequestURL().toString();
		histModel.setDwldPageUrl(tagretUrl.split("\\?")[0]);
		histModel.setInnfVwCnt(excelList.size());
		histModel.setDwldPageNm("패키지 관리");
		histModel.setDwldCont("검진센터명, 패키지명, 패키지타입, 성별, 패키지기본타입가격, 제안서기간시작일, 제안서기간종료일, PackageTypeID, 오류내용");
		batchXlsHistProcess.insertHistXlsDownload(histModel);
		return download(excelList, request, response);
	}

	@PostMapping("/package/download-excel")
	public ResponseEntity<?> downloadExcel(@RequestBody List<BatchPackageUploadModel> in, HttpServletRequest request, HttpServletResponse response) {
		List<PackageUploadExcelModel> excelList = service.getPackageExcelList(in);

		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		String tagretUrl = request.getRequestURL().toString();
		histModel.setDwldPageUrl(tagretUrl.split("\\?")[0]);
		histModel.setInnfVwCnt(excelList.size());
		histModel.setDwldPageNm("패키지 관리");
		histModel.setDwldCont("검진센터명, 패키지명, 패키지타입, 성별, 패키지기본타입가격, 제안서기간시작일, 제안서기간종료일, PackageTypeID, 오류내용");
		batchXlsHistProcess.insertHistXlsDownload(histModel);
		return download(excelList, request, response);
	}

	@PostMapping("/package/type-template")
	ResponseEntity<?> typeTemplate(HttpServletRequest request, HttpServletResponse response) throws Exception  {

		return downloadExcel(service.getPackageTypeTemplate(), request, response, "typeTemplate", PackageTypeItemExcelModel.class);
	}

	@PostMapping("/package-type/upload")
	void uploadType(@RequestBody PackageItemUploadBasicModel in) throws IOException {

		// Excel convert
		FileConvertInput<LocalExcelFileToMultipleSheetDataConverter.Option, Map<Object, List<RowInfo>>> converter =
			LocalExcelFileToMultipleSheetDataConverter.builder(in.getFileGrpId(), true, Arrays.asList(Map.class, Map.class), Arrays.asList("1_", "2_"))
			.metaDataId(FileConvertInput.FileMetaId.builder().fileId(in.getFileId()).fileNos(Arrays.asList(in.getFileNo())).build())
			.build();
		Map<Object, List<RowInfo>> converted = fileOperationManager.convert(converter);

		// 시트 개수가 2보다 작으면 오류 처리한다.
		if( converted.size() < 2 )
			BatchResponseCode.INVALID_SHEET.occur();

		service.packageTypeValidate(converted, in.getClcoId(), in.getYr(), in.getCuiId(), false);
	}

	@PostMapping("/package-type/result")
	BatchPackageUploadResultModel getPackageTypeUploadResult(@RequestBody BatchPackageUploadResultRequestModel in) {

		return service.packageTypeUploadResult(in);
	}

	@PostMapping("/package-type/error-list")
	List<BatchPackageTypeUploadErrorModel> getPackageTypeUploadErrorList(@RequestBody BatchPackageUploadResultRequestModel in) {

		return service.packageTypeUploadErrorList(in);
	}

	@PostMapping("/package-type/remove")
	void removePackageTypeUpload(@RequestBody List<PackageItemUploadRemoveRequestModel> in) {

		service.packageTypeUploadRemove(in);
	}

	@PostMapping("/package-type/remove-all")
	void removeAllPackageTypeUpload(@RequestBody BatchPackageUploadResultRequestModel in) {

		service.packageTypeUploadRemoveAll(in);
	}

	@PostMapping("/package-type/regist")
	void registPackageType(@RequestBody PackageItemUploadBasicModel in) {

		service.packageTypeRegist(in);
	}

	@PostMapping("/package-type/update")
	void updatePackageType(@RequestBody List<BatchPackageTypeUploadErrorModel> in) {

		service.packageTypeUpdate(in);
	}

	/**
	 *
	 * 처리내용 : 엑셀 다운로드
	 * @param request, response, excelFileName, classType
	 * @return
	 */
	private ResponseEntity<?> downloadExcel(List<?> in, HttpServletRequest request, HttpServletResponse response, String excelFileName, Class classType) throws Exception {
		// ResponseEntity<Resource>
//		File directory = new File("C:\\temp\\excel\\");
//		if(!directory.exists()) {
//			try {
//				directory.mkdir();
//				//				LOGGER.info("Directory has been created.");
//			} catch(GchcException e) {
//				//				e.getStackTrace();
//			}
//		}
//		String fileName = excelFileName;
//		String filePath = "C:\\temp\\excel\\" + fileName + ".xlsx";
		String basePath = File.separator + "share" + File.separator + "data" + File.separator + "files" + File.separator + "privateexcel" + File.separator;
		File directory 	= new File(basePath);
		if(!directory.exists()) {
			try {
				directory.mkdir();
			} catch(Exception e) {
				e.getStackTrace();
			}
		}
		String fileName = excelFileName + ".xlsx";
		String filePath = basePath + fileName;

		final FileOutputStream fos = new FileOutputStream(filePath);

       UstraExcelUtils.saveSheet(fos, in, classType);

	   // SPARROW 1490476 RESOURCE_LEAK
	   fos.close();

       try {
       	Resource resource = resourceLoader.getResource("file:" + filePath);
       	File file = resource.getFile();
       	//        	LOGGER.info("다운로드 할 파일 " + file.length());

       	WebResourceAttachFileConverter w = new WebResourceAttachFileConverter();
       	Option option = new Option(fileName, true, request, response);
       	List<Resource> fileResources = new ArrayList<>();
       	fileResources.add(resource);
			option.setFileResources(fileResources);
			return w.convert(option );
       } catch(FileNotFoundException e) {
       	//	      	LOGGER.info("### FileNotFoundGchcException : " + e);
       	//	      	e.printStackTrace();
	      	return ResponseEntity.badRequest().body(null);
       } catch(GchcException e) {
       	//	      	LOGGER.info("### GchcException : " + e);
       	//	      	e.printStackTrace();
	      	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
       }
	}

	/**
	 * 패키지관리 메인 조회
	 *
	 * @param  PackageItemUploadBasicModel
	 * @return List<PackageItemSelectModel>
	 */
	@GetMapping("/package/getPkgUploadList")
	public List<PackageItemSelectModel> getPkgUploadList(PackageItemUploadBasicModel model) {
		System.out.println("##### model = "+model);
		return service.getPkgUploadList(model);
	}

	/**
	 * 패키지관리 상세 조회
	 *
	 * @param  PackageItemUploadBasicModel
	 * @return List<PackageItemSelectModel>
	 */
	@GetMapping("/package/getPkgUploadDtlList")
	public List<PackageItemSelectModel> getPkgUploadDtlList(PackageItemUploadBasicModel model) {
		return service.getPkgUploadDtlList(model);
	}

    /**
     * 패키지-타입 메인 조회
     *
     * @param  PackageItemUploadBasicModel
     * @return List<PackageItemSelectModel>
     */
    @GetMapping("/package/getPkgTypeUploadList")
    public List<PackageTypeItemSelectModel> getPkgTypeUploadList(PackageItemUploadBasicModel model) {
        System.out.println("##### getPkgTypeUploadList model = "+model);
        return service.getPkgTypeUploadList(model);
    }

	public ResponseEntity<?> download(List<PackageUploadExcelModel> pkgList, HttpServletRequest request, HttpServletResponse response) {

		return fileOperationManager.convert(
			DataToExcelWebResourceConverter.entityBuilder(
				Arrays.asList(UstraExcelModel.of(
					pkgList.stream()
					.map(p->{
						Map<String, Object> r = new HashMap<>();
						r.put("col1", p.getCuiNm());
						r.put("col2", p.getPkgNm());
						r.put("col3", p.getPkgTyCont());
						r.put("col4", p.getSexCdNm());
						r.put("col5", p.getPkgBscPrcVal());
						r.put("col6", p.getPrpPridSrtDt());
						r.put("col7", p.getPrpPridEndDt());
						r.put("col8", p.getUpldPkgId());
						r.put("col9", p.getPkgErrCont());
						return r;
					})
					.collect(Collectors.toList()),
					Arrays.asList(
						new UstraExcelCellInfoModel("col1"	, "검진센터명"),
						new UstraExcelCellInfoModel("col2"	, "패키지명"),
						new UstraExcelCellInfoModel("col3"	, "패키지타입"),
						new UstraExcelCellInfoModel("col4"	, "성별"),
						new UstraExcelCellInfoModel("col5"	, "패키지기본타입가격"),
						new UstraExcelCellInfoModel("col6"	, "제안서기간시작일"),
						new UstraExcelCellInfoModel("col7"	, "제안서기간종료일"),
						new UstraExcelCellInfoModel("col8"  , "PackageTypeID"),
						new UstraExcelCellInfoModel("col9"  , "오류내용")
					)
				)
				.withCellGenerator(new BatchUploadCellGenerator(Arrays.asList(
						"검진센터명",
						"패키지명",
						"패키지타입",
						"성별",
						"패키지기본타입가격",
						"제안서기간시작일",
						"제안서기간종료일"
					)))
				.withSheetName("패키지등록")), "패키지등록", request, response)
			.build());
	}


	@PostMapping("/package/templateExcelDown")
	public ResponseEntity<?> excelDownload(@RequestBody ExamItemModel in, HttpServletRequest request, HttpServletResponse response) {
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		List<Map<String, Object>> list1 = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		//ExaminationSrcModel src = new ExaminationSrcModel();
		// 1. 결과 목록호출 resultFlag (0:전체, 1:성공, 2:에러)
		// System.out.println("##### getResultFlag() = "+in.getResultFlag());

		//List<PackageUploadExcelModel> pkgList = examinationService.getPackageExcelList(in);
		// List<ExamItemModel> examItemList = examItemService.getExamItemList(in);
		List<ExamItemModel> examItemList = service.getExamItemTemplateList(in);
		//System.out.println("############# excelList.size = "+vaccineList.size());
		String brdtArr[];
		String bryr = "";
		String brdt = "";
		String sexCd = "";

		// 2. 공통백신결과 List MAP 처리
		for(int i=0; i<examItemList.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			ExamItemModel exMap = examItemList.get(i);				// 패키지 조회결과 리스트

			map.put("col1"	, exMap.getCatNm());		// 카테고리
			map.put("col2"	, exMap.getCatDetailNm());	// 검진세부항목
			map.put("col3"	, exMap.getExamItmNm());	// 검사명
			map.put("col4"	, "");						// 테스트패키지-종합검진I-150000 (공백)
			map.put("col5"	, "");						// 비고 (공백)
			map.put("col6"	, "");						// 테스트패키지-종합검진II-160000 (공백)
			map.put("col7"	, "");						// 비고 (공백)

			list.add(map);
		}
		System.out.println("#### list = "+list.toString());

		// 3. 헤더 값   매핑
		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "카테고리"),
				new UstraExcelCellInfoModel("col2"	, "검진세부항목"),
				new UstraExcelCellInfoModel("col3"	, "검사명"),
				new UstraExcelCellInfoModel("col4"	, "테스트패키지-종합검진I-150000"),
				new UstraExcelCellInfoModel("col5"	, "비고"),
				new UstraExcelCellInfoModel("col6"	, "테스트패키지-종합검진II-160000"),
				new UstraExcelCellInfoModel("col7"	, "비고")
			))
		.withCellGenerator(new BatchUploadCellGenerator())
		.withSheetName("1_");	// 시트명

		UstraExcelModel excelModel1;
		excelModel1 = UstraExcelModel.of(
			list1,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "카테고리"),
				new UstraExcelCellInfoModel("col2"	, "검진세부항목"),
				new UstraExcelCellInfoModel("col3"	, "검사명"),
				new UstraExcelCellInfoModel("col4"	, "추가검사선택시비용"),
				new UstraExcelCellInfoModel("col5"	, "비고")
			))
		.withCellGenerator(new BatchUploadCellGenerator())
		.withSheetName("2_");	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel, excelModel1), "일괄업로드패키지타입등록_V1_4", request, response)
				.build());
	}
}
