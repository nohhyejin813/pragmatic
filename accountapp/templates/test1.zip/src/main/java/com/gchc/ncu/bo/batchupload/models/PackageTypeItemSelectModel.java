package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class PackageTypeItemSelectModel extends UstraManagementBaseModel {

	private int pkgId;			// 패키지 아이디
	private String pkgNm;		// 패키지 명
	private int pkgTyId;		// 패키지타입 아이디
	private String yr;			// 연도
	private int clcoId;			// 고객사 아이디
	private String pkgTyNm;		// 패키지 타입명
	private int prc;			// 패키지타입금액
	private String pkgStCd;		// 패키지상태코드
	private String chexNm;		// 패키지유형명

}
