package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
public class BatchMemberUploadCustomerReentryModel extends NcuModel {

	private Integer clcoId;

	private Integer yr;

	private Integer aempReenRegSeq;

	private Integer uid;

	private String aempNm;

	private String aempBrdt;

	private String aempSexCd;

	private String existAempId;

	private String newAempId;

	private String pkgNm;

	private Integer corpSpfnVal;

	private Integer upldYn;

	private Integer mngrId;

	private Integer upldStVal;

	private String upldErrVal;

	private Integer useYn;

	private Integer delYn;
}
