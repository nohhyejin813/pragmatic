package com.gchc.ncu.bo.abnormalfindings.vo;

import java.util.ArrayList;

import com.gchc.common.model.GchcPageableVo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AbnfMemberVo extends GchcPageableVo
{
	@ApiModelProperty(value="고객사Id")
	private Integer[] clcoIds;

	@ApiModelProperty(value="고객사 검색 타입(고객명, 사번, UID, 휴대폰전화, 일반전화, 생년월일, 이메일)")
	private String clcoSearchTy;

	@ApiModelProperty(value="고객사 검색어")
	private String clcoSearch;

	@ApiModelProperty(value="건강습관평가")
	private Integer asmSt;

	@ApiModelProperty(value="건강습관평가 시작일")
	private String asmFromDt;

	@ApiModelProperty(value="건강습관평가 종료일")
	private String asmToDt;


	@ApiModelProperty(value="1차군 선택")
	private Integer tmpSvcgCd;

	@ApiModelProperty(value="2차군 선택")
	private Integer[] svcgDtlCd;


	@ApiModelProperty(value="군진행 상태(고객상태)")
	private Integer pgrsStCd;

	@ApiModelProperty(value="다운로드 메모")
	private String dwldMemo;

	@ApiModelProperty(value="다운로드 사유코드")
	private String dwldRsnCd;

	@ApiModelProperty(value="다운로드 접근경로")
	private String dwldPageUrl;



	public void setSvcgDtlCd(Integer[] svcgDtlCd) {
		if(svcgDtlCd.length == 1)
		{
			this.svcgDtlCd = null;
		}
		else
		{
			ArrayList<Integer> list = new ArrayList<Integer>();
			for(int i = 1; i < svcgDtlCd.length; i++)
			{
				if(svcgDtlCd[i] != -1)
				{
					list.add(svcgDtlCd[i]);
				}
			}
			if(list.size() > 0)
			{
				this.svcgDtlCd = list.toArray(new Integer[list.size()]);
			}
		}
	}



}




