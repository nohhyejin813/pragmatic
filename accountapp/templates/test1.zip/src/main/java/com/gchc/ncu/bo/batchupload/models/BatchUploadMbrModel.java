package com.gchc.ncu.bo.batchupload.models;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchUploadMbrModel extends UstraManagementBaseModel {
	private Integer yr;				// 기준년도

	// MBR.T_MBR_BSC
	private Integer uid;			// 회원 아이디
	private String nm;				// 이름 50 length
	private String sexCd;			// 성별 코드 1 length
	private String brdt; 			// 생년월일 10 length
	private Integer lunYn; 			// 음력 여부 bit
	private String emlAdr;			// 이메일주소
	private String ciVal;			// CI 값
	private String selfAthoTyCd;	// 본인인증유형 코드
	private String athoDtm;			// 인증일시 datetime2
	private String mbrTyCd;			// 회원유형 코드
	private String mbrStCd;			// 회원상태 코드
	private Integer uprUid;			// 상위회원 아이디
	private Integer appLginFailCnt;	// 앱로그인실패횟수
	private String mblNo;			// 휴대전화번호
	private Integer slctClcoId;		// 선택고객사 아이디
	private Integer tstIdYn;		// 테스트아이디 여부 bit
	@ApiModelProperty(value="최초등록일시")
	private String frstRegDtm;
	@ApiModelProperty(value="최초등록자유형코드")
	private String frstRegrTyCd;
	@ApiModelProperty(value="최초등록자 ID")
	private String frstRegrId;
	@ApiModelProperty(value="최종수정일시")
	private String lastUpdDtm;
	@ApiModelProperty(value="최종수정자유형코드")
	private String lastUpdrTyCd;
	@ApiModelProperty(value="최종수정자 ID")
	private String lastUpdrId;
	private Integer webLginFailCnt;	// 웹로그인실패횟수
	private String mbrAthoKvl;		// 회원인증키값
	private String instToknVal;		// 기기토큰값
	private Integer mbrGrdVal;		// 회원등급값

	// T_CU_TGT_HIS (헬스케어_검진대상내역)
	private Integer cuTgtId;		// 검진기관 아이디
	// private Integer uid;			// 회원 아이디
	private String tgtYr;			// 대상년도
	private Integer spcuTgtYn;		// 특수검진대상여부
	private String prcsStCd;		// 처리상태코드
	private String datCrtDtm;		// 데이터생성일시 datetime2
	private Integer excuYn;			// 임원 여부 bit
	private Integer spltYn;			// 분할 여부 bit
	private Integer tnsfYn;			// 양도 여부 bit
	private Integer tnsfTgtrRegYn;	// 양도대상자등록 여부 bit
	private String custMemo;		// 고객메모 ntext
	private Integer suptSpltAmt;	// 지원분할금액
	private Integer clcoId;			// 고객사 아이디
	private Integer delYn;			// 삭제 여부

	// T_CU_TGTR_HIS (헬스케어_검진대상자내역)
	private Integer cuTgtrId;		// 검진대상자 아이디
	// private Integer cuTgtId;		// 검진대상 아이디
	// private String nm;			// 이름
	// private String brdt;			// 생년월일
	// private String mblNo;		// 휴대전화번호
	private String tlno;			// 전화번호
	// private String emlAdr;		// 이메일주소
	private String zpcd;			// 우편번호
	private String bscAdr;			// 기본주소
	private String dtlAdr;			// 상세주소
	private String agDvCd;			// 나이구분 코드
	private String corpSpfnVal;		// 회사지원금 corpSpfn(Integer) -> corpSpfnVal(String) 20211220
	private Integer nhicTgtYn;		// 건강보험공단대상 여부 bit
	// private String datCrtDtm;	// 데이터생성일시 datetime2
	private String memo;			// 메모
	private Integer mbrGrdId;		// 회원등급 아이디
	private String pkgNm;			// 패키지명
	private Integer emlRcvAgrYn;	// 이메일수신동의 여부 bit
	private Integer smsRsvAgrYn;	// SMS수신동의 여부 bit
	private Integer suptTgtDsgtYn;	// 지원대상지정 여부 bit
	private Integer tnsfTgtrYn;		// 양도대상자 여부 bit
	private String suptTgtrDvCd;	// 지원대상자구분 코드
	private Integer cuTgtUid;		// 검진대상회원 아이디
	private Integer cuTgtrUid;		// 검진대상자회원 아이디
	private Integer spltTgtrYn;		// 분할대상자 여부]
	// private Integer delYn;		// 삭제 여부

	// T_SUSE_SPFN_TGT_INF_BSC (향후 추가 테이블)

	// T_EXTR_HNDL_MTTR_RESV_TGT (헬스케어_특수물질취급물질예약대상)
	private Integer extrHndlMttrResvTgtId;	// 특수취급물질예약대상 아이디
	// private Integer cuTgtId;				// 검진기관 아이디
	private Integer extrHndlMttrId;			// 특수취급물질 아이디
	private String spcuResvDvCd;			// 특수검진예약구분 코드
	// private Integer delYn;				// 삭제 여부

}
