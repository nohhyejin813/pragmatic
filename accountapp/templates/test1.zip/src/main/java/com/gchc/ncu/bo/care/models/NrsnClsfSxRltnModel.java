package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class NrsnClsfSxRltnModel extends UstraManagementBaseModel {

	private Integer nrsnSxId;
	private Integer nrsnClsfId;
	private String nrsnClsfNm;
	private String nrsnCatCd;
	private String nrsnCatNm;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
