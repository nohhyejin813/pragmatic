package com.gchc.ncu.bo.abnormalfindings.models.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;




@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentEnterPriseStatisticssModel extends UstraManagementBaseModel
{
	@ApiModelProperty(value="년도")
	private String yr;

	@ApiModelProperty(value="전체")
	private Integer totalCnt;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt;

	@ApiModelProperty(value="정상A_%")
	private String normalCntPer;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt;

	@ApiModelProperty(value="정상B(경계)_%")
	private String warningCntPer;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt;

	@ApiModelProperty(value="정상B(경계)_%")
	private String careCntPer;
}
