package com.gchc.ncu.bo.batchupload.repository;

import com.gchc.ncu.bo.batchupload.models.BatchUploadTgtrModel;
import com.gchc.ncu.bo.member.models.MemberClcoRltnModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * @FileName : BatchCampaignUploadRepository.java
 * @date : 2023. 02. 01
 * @author : jclee
 * @프로그램 설명 : 부가정보변경 일괄업로드 Repository
 * @변경이력 :
 */
@Mapper
public interface BatchResignationUploadRepository {
    String getAempInformation(Map<String, Object> map);
    void updateAempResignation(Map<String, Object> map);
    int getAempHffcStcd(Map<String, Object> map);
    BatchUploadTgtrModel getAempInfo(Map<String, Object> map);
    /**
     * 처리내용 : #13314 신한은행 퇴사자 일괄 반영 요청 건 by 양재환 2023-03-09
     * @return
     */
    List<MemberClcoRltnModel> getAempRsntList();

    void updateAempRsnt(MemberClcoRltnModel vo);

    //    List<BatchUploadTgtrModel> getAempReservationInfo(Map<String, Object> map);

    int getAempReservationCount(Map<String, Object> map);
    List<BatchUploadTgtrModel> getAempReservationInfo(Map<String, Object> map);
    /**
     *  #14875 퇴사자일괄반영기능 by 양재환 2023-05-03
     * @return
     */
    List<MemberClcoRltnModel> getAempRsntList2(int clcoId);
}
