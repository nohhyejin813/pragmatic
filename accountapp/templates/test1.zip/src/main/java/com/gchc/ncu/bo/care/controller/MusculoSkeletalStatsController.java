package com.gchc.ncu.bo.care.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.ncu.bo.care.models.MusculoSkeletalStatsModel;
import com.gchc.ncu.bo.care.models.MusculoSkeletalStatusModel;
import com.gchc.ncu.bo.care.service.MusculoSkeletalStatsService;
import com.gchc.ncu.bo.care.vo.MusculoSkeletalStatsVo;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/musc-stats/")
@RequiredArgsConstructor
public class MusculoSkeletalStatsController {

	private final MusculoSkeletalStatsService service;

	@GetMapping("/search-condition/yr")
	public List<Map<String, Object>> getYearList() {
		return service.getYearList();
	}

	@GetMapping("/search-condition/clco")
	public List<Map<String, Object>> getClcoListByYear(@RequestParam(name="year") String year) {
		return service.getClcoListByYear(year);
	}

	@GetMapping("/search-condition/bspl")
	public List<Map<String, Object>> getClcoList(@RequestParam(name="yr") String yr, @RequestParam(name="clcoId") int clcoId, @RequestParam(name="joinCd", required = false) String joinCd) {
		Map<String, Object> params = new HashMap<>();

		params.put("yr", yr);
		params.put("clcoId", clcoId);
		params.put("joinCd", joinCd);

		return service.getBsplListByClcoId(params);
	}

	@GetMapping("/items")
	public List<MusculoSkeletalStatsModel> getStatisticsItems(@ModelAttribute MusculoSkeletalStatsVo vo) {
		return service.getStatisticsItems(vo);
	}

	@GetMapping("/status")
	public List<MusculoSkeletalStatusModel> getStatisticsListStatus(@ModelAttribute MusculoSkeletalStatsVo vo) {
		return service.getStatisticsListStatus(vo);
	}

}
