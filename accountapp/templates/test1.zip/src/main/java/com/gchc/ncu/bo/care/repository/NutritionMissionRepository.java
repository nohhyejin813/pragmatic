package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.NtrtMsnBscModel;
import com.gchc.ncu.bo.care.vo.NutritionMissionVo;

@Mapper
public interface NutritionMissionRepository {

	List<NtrtMsnBscModel> selectNutritionMissionList(NutritionMissionVo criteria);
	NtrtMsnBscModel selectNutritionMissionDetail(NtrtMsnBscModel criteria);
	void insertNutritionMissionBase(NtrtMsnBscModel model);
	void updateNutritionMissionBase(NtrtMsnBscModel model);
	void deleteNutritionMissionBase(NtrtMsnBscModel model);
	int selectUsedNutritionMissionCount(NtrtMsnBscModel model);

}
