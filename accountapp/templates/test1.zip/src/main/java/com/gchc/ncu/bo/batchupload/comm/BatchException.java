package com.gchc.ncu.bo.batchupload.comm;

import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.core.exception.UstraException;

public class BatchException extends UstraException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public BatchException(ResponseCode code) {
		super(code);
	}

	public BatchException(ResponseCode code, Object[] messageArguments) {
		super(code, messageArguments);
	}
}
