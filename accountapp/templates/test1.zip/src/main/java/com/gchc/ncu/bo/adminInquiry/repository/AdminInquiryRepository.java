package com.gchc.ncu.bo.adminInquiry.repository;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gchc.ncu.bo.abnormalfindings.models.AbnfCodeModel;
import com.gchc.ncu.bo.abnormalfindings.models.AbnfMemberModel;
import com.gchc.ncu.bo.abnormalfindings.models.HthSvcModel;
import com.gchc.ncu.bo.abnormalfindings.models.MemberInfoModel;
import com.gchc.ncu.bo.abnormalfindings.vo.AbnfMemberVo;
import com.gchc.ncu.bo.adminInquiry.models.WebInquiryModel;
import com.gchc.ncu.bo.comm.models.CommonApprovalStatusCodeModel;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.mybatis.executor.Many;


/**
 *
 * @author spm
 *
 */
@Mapper
public interface AdminInquiryRepository
{
	Integer insertAdminInquiry(@Valid WebInquiryModel vo);

}

