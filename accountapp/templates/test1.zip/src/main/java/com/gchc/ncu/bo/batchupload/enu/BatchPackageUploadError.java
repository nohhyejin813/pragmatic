package com.gchc.ncu.bo.batchupload.enu;

import java.text.MessageFormat;

public enum BatchPackageUploadError {

	MISSING_INFORMATION("2", "{0}이(가) 누락되었습니다."),

	INVALID_INFORMATION("3", "{0}이(가) 잘못되었습니다."),

	NO_DIGIT("2", "{0}이(가) 숫자가 아닙니다."),

	TOO_SMALL_PRICE("2", "금액이 1000 이하입니다.")

	;

	String errCd;
	String message;

	BatchPackageUploadError(String value, String message) {

		this.message = message;
		this.errCd = value;
	}

	public String getErrorCd() {

		return this.errCd;
	}

	public String getMessage(Object...args) {

		return MessageFormat.format(this.message, args);
	}
}
