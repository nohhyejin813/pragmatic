package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.ChrcBscModel;
import com.gchc.ncu.bo.care.models.ChrcDtlModel;
import com.gchc.ncu.bo.care.vo.CsttMateVo;

@Mapper
public interface CsttMateRepository {

	List<ChrcBscModel> selectCsttMateBsc(CsttMateVo criteria);
	List<ChrcDtlModel> selectCsttMateDtl(CsttMateVo criteria);
	void updateCsttMateBsc(ChrcBscModel model);
	void insertCsttMateDtl(ChrcDtlModel model);
	void updateCsttMateDtl(ChrcDtlModel model);
	void deleteCsttMateDtl(ChrcDtlModel model);


}
