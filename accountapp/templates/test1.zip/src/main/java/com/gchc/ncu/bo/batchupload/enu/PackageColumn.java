package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum PackageColumn implements BatchUploadColumn {

	CUI_NM("검진센터명", "CuiNm"),

	PKG_NM("패키지명", "PkgNm"),

	PKG_TY_NM("패키지타입", "PkgTyCont"),

	SEX_CD_NM("성별", "SexCdNm"),

	PKG_PRC("패키지기본타입가격", "PkgBscPrcVal"),

	PRIP_SRT_DT("제안서기간시작일", "PrpPridSrtDt"),

	PRIP_END_DT("제안서기간종료일", "PrpPridEndDt"),

	PKG_TY_ID("PackageTypeID", "UpldPkgId", false)

	;

	String title;

	String field;

	boolean required;

	PackageColumn(String title, String field) {

		this.title = title;
		this.field = field;
		this.required = false;
	}

	PackageColumn(String title, String field, boolean required) {

		this.title = title;
		this.field = field;
		this.required = required;
	}
}
