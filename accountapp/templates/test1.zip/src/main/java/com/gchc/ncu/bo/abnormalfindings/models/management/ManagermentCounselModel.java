package com.gchc.ncu.bo.abnormalfindings.models.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.gchc.common.model.GchcPageableVo;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;

@Data
@Builder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentCounselModel extends GchcPageableVo
{
	private Integer rowNum;
	private Integer totalCnt;

	private Integer uid;

	@Masked(MaskingType.ID)
	private String empno;

	@ApiModelProperty(value="사업장 이름")
	private String bsplNm;

	private String deptNm;

	@ApiModelProperty(value="기업 ID")
	private Integer clcoId;

	@ApiModelProperty(value="부서ID")
	private Integer deptId;

	@ApiModelProperty(value="유저 이름")
	@Masked(MaskingType.NAME)
	private String nm;

	private String birthDay;

	@ApiModelProperty(value="검진ID")
	private Integer cuRecId;

	private String cnslTy;

	private String cnslCta;

	private String cnslTitl;

	private String msrCont;

	private String abnfCnslMemo;
	private String cnslDtm;


	private Integer abnfCnslId;


	@ApiModelProperty(value="암예방군")
	private String cont;
}

