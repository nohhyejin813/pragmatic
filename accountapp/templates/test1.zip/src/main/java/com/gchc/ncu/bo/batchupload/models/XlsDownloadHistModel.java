package com.gchc.ncu.bo.batchupload.models;

import lombok.Data;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Data
public class XlsDownloadHistModel extends NcuModel {

	String dwldPageNm;

	String dwldCont;

	String dwldPageUrl;

	String dwldMemo;

	String dwldCustNm;

	Integer innfVwCnt;
}
