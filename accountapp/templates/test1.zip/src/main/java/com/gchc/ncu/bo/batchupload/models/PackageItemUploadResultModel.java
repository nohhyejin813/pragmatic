package com.gchc.ncu.bo.batchupload.models;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Getter
@Setter
@EqualsAndHashCode(callSuper=false)
public class PackageItemUploadResultModel extends UstraManagementBaseModel {

	int totalCount;

	int successCount;

	int errorCount;

	List<String> headers;

	List<PackageItemUploadErrorModel> errorDesc;
}
