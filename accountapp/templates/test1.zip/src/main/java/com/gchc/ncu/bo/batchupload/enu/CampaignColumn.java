package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum CampaignColumn implements BatchUploadColumn {

	CLCO_NM("고객사"		, "ClcoNm"		),

	AEMP_NM("이름"			, "AempNm"		),

	AEMP_ID("사번"			, "AempId"		),

	WORK_DEPT_NM("근무부서"	, "WorkDeptNm"	),

	LINE_NM("라인"			, "LineNm"		),

	JOB_NM("작업"			, "JobNm"		),
	
	TEAM_NM("캠페인팀"		, "TeamNm"		);

	String title;	// 제목

	String field;	// 필드명

	CampaignColumn(String title, String field) {
		this.title = title;
		this.field = field;
	}
}
