package com.gchc.ncu.bo.batchupload.enu;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public interface BatchUploadColumn {

	public String getTitle();

	public String getField();

	public static <T extends Enum<T>> Stream<T> stream(Class<T> clazz) {

		return Arrays.asList(clazz.getEnumConstants()).stream();
	}

	@SuppressWarnings("unchecked")
	public static <T extends Enum<T>> Map<String, String> table(Class<T> clazz) {

		return stream(clazz)
			.collect((Collector<? super T, ?, Map<String, String>>)Collectors.toMap(BatchUploadColumn::getTitle, BatchUploadColumn::getField));
	}
}
