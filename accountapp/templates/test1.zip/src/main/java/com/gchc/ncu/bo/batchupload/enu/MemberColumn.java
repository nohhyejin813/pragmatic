package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum MemberColumn implements BatchUploadColumn {

	AEMP_NM("이름", "AempNm"),

	AEMP_CU_GRD_NM("등급", "AempCuGrdNm"),

	AEMP_VCN_GRD_NM("백신등급", "AempVcnGrdNm"),

	AEMP_ID("사번", "AempId"),

	EXCU_YN("임원여부", "ExcuYn"),

	AEMP_BRDT("생년월일", "AempBrdt"),

	ENCM_DT("입사일", "EncmDt"),

	PKG_NM("검진패키지", "PkgNm"),

	CORP_SPFN_VAL("지원금", "CorpSpfnVal"),

	NHIC_SUPT_TGT_YN("공단지원여부", "NhicSuptTgtYn"),

	SPCU_TGT_YN("특수검진여부", "SpcuTgtYn"),

	EXTR_MTTR_NM1("특수물질(1차)", "ExtrMttrNm1"),

	EXTR_MTTR_NM2("특수물질(2차)", "ExtrMttrNm2"),

	EML_ADR("이메일", "EmlAdr"),

	MBL_NO("핸드폰", "MblNo"),

	SPSR_NM("배우자명", "SpsrNm"),

	SPSR_CU_GRD_NM("배우자검진등급", "SpsrCuGrdNm"),

	SPSR_VCN_GRD_NM("배우자백신등급", "SpsrVcnGrdNm"),

	SPSR_BRDT("배우자생년월일", "SpsrBrdt"),

	SPSR_CORP_SPFN("배우자지원금", "SpsrCorpSpfn"),

	SPSR_PKG_NM(" 배우자검진패키지", "SpsrPkgNm"),

	BSPL_NM("사업장", "BsplNm"),

	DEPT_NM1("부서1", "DeptNm1"),

	DEPT_NM2("부서2", "DeptNm2"),

	DEPT_NM3("부서3", "DeptNm3"),

	JBGD_NM("직급", "JbgdNm"),

	WRPL_TL_NO("직장 전화", "WrplTlno"),

	WRPL_ZP_CD("직장 우편번호", "WrplZpcd"),

	WRPL_BSC_ADR("직장 기본 주소", "WrplBscAdr"),

	WRPL_DTL_ADR("직장 상세 주소", "WrplDtlAdr"),

	HS_TL_NO("집 전화", "HsTlno"),

	HS_ZP_CD("집 우편번호", "HsZpcd"),

	HS_BSC_ADR("집 기본 주소", "HsBscAdr"),

	HS_DTL_ADR("집 상세 주소", "HsDtlAdr"),

	AEMP_REG_SEQ("MemberId", "AempRegSeq"),

	WORK_DEPT_NM("근무부서명", "WorkDeptNm"),

	LINE_NM("라인명", "LineNm"),

	JOB_NM("작업명", "JobNm"),

	TEAM_NM("캠페인팀", "TeamNm"),

	CUST_MEMO("어떠케어 특이사항", "CustMemo")

	;

	String title;

	String field;

	MemberColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
