package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.ChrcBscModel;
import com.gchc.ncu.bo.care.models.ChrcDtlModel;
import com.gchc.ncu.bo.care.service.CsttMateService;
import com.gchc.ncu.bo.care.vo.CsttMateVo;

@RestController
@RequestMapping("/api/bo/care/cstt/mate")
@RequiredArgsConstructor
public class CsttMateController {

	private final CsttMateService MateService;

	@GetMapping("/searchBsc")
	public List<ChrcBscModel> searchBsc(@ModelAttribute CsttMateVo criteria) {
		return MateService.getCsttMateBsc(criteria);
	}

	@GetMapping("/searchDtl")
	public List<ChrcDtlModel> searchDtl(@ModelAttribute CsttMateVo criteria) {
		return MateService.getCsttMateDtl(criteria);
	}

	@PostMapping("/saveBsc")
	public RestResult<?> updateCsttMateBsc(@RequestBody @Valid ChrcBscModel model) {
		MateService.updateCsttMateBsc(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/saveDtl")
	public RestResult<?> saveCsttMateDtl(@RequestBody @Valid ChrcDtlModel model) {
		MateService.saveCsttMateDtl(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<ChrcDtlModel> list) {
		MateService.deleteCsttMateDtl(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
