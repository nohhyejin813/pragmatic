package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClcoCtraTnsfInfoModel {

	private String tnsfTgtrSlctRngCd;

	private Integer tnsfSpfnUseYn;

	private String spfnTnsfDvCd;

	private Integer slctSpfnUseYn;
}
