package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum PackageTypeColumn implements BatchUploadColumn{

	CAT_NM("카테고리", "ItmCatNm"),

	SUB_CAT_NM("검진세부항목", "DtlCatItmNm"),

	EXAM_NM("검사명", "ExamNm")

	;

	String title;

	String field;

	PackageTypeColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
