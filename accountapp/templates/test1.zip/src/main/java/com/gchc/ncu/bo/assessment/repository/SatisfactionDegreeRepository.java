package com.gchc.ncu.bo.assessment.repository;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.domains.PaginationRequest;

import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.SatisfactionDegreeModel;
import com.gchc.ncu.bo.unicmm.models.FaqModel;

/**
 * 프로토타입 Repository
 *
 * @author gs_hykim@gchealthcare.com
 */
@Mapper
public interface SatisfactionDegreeRepository {

	int 							getSatisfactionLastYear();
	int[]							getSatisfactionYears();

	List<SatisfactionDegreeModel>	getSatisfactionDegreeClcoList(int srchYr);
	List<SatisfactionDegreeModel>	getSatisfactionDegreeCuiList(@Param("model")SatisfactionDegreeModel in);
	PaginationList<SatisfactionDegreeModel> getSatisfactionDegreeList(@Param("model")SatisfactionDegreeModel model, PaginationRequest pr);

	SatisfactionDegreeModel			getSatisfactionDegree(@Param("model")SatisfactionDegreeModel model);
	List<SatisfactionDegreeModel> 	getSatisfactionDegreeCommentList(@Param("model")SatisfactionDegreeModel model);
	List<SatisfactionDegreeModel> 	getSatisfactionDegreeCommentAllList(@Param("model")SatisfactionDegreeModel model);

	int								deleteComment(SatisfactionDegreeModel in);
}
