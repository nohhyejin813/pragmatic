package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchPackageTypeUploadErrorModel {

	Integer clcoId;

	Integer cuiId;

	Integer yr;

	String itmCatNm;

	String dtlCatItmNm;

	String examResvItmNm;

	String pkgItmAtriVal;

	String etcVal;

	Integer xclRowId;

	Integer xclComnId;

	Integer xclShtNo;

	String pkgVal;

	Integer pkgTitlStVal;

	String pkgTitlErrCont;

	Integer pkgItmStVal;

	String pkgItmErrCont;

	Integer pkgItmUpldStVal;

	String pkgItmErrStVal;
}
