package com.gchc.ncu.bo.batchupload.controller;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.file.model.FileConvertInput;
import com.gsitm.ustra.java.data.file.processor.convert.LocalExcelFileToMultipleSheetDataConverter;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import com.gsitm.ustra.java.data.poi.convert.UstraExcelCellEncoder;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.batchupload.models.BatchMemberTransferUploadResultModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberTransferUploadValidateRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadCustomerDetailModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadDetailErrorRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadReentryDownloadRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadResultRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadMultiFamilyExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadTransferExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadTransferFamilyExcelModel;
import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.batchupload.service.BatchMemberTransferUploadService;

@RestController
@RequestMapping("/api/bo/batchupload/transfer")
public class BatchMemberTransferUploadController {

	@Autowired private BatchMemberTransferUploadService service;

	@Autowired private FileOperationManager fileOperationManager;

	@Autowired private BatchXlsHistProcess batchXlsHistProcess;

	@RequestMapping("/validate")
	public void validate(@RequestBody BatchMemberTransferUploadValidateRequestModel in) {

		// Excel convert
		FileConvertInput<LocalExcelFileToMultipleSheetDataConverter.Option, Map<Object, List<RowInfo>>> converter =
			LocalExcelFileToMultipleSheetDataConverter.builder(in.getFileGrpId(), true, Arrays.asList(
				BatchUploadTransferExcelModel.class,
				BatchUploadTransferFamilyExcelModel.class,
				BatchUploadMultiFamilyExcelModel.class), Arrays.asList(0, 1, 2))
			.metaDataId(FileConvertInput.FileMetaId.builder().fileId(in.getFileId()).fileNos(Arrays.asList(in.getFileNo())).build())
			.build();
		Map<Object, List<RowInfo>> converted = fileOperationManager.convert(converter);

		final int clcoId = in.getClcoId();
		final int yr = in.getYr();

		service.memberValidate(converted, clcoId, yr);
	}

	@RequestMapping("/result")
	public BatchMemberTransferUploadResultModel result(@RequestBody BatchMemberUploadResultRequestModel in) {

		return service.getResult(in);
	}

	@RequestMapping("/remove")
	public void remove(@RequestBody List<BatchMemberUploadCustomerDetailModel> in) {

		service.remove(in);
	}

	@RequestMapping("/remove-all")
	public void removeAll(@RequestBody BatchMemberUploadDetailErrorRequestModel in) {

		service.removeAll(in);
	}

	@RequestMapping("/init")
	public void init(@RequestBody BatchMemberUploadResultRequestModel in) {

		service.init(in);
	}

	@RequestMapping("/regist")
	public void regist(@RequestBody BatchMemberUploadResultRequestModel in) {

		service.regist(in);
	}

	@RequestMapping("/error-list")
	public RestResult<List<BatchMemberUploadCustomerDetailModel>> errorList(@RequestBody BatchMemberUploadDetailErrorRequestModel in) {

		return GchcRestResult.of(service.getErrorList(in));
	}

	@RequestMapping("/download-excel")
	public ResponseEntity<?> downloadExcelReentry(@RequestBody BatchMemberUploadReentryDownloadRequestModel in, HttpServletRequest request, HttpServletResponse response) {

		return convertExcel(service.selectCustomerDetailTmpExcelList(in), request, response);
	}

	@RequestMapping("/download-excel-list")
	public ResponseEntity<?> downloadExcelReentry(@RequestBody List<BatchMemberUploadCustomerDetailModel> in, HttpServletRequest request, HttpServletResponse response) {

		return convertExcel(service.selectCustomerDetailTmpExcelList(in), request, response);
	}

	static class YnEncoder implements UstraExcelCellEncoder {

		@Override
		public String convert(Object src) throws Exception {

			if( src instanceof Integer ) {
				return (int)src == 0 ? "N" : "Y";
			}
			return "";
		}
	}

	String toString(Object src) {

		return ObjectUtils.isEmpty(src) ? "" : src.toString();
	}

	List<Map<String, Object>> getTargetMap(List<BatchMemberUploadCustomerDetailModel> targets) {

		return targets.stream()
			.map(target->{

				Map<String, Object> result = new HashMap<>();
				Arrays.asList(target.getClass().getDeclaredFields()).forEach(f->{

					try {

						f.setAccessible(true);
						if( f.getName().contains("Brdt") ) {

							String brdt = toString(f.get(target));
							if( StringUtils.isNotEmpty(brdt) ) {

								Field sexField = target.getClass().getDeclaredField(f.getName().replace("Brdt", "SexCd"));
								sexField.setAccessible(true);
								result.put(f.getName(), f.get(target).toString().replace("-", "") + "-" + sexField.get(target));
							}
						}
						else
							result.put(f.getName(), f.get(target));
					}
					catch( Exception e ) {

					}
				});

				return result;
			})
			.collect(Collectors.toList());

	}

	ResponseEntity<?> convertExcel(List<BatchMemberUploadCustomerDetailModel> targets, HttpServletRequest request, HttpServletResponse response) {
		String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
		String pageNm = "고객-양도,선택,다중";
		String cont = "양도분할다중등록 sheet, 양도대상자 sheet, 다중대상자sheet";
		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		histModel.setDwldPageUrl(tagretUrl);
		histModel.setInnfVwCnt(targets.size());
		histModel.setDwldPageNm(pageNm);
		histModel.setDwldCont(cont);
		histModel.setDwldCustNm(targets.get(0).getAempNm());
		batchXlsHistProcess.insertHistXlsDownload(histModel);

		List<UstraExcelModel> models = Arrays.asList(
			UstraExcelModel.of(
				getTargetMap(targets),
				Arrays.asList(
					new UstraExcelCellInfoModel("aempNm", "임직원 이름"),
					new UstraExcelCellInfoModel("aempGrdNm", "임직원 등급"),
					new UstraExcelCellInfoModel("aempId", "임직원 사번"),
					new UstraExcelCellInfoModel("tnsfYn", "양도 여부", new YnEncoder()),
					new UstraExcelCellInfoModel("spfnTnsfGrpNm", "양도그룹명"),
					new UstraExcelCellInfoModel("slctSpfnUseYn", "선택 여부", new YnEncoder()),
					new UstraExcelCellInfoModel("slctSpfnSuptSlctGrpNm", "선택그룹명"),
					new UstraExcelCellInfoModel("mltiYn", "다중 여부", new YnEncoder()),
					new UstraExcelCellInfoModel("pkgNm", "다중 검진패키지"),
					new UstraExcelCellInfoModel("corpSpfn", "다중 지원금"),
					new UstraExcelCellInfoModel("mltiSlctTgtrCnt", "다중 지원자수"),
					new UstraExcelCellInfoModel("fmlyGrdNm", "가족 등급"),
					new UstraExcelCellInfoModel("aempDtlRegSeq", "MemberID"),
					new UstraExcelCellInfoModel("upldErrVal", "오류내용")
				)
			)
			.withCellGenerator(new BatchUploadCellGenerator(Arrays.asList(
				"임직원 이름",
				"임직원 사번"
			)))
			.withSheetName("양도분할다중등록"),
			UstraExcelModel.of(
				getTargetMap(targets),
				Arrays.asList(
					new UstraExcelCellInfoModel("aempNm", "임직원 이름"),
					new UstraExcelCellInfoModel("aempId", "임직원 사번"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm1", "가족1이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt1", "가족1생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm2", "가족2이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt2", "가족2생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm3", "가족3이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt3", "가족3생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm4", "가족4이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt4", "가족4생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm5", "가족5이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt5", "가족5생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm6", "가족6이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt6", "가족6생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm7", "가족7이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt7", "가족7생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm8", "가족8이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt8", "가족8생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm9", "가족9이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt9", "가족9생년월일"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyNm10", "가족10이름"),
					new UstraExcelCellInfoModel("tnsfTgtFmlyBrdt10", "가족10생년월일")
				)
			)
			.withCellGenerator(new BatchUploadCellGenerator())
			.withSheetName("양도대상자"),
			UstraExcelModel.of(
				getTargetMap(targets),
				Arrays.asList(
					new UstraExcelCellInfoModel("aempNm", "임직원 이름"),
					new UstraExcelCellInfoModel("aempId", "임직원 사번"),
					new UstraExcelCellInfoModel("fmlyNm1", "가족1이름"),
					new UstraExcelCellInfoModel("fmlyBrdt1", "가족1생년월일"),
					new UstraExcelCellInfoModel("fmlyNm2", "가족2이름"),
					new UstraExcelCellInfoModel("fmlyBrdt2", "가족2생년월일"),
					new UstraExcelCellInfoModel("fmlyNm3", "가족3이름"),
					new UstraExcelCellInfoModel("fmlyBrdt3", "가족3생년월일"),
					new UstraExcelCellInfoModel("fmlyNm4", "가족4이름"),
					new UstraExcelCellInfoModel("fmlyBrdt4", "가족4생년월일"),
					new UstraExcelCellInfoModel("fmlyNm5", "가족5이름"),
					new UstraExcelCellInfoModel("fmlyBrdt5", "가족5생년월일"),
					new UstraExcelCellInfoModel("fmlyNm6", "가족6이름"),
					new UstraExcelCellInfoModel("fmlyBrdt6", "가족6생년월일"),
					new UstraExcelCellInfoModel("fmlyNm7", "가족7이름"),
					new UstraExcelCellInfoModel("fmlyBrdt7", "가족7생년월일"),
					new UstraExcelCellInfoModel("fmlyNm8", "가족8이름"),
					new UstraExcelCellInfoModel("fmlyBrdt8", "가족8생년월일"),
					new UstraExcelCellInfoModel("fmlyNm9", "가족9이름"),
					new UstraExcelCellInfoModel("fmlyBrdt9", "가족9생년월일"),
					new UstraExcelCellInfoModel("fmlyNm10", "가족10이름"),
					new UstraExcelCellInfoModel("fmlyBrdt10", "가족10생년월일")
				)
			)
			.withCellGenerator(new BatchUploadCellGenerator())
			.withSheetName("다중대상자")
		);

		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
					.entityBuilder(models, "양도선택다중", request, response)
					.build());
	}
}
