package com.gchc.ncu.bo.batchupload.processor;

import com.gchc.ncu.bo.batchupload.comm.BatchException;
import com.gchc.ncu.bo.batchupload.exception.BatchRestResult;
import com.gchc.ncu.bo.batchupload.service.BatchPackageUploadService;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.comm.code.NcuResponseCode;
import com.gsitm.ustra.java.data.file.processor.convert.ExcelDataMultisheetPostProcessor;
import com.gsitm.ustra.java.data.file.processor.convert.ExcelFileToMultiSheetDataProcessConverter.Option;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component("batchPackageTypeUploadProcessor")
public class BatchPackageTypeUploadProcessor implements ExcelDataMultisheetPostProcessor {

	@Autowired private BatchPackageUploadService service;

	@Override
	public Object doProcess(Option option, Map<Object, List<RowInfo>> converted) {

		Map<String, String> params = BatchUploadUtils.parseParameter(option.getExcelDataPostProcessorParameter());

		if( !params.containsKey("yr") || "-1".equals(params.get("yr")) || !NumberUtils.isCreatable(params.get("yr")) )
			return BatchRestResult.of("9999", "연도를 선택해야 합니다.");
		if( !params.containsKey("clcoId") || "-1".equals(params.get("clcoId")) || !NumberUtils.isCreatable(params.get("clcoId")) )
			return BatchRestResult.of("9999", "고객사를 선택해야 합니다.");
		if( !params.containsKey("cuiId") || "-1".equals(params.get("cuiId")) || !NumberUtils.isCreatable(params.get("cuiId")) )
			return BatchRestResult.of("9999", "검진기관을 선택해야 합니다.");

		try {

			service.packageTypeValidate(converted,
				NumberUtils.toInt(params.get("clcoId")),
				NumberUtils.toInt(params.get("yr")),
				NumberUtils.toInt(params.get("cuiId")),
				NumberUtils.toInt(params.get("overwriteItem")) == 1);
		}
		catch( BatchException e ) {

			LOGGER.debug(ExceptionUtils.getStackTrace(e));
			return BatchRestResult.of(e.getCode(), e.getMessage());
		}

		return BatchRestResult.of(NcuResponseCode.SUCCESS);
	}

}
