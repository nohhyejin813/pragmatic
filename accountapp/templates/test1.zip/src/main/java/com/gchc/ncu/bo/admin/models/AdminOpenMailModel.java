package com.gchc.ncu.bo.admin.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AdminOpenMailModel extends NcuModel {

	private int clcoId;//CLCO_ID
	private int clcoCtraId;//CLCO_CTRA_ID
	private String clcoNm; // CLCO_NM
	private String svcDmnNm; // SVC_DMN_NM
	private String chrgrNm; // CHRGR_NM
	private String chrgrTlno; // CHRGR_TLNO
	private String chrgrEmlAdr; //CHRGR_EML_ADR
	private String brno; // BRNO
	private String zpcd; // ZPCD
	private String bscAdr; // BSC_ADR
	private String dtlAdr; // DTL_ADR
	private String ctraSrtDt; // CTRA_SRT_DT
	private String ctraEndDt; // CTRA_END_DT
	private int spfn; // SPFN
	private String fmcuUseYn; //FMCU_USE_YN 가족검진비 지원여부
	private String cuTgt; //검진대상 <--- 이거 뭐 뽑아야 할지 몰라서 대기.
	private int empCnt;
	private String clcoSvcTyCd;	// 고객사서비스유형코드 CLCO_SVC_TY_CD
	private String stlAmt;	// 결제금액
	private String stlTyCd;	// 결제유형코드
	private String cuImplSrtDt;	// 검진시작일자
	private String cuImplEndDt;	// 검진종료일자
}