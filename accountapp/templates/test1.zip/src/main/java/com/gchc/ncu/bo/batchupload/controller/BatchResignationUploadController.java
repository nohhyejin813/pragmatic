package com.gchc.ncu.bo.batchupload.controller;

import com.gchc.ncu.bo.batchupload.models.BatchResignationExcelModel;
import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.batchupload.service.BatchResignationUploadService;
import com.gchc.ncu.bo.member.models.MemberClcoRltnModel;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * @FileName : BatchResignationUploadController.java
 * @date : 2023. 03. 07
 * @author : 양재환
 * @프로그램 설명 : 일괄업로드 Controller
 * @변경이력 :
 */
@RequiredArgsConstructor
@Api(tags = "일괄업로드 컨트롤러")
@RestController
@RequestMapping("/api/bo/batchupload/resignation")
public class BatchResignationUploadController {

	@Autowired
	private FileOperationManager fileOperationManager;
	@Autowired
	private BatchResignationUploadService service;
	@Autowired
	private BatchXlsHistProcess batchXlsHistProcess;

	/**
	 * 양식 다운로드
	 */
	@PostMapping("/sample-download-excel")
	@ApiOperation(value="퇴사 양식 다운로드", notes="퇴사 양식 다운로드")
	public ResponseEntity<?> downloadExcel(HttpServletRequest request, HttpServletResponse response) {
		return sampleConvertExcel(service.getSampleDownloadExcel(), request, response);
	}

	ResponseEntity<?> sampleConvertExcel(List<BatchResignationExcelModel> model, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();

		for( int i = 0; i < model.size(); i++ ) {

			Map<String, Object> map = new TreeMap<>();

			// 리스트 셋팅
			BatchResignationExcelModel exMap = model.get(i);
			map.put("col1", exMap.getClcoNm()); 		// 고객사
			map.put("col2", exMap.getAempNm()); 		// 이름
			map.put("col3", exMap.getEmpNo()); 		// 사번
			list.add(map);
		}

		if( StringUtils.isNotEmpty(model.get(0).getAempNm()) ) {

			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "일괄업로드 > 고객 > 퇴사";
			String cont = "고객사, 이름, 사번";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사"	),
				new UstraExcelCellInfoModel("col2"	, "이름"		),
				new UstraExcelCellInfoModel("col3"	, "사번"		)
			))
			.withSheetName("업로드정보");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "고객(퇴사)", request, response)
			.build());
	}

	/**
	 * 정상 다운로드
	 */
	@PostMapping("/normal-download-excel")
	@ApiOperation(value="퇴사 정상 엑셀 다운로드", notes="퇴사 정상 엑셀 다운로드")
	public ResponseEntity<?> normalDownloadExcelCustomer(@RequestBody List<BatchResignationExcelModel> param, HttpServletRequest request, HttpServletResponse response) {
		return normalConvertExcel(param, request, response);
	}

	ResponseEntity<?> normalConvertExcel(List<BatchResignationExcelModel> normalList, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();

		for( int i = 0; i < normalList.size(); i++ ) {

			Map<String, Object> map = new TreeMap<>();

			// 리스트 셋팅
			BatchResignationExcelModel exMap = normalList.get(i);

			map.put("col1", 	exMap.getClcoNm()); 					// 고객사명
			map.put("col2", 	exMap.getBsplNm()); 					// 사업장명
			map.put("col3", 	exMap.getMbrGrdNm());					// 등급명
			map.put("col4", 	exMap.getEmpNo()); 						// 사번
			map.put("col5", 	exMap.getTgtrNm());						// 검진대상자명
			map.put("col6", 	exMap.getTgtrbrdt());					// 검진대상자 생년월일
			map.put("col7", 	exMap.getAempNm());						// 임직원 이름
			map.put("col8", 	exMap.getAempBrdt());					// 임직원 생년월일
			map.put("col9", 	exMap.getCorpSpfn());					// 회사 지원금
			map.put("col10", exMap.getPkgNm());						// 지원패키지명
			map.put("col11", exMap.getResvStCd());					// 예약상태
			map.put("col12", exMap.getCuiNm());						// 검진센터명
			map.put("col13", exMap.getPkgTyNm());					// 검진센터명
			map.put("col14", exMap.getCmplDtm());					// 검진 완료일
			map.put("col15", exMap.getResvFnlzDt());					// 예약 확정일
			map.put("col16", exMap.getTn1ResvApplDt());				// 1차 예약 신청일
			map.put("col17", exMap.getTn2ResvApplDt());				// 2차 예약 신청일
			map.put("col18", exMap.getFrstResvDt());					// 예약 신청일
			map.put("col19", exMap.getFirstaempNm());				// 직원명(최초)
			list.add(map);
		}

		if( StringUtils.isNotEmpty(normalList.get(0).getAempNm()) ) {
			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "일괄업로드 > 고객 > 퇴사";
			String cont = "고객사, 사업장, 등급, 사번, 수검자명, 수검자생년월일, 임직원명, 임직원생년월일, 회사지원금, 지원패키지" +
					"진행상태, 검진센터명, 예약패키지, 검진완료일, 예약확정일, 1차희망일, 2차희망일, 예약신청일, 직원명(최초)";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;

		excelModel = UstraExcelModel.of(
				list,
				Arrays.asList(
						new UstraExcelCellInfoModel("col1"		, "고객사"			),
						new UstraExcelCellInfoModel("col2"		, "사업장"			),
						new UstraExcelCellInfoModel("col3"		, "등급"				),
						new UstraExcelCellInfoModel("col4"		, "사번"				),
						new UstraExcelCellInfoModel("col5"		, "수검자명"			),
						new UstraExcelCellInfoModel("col6"		, "수검자생년월일"		),
						new UstraExcelCellInfoModel("col7"		, "임직원명"			),
						new UstraExcelCellInfoModel("col8"		, "임직원생년월일"		),
						new UstraExcelCellInfoModel("col9"		, "회사지원금"			),
						new UstraExcelCellInfoModel("col10"		, "지원패키지"			),
						new UstraExcelCellInfoModel("col11"		, "진행상태"			),
						new UstraExcelCellInfoModel("col12"		, "검진센터명"			),
						new UstraExcelCellInfoModel("col13"		, "예약패키지"			),
						new UstraExcelCellInfoModel("col14"		, "검진완료일"			),
						new UstraExcelCellInfoModel("col15"		, "예약확정일"			),
						new UstraExcelCellInfoModel("col16"		, "1차희망일"			),
						new UstraExcelCellInfoModel("col17"		, "2차희망일"			),
						new UstraExcelCellInfoModel("col18"		, "예약신청일"			),
						new UstraExcelCellInfoModel("col19"		, "직원명(최초)"		)
				))
				.withSheetName("정상내용");	// 시트명
		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
						.entityBuilder(Arrays.asList(excelModel), "정상내용", request, response)
						.build());
	}

	/**
	 * 오류 다운로드
	 */
	@PostMapping("/error-download-excel")
	@ApiOperation(value="퇴사 오류 엑셀 다운로드", notes="퇴사 오류 엑셀 다운로드")
	public ResponseEntity<?> downloadExcelCustomer(@RequestBody List<BatchResignationExcelModel> param, HttpServletRequest request, HttpServletResponse response) {
		return errorConvertExcel(param, request, response);
	}

	ResponseEntity<?> errorConvertExcel(List<BatchResignationExcelModel> errorList, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();

		for( int i = 0; i < errorList.size(); i++ ) {

			Map<String, Object> map = new TreeMap<>();

			// 리스트 셋팅
			BatchResignationExcelModel exMap = errorList.get(i);

			map.put("col1", 	exMap.getClcoNm()); 					// 고객사명
			map.put("col2", 	exMap.getBsplNm()); 					// 사업장명
			map.put("col3", 	exMap.getMbrGrdNm());					// 등급명
			map.put("col4", 	exMap.getEmpNo()); 						// 사번
			map.put("col5", 	exMap.getTgtrNm());						// 검진대상자명
			map.put("col6", 	exMap.getTgtrbrdt());					// 검진대상자 생년월일
			map.put("col7", 	exMap.getAempNm());						// 임직원 이름
			map.put("col8", 	exMap.getAempBrdt());					// 임직원 생년월일
			map.put("col9", 	exMap.getCorpSpfn());					// 회사 지원금
			map.put("col10", exMap.getPkgNm());						// 지원패키지명
			map.put("col11", exMap.getResvStCd());					// 예약상태
			map.put("col12", exMap.getCuiNm());						// 검진센터명
			map.put("col13", exMap.getPkgTyNm());					// 검진센터명
			map.put("col14", exMap.getCmplDtm());					// 검진 완료일
			map.put("col15", exMap.getResvFnlzDt());					// 예약 확정일
			map.put("col16", exMap.getTn1ResvApplDt());				// 1차 예약 신청일
			map.put("col17", exMap.getTn2ResvApplDt());				// 2차 예약 신청일
			map.put("col18", exMap.getFrstResvDt());					// 예약 신청일
			map.put("col19", exMap.getFirstaempNm());				// 직원명(최초)
			map.put("col20", exMap.getErrMsg());						// 오류내용
			list.add(map);
		}

		if( StringUtils.isNotEmpty(errorList.get(0).getAempNm()) ) {
			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "일괄업로드 > 고객 > 퇴사";
			String cont = "고객사, 사업장, 등급, 사번, 수검자명, 수검자생년월일, 임직원명, 임직원생년월일, 회사지원금, 지원패키지" +
					"진행상태, 검진센터명, 예약패키지, 검진완료일, 예약확정일, 1차희망일, 2차희망일, 예약신청일, 직원명(최초), 오류내용";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;

		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"		, "고객사"			),
				new UstraExcelCellInfoModel("col2"		, "사업장"			),
				new UstraExcelCellInfoModel("col3"		, "등급"				),
				new UstraExcelCellInfoModel("col4"		, "사번"				),
				new UstraExcelCellInfoModel("col5"		, "수검자명"			),
				new UstraExcelCellInfoModel("col6"		, "수검자생년월일"		),
				new UstraExcelCellInfoModel("col7"		, "임직원명"			),
				new UstraExcelCellInfoModel("col8"		, "임직원생년월일"		),
				new UstraExcelCellInfoModel("col9"		, "회사지원금"			),
				new UstraExcelCellInfoModel("col10"		, "지원패키지"			),
				new UstraExcelCellInfoModel("col11"		, "진행상태"			),
				new UstraExcelCellInfoModel("col12"		, "검진센터명"			),
				new UstraExcelCellInfoModel("col13"		, "예약패키지"			),
				new UstraExcelCellInfoModel("col14"		, "검진완료일"			),
				new UstraExcelCellInfoModel("col15"		, "예약확정일"			),
				new UstraExcelCellInfoModel("col16"		, "1차희망일"			),
				new UstraExcelCellInfoModel("col17"		, "2차희망일"			),
				new UstraExcelCellInfoModel("col18"		, "예약신청일"			),
				new UstraExcelCellInfoModel("col19"		, "직원명(최초)"		),
				new UstraExcelCellInfoModel("col20"		, "오류내용"			)
			))
			.withSheetName("오류내용");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "오류내용", request, response)
			.build());
	}

	/**
	 * 처리내용 : #13314 신한은행 퇴사자 일괄 반영 요청 건 by 양재환 2023-03-09
	 *
	 * @return
	 */
	@GetMapping("/aemp-rsnt")
	@ApiOperation(value="일괄퇴사 리스트", notes="일괄퇴사 리스트")
	public List<MemberClcoRltnModel> getAempRsntList() {
		return service.getAempRsntList();
	}

	/**
	 * 처리내용 : #14875 퇴사자일괄반영기능 by 양재환 2023-05-03
	 *
	 * @return
	 */
	@GetMapping("/aemp-rsnt/{clcoId}")
	@ApiOperation(value="일괄퇴사 리스트", notes="일괄퇴사 리스트")
	public List<MemberClcoRltnModel> getAempRsntList2(@PathVariable Integer clcoId) {
		return service.getAempRsntList2(clcoId);
	}
}
