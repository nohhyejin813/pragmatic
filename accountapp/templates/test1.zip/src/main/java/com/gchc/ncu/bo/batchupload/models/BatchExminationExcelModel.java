package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchExminationExcelModel extends NcuModel {
	private String excelFileName; // 다운로드 엑셀 파일명
	private int yr;	// 기준년도

	private Integer row;
	private int blkUpldExamId; //BLK_UPLD_EXAM_ID
	private String cuiNm; //CUI_NM
	private int cuiId; //CUI_ID
	private String clcoNm; // CLCO_NM
	private int clcoId; //CLCO_ID
	private String exmrNm; //EXMR_NM
	private String brdt; //BRDT
	private String sexCd; //SEX_CD
	private String hvexCmplDt; //HVEX_CMPL_DT
	private String corpSpfn; //CORP_SPFN
	private String nhicSubtYn; //NHIC_SUBT_YN
	private String nhicAmt; //NHIC_AMT
	private String addSpfn; //ADD_SPFN
	private String corpClmAmt; //CORP_CLM_AMT
	private String uid; //UID
	private String cuTgtrId; //CU_TGTR_ID
	private String resvId; //RESV_ID
	private String resvStCd; //RESV_ST_CD
	private String selfYn; //SELF_YN
	private String suptYn; //SUPT_YN
	private String cuiYn; //CUI_YN
	private String uid1;//UID1
	private String datStCd; //DAT_ST_CD
	private String upldErrCausCont; //UPLD_ERR_CAUS_CONT
	private String useYn; //USE_YN
	private String upldCmplYn; //UPLD_CMPL_YN
	private String usrKdCd; //USR_KD_CD
	private String mngrId; //MNGR_ID
	private String delMngrId; //DEL_MNGR_ID
	private String delDtm; //DEL_DTM
	private String delYn; //DEL_YN
	// private String frstRegDtm; //FRST_REG_DTM
	// private String frstRegrTyCd; //FRST_REGR_TY_CD
	// private String frstRegrId; //FRST_REGR_ID
	// private String lastUpdDtm; //LAST_UPD_DTM
	// private String lastUpdrTyCd; //LAST_UPDR_TY_CD
	// private String lastUpdrId; //LAST_UPDR_ID

	// 오류
	private List<String> error;
	private Integer errorCnt;
}
