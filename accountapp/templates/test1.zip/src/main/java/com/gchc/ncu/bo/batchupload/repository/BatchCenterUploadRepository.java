package com.gchc.ncu.bo.batchupload.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsitm.ustra.java.data.domains.PaginationRequest;

import com.gchc.ncu.bo.batchupload.models.BatchCenterVaccineUploadModel;
import com.gchc.ncu.bo.batchupload.models.CenterVaccineUploadRequestModel;
import com.gchc.ncu.bo.batchupload.models.CenterVaccineUploadResultModel;

@Mapper
public interface BatchCenterUploadRepository {

	public void updateCuiBlkVcnHisUploadYn(Map<String, Object> map);

	public List<BatchCenterVaccineUploadModel> selectPkgUpldBscForUpdate(Map<String, Object> map);

	public void updateCuiBlkVcnHisIds(Map<String, Object> map);

	public void updateCuiBlkVcnHisValidate(Map<String, Object> map);

	public void updateCuiBlkVcnHisValidate2(Map<String, Object> map);

	public void updateCuiBlkVcnHisValidate3(Map<String, Object> map);

	public CenterVaccineUploadResultModel getCuiBlkVcnHisResult(CenterVaccineUploadRequestModel in);

	public List<BatchCenterVaccineUploadModel> getCuiBlkVcnHis(@Param("model")CenterVaccineUploadRequestModel in, PaginationRequest paginationRequest);

	public List<BatchCenterVaccineUploadModel> selectCuiBlkVcnHisTest(CenterVaccineUploadRequestModel in);

	public void updateCuiBlkVcnHisInit(CenterVaccineUploadRequestModel in);

	public List<BatchCenterVaccineUploadModel> getCuiBlkVcnHisForExcel(CenterVaccineUploadRequestModel in);

	public void updateCuiBlkVcnHisRemove(Map<String, Object> map);

	public void updateCuiBlkVcnHisRemoveAll(CenterVaccineUploadRequestModel in);

	public void updateCuiBlkVcnHisRegist(CenterVaccineUploadRequestModel in);

	public void insertCuiVcnDtl(CenterVaccineUploadRequestModel in);

	public List<BatchCenterVaccineUploadModel> getCuiBlkVcnHisForExcelList(Map<String, Object> map);

}
