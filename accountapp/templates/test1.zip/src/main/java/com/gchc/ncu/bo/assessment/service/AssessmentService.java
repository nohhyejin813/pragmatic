package com.gchc.ncu.bo.assessment.service;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import com.gchc.common.message.model.MessageUnion;
import com.gchc.ncu.bo.assessment.models.AssessmentFileModel;
import com.gchc.ncu.bo.assessment.models.AssessmentGradeModel;
import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.AssessmentQuestionModel;
import com.gchc.ncu.bo.assessment.models.AssessmentScoreModel;
import com.gchc.ncu.bo.assessment.models.AssessmentTargetModel;
import com.gchc.ncu.bo.assessment.repository.AssessmentRepository;
import com.gchc.ncu.bo.assessment.vo.AssessmentQuestionTypeVo;
import com.gchc.ncu.bo.assessment.vo.AssessmentQuestionVo;
import com.gchc.ncu.bo.assessment.vo.AssessmentVo;
import com.gchc.ncu.bo.checkupinst.models.ZipModel;
import com.gchc.ncu.bo.checkupinst.util.CryptoHelper;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.service.CommonService;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gchc.ncu.bo.message.service.MessageService;
import com.gchc.ncu.bo.message.vo.MessageSendVo;
import com.gchc.ncu.bo.unicmm.models.SurveyModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 프로토타입 Service
 *
 * @author gs_hykim@gchealthcare.com
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class AssessmentService {
	@Autowired
	CryptoHelper cryptoHelper;

    @Autowired
    MessageService messageService;

    @Autowired
    CommonService commonService;

	@Autowired
	private AssessmentRepository repository;

	public int getAssessmentLastYear() {
		return repository.getAssessmentLastYear();
	}

	public int[] getAssessmentYearList() {
		return repository.getAssessmentYearList();
	}

	public List<ZipModel> getAssessmentSidoList(AssessmentModel in) {
		return repository.getAssessmentSidoList(in);
	}

	public List<ZipModel> getAssessmentGugunList(AssessmentModel in) {
		return repository.getAssessmentGugunList(in);
	}

	public List<AssessmentModel> getAssessmentClcoList(int srchYr) {
		return repository.getAssessmentClcoList(srchYr);
	}

	public List<AssessmentModel> getAssessmentCuiList(AssessmentModel in) {
		return repository.getAssessmentCuiList(in);
	}

	public List<AssessmentModel> getAssessmentStatusList(AssessmentModel in) {
		return repository.getAssessmentStatusList(in);
	}

	public int uptAsmDt(AssessmentTargetModel in) {
		return repository.uptAsmDt(in);
	}

	public int sumResult(AssessmentModel model) {
		return repository.sumResult(model);
	}

	public int calResultAssessment(List in) {
		int result = 0;
		for(int i=0; i< in.size(); i++) {
			repository.calResultAssessment(in.get(i));
			result++;
		}
		return result;
	}

	public AssessmentVo getAssessmentStatusDetail(int cuiAsmTgtId) {
		AssessmentVo getAsmVo = new AssessmentVo();
		getAsmVo.setCuiAsmTgtId(cuiAsmTgtId);

		AssessmentModel asm = repository.getAssessmentStatusDetail(cuiAsmTgtId);
		getAsmVo.setInfo(asm);
		getAsmVo.setYr(asm.getYr());

		if(cuiAsmTgtId > 0) {
			if(asm != null) {
				int cuiAsmId = repository.getCuiAsmIdByCuiAsmTgtId(cuiAsmTgtId);
				asm.setCuiAsmId(cuiAsmId);
				getAsmVo.setCuiAsmId(cuiAsmId);

				List<AssessmentQuestionModel> 	getQstRspnExmList 	= repository.getAssessmentQuestionResponseExampleList(asm);

				List<AssessmentScoreModel>		getAsmRsltList 		= repository.getAssessmentStatusResultList(asm);
				List<AssessmentScoreModel>		getYrScrList 		= repository.getAssessmentStatusYearScoreList(asm.getCuiId());
//				List<AssessmentFileModel>		getFileList 		= repository.getAssessmentStatusFileList(cuiAsmTgtId);
				List<AssessmentFileModel>		getFileList 		= repository.getAssessmentStatusFileListTobeTable(cuiAsmTgtId); // (2022.07.01) #9009
				Double level = null;
				if(!getAsmRsltList.isEmpty()) {
					level = repository.getAssessmentStatusSatisfactionLevel(asm);
				}

				List<AssessmentQuestionTypeVo> getQstTyList 		=
					getQstRspnExmList.stream().collect(Collectors.groupingBy(l -> l.getThmAreaTitl())).entrySet().stream()
					.map(
						questionType -> {
//							int qstTyCd = questionType.getValue().get(0).getSrvyQstSlctItmId();
							int qstTyCd = questionType.getValue().get(0).getSrvyQstThmAreaId();
							List<AssessmentQuestionVo>  questionList =
							questionType.getValue().stream().collect(Collectors.groupingBy(l -> l.getSrvyQstId())).entrySet().stream()
							.map(
								question -> {
									List<AssessmentQuestionModel> 	getQuestionExampleList 	= question.getValue();
									List<AssessmentQuestionModel>	filterQuestionExampleList = getQuestionExampleList.stream().
											filter(qst -> qst.getAnswSrvyQstSlctItmId() == qst.getSrvyQstSlctItmId()).collect(Collectors.toList());

//									AssessmentQuestionModel 		getQuestionResponse 	= getQuestionExampleList.get(0);
									AssessmentQuestionModel 		getQuestionResponse
										= filterQuestionExampleList.size() == 0 ? getQuestionExampleList.get(0) : filterQuestionExampleList.get(0);

//									int cuiAsmQstId = getQuestionResponse.getSrvyQstSlctItmId();
//									int cuiAsmQstId = getQuestionResponse.getCuiAsmQstId();
									int cuiAsmQstId = getQuestionResponse.getSrvyQstId();

									return new AssessmentQuestionVo(cuiAsmQstId, getQuestionResponse, getQuestionExampleList);
//								}).collect(Collectors.toList());
								}).sorted(Comparator.comparing(AssessmentQuestionVo::getCuiAsmQstId)).collect(Collectors.toList());
						return new AssessmentQuestionTypeVo(qstTyCd, questionType.getKey(), questionList);
					}).sorted(Comparator.comparing(AssessmentQuestionTypeVo::getQstTyCd)).collect(Collectors.toList());

				getAsmVo.setQstRspnExmList(getQstRspnExmList);
				getAsmVo.setAsmRsltList(getAsmRsltList);
				getAsmVo.setYrScrList(getYrScrList);
				getAsmVo.setFileList(getFileList);
				getAsmVo.setQstTyList(getQstTyList);
				getAsmVo.setLevel(level);
			}
		}

		return getAsmVo;
	}

	public AssessmentVo getAssessmentSurvey(Map<String, Object> map) {
		AssessmentVo getAsmVo = new AssessmentVo();
		/*
		 * 2022-02-21 변경된 로직
		 * 2019년 2020년 asmKvl데이터가 운영, 개발 모두 같은 데이터를 쓰는경우가 있고, 암호화방식이 프레임워크 교체로 달라졌다.
		 * 따라서... 2019, 2020년같은 중복된 데이터는 yr데이터를 추가로 사용하여 구분한다.
		 *  -- 인크립트 Key 값 Decode 오류 잦은 발생으로 파라미터에 YR값 추가. 별도 Decode 로직 제거 [2022.03.08 김병섭]
		 */
		AssessmentModel asm;

		int yr = Integer.parseInt((String)map.get("yr"));
//		String yr = (String)map.get("yr");
		String asmKvl = (String) map.get("encryptedKey");
		asm = AssessmentModel.builder()
			 .yr(yr)
			 .asmKvl(asmKvl)
			 .build();

		Integer cuiAsmTgtId = repository.getCuiAsmTgtId(asm);
		if (cuiAsmTgtId != null) {
			asm = repository.getAssessmentStatusDetail(cuiAsmTgtId);
		} else {
			cuiAsmTgtId = 0;
		}
		getAsmVo.setCuiAsmTgtId(cuiAsmTgtId);

		if(asm != null) { // 평가대상임
			getAsmVo.setInfo(asm);
			getAsmVo.setYr(asm.getYr());
		}else { // 평가대상이 아님
			return getAsmVo;
		}

		if(cuiAsmTgtId > 0) { // 평가가 이루어져야 하는 평가대상 기관ID
			if(asm != null) {
				int cuiAsmId = repository.getCuiAsmIdByCuiAsmTgtId(cuiAsmTgtId); // 검진기관 평가아이디
				asm.setCuiAsmId(cuiAsmId);
				getAsmVo.setCuiAsmId(cuiAsmId);

				List<AssessmentTargetModel> 	getTargetHistoryList = repository.getAssessmentTargetHistoryList(asm);
				List<AssessmentQuestionModel> 	getQstRspnExmList 	= repository.getAssessmentQuestionSurveyList(asm);

				List<AssessmentScoreModel>		getAsmRsltList 		= repository.getAssessmentStatusResultList(asm);
				List<AssessmentScoreModel>		getYrScrList 		= repository.getAssessmentStatusYearScoreList(asm.getCuiId());
				List<AssessmentFileModel>		getFileList 		= repository.getAssessmentStatusFileListTobeTable(cuiAsmTgtId);
				Double level = null;
				if(!getAsmRsltList.isEmpty()) {
					level = repository.getAssessmentStatusSatisfactionLevel(asm);
				}
// getSrvyQstSlctItmId > getSrvyQstId
				List<AssessmentQuestionTypeVo> getQstTyList 		=
					getQstRspnExmList.stream().collect(Collectors.groupingBy(l -> l.getThmAreaTitl())).entrySet().stream()
					.map(
						questionType -> {
							int qstTyCd = questionType.getValue().get(0).getSrvyQstThmAreaId(); //getSrvyQstSlctItmId();
							List<AssessmentQuestionVo>  questionList =
							questionType.getValue().stream().collect(Collectors.groupingBy(l -> l.getSrvyQstId())).entrySet().stream()
							.map(
								question -> {
									List<AssessmentQuestionModel> 	getQuestionExampleList 	= question.getValue();
									List<AssessmentQuestionModel>	filterQuestionExampleList = getQuestionExampleList.stream().
										filter(qst -> qst.getAnswSrvyQstSlctItmId() == qst.getSrvyQstSlctItmId()).collect(Collectors.toList());

									AssessmentQuestionModel 		getQuestionResponse 	= filterQuestionExampleList.size() == 0 ?
										getQuestionExampleList.get(0) : filterQuestionExampleList.get(0);
									int cuiAsmQstId = getQuestionResponse.getSrvyQstId();

									return new AssessmentQuestionVo(cuiAsmQstId, getQuestionResponse, getQuestionExampleList);
								}).sorted(Comparator.comparing(AssessmentQuestionVo::getCuiAsmQstId)).collect(Collectors.toList());
						return new AssessmentQuestionTypeVo(qstTyCd, questionType.getKey(), questionList);
					}).sorted(Comparator.comparing(AssessmentQuestionTypeVo::getQstTyCd)).collect(Collectors.toList());

				getAsmVo.setTargetHistoryList(getTargetHistoryList);
				getAsmVo.setQstRspnExmList(getQstRspnExmList);
				getAsmVo.setAsmRsltList(getAsmRsltList);
				getAsmVo.setYrScrList(getYrScrList);
				getAsmVo.setFileList(getFileList);
				getAsmVo.setQstTyList(getQstTyList);
				getAsmVo.setLevel(level);
			}
		}

		return getAsmVo;
	}

	public void getDownloadFile(AssessmentFileModel vo, HttpServletRequest request, HttpServletResponse response) {

		try {
				AssessmentFileModel resultVo = repository.getFileDownload(vo);

				String deStr = cryptoHelper.decrypt(resultVo.getFileDesc(), cryptoHelper.makeKey(cryptoHelper.keyValue));

				cryptoHelper.binaryToFile(deStr, resultVo.getFileNm(), request, response);
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

	}

	public int sendUrl(AssessmentModel model) {
		int msgId = 0;

		// 1. 이메일 발송
		msgId = _addPush(model,"email");

		if(msgId > 0) {
			_sendPush(msgId);
		}

		return msgId;
	}

	private Integer _addPush(AssessmentModel model, String sendFlag) {
		MessageUnion messageUnion = new MessageUnion();

		//------------------------------------------------------
		// 수신자 목록 데이터 생성
		ArrayList<String> rcvUserList = new ArrayList<String>();

		//------------------------------------------------------
		// 메시지 저장
		if("email".equals(sendFlag)) {
//			rcvUserList.add(model.getEmlAdr()+"#"+model.getCuTgtrUid());
			messageUnion.setRcvUserList(rcvUserList);

			LOGGER.debug(">>>>>>>>> EMAIL 전송============");
			messageUnion.setSysDvCd("UMS"); 					// 시스템=통합관리자
			messageUnion.setSndDvCd("2"); 						// 발송구분(1: 문자(SMS) 2: 메일, 3:카카오알림톡, 4:앱푸쉬 5:문자(MMS))
			messageUnion.setSndGrpDvCd(3050); 					// 발송그룹구분(SND_GRP_DV_CD): 3050 검진약관발송
			messageUnion.setResvStCd(0); 						// 예약상태코드(RESV_ST_CD): 0-즉시발송, 1-예약전송, 2-예약취소
			messageUnion.setResvDtm("");						// [예약전송]이면 [발송예약시각]
			messageUnion.setTitl("검진기관 평가관리 URL 발송");
			messageUnion.setCont("############################ 임시 URL입니다 #############################");
			messageUnion.setLinkKvl("0");						// 키값
			messageUnion.setLinkUrl("http://www.naver.com");
			messageUnion.setSvcDmnNm("");						// 서비스 도메인명
			messageUnion.setTmplId(0);							// 템플릿 아이디
			messageUnion.setSndKdCd(0); 						// 메세지유형(SND_KD_CD: 0-메일, 1-SMS, 2-PNS)
			messageUnion.setFrstRegrTyCd("0");
			messageUnion.setFrstRegrId(model.getRegUsrId());
			messageUnion.setPshSndTyCd(null);					//
//			messageUnion.setRcvMngrId(model.getAgrUsrId());		// 수신 관리자 아이디
			messageUnion.setRcvrTyCd(0);						// 수신자 유형코드	(0-개별, 1-그룹, 2-엑셀)
			messageUnion.setRefId(0);							// 참조에 부여한 고유 아이디
			messageUnion.setFrarDvCd("0");						// 발송지 구분코드 (sndGrpDvCd와 중복 코드)
			messageUnion.setSndEmlAdr("yeyoonji@naver.com");	// 발송이메일 주소


		}

		int msgId = messageService.insertMessage(messageUnion);
		LOGGER.info("[웰보드 > Push발송] 등록된 MSG_ID = {}", msgId);

		return msgId;
	}



	private void _sendPush(Integer msgId) {
		//if (msgId == null || msgId > 0) return;
		LOGGER.debug("######## _sendPush================================"+msgId);

		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(msgId);

		MessageSendVo messageSendVo = new MessageSendVo();
		messageSendVo.setMsgIdList(list);


		Integer result = messageService.sendMessage(messageSendVo);

	}


	// 평가문항관리

	public List<AssessmentModel> getAssessmentManagementList() {
		return repository.getAssessmentManagementList();
	}

	public List<AssessmentTargetModel> getAssessmentManagementTargetList(int yr) {
		return repository.getAssessmentManagementTargetList(yr);
	}


	public List<AssessmentQuestionTypeVo> getAssessmentManagementByLastYear(int yr) {
		List<AssessmentQuestionTypeVo>		getQstTyList 		= new ArrayList<AssessmentQuestionTypeVo>();
		int cuiAsmId = repository.getCuiAsmIdByLastYear(yr-1);

		if(cuiAsmId > 0) {
			List<AssessmentQuestionModel> 	getQstExmList 		= repository.getAssessmentQuestionExampleList(cuiAsmId);

			getQstTyList 		=
				getQstExmList.stream().collect(Collectors.groupingBy(l -> l.getQstTyNm())).entrySet().stream()
				.map(
					questionType -> {
						int qstTyCd = questionType.getValue().get(0).getCuiAsmQstId();
						List<AssessmentQuestionVo>  questionList =
						questionType.getValue().stream().collect(Collectors.groupingBy(l -> l.getCuiAsmQstId())).entrySet().stream()
						.map(
							question -> {
								List<AssessmentQuestionModel> 	getQuestionExampleList 	= question.getValue();
								AssessmentQuestionModel 		getQuestion 	= getQuestionExampleList.get(0);
								int cuiAsmQstId = getQuestion.getCuiAsmQstId();

								return new AssessmentQuestionVo(cuiAsmQstId, getQuestion, getQuestionExampleList);
							}).collect(Collectors.toList());
					return new AssessmentQuestionTypeVo(qstTyCd, questionType.getKey(), questionList);
				}).sorted(Comparator.comparing(AssessmentQuestionTypeVo::getQstTyCd)).collect(Collectors.toList());

		}

		return getQstTyList;
	}

	public AssessmentVo getAssessmentManagement(int cuiAsmId) {
		AssessmentVo getAsmVo = new AssessmentVo();

		if(cuiAsmId > 0) {
			AssessmentModel asm = repository.getAssessmentManagementDetail(cuiAsmId);

			if(asm != null) {
				List<AssessmentQuestionModel> 	getQstExmList 		= repository.getAssessmentQuestionExampleList(cuiAsmId);
				List<AssessmentQuestionTypeVo>	getQstTyList 		=
					getQstExmList.stream().collect(Collectors.groupingBy(l -> l.getQstTyNm())).entrySet().stream()
					.map(
						questionType -> {
							int qstTyCd = questionType.getValue().get(0).getCuiAsmQstId();
							List<AssessmentQuestionVo>  questionList =
							questionType.getValue().stream().collect(Collectors.groupingBy(l -> l.getCuiAsmQstId())).entrySet().stream()
							.map(
								question -> {
									List<AssessmentQuestionModel> 	getQuestionExampleList 	= question.getValue();
									AssessmentQuestionModel 		getQuestion 	= getQuestionExampleList.get(0);
									int cuiAsmQstId = getQuestion.getCuiAsmQstId();

									return new AssessmentQuestionVo(cuiAsmQstId, getQuestion, getQuestionExampleList);
								}).collect(Collectors.toList());
						return new AssessmentQuestionTypeVo(qstTyCd, questionType.getKey(), questionList);
					}).sorted(Comparator.comparing(AssessmentQuestionTypeVo::getQstTyCd)).collect(Collectors.toList());


				/* 전체검진기관대상여부 체크 */
				if(!asm.isWholCuiTgtYn()) {
					// 선택검진기관목록내용
					if(asm.getSlctCuiLstCont() != null && !asm.getSlctCuiLstCont().isEmpty()) {
						String[] selectedCuiIdList= asm.getSlctCuiLstCont().split(",");
						asm.setCuiIdList( Stream.of(selectedCuiIdList).mapToInt(Integer::parseInt).toArray());
					}
				}

				//int[] cuiIdList = {1,2}; // TODO 삭제해야함 (테스트용 코드)
				//asm.setCuiIdList(cuiIdList);

				getAsmVo.setInfo(asm);
				getAsmVo.setQstExmList(getQstExmList);
				getAsmVo.setQstTyList(getQstTyList);

			}
		}

		return getAsmVo;
	}

	@Transactional
	public void saveAssessmentManagement(boolean isTemp, AssessmentVo in) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
		int		yr 				= in.getInfo().getYr();
		int		cuiAsmId 		= in.getInfo().getCuiAsmId();
		int[] 	cuiIdList 		= in.getInfo().getCuiIdList();

		boolean qstnRegCmplYn 	= in.getInfo().isQstnRegCmplYn();
		boolean wholCuiTgtYn 	= in.getInfo().isWholCuiTgtYn();

		// 1. 평가대상 데이터 셋팅
		if(!wholCuiTgtYn && cuiIdList.length > 0) {
			// 1-1. [검진기관 직접 선택] 일 경우
			in.getInfo().setSlctCuiLstCont(Arrays.stream(cuiIdList).boxed().collect(Collectors.toList()).stream().map(String::valueOf).collect(Collectors.joining(",")));
		}else {
			// 1-2. [전체 검진기관] 일 경우
			in.getInfo().setSlctCuiLstCont("");
		}

		// 2. 검진기관평가관리기본 저장
		if(cuiAsmId > 0) {
			repository.uptAssessmentManagement(in.getInfo());
		} else {
			repository.addAssessmentManagement(in.getInfo());
		}

		//if(!qstnRegCmplYn) {
		// 3. 검진기관평가 질문, 보기상세 저장  > [문항등록완료여부]가 "완료" 에만  <---3. 검진기관평가 질문, 보기상세 저장  > [문항등록완료여부]가 "완료가 아닌 경우" 에만
		if(qstnRegCmplYn) { //if(!qstnRegCmplYn) {

			if(cuiAsmId > 0) { // cuiId, yr
		        // 기존에 있는 경우 : 전체 삭제 후 다시 넣음
				repository.delAssessmentQuestionExampleList(in.getInfo()); // 전체 삭제처리
			}

//			// 평가 구분 리스트
//			List<AssessmentQuestionTypeVo> qstTypeList = in.getQstTyList().stream().filter(t -> !t.isDelYn()).collect(Collectors.toList());
//			for(AssessmentQuestionTypeVo qstType: qstTypeList) {
//				// 평가 문항 리스트
//				List<AssessmentQuestionVo> qstList = qstType.getQstList().stream().filter(t -> !t.isDelYn()).collect(Collectors.toList());
//				for(AssessmentQuestionVo qst : qstList) {
//					qst.getQstRspnInfo().setQstTyNm(qstType.getQstTyNm()); 				// 질문 데이터 셋팅 (질문유형명)
//					qst.getQstRspnInfo().setCuiAsmId(in.getInfo().getCuiAsmId()); 		// 질문 데이터 셋팅 (검진기관평가아이디)
//
//					repository.addAssessmentQuestion(qst.getQstRspnInfo());				// 질문 저장
//
//					if(!"2".equals(qst.getQstRspnInfo().getQstnTyCd())) {				// [질문유형코드]가  "주관식 이 아닌 경우" 에만 보기상세 저장  (QstnTyCd - 1: 객관식, 2: 주관식, 3: 객관식+주관식
//						for(AssessmentQuestionModel exm : qst.getExmList()) {
//							exm.setCuiAsmQstId(qst.getQstRspnInfo().getCuiAsmQstId()); 	// 보기상세 데이터 셋팅 (검진기관평가질문아이디)
//
//							repository.addAssessmentQuestionExample(exm);				// 보기상세 저장
//						}
//					}
//				}
//			}
		}

		// 4. 검진기관평가대상 저장 : [문항등록완료여부]가 "완료인 경우" 에만
		if(qstnRegCmplYn) {
			List<AssessmentTargetModel> targetList = repository.getAssessmentManagementTargetList(yr);
			List<AssessmentTargetModel> newTargetList = targetList.stream().filter(t -> t.getCuiAsmTgtId() == 0).collect(Collectors.toList());
			List<AssessmentTargetModel> uptTargetList = targetList.stream().filter(t -> (t.getCuiAsmTgtId() > 0 && ("1".equals(t.getAsmStCd()) || "2".equals(t.getAsmStCd()))) ).collect(Collectors.toList());

			if(!wholCuiTgtYn) {
				newTargetList = newTargetList.stream().filter(t -> Arrays.stream(cuiIdList).boxed().collect(Collectors.toList()).contains(t.getCuiId())).collect(Collectors.toList());
				uptTargetList = uptTargetList.stream().filter(t -> Arrays.stream(cuiIdList).boxed().collect(Collectors.toList()).contains(t.getCuiId())).collect(Collectors.toList());
			}

			if(!newTargetList.isEmpty()) {
				for(AssessmentTargetModel target : newTargetList) {
					int cuiId = target.getCuiId();

					target.setYr(yr);
					target.setAsmSrtDt(in.getInfo().getAsmSrtDt());
					target.setAsmEndDt(in.getInfo().getAsmEndDt());
					target.setAsmKvl(cryptoHelper.encrypt(String.format("%d,%d", yr, cuiId), cryptoHelper.makeKey(cryptoHelper.keyValue)));

					repository.addAssessmentTarget(target);
				}
			}

			if(!uptTargetList.isEmpty()) {
				for(AssessmentTargetModel target : uptTargetList) {
					target.setYr(yr);
					target.setAsmSrtDt(in.getInfo().getAsmSrtDt());
					target.setAsmEndDt(in.getInfo().getAsmEndDt());

					repository.uptAsmDt(target); // DEL_YN = 0으로 변경하여 사용가능한 값으로 변경합니다.
				}
			}
		}
	}


	public List<AssessmentGradeModel> getAssessmentGradeList(int cuiAsmId, int yr){
		if(cuiAsmId > 0) {
			AssessmentModel asm = repository.getAssessmentManagementDetail(cuiAsmId);
			yr = asm.getYr();
		}

		return repository.getAssessmentGradeList(yr);
	}

	@Transactional
	public int saveAssessmentGrade(List<AssessmentGradeModel> in){
		int saveCnt = 0;

		for(AssessmentGradeModel grade : in) {
			saveCnt += repository.saveAssessmentGrade(grade);
		}

		return saveCnt;
	}

	public List<AssessmentScoreModel> getAssessmentDivisionList(int cuiAsmId, int yr){
		if(cuiAsmId > 0) {
			AssessmentModel asm = repository.getAssessmentManagementDetail(cuiAsmId);
			yr = asm.getYr();
		}

		return repository.getAssessmentDivisionList(yr);
	}

	public List<String> getAssessmentConnectClcoList(int cuiAsmTgtId){
		AssessmentModel asm = repository.getAssessmentStatusDetail(cuiAsmTgtId);

		return repository.getAssessmentConnectClcoList(asm);
	}

	public List<SurveyModel> getAssessmentQuestionList(){
		return repository.getAssessmentQuestionList();
	}

	@Transactional
	public void saveSurvey(boolean isTemp, AssessmentVo in) throws Exception {
		List<AssessmentQuestionModel> qstRspnExmList 	= in.getQstRspnExmList(); // 답변문항리스트
		List<AssessmentFileModel> 		getFileList 	= in.getFileList(); // 파일리스트
		int		cuiAsmId 								= in.getCuiAsmId();
		int 	cuiAsmTgtId								= in.getCuiAsmTgtId(); // 설문타겟아이디
		AssessmentModel info 							= in.getInfo(); // 설문의 개략적인 정보

		NcuUserDetail userDetail = commonService.getUserDetail(GchcJwtUtil.getUserId()); // 토큰데이터 가져오고
		String userMngrId = "" + userDetail.getMngrId();
//        WHEN B.ASM_ST_CD = 1 THEN '미진행'
//        WHEN B.ASM_ST_CD = 2 THEN '진행중'
//        WHEN B.ASM_ST_CD = 3 THEN '진행완료'
//        WHEN B.ASM_ST_CD = 4 THEN '평가완료'

		String asmStCd = isTemp ? "2" : "3"; // 임시라면 진행중 , 진짜 저장이면 진행완료

		info.setLastUpdrId(userMngrId);
		info.setAsmStCd(asmStCd);
		//info 데이터 저장
		int result = repository.saveAssessmentStatusDetail(info);
		if(result != 1) {

			throw new RuntimeException("AssessmentService.saveSurvey - saveAssessmentStatusDetail fail");
		}



		//문항답변 기본 정보 저장
		result = 0;
		result = repository.saveAssessmentQuestionResponse(info); // 문항답변
		if(result != 1) {
			throw new RuntimeException("AssessmentService.saveSurvey - saveAssessmentQuestionResponse fail");
		}
		AssessmentModel asmQstResBsc = repository.getAssessmentQuestionResponseBasic(info);
		info.setSrvyAnswId(asmQstResBsc.getSrvyAnswId());
		int srvyAnswId = asmQstResBsc.getSrvyAnswId();

		result = 0;
		//fileList 저장
		getFileList.stream().forEach(file -> {
			file.setCuiAsmTgtId(cuiAsmTgtId);
			file.setSrvyAnswId(srvyAnswId);
			file.setUpdUsrId("" + userDetail.getMngrId());
			file.setRegUsrId("" + userDetail.getMngrId());
			repository.saveQuestionAnswerFile(file);
		});

		//문항 답변내용 전부 삭제
		//문항 답변 신규로 insert

		repository.delQuestionAnswers(info);
		qstRspnExmList.forEach(qstRspnExm -> {
			qstRspnExm.setSrvyAnswId(srvyAnswId);
			qstRspnExm.setUpdUsrId(userMngrId);
			repository.saveQuestionAnswer(qstRspnExm);
		});


//		return true;

	}
}
