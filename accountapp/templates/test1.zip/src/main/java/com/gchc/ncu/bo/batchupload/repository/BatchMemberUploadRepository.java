package com.gchc.ncu.bo.batchupload.repository;

import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.comm.models.CommonParametersModel;
import com.gchc.ncu.bo.member.models.ClientModel;
import com.gchc.ncu.bo.member.models.MemberModel;
import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @FileName : BatchUploadRepository.java
 * @date : 2021. 10. 12
 * @author : hykim
 * @프로그램 설명 : 일괄업로드 Repository
 * @변경이력 :
 */
@Mapper
public interface BatchMemberUploadRepository {

	/**
	 *
	 * 처리내용 : 시퀃스 목록으로 DB 조회
	 *
	 * @param checkUpdate
	 * @return
	 */
	List<BatchMemberUploadCustomerModel> getClcoAempBlkRegTmpForUpdate(Map<String, Object> checkUpdate);

	/**
	 *
	 * 처리내용 : 배치 테이블 시퀀스 채번
	 * @param map
	 *
	 * @return
	 */
	int getAempBlkRegTmpNextSeq(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 지원 등급 정보 목록을 조회한다.
	 *
	 * @param map
	 * @return
	 */
	List<SupportGradeModel> getMemberGradeList(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 패키지 목록을 조회한다.
	 *
	 * @param request
	 * @return
	 */
	List<PackageBasicModel> getPackageList(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 사업장 목록을 조회한다.
	 *
	 * @param request
	 * @return
	 */
	List<BsplModel> getBsplList(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 중복 체크를 위해 PRIR 업데이트
	 *
	 * @param map
	 */

	void updateClcoAempBlkRegTmpRnk(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 중복 체크
	 *
	 * @param map
	 */

	void updateClcoAempBlkRegTmpValidate(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : upldYn 초기화
	 *
	 * @param map
	 */

	void updateClcoAempBlkRegTmpUploadYn(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 일괄업로드 결과 조회
	 *
	 * @param in
	 * @return
	 */

	BatchMemberUploadResultModel getBatchMemberUploadResult(BatchMemberUploadResultRequestModel in);


	BatchMemberUploadResultModel selectClcoAempBlkRegTmpCurrentReg(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 일괄업로드 오류 조회
	 *
	 * @param in
	 * @param pr
	 * @return
	 */

	PaginationList<BatchMemberUploadCustomerModel> getClcoAempBlkRegTmpError(@Param("model") BatchMemberUploadErrorRequestModel in, PaginationRequest pr);

	List<BatchMemberUploadCustomerModel> getClcoAempBlkRegTmpError2(@Param("model") BatchMemberUploadErrorRequestModel in);

	PaginationList<BatchMemberUploadCustomerModel> getClcoAempBlkRegTmpErrorDuplicated(@Param("model") BatchMemberUploadErrorRequestModel in,
		PaginationRequest paginationRequest);

	/**
	 *
	 * 처리내용 : 오류 삭제 처리
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpRemove(Map<String, Object> in);

	/**
	 *
	 * 처리내용 : 일괄업로드 현재db 비교
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpValidateStep2_1(Map<String, Object> in);

	void updateClcoAempBlkRegTmpValidateStep2_2(Map<String, Object> in);

	void updateClcoAempBlkRegTmpValidateStep2_3(Map<String, Object> map);

	void updateClcoAempBlkRegTmpValidateStep2_4(Map<String, Object> map);

	void updateClcoAempBlkRegTmpValidateStep3(Map<String, Object> map);

	void updateClcoAempBlkRegTmpValidateStep3_2(Map<String, Object> map);

	void updateClcoAempBlkRegTmpExcuYn(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 예약 정보가 존재하는 회원인지 체크
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpValidateStep4_1(Map<String, Object> in);

	void updateClcoAempBlkRegTmpValidateStep4_2(Map<String, Object> in);

	void updateClcoAempBlkRegTmpValidateStep4_3(Map<String, Object> map);

	void updateClcoAempBlkRegTmpValidateStep4_4(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 일괄업로드 작업내역 초기화
	 *
	 * @param in
	 * @return
	 */

	void updateClcoAempBlkRegTmpInit(BatchMemberUploadInitRequestModel in);

	/**
	 *
	 * 처리내용 : 당해년도 모든 고객 다운로드 (for Test)
	 *
	 * @param in
	 * @return
	 */

	List<BatchCustomerExcelModel> selectCustomerTmpTestExcelList(CustomerExcelDownModel in);

	/**
	 *
	 * 처리내용 : 중복 항목 신규 내용으로 업데이트를 위해 상태 값 변경 (upldStVal = 14)
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpUpldStVal(BatchMemberUploadRegistRequestModel in);

	void updateClcoAempBlkRegTmpUpldStVal2(BatchMemberUploadRegistRequestModel in);

	void updateClcoAempBlkRegTmpUpldStVal3(BatchMemberUploadRegistRequestModel in);

	MemberModel DmcyBlkRlsPrcs(BatchMemberUploadRegistRequestModel in);

	MemberModel DmcyBlkRstPrcs(BatchMemberUploadRegistRequestModel in);

	List<BatchCustomerExcelModel> selectCustomerTmpExcelList(CustomerExcelDownModel in);

//	List<BatchCustomerExcelModel> getClcoAempBlkRegTmp(CustomerExcelDownModel vo);

	/**
	 *
	 * 처리내용 : 현재 정상인 건수들의 예약 정보를 조회한다.
	 *
	 * @param in
	 * @return
	 */

	//BatchMemberUploadReserveInfoModel getClcoAempBlkRegTmpReserve(BatchMemberUploadRegistRequestModel in);

	/**
	 *
	 * 처리내용 : 선택된 중복 오류 건들의 예약 정보를 조회한다.
	 *
	 * @param in
	 * @return
	 */

	//BatchMemberUploadReserveInfoModel getClcoAempBlkRegTmpReserveForList(BatchMemberUploadRegistRequestModel in);

	/**
	 *
	 * 처리내용 : upldStVal 1과 4를 백업
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpBackup(BatchMemberUploadRegistRequestModel in);

	/**
	 *
	 * 처리내용 : upldStVal 1과 4를 복구
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpRestore(BatchMemberUploadRegistRequestModel in);

	List<BatchCustomerExcelModel> selectClcoAempBlkRegTmpExcelList(Map<String, Object> map);

	void updateClcoAempBlkRegTmpRemoveAll(CustomerExcelDownModel in);

	ClientModel getClcoBsc(Map<String, Object> map);

	List<CommonParametersModel> getClcoList(CommonParametersModel model);

	List<BatchCustomerExcelModel> selectClcoAempBlkRegTmpDuplicatedExcel(CustomerExcelDownModel in);

	List<BatchCustomerExcelModel> selectClcoAempBlkRegTmpDuplicatedExcelList(Map<String, Object> map);

	void updateClcoAempBlkRegTmpValidateStep5(Map<String, Object> map);

    void updateClcoAempBlkRegTmpDmcy(Map<String, Object> map);

	void updateClcoAempBlkRegTmpOtherTgtr(Map<String, Object> map);

	void updateClcoAempBlkRegTmpHffc(Map<String, Object> map);

//	void DmcyRlsPrcs(MemberModel in);
//
//	void DmcyMnlPrcs(MemberModel in);
}
