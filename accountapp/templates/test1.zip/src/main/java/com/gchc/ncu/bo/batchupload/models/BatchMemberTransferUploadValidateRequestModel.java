package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchMemberTransferUploadValidateRequestModel {

	Integer clcoId;

	Integer yr;

	String fileGrpId;

	String fileId;

	Integer fileNo;
}
