package com.gchc.ncu.bo.abnormalfindings.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBoardInfoModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBusinessPlaceModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentCorporationNameModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentCounselModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentDepartmentNameModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentEnterPriseStatisticssAllModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentEnterPriseStatisticssModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentMngCounselHistoryModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentYearModel;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBoardInfoVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBrainDiseaselevelVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBusinessPlaceVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentCorporationNameVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentDepartmentNameVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentDeptNmVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentEnterpriseStatisticssVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentMngCounselHistoryVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentYearVo;
import com.gsitm.ustra.java.data.mybatis.executor.Many;

/**
 * 프로토타입 Repository
 *
 * @author gs_shbaek@gchealthcare.com
 */
@Mapper
public interface ManagermentRepository
{
	@Many List<ManagermentYearModel> getCheckUpYear(ManagermentYearVo AbnormalFindingsYearVO);

	@Many List<ManagermentCorporationNameModel> getCoporationNameList(ManagermentCorporationNameVo AbnormalFindingsCorporationNameVo);

	@Many List<ManagermentBusinessPlaceModel> getBusinessPlaceList(ManagermentBusinessPlaceVo AbnormalFindingsBusinessPlaceVo);

	@Many List<ManagermentDepartmentNameModel> getDepartmentNameList(ManagermentDepartmentNameVo AbnormalFindingsDepartmentNameVo);


	@Many List<String> getBrainDiseaseLevel(ManagermentBrainDiseaselevelVo abnormalFindingsbrainDiseaselevelVo);



	ManagermentBoardInfoModel getBoardInfo(ManagermentBoardInfoVo anbfBoardInfoVo);



	/**
	 * 유소견 목록 조회
	 * 특이사항 - 기존 쿼리에 아이디를 uid로 변경(변경 사유 : TO_BE 테이블에는 아이디가 없음)
	 */
	@Many List<ManagermentModel> getAbnormalFindingsList(Map<String, Object> model);

	@Many List<ManagermentModel> getAbnormalFindingsListExcel(Map<String, Object> model);



	void exeKeyOpen();


	List<ManagermentEnterPriseStatisticssModel> getEnterpriseStatisticss(ManagermentEnterpriseStatisticssVo abnormalFindingsEnterPriseStatisicsVo);
	List<ManagermentEnterPriseStatisticssAllModel> getEnterpriseStatisticssAll(ManagermentEnterpriseStatisticssVo abnormalFindingsEnterPriseStatisicsVo);

	void exeKeyClose();




	//상담 내역
	@Many List<ManagermentCounselModel> getCounselList(Map<String, Object> model);




	@Many List<ManagermentMngCounselHistoryModel> getMngCounselHistory(ManagermentMngCounselHistoryVo AbnormalFindingsMngCounselHistoryVo);


	Integer insertMngCounselHistory(ManagermentMngCounselHistoryModel AbnormalFindingsMngCounselHistoryModel);


	Integer updateMngCounselHistory(ManagermentMngCounselHistoryModel AbnormalFindingsMngCounselHistoryModel);

	Integer deleteMngCounselHistory(ManagermentMngCounselHistoryModel abnormalFindingsMngCounselHistoryMode);

	String getDeptNm(ManagermentDeptNmVo abnormalFindingsDeptNmVo);
}
