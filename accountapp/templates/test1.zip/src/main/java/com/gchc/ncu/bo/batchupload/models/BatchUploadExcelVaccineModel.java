package com.gchc.ncu.bo.batchupload.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchUploadExcelVaccineModel extends UstraManagementBaseModel {
	private String excelFileName; // 다운로드 엑셀 파일명

	private Integer yr;	// 기준년도
	private Integer row;

	@UstraExcelCellInfo(col = 0, header = "고객사명", required = false)
	private String clcoNm;
	@UstraExcelCellInfo(col = 1, header = "검진기관명", required = false)
	private String cuiNm;
	@UstraExcelCellInfo(col = 2, header = "이름", required = false)
	private String custNm; // EXMR_NM 수검자이름
	@UstraExcelCellInfo(col = 3, header = "주민번호", required = false)
	private String brdt; // BRDT 생년월일
	@UstraExcelCellInfo(col = 4, header = "접종백신", required = false)
	private String vcnInctNm; // VCN_INCT_NM 접종백신
	@UstraExcelCellInfo(col = 5, header = "접종일자", required = false)
	private String vcnInctDt; // VCN_INCT_DT 접종일자
	@UstraExcelCellInfo(col = 6, header = "MemeberId", required = false)
	private String uid; // CORP_CLM_AMT 회사청구금액

	// 오류
	private List<String> error;
	private Integer errorCnt;
}
