package com.gchc.ncu.bo.abnormalfindings.models.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentModel extends UstraManagementBaseModel
{
	private Integer rowNum;
	private Integer totalCnt;

	@ApiModelProperty(value="이름")
	private Integer uid;

	@ApiModelProperty(value="사번")
	@Masked(MaskingType.ID)
	private String empno;

	@ApiModelProperty(value="유저 이름")
	@Masked(MaskingType.NAME)
	private String nm;

	@ApiModelProperty(value="검진기록아이디")
	private Integer cuRecId;

	@ApiModelProperty(value="사업장 이름")
	private String bsplNm;


	@ApiModelProperty(value="부서 이름")
	private String deptNm;

	@ApiModelProperty(value="등급?")
	private String gradeNm;


	@ApiModelProperty(value="생년월일")
	private String birthDay;

	@ApiModelProperty(value="성별")
	private String sex;

	@ApiModelProperty(value="검진 센터")
	private String center;

	@ApiModelProperty(value="검진동의")
	private Integer checkupComplete;

	@ApiModelProperty(value="검진일")
	private String cuDtm;


	@ApiModelProperty(value="결과 동의")
	private String isResultAgree;

	@ApiModelProperty(value="제3자정보동의")
	private String thirdpartyAgree;

	@ApiModelProperty(value="유소견 동의")
	private String yusogyeonAgree;

	@ApiModelProperty(value="뇌심 혈관 위험도")
	private String personinfoAgree;


	private String sensitiveinfoAgree;

	@ApiModelProperty(value="직무 스트레스")
	private String jobStress;






	@ApiModelProperty(value="비만등급")
	private String obstGrd;

	@ApiModelProperty(value="고혈압등급")
	private String hypeGrd;

	@ApiModelProperty(value="당뇨병등급")
	private String glycGrd;

	@ApiModelProperty(value="간장질환등급")
	private String dssGrd;

	@ApiModelProperty(value="이상지질혈증등급")
	private String dyspGrd;

	@ApiModelProperty(value="이상지질혈증등급")
	private String amGrd;

	@ApiModelProperty(value="빈혈등급")
	private String htDssGrd;

	@ApiModelProperty(value="BMI")
	private String bmi;


	@ApiModelProperty(value="허리둘레")
	private String lmbGrd;

	@ApiModelProperty(value="SBP")
	private String sbp;


	@ApiModelProperty(value="DBP")
	private String dbp;

	@ApiModelProperty(value="BST")
	private String bst;

	@ApiModelProperty(value="SGOT")
	private String sgot;

	@ApiModelProperty(value="SGPT")
	private String sgpt;


	@ApiModelProperty(value="감마지티피_γGTP")
	private String gtp;


	@ApiModelProperty(value="TC총콜레스테롤")
	private String tcClst;

	@ApiModelProperty(value="TG중성지방 ")
	private String tgntft;


	@ApiModelProperty(value="LDL콜레스테롤")
	private String ldlClst;

	@ApiModelProperty(value="HDL콜레스테롤")
	private String hdlClst;

	@ApiModelProperty(value="Hb혈색소")
	private String hbHemo;

	@ApiModelProperty(value="요단백")
	private String urineProtein;

	@ApiModelProperty(value="크레아티닌")
	private String creatinine;


	@ApiModelProperty(value="GFR신사구체여과율")
	private String gfrRate;

	@ApiModelProperty(value="흉부Xray정면")
	private String thorXrayFrnt;

	@ApiModelProperty(value="흉부Xray측면")
	private String thorXrayLat;

	@ApiModelProperty(value="상담")
	private String cnsl;


	private String abnfCnslId;

	@ApiModelProperty(value="기업 ID")
	private Integer clcoId;


	private Integer deptId;
}
