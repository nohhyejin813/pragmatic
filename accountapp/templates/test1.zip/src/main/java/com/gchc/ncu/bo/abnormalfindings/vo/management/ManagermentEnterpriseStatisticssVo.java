package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;


@Getter
@Setter
@ToString
public class ManagermentEnterpriseStatisticssVo extends GchcVo
{
	@ApiModelProperty(value="조회 년도", example="2019")
	private String yr;

	@ApiModelProperty(value="고객사 ID", example="1")
	private Integer clcoId;


	@ApiModelProperty(value="사업장 아이디")
	private Integer bsplId;


	@ApiModelProperty(value="관리자 아이디", example="-1")
	private Integer mngrId = -1;



	@ApiModelProperty(value="통계 타입", example="1")
	private Integer statisticssTy;

	@ApiModelProperty(value="조회 년도0")
	private String yr0;

	@ApiModelProperty(value="조회 년도1")
	private String yr1;

	@ApiModelProperty(value="조회 년도2")
	private String yr2;
}
