package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Getter
@Setter
public class BatchUploadReentryExcelModel extends UstraManagementBaseModel {

	private Integer clcoId;

	private Integer yr;

	private String uid;

	@UstraExcelCellInfo(col = 0)
	private String aempNm;

	@UstraExcelCellInfo(col = 1)
	private String aempBrdt;

	@UstraExcelCellInfo(col = 2)
	private String existAempId;

	@UstraExcelCellInfo(col = 3)
	private String newAempId;

	@UstraExcelCellInfo(col = 4)
	private String pkgNm;

	@UstraExcelCellInfo(col = 5)
	private String corpSpfnVal;

	@UstraExcelCellInfo(col = 6)
	private String aempReenRegSeq;

	@UstraExcelCellInfo(col = 7)
	private String upldErrVal;
}
