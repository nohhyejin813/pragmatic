package com.gchc.ncu.bo.assessment.controller;

import java.util.Calendar;
import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.management.exception.UstraManagementResponseCode;

import com.gchc.ncu.bo.assessment.models.AssessmentGradeModel;
import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.AssessmentScoreModel;
import com.gchc.ncu.bo.assessment.service.AssessmentService;
import com.gchc.ncu.bo.checkupinst.models.ZipModel;
import com.gchc.ncu.bo.unicmm.models.SurveyModel;

/**
 * @FileName	: AssessmentManagementController.java
 * @date		: 2021. 7. 8
 * @author		: gs_yjhan
 * @프로그램 설명	: 검진기관평가관리 Controller
 * @변경이력		:
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/assessment")
@Api(tags = "검진기관평가관리 - AssessmentController")
public class AssessmentController {

	private final AssessmentService service;

	/**
	* 처리내용 : 마지막 회계년도 조회
	*
	* 회계년도 데이터가 없을 경우, 마지막 해를 넣어준다.
	*
	* @return int
	*/
	@GetMapping("/last-year")
	@ApiOperation(value="마지막 회계년도 조회", notes="마지막 회계년도를 반환한다.")
	public int getAssessmentLastYear() {
		int asmYear = service.getAssessmentLastYear();
		int year = Calendar.getInstance().get(Calendar.YEAR);

		if(asmYear == 0 || asmYear > year) {
			asmYear = year;
		}
		return asmYear;
	}

	/**
	* 처리내용 : 회계년도 목록 조회
	*
	* @return int[]
	*/
	@GetMapping("/years")
	@ApiOperation(value="회계년도 목록 조회", notes="회계년도 목록을 반환한다.")
	public int[] getAssessmentYearList() {
		return service.getAssessmentYearList();
	}

	/**
	* 처리내용 : 지역(시/도) 조회
	*
	* 검진기관평가관리에서는 [조회조건 - 고객사]에 따라서 지역(시/도)가 제어되므로 새로 Api 생성
	*
	* @return List<ZipModel>
	*/
	@GetMapping("/sido")
	@ApiOperation(value="지역(시/도) 조회", notes="지역(시/도) 목록을 반환한다.")
	public List<ZipModel> getAssessmentSidoList(@ModelAttribute AssessmentModel in) {
		return service.getAssessmentSidoList(in);
	}

	/**
	* 처리내용 : 지역(구/군) 조회
	*
	* 검진기관평가관리에서는 [조회조건 - 고객사]에 따라서 지역(구/군)가 제어되므로 새로 Api 생성
	*
	* @return List<ZipModel>
	*/
	@GetMapping("/gugun")
	@ApiOperation(value="지역(구/군) 조회", notes="지역(구/군) 목록을 반환한다.")
	public List<ZipModel> getAssessmentGugunList(@ModelAttribute AssessmentModel in) {
		return service.getAssessmentGugunList(in);
	}

	/**
	* 처리내용 : 고객사 조회
	*
	* @return String[]
	*/
	@GetMapping("/clcos")
	@ApiOperation(value="지역(구/군) 조회", notes="지역(구/군) 목록을 반환한다." )
	public List<AssessmentModel> getAssessmentClcoList(@RequestParam int srchYr) {
		return service.getAssessmentClcoList(srchYr);
	}

	/**
	* 처리내용 : 검진기관 목록 조회
	*
	* @return String[]
	*/
	@PostMapping("/cuis")
	@ApiOperation(value="검진기관 목록 조회", notes="검진기관 목록을 반환한다." )
	public List<AssessmentModel> getAssessmentCuiList(@RequestBody @Valid AssessmentModel in) {
		return service.getAssessmentCuiList(in);
	}


	/**
	 * 검진기관관리 - 고객사 검진기관평가관리  > 등급기준 조회
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@GetMapping("/{cuiAsmId}/grade")
	@ApiOperation(value="등급기준 조회", notes="등급 기준을 조회한다." )
	public List<AssessmentGradeModel> getAssessmentGradeList(@PathVariable int cuiAsmId, @RequestParam int yr) {
		return service.getAssessmentGradeList(cuiAsmId, yr);
	}

	/**
	 * 검진기관관리 - 고객사 검진기관평가관리  > 등급기준 저장
	 *
	 * @param
	 *
	 * @return
	 */
	@PostMapping("/{cuiAsmId}/grade")
	@ApiOperation(value="등급기준 저장", notes="등급 기준을 저장한다." )
	public ResponseCode saveAssessmentGrade(@PathVariable int cuiAsmId, @RequestParam int yr, @RequestBody List<AssessmentGradeModel> in) {

		if (service.saveAssessmentGrade(in) != in.size()) {
			return UstraManagementResponseCode.CANNOT_SAVE_RECORD;
		}

		return UstraManagementResponseCode.SUCCESS;
	}


	/**
	 * 검진기관관리 - 고객사 검진기관평가관리  > 등급기준 조회
	 *
	 * @param
	 *
	 * @return
	 */
	@GetMapping("/{cuiAsmId}/division")
	@ApiOperation(value="등급기준 조회", notes="등급 기준을 조회한다." )
	public List<AssessmentScoreModel> getAssessmentDivisionList(@PathVariable int cuiAsmId, @RequestParam int yr) {
		return service.getAssessmentDivisionList(cuiAsmId, yr);
	}

	/**
	 * 검진기관관리 - 고객사 검진기관평가관리  > 연결고객사 조회
	 *
	 * @param
	 *
	 * @return
	 */
	@GetMapping("/{cuiAsmTgtId}/connect-clcos")
	@ApiOperation(value="연결고객사 조회", notes="연결고객사 목록을 조회한다." )
	public List<String> getAssessmentConnectClcoList(@PathVariable int cuiAsmTgtId) {
		return service.getAssessmentConnectClcoList(cuiAsmTgtId);
	}




}
