package com.gchc.ncu.bo.challenge.operation.controller;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.*;
import com.gchc.ncu.bo.challenge.operation.models.CmpgCtraBsc2Model;
import com.gchc.ncu.bo.challenge.operation.service.ChallengeOperationService;
import com.gchc.ncu.bo.challenge.operation.vo.ChallengeOperationVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/challenge/operation")
public class ChallengeOperationController {

	private final ChallengeOperationService challengeService;

	@GetMapping("/contract/detail")
	public CmpgCtraBsc2Model getCampaignContract(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getCampaignContract(vo);
	}

	@DeleteMapping("/contract/remove")
	public RestResult<?> removeCampaignContract(@RequestBody List<CmpgCtraBsc2Model> models) {
		challengeService.removeCampaignContract(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/contract/term/list")
	public List<CmpgBscModel> getContractTermList(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getContractTermList(vo);
	}

	@PostMapping("/contract/term/save")
	public RestResult<?> setCampaignContractTerm(@RequestBody List<CmpgBscModel> models) {
		challengeService.setCampaignContractTerm(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/contract/notice/list")
	public List<CmpgNtfcDtlModel> getContractNoticeList(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getContractNoticeList(vo);
	}

	@PostMapping("/contract/notice/save")
	public RestResult<?> setCampaignContractNotice(@RequestBody List<CmpgNtfcDtlModel> models) {
		challengeService.setCampaignContractNotice(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/reward/list")
	public List<CmpgCmpnDtlModel> getCampaignRewardList(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getCampaignRewardList(vo);
	}

	@PostMapping("/reward/save")
	public RestResult<?> setCampaignReward(@RequestBody List<CmpgCmpnDtlModel> models) {
		challengeService.setCampaignReward(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/reward/member/list")
	public List<MbrCmpgRecsModel> getCampaignRewardMemberList(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getCampaignRewardMemberList(vo);
	}

	@PostMapping("/reward/confirm")
	public RestResult<?> setCampaignRewardConfirm(@RequestBody ChallengeOperationVo vo) {
		challengeService.setCampaignRewardConfirm(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/reward/cancel")
	public RestResult<?> setCampaignRewardCancel(@RequestBody ChallengeOperationVo vo) {
		challengeService.setCampaignRewardCancel(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/reward/prize")
	public RestResult<?> setCampaignRewardPrize(@RequestBody List<MbrCmpgRecsModel> models) {
		challengeService.setCampaignRewardPrize(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/operation-management/list")
	public List<CmpgBscModel> getOperManagementList(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperManagementList(vo);
	}

	@GetMapping("/operation-management/detail")
	public CmpgCtraBsc2Model getOperManagementDetail(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperManagementDetail(vo);
	}

	@GetMapping("/operation-management/detail-people")
	public List<MbrCmpgRecsModel> getOperManagementPeople(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperManagementPeople(vo);
	}

	@GetMapping("/operation-management/noenter-people")
	public List<MbrCmpgRecsModel> getOperNoenterPeople(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperNoenterPeople(vo);
	}

	@GetMapping("/operation-management/person-detail")
	public List<MbrCmpgRecsModel> getOperPersonDetail(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperPersonDetail(vo);
	}

	@GetMapping("/operation-management/campaign-reset")
	public RestResult<?> getCampaignReset(@ModelAttribute ChallengeOperationVo vo) {
		challengeService.getCampaignReset(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/notice/list")
	public List<CmpgNtfcBscModel> getCampaignNoticeList(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getCampaignNoticeList(vo);
	}

	@GetMapping("/notice/detail")
	public CmpgNtfcBscModel getCampaignNotice(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getCampaignNotice(vo);
	}

	@PostMapping("/notice/save")
	public RestResult<?> setCampaignNotice(@RequestBody CmpgNtfcBscModel model) {
		challengeService.setCampaignNotice(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/notice/remove")
	public RestResult<?> removeCampaignNotice(@RequestBody List<CmpgNtfcBscModel> models) {
		challengeService.removeCampaignNotice(models);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/operation-management/detail-team")
	public List<CmpgTeamRecsModel> getOperationDetailTeam(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperationDetailTeam(vo);
	}

	@GetMapping("/operation-management/team-person-detail")
	public List<CmpgTeamRecsModel> getOperTeamPersonDetail(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperTeamPersonDetail(vo);
	}

	@PostMapping("/operation-management/team-info-update")
	public RestResult<?> setTeamInfoUpdate(@RequestBody ChallengeOperationVo vo) {
		challengeService.setTeamInfoUpdate(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/operation-management/detail-team-count")
	public CmpgBscModel getOperationTeamCount(@ModelAttribute ChallengeOperationVo vo) {
		return challengeService.getOperationTeamCount(vo);
	}

}
