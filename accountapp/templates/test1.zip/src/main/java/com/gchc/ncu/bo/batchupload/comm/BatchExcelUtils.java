package com.gchc.ncu.bo.batchupload.comm;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BatchExcelUtils {

//	public BatchWorkbook openWorkbook(InputStream is) {
//
//		return new BatchWorkbook(is);
//	}
}
