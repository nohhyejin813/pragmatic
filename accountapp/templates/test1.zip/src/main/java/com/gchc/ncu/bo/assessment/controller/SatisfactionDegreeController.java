package com.gchc.ncu.bo.assessment.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import lombok.SneakyThrows;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.management.exception.UstraManagementResponseCode;

import com.gchc.ncu.bo.assessment.models.SatisfactionDegreeModel;
import com.gchc.ncu.bo.assessment.service.SatisfactionDegreeService;
import com.gchc.ncu.bo.assessment.vo.SatisfactionDegreeVo;

/**
 * @FileName	: SatisfactionDegreeController.java
 * @date		: 2021. 7. 8
 * @author		: gs_yjhan
 * @프로그램 설명	: 고객만족도조사 Controller
 * @변경이력		:
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/assessment/satisfaction-degree")
@Api(tags = "고객만족도조사- SatisfactionDegreeController")
public class SatisfactionDegreeController {

	private final SatisfactionDegreeService service;


	private final String RESPONSE_EXCEL_CONT_TYPE = "ms-vnd/excel";
	private final String RESPONSE_ATTATCH_FORMAT = "attachment;filename=%s";



	@GetMapping("/last-year")
	@ApiOperation(value="마지막 년도 조회", notes="마지막 년도를 반환한다.")
	public int getSatisfactionLastYear() {
		return service.getSatisfactionLastYear();
	}
	@GetMapping("/years")
	@ApiOperation(value="년도 목록 조회", notes="년도 목록을 반환한다.")
	public int[] getAssessmentYears() {
		return service.getSatisfactionYears();
	}

	/**
	* 처리내용 : 고객사 조회
	*
	* @return String[]
	*/
	@GetMapping("/clcos")
	@ApiOperation(value="고객사 조회", notes="고객만족도조사 고객사 목록을 반환한다.")
	public List<SatisfactionDegreeModel> getSatisfactionDegreeClcoList(@RequestParam int srchYr) {
		return service.getSatisfactionDegreeClcoList(srchYr);
	}

	/**
	* 처리내용 : 검진기관 조회
	*
	* @return String[]
	*/
	@PostMapping("/cuis")
	@ApiOperation(value="검진기관 조회", notes="고객만족도조사 검진기관 목록을 반환한다.")
	public List<SatisfactionDegreeModel> getSatisfactionDegreeCuiList(@RequestBody @Valid SatisfactionDegreeModel in) {
		return service.getSatisfactionDegreeCuiList(in);
	}

	/**
	 * 만족도/평가관리 - 고객만족도조사 - 목록 조회
	 *
	 * @param
	 *
	 * @return List<SatisfactionDegreeModel>
	 */
	@PostMapping("")
	@ApiOperation(value="고객만족도조사 목록 조회", notes="고객만족도조사 목록을 반환한다.")
	public List<SatisfactionDegreeModel> getSatisfactionDegreeList(@RequestBody @Valid SatisfactionDegreeModel in) {
		return service.getSatisfactionDegreeList(in);
	}

	/**
	 * 만족도/평가관리 - 고객만족도조사 - 상세 조회
	 *
	 * @param
	 *
	 * @return List<SatisfactionDegreeModel>
	 */
	@GetMapping("")
	@ApiOperation(value="고객만족도조사 상세 조회", notes="고객만족도조사 상세 정보를 반환한다.")
	public SatisfactionDegreeVo getSatisfactionDegree(@RequestParam int yr, @RequestParam int cuiId, @RequestParam int clcoId) {
		SatisfactionDegreeModel in = new SatisfactionDegreeModel();
		in.setYr(yr);
		in.setCuiId(cuiId);
		in.setClcoId(clcoId);

		SatisfactionDegreeVo getSatisfactionDegreeVo = new SatisfactionDegreeVo();
		getSatisfactionDegreeVo.setYr(yr);
		getSatisfactionDegreeVo.setCuiId(cuiId);
		getSatisfactionDegreeVo.setClcoId(clcoId);
		getSatisfactionDegreeVo.setInfo(service.getSatisfactionDegree(in));
		getSatisfactionDegreeVo.setCommentList(service.getSatisfactionDegreeCommentList(in));
		return getSatisfactionDegreeVo;
	}

	@SneakyThrows
	@PostMapping("/excel")
	@ApiOperation(value="엑셀다운로드", notes="엑셀다운로드 한다.")
	public void getSatisFactionDegreeExcel(HttpServletResponse response, @RequestBody @Valid SatisfactionDegreeModel model){
		Workbook wb = null;

		wb = service.getSatisfactionDegreeCommentExcel(model);

		try {
			this.writeWorkbookToResponse(wb, response, String.format("surveyrawdata%s.xlsx", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"))) );
		} catch (GchcException ex){
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "엑셀 파일 생성에 실패했습니다.");
		} catch (Exception ex){
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "엑셀 파일 생성에 실패했습니다.\n" + ex.getMessage());
		}

//		return wb;
	}


	@SneakyThrows
	@PostMapping("/all/excel")
	@ApiOperation(value="엑셀다운로드(전체)", notes="엑셀다운로드 한다.")
	public void getSatisFactionDegreeAllExcel(HttpServletResponse response, @RequestBody @Valid SatisfactionDegreeModel model){
		Workbook wb = null;

		wb = service.getSatisfactionDegreeCommentAllExcel(model);

		try {
			this.writeWorkbookToResponse(wb, response, String.format("surveyrawdata%s.xlsx", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"))) );
		} catch (GchcException ex){
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "엑셀 파일 생성에 실패했습니다.");
		} catch (Exception ex){
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "엑셀 파일 생성에 실패했습니다.\n" + ex.getMessage());
		}

//		return wb;
	}

	/**
	 * 엑셀 work boot 리스폰스 객체로 전달 하는 메소드
	 * @param wb workbook
	 * @param response http response 객체
	 * @param fileName 파일명
	 * @throws GchcException GC에서 사용하는 비지니스 익셉션
	 */
	private void writeWorkbookToResponse(Workbook wb, HttpServletResponse response, String fileName) throws GchcException {
		response.setContentType(RESPONSE_EXCEL_CONT_TYPE);
		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, String.format(RESPONSE_ATTATCH_FORMAT, fileName));

		if (StringUtils.isEmpty(fileName) || wb == null) {
			response.setStatus(HttpServletResponse.SC_NO_CONTENT);
			throw new GchcException(GchcResponseCode.CANNOT_SAVE_RECORD, "엑셀 파일을 확인하십시오.");
		}

		try {
			wb.write(response.getOutputStream());
			wb.close();
		} catch (IOException ioEx) {
			throw new GchcException(GchcResponseCode.CANNOT_SAVE_RECORD,
					String.format("엑셀 파일 생성에 실패했습니다.\n%s", ioEx.getMessage()));
		} catch (Exception ex){
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "엑셀 파일 생성에 실패했습니다.\n" + ex.getMessage());
		}
	}




	/**
	 * 만족도/평가관리 - 고객만족도조사 - 상세 조회 - 의견삭제
	 *
	 * @param
	 *
	 * @return List<SatisfactionDegreeModel>
	 */
	@DeleteMapping("/comment")
	@ApiOperation(value="고객만족도조사 상세 조회 의견삭제", notes="고객만족도조사 상세 정보 중 의견을 삭제한다.")
	public ResponseCode deleteComment(@RequestBody @Valid SatisfactionDegreeModel in) {

		if(service.deleteComment(in) != 1) {
			return UstraManagementResponseCode.CANNOT_SAVE_RECORD;
		}
		return UstraManagementResponseCode.SUCCESS;

	}



}
