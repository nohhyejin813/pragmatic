package com.gchc.ncu.bo.assessment.models;

import java.util.Date;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentScoreModel extends UstraManagementBaseModel {
	/* 연도별 검진기관 평가 점수 조회 > T_CUI_SCR_DTL [헬스케어_검진기관점수상세] */

	private	int		yr;				//년도
	private	int		cuiId;			//검진기관아이디
	private int		cuiAsmTotScr;

	/* 결과산정 조회 */
	private String 	qstTyNm;    		//질문유형명
	private String 	grade;    			//등급
	private int		score;
	private int		maxScr;
	private int		qstCnt;
	private int		scrQstCnt;

	/* T_CUI_BSC [헬스케어_검진기관기본] */
	private String	cuiNm;
	private String	rgnNm1;
	private String	rgnNm2;
	private int   	srvyQstThmAreaId;
	private String	thmAreaTitl;

}
