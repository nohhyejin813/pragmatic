package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

/**
 * @FileName : MemberAdvanceResvColumn.java
 * @date : 2022. 06. 10
 * @author : 이광희
 * @프로그램 설명 : 선예약 일괄업로드 Service
 * @변경이력 :
 */
@Getter
public enum MemberAdvanceResvColumn implements BatchUploadColumn {


	/*임직원-필수정보*/
	//CLCO_CODE("고객사코드","ClcoCode"),
	AEMP_NM("이름", "AempNm"),
	CORP_SPFN_VAL("지원금", "CorpSpfnVal"),
	AEMP_CU_GRD_NM("등급", "AempCuGrdNm"),
	AEMP_VCN_GRD_NM("백신등급", "AempVcnGrdNm"),
	AEMP_BRDT("생년월일", "AempBrdt"),
	MBL_NO("핸드폰", "MblNo"),


	/*임직원-선예약정보*/
	CUI_NM("검진기관명", "CuiNm"),
	PKG_NM("패키지명", "PkgNm"),
	TN1_RESV_APPL_DT("예약신청일", "Tn1ResvApplDt"),
	TN1_RESV_TMC_RNG_VAL("예약신청시간", "Tn1ResvTmcRngVal"),
	//RESV_APPL_DT2("예약신청일2차", "ResvApplDt2"),
	//RESV_APPL_TMC2("예약신청시간2차", "ResvApplTmc2"),
	PKG_TY_NM("패키지유형명", "PkgTyNm"),

	/*임직원-부가정보*/
	EML_ADR("이메일", "EmlAdr"),
	EXCU_YN("임원여부", "ExcuYn"),
	NHIC_SUPT_TGT_YN("공단지원여부", "NhicSuptTgtYn"),
	SPCU_TGT_YN("특수검진여부", "SpcuTgtYn"),
	EXTR_MTTR_NM1("특수물질(1차)", "ExtrMttrNm1"),
	EXTR_MTTR_NM2("특수물질(2차)", "ExtrMttrNm2"),
	//DEPT_NM1("부서", "DeptNm"),
	//JBGD_NM("직급", "JbgdNm"),
	BSPL_NM("사업장", "BsplNm"),
	AEMP_ID("사번", "AempId"),
	DEPT_NM1("부서1", "DeptNm1"),
	DEPT_NM2("부서2", "DeptNm2"),
	DEPT_NM3("부서3", "DeptNm3"),
	JBGD_NM("직급", "JbgdNm"),
	WRPL_TL_NO("직장 전화", "WrplTlno"),
	WRPL_ZP_CD("직장 우편번호", "WrplZpcd"),
	WRPL_BSC_ADR("직장 기본 주소", "WrplBscAdr"),
	WRPL_DTL_ADR("직장 상세 주소", "WrplDtlAdr"),
	HS_TL_NO("집 전화", "HsTlno"),
	HS_ZP_CD("집 우편번호", "HsZpcd"),
	HS_BSC_ADR("집 기본 주소", "HsBscAdr"),
	HS_DTL_ADR("집 상세 주소", "HsDtlAdr"),
	ENCM_DT("입사일", "EncmDt"),

	//AEMP_CMT("임직원비고", "AempCmt"),


	/*가족-기본정보*/
	SPSR_NM("가족명", "SpsrNm"),
	SPSR_CU_GRD_NM("가족검진등급", "SpsrCuGrdNm"),
	SPSR_VCN_GRD_NM("가족백신등급", "SpsrVcnGrdNm"),
	SPSR_BRDT("가족생년월일", "SpsrBrdt"),
	SPSR_CORP_SPFN("가족지원금", "SpsrCorpSpfn"),
	//SPSR_NO("가족연락처", "SpsrNo"),
	//SPSR_CMT("가족비고", "SpsrCmt"),


	/*가족-선예약정보*/
	SPSR_CUI_NM("가족검진기관명", "SpsrCuiNm"),
	SPSR_PKG_NM("가족패키지명", "SpsrPkgNm"),
	TN1_SPSR_RESV_APPL_DT("가족예약신청일", "Tn1SpsrResvApplDt"),
	TN1_SPSR_RESV_TMC_RNG_VAL("가족예약신청시간", "Tn1SpsrResvTmcRngVal"),
	//SPSR_RESV_APPL_DT2("가족예약신청일2차", "SpsrResvApplDt2"),
	//SPSR_RESV_APPL_TMC2("가족예약신청시간2차", "SpsrResvApplTmc2"),
	SPSR_PKG_TY_NM("가족패키지유형명", "SpsrPkgTyNm"),


	AEMP_REG_SEQ("MemberId", "AempRegSeq");
	String title;
	String field;
	MemberAdvanceResvColumn(String title, String field) {
		this.title = title;
		this.field = field;
	}
}
