package com.gchc.ncu.bo.abnormalfindings.models.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentYearModel extends UstraManagementBaseModel
{
	@ApiModelProperty(value="년도")
	private String yr;

	@ApiModelProperty(value="고객사 아이디")
	private String clcoId;
}
