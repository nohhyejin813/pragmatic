package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ContentRegisterVo extends UstraManagementBaseModel {

	private String staDate;
	private String endDate;
	private String cnntRegId;
	private String cmsDtlCd;
	private String cnntAbvRsnCd;
	private String sucYn;

	private String cnntAbvRcptId;
	private String rmk;

}
