package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.comm.SearchMapContextHolder;
import com.gchc.ncu.bo.batchupload.enu.*;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.repository.BatchPackageUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchFormatUtils;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.config.GchcDataBatchExecutor;
import com.gchc.ncu.bo.packages.models.ExamItemModel;
import com.gchc.ncu.bo.packages.models.PackageExamRstrModel;
import com.gchc.ncu.bo.packages.models.PackageItemModel;
import com.gchc.ncu.bo.packages.models.PackageTypeModel;
import com.gchc.ncu.bo.packages.service.PackageManagementService;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import com.gsitm.ustra.java.management.data.mapper.UstraCommonCodeDataMapper;
import com.gsitm.ustra.java.management.models.UstraCodeModel;
import com.gsitm.ustra.java.security.authentication.UstraAuthenticationManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BatchPackageUploadService {

	final static int PACKAGE_TYPE_UPLOAD_LIMIT = 10;

//	final static String[] PACKAGETYPE_PROPOSAL_COLUMNS = { "카테고리", "검진세부항목", "검사명" };
//	final static String[] PACKAGETYPE_ADD_PROPOSAL_COLUMNS = { "카테고리", "검진세부항목", "검사명", "추가검사선택시비용", "비고" };
//	final static Map<String, String> PACKAGE_PROPOSAL_TABLES = UstraMapUtils.getMap(
//		"검진센터명", "CuiNm",
//		"패키지명", "PkgNm",
//		"패키지타입", "PkgTyCont",
//		"패키지기본타입가격", "PkgBscPrcVal",
//		"제안서기간시작일", "PrpPridSrtDt",
//		"제안서기간종료일", "PrpPridEndDt",
//		"PackageTypeID", "UpldPkgId"
//	);

	@Autowired
	BatchPackageUploadRepository repository;

	@Autowired
	UstraAuthenticationManager authenticationManager;

	@Autowired
	FileOperationManager fileOperationManager;

	@Autowired
	PackageManagementService packageManagementService;

	@Autowired
	UstraCommonCodeDataMapper commonCodeDataMapper;

	@Autowired private GchcDataBatchExecutor batchExecutor;

	List<BatchPackageUploadModel> packages;

	List<PackageItemUploadTitleModel> titles;
	List<PackageItemUploadListModel> lists;
	List<PackageItemUploadItemModel> items;

	List<PackageItemModel> packageItemList;

	List<UstraCodeModel> commonCodeList;

	void validatePackageType2() {

		// 패키지타입 항목 오류 체크
		titles.forEach(t->{

			// 항목들 중 오류가 있는지 체크
			t.setPkgItmStVal(items.stream()
				.filter(itm->itm.getXclComnId() == t.getXclComnId())
				.anyMatch(itm->itm.getPkgItmUpldStVal() == 2) ? 0 : 1);

			// 선택검사 개수 체크
			Map<String, Integer[]> chexCnts = commonCodeList.stream()
				.filter(c->"EXAM_KD_CD".equals(c.getGrpCd()))
				.filter(c->c.getCdNm().startsWith("선택검사"))
				.map(c->new AbstractMap.SimpleEntry<>(c.getDtlCd(), new Integer[] { 0, 0 }))
				.collect(HashMap::new, (m, v)->m.put(v.getKey(), v.getValue()), HashMap::putAll);

			items.stream()
			.filter(itm->itm.getPkgItmUpldStVal() == 1)
			.filter(itm->itm.getXclComnId() == t.getXclComnId())
			.filter(itm->!"0".equals(itm.getItmTyCd()) && !"1".equals(itm.getItmTyCd()))
			.forEach(itm->{

				chexCnts.get(itm.getItmTyCd())[0]++;

				// 제한 수가 다른 경우
				if( chexCnts.get(itm.getItmTyCd())[1] > 0 &&
					chexCnts.get(itm.getItmTyCd())[1] != itm.getChexStupCnt() )
					chexCnts.get(itm.getItmTyCd())[1] = -1;
				else if( chexCnts.get(itm.getItmTyCd())[1] == 0 )
					chexCnts.get(itm.getItmTyCd())[1] = itm.getChexStupCnt();
			});

			boolean errFlag = chexCnts.entrySet().stream()
				.anyMatch(e->e.getValue()[1] < 0 || e.getValue()[0] < e.getValue()[1]);
			t.setChexYn(errFlag ? 0 : 1);

			items.stream()
			.filter(itm->itm.getPkgItmUpldStVal() == 1)
			.filter(itm->itm.getXclComnId() == t.getXclComnId())
			.filter(itm->!"0".equals(itm.getItmTyCd()) && !"1".equals(itm.getItmTyCd()))
			.forEach(itm->{

				if( chexCnts.get(itm.getItmTyCd())[1] < 0 ||
					chexCnts.get(itm.getItmTyCd())[0] < chexCnts.get(itm.getItmTyCd())[1] ) {

					itm.setPkgItmUpldStVal(2);
					itm.setPkgItmErrStVal("선택검사 수가 제한 수 보다 적거나 갯수가 다릅니다.");
				}
			});
		});
	}

	@Transactional
	public void packageTypeUpdate(List<BatchPackageTypeUploadErrorModel> in) {

		int mngrId = BatchUploadUtils.getCurrentMngrId();

		SearchMapContextHolder.set(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"cuiId", in.get(0).getCuiId(),
			"mngrId", mngrId));

		PackageItemUploadBasicModel basic = repository.getPkgItmUpldBsc(SearchMapContextHolder.get());

		// 검사항목 전체 데이터를 조회한다.
		packageItemList = packageManagementService.getPackageItemList(new PackageExamRstrModel());

		// 공통코드 목록을 가져온다.
		commonCodeList = commonCodeDataMapper.all();

		titles = repository.getPkgItmTitlUpldDtl(SearchMapContextHolder.get());

		lists = in.stream()
			.filter(err->StringUtils.isNotEmpty(err.getItmCatNm()) ||
				StringUtils.isNotEmpty(err.getDtlCatItmNm()) ||
				StringUtils.isNotEmpty(err.getExamResvItmNm()))
			.map(err->{

				return listCheck(PackageItemUploadListModel.builder()
					.pkgItmUpldBscId(basic.getPkgItmUpldBscId())
					.xclShtNo(err.getXclShtNo())
					.xclRowId(err.getXclRowId())
					.itmCatNm(err.getItmCatNm())
					.dtlCatItmNm(err.getDtlCatItmNm())
					.examResvItmNm(err.getExamResvItmNm())
					.adminUserMngrId(mngrId)
					.build());
			})
			.collect(Collectors.toList());

		List<PackageItemUploadItemModel> errItems = repository.getPkgItmUpldDtlError(SearchMapContextHolder.get());

		items = in.stream()
			.filter(err->StringUtils.isNotEmpty(err.getItmCatNm()) ||
				StringUtils.isNotEmpty(err.getDtlCatItmNm()) ||
				StringUtils.isNotEmpty(err.getExamResvItmNm()))
			.flatMap(err->{
				List<PackageItemUploadItemModel> itms = new ArrayList<>();
				itms.add(itemCheck(PackageItemUploadItemModel.builder()
					.pkgItmUpldBscId(basic.getPkgItmUpldBscId())
					.xclShtNo(err.getXclShtNo())
					.xclRowId(err.getXclRowId())
					.xclComnId(err.getXclComnId())
					.pkgItmAtriVal(err.getPkgItmAtriVal())
					.adminUserMngrId(mngrId)
					.build(), false));
				itms.add(itemCheck(PackageItemUploadItemModel.builder()
					.pkgItmUpldBscId(basic.getPkgItmUpldBscId())
					.xclShtNo(err.getXclShtNo())
					.xclRowId(err.getXclRowId())
					.xclComnId(err.getXclComnId() + 1)
					.pkgItmAtriVal(err.getEtcVal())
					.adminUserMngrId(mngrId)
					.build(), true));
				return itms.stream();
			})
			.collect(Collectors.toList());

		items.addAll(errItems.stream()
				.filter(e->{
					return items.stream()
							.allMatch(itm->{
										return itm.getXclRowId() != e.getXclRowId() || itm.getXclComnId() != e.getXclComnId();
							});
				})
				.collect(Collectors.toList()));

		validatePackageType2();

		batchExecutor.batchUpdate(
			"UPDATE T_PKG_ITM_TITL_UPLD_DTL\r\n" +
			"SET  CHEX_YN = #{chexYn} \r\n" +
			"	, PKG_ITM_ST_VAL = #{pkgItmStVal} \r\n" +
			"	, LAST_UPDR_ID = #{adminUserMngrId}\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"WHERE 1=1\r\n" +
			"	AND PKG_ITM_UPLD_BSC_ID = #{pkgItmUpldBscId} \r\n" +
			"	AND PKG_ITM_SHT_DV_CD = #{pkgItmShtDvCd} \r\n" +
			"	AND XCL_COMN_ID = #{xclComnId} ", titles);

		batchExecutor.batchUpdate(
			"UPDATE T_PKG_ITM_LST_UPLD_DTL \r\n" +
			"SET  ITM_CAT_NM = #{itmCatNm} \r\n" +
			"	, ITM_CAT_ID = #{itmCatId} \r\n" +
			"	, DTL_CAT_ITM_NM = #{dtlCatItmNm} \r\n" +
			"	, DTL_CAT_ITM_ID = #{dtlCatItmId} \r\n" +
			"	, EXAM_RESV_ITM_NM = #{examResvItmNm} \r\n" +
			"	, EXAM_NM = #{examNm} \r\n" +
			"	, PKG_ITM_ST_VAL = #{pkgItmStVal} \r\n" +
			"	, PKG_ITM_ERR_CONT = #{pkgItmErrCont} \r\n" +
			"	, LAST_UPDR_ID = #{adminUserMngrId}\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"WHERE 1=1\r\n" +
			"	AND PKG_ITM_UPLD_BSC_ID = #{pkgItmUpldBscId}\r\n" +
			"	AND XCL_SHT_NO = #{xclShtNo} \r\n" +
			"	AND XCL_ROW_ID = #{xclRowId} ", lists);

		batchExecutor.batchUpdate(
			"UPDATE T_PKG_ITM_UPLD_DTL\r\n" +
			"SET   PKG_ITM_ATRI_VAL = #{pkgItmAtriVal} \r\n" +
			"	, WRAR_CNT = #{wrarCnt} \r\n" +
			"	, XCL_N1ST_CSTR_VAL = #{xclN1stCstrVal} \r\n" +
			"	, XCL_N2ND_CSTR_VAL = #{xclN2ndCstrVal} \r\n" +
			"	, XCL_N3RD_CSTR_VAL = #{xclN3rdCstrVal} \r\n" +
			"	, ITM_TY_CD = #{itmTyCd} \r\n" +
			"	, SEX_CD = #{sexCd} \r\n" +
			"	, CHEX_STUP_CNT = #{chexStupCnt} \r\n" +
			"	, ITM_PRC = #{itmPrc} \r\n" +
			"	, PKG_ITM_UPLD_ST_VAL = #{pkgItmUpldStVal} \r\n" +
			"	, PKG_ITM_ERR_ST_VAL = #{pkgItmErrStVal} \r\n" +
			"	, LAST_UPDR_ID = #{adminUserMngrId}\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"WHERE 1=1\r\n" +
			"	AND PKG_ITM_UPLD_BSC_ID = #{pkgItmUpldBscId} \r\n" +
			"	AND XCL_SHT_NO = #{xclShtNo} \r\n" +
			"	AND XCL_ROW_ID = #{xclRowId} \r\n" +
			"	AND XCL_COMN_ID = #{xclComnId} ", items);

		// 패키지타입 일괄업로드 기본테이블에 오류여부 설정
		repository.updatePackageItemUploadBasicError(SearchMapContextHolder.get());
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void packageTypeValidate(Map<Object, List<RowInfo>> converted, Integer clcoId, Integer yr, Integer cuiId, boolean overwriteItem) {

		int mngrId = BatchUploadUtils.getCurrentMngrId();

		if( ObjectUtils.isEmpty(converted) || converted.entrySet().stream()
			.filter(e->!ObjectUtils.isEmpty(e.getValue()))
			.count() != 2 )
			BatchResponseCode.INVALID_SHEET.occur();

		SearchMapContextHolder.set(UstraMapUtils.getMap(
			"clcoId", clcoId,
			"yr", yr,
			"cuiId", cuiId,
			"mngrId", BatchUploadUtils.getCurrentMngrId()));

		// 검사항목 전체 데이터를 조회한다.
		packageItemList = packageManagementService.getPackageItemList(new PackageExamRstrModel());

		// 공통코드 목록을 가져온다.
		commonCodeList = commonCodeDataMapper.all();

		// 로그인 사용자의 패키지타입 일괄업로드 기본 데이터를 사용안함 처리한다.
		repository.updatePackageItemUploadBasicUseYn(SearchMapContextHolder.get());

		// 패키지타입 일괄업로드 기본 데이터를 등록한다.
		PackageItemUploadBasicModel basic = PackageItemUploadBasicModel.builder()
			.clcoId(clcoId)
			.yr(yr)
			.cuiId(cuiId)
			.adminUserMngrId(mngrId)
			.build();
		repository.insertPackageItemUploadBasic(basic);

		titles = new ArrayList<>();
		lists = new ArrayList<>();
		items = new ArrayList<>();

		for( Map.Entry<Object, List<RowInfo>> e : converted.entrySet()) {

			Map<String, Object> headerRow = (Map<String, Object>)e.getValue().get(0).getObject();

			int sheetValue = "1_".equals(e.getKey()) ? 1 : 2;
			String missed;
			if( sheetValue == 1 ) {

				missed = BatchUploadColumn.stream(PackageTypeColumn.class)
						.filter(c -> !BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
						.findFirst()
						.map(BatchUploadColumn::getTitle)
						.orElse(null);
			}
			else {

				missed = BatchUploadColumn.stream(PackageTypeAddColumn.class)
						.filter(c -> !BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
						.findFirst()
						.map(BatchUploadColumn::getTitle)
						.orElse(null);
			}
			if( StringUtils.isNotEmpty(missed) )
				BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

			headerRow.forEach((key, value)->{

				PackageItemUploadTitleModel title = titleCheck(PackageItemUploadTitleModel.builder()
					.pkgItmUpldBscId(basic.getPkgItmUpldBscId())
					.xclComnId(NumberUtils.toInt(key))
					.xclVal(value.toString())
					.pkgItmShtDvCd("" + sheetValue)
					.adminUserMngrId(mngrId)
					.build());
				titles.add(title);
			});

			// 엑셀 내용으로 패키지타입 일괄업로드 목록/항목 데이터를 설정한다.
			for( int rowId=1; rowId<e.getValue().size(); rowId++ ) {

				Map<String, Object> cols = (Map<String, Object>)e.getValue().get(rowId).getObject();

				// 카테고리/검진세부항목/검사명이 모두 비어 있으면 무시한다.
				// AS-IS "BatchPackageItemNullDelete" 대응
				if( ObjectUtils.isEmpty(cols.get("0")) &&
					ObjectUtils.isEmpty(cols.get("1")) &&
					ObjectUtils.isEmpty(cols.get("2")) )
					continue;

				// 첫 세개의 열로 목록을 설정한다.
				PackageItemUploadListModel itemList = listCheck(PackageItemUploadListModel.builder()
					.pkgItmUpldBscId(basic.getPkgItmUpldBscId())
					.xclShtNo(sheetValue)
					.xclRowId(rowId)
					.itmCatNm(cols.get("0").toString())
					.dtlCatItmNm(cols.get("1").toString())
					.examResvItmNm(cols.get("2").toString())
					.adminUserMngrId(mngrId)
					.build());
				lists.add(itemList);

				// 나머지 열은 개별항목으로 설정한다.
				for( int colId=3; colId<cols.size(); colId++ ) {

					// itemCheck 함수에서 1차 validation 처리 진행
					PackageItemUploadItemModel item = itemCheck(PackageItemUploadItemModel.builder()
						.pkgItmUpldBscId(basic.getPkgItmUpldBscId())
						.xclShtNo(sheetValue)
						.xclRowId(rowId)
						.xclComnId(colId)
						.pkgItmAtriVal(cols.get("" + colId).toString())
						.adminUserMngrId(mngrId)
						.build(), isEtc(colId));
					items.add(item);
				}
			}
		}

		// 패키지 존재 여부 체크 및 금액 및 상태 변경(등록완료 : '2')
		List<PackageTypeModel> pkgTypes = repository.selectPackageType(UstraMapUtils.getMap(
			"clcoId", clcoId,
			"yr", yr,
			"cuiId", cuiId,
			"list", titles));
		Map<String, Integer> dupCheck = new HashMap<>();
		List<String> registeredCheck = new ArrayList<>();
		titles.forEach(title->{

			title.setPkgExscYn(0);
			if( title.getXclComnId() > 2 &&
				!"비고".equals(title.getXclVal()) &&
				"1".equals(title.getPkgItmShtDvCd()) &&
				title.getPkgTitlStVal() == 1 ) {

				PackageTypeModel pkgType = pkgTypes.stream()
					.filter(pt->pt.getPkgNm().equals(title.getPkgNm()))
					.filter(pt->pt.getPkgTyNm().equals(title.getPkgTyCont()))
					.findFirst().orElse(null);

				if( pkgType != null ) {

					if( !"0".equals(pkgType.getPkgStCd()) ) {

						BatchResponseCode.INVALID_PACKAGE_TYPE_STATE.occur(title.getXclVal());
					}
					else if( pkgType.getItemCnt() > 0 ) {

						//BatchResponseCode.ALREADY_REGISTERD_PACKAGE_TYPE.occur(title.getXclVal());
						registeredCheck.add(title.getXclVal());
					}
					title.setPkgExscYn(1);
					String key = title.getPkgNm() + "-" + title.getPkgTyCont();
					if( dupCheck.containsKey(key) )
						dupCheck.put(key, dupCheck.get(key) + 1);
					else
						dupCheck.put(key, 1);
				}
				else {

					BatchResponseCode.CANNOT_FOUND_PACKAGE_TYPE.occur(title.getXclVal());
				}
			}
		});

		if( !overwriteItem && registeredCheck.size() > 0 ) {

			BatchResponseCode.ALREADY_REGISTERD_PACKAGE_TYPE.occur(String.join(",", registeredCheck));
		}

		if( dupCheck.entrySet().stream().anyMatch(e->e.getValue() > 1) ) {

			BatchResponseCode.DUPLICATED_PACKAGE_TYPE.occur(dupCheck.entrySet().stream().filter(e->e.getValue() > 1).map(Map.Entry::getKey).collect(Collectors.joining(",")));
		}

		validatePackageType2();

		// 패키지타입 일괄업로드 제목/목록/항목 데이터를 등록한다.
		batchExecutor.batchUpdate(
			"INSERT INTO T_PKG_ITM_TITL_UPLD_DTL(\r\n" +
			"	  PKG_ITM_UPLD_BSC_ID\r\n" +
			"	, PKG_ITM_SHT_DV_CD\r\n" +
			"	, XCL_COMN_ID\r\n" +
			"	, XCL_VAL\r\n" +
			"	, PKG_NM\r\n" +
			"	, PKG_TY_CONT\r\n" +
			"	, PKG_ITM_AMT_VAL\r\n" +
			"	, PKG_TY_ID\r\n" +
			"	, PKG_EXSC_YN\r\n" +
			"	, CHEX_YN\r\n" +
			"	, PKG_ITM_ST_VAL\r\n" +
			"	, CMPL_YN\r\n" +
			"	, PKG_TITL_ST_VAL\r\n" +
			"	, PKG_TITL_ERR_CONT\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			")\r\n" +
			"VALUES\r\n" +
			"(\r\n" +
			"	  #{pkgItmUpldBscId}\r\n" +
			"	, #{pkgItmShtDvCd}\r\n" +
			"	, #{xclComnId}\r\n" +
			"	, #{xclVal}\r\n" +
			"	, #{pkgNm}\r\n" +
			"	, #{pkgTyCont}\r\n" +
			"	, #{pkgItmAmtVal}\r\n" +
			"	, #{pkgTyId}\r\n" +
			"	, 1\r\n" +
			"	, #{chexYn}\r\n" +
			"	, #{pkgItmStVal}\r\n" +
			"	, #{cmplYn}\r\n" +
			"	, #{pkgTitlStVal}\r\n" +
			"	, #{pkgTitlErrCont}\r\n" +
			"	, #{adminUserMngrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			"	, #{adminUserMngrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			")", titles);

		batchExecutor.batchUpdate(
			"INSERT INTO T_PKG_ITM_LST_UPLD_DTL(\r\n" +
			"	  PKG_ITM_UPLD_BSC_ID\r\n" +
			"	, XCL_SHT_NO\r\n" +
			"	, XCL_ROW_ID\r\n" +
			"	, ITM_CAT_NM\r\n" +
			"	, ITM_CAT_ID\r\n" +
			"	, DTL_CAT_ITM_NM\r\n" +
			"	, DTL_CAT_ITM_ID\r\n" +
			"	, EXAM_RESV_ITM_NM\r\n" +
			"	, EXAM_NM\r\n" +
			"	, PKG_ITM_ST_VAL\r\n" +
			"	, PKG_ITM_ERR_CONT\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			")\r\n" +
			"VALUES\r\n" +
			"(\r\n" +
			"	  #{pkgItmUpldBscId}\r\n" +
			"	, #{xclShtNo}\r\n" +
			"	, #{xclRowId}\r\n" +
			"	, #{itmCatNm}\r\n" +
			"	, #{itmCatId}\r\n" +
			"	, #{dtlCatItmNm}\r\n" +
			"	, #{dtlCatItmId}\r\n" +
			"	, #{examResvItmNm}\r\n" +
			"	, #{examNm}\r\n" +
			"	, #{pkgItmStVal}\r\n" +
			"	, #{pkgItmErrCont}\r\n" +
			"	, #{adminUserMngrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			"	, #{adminUserMngrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			")", lists);

		batchExecutor.batchUpdate(
			"INSERT INTO T_PKG_ITM_UPLD_DTL(\r\n" +
			"	  PKG_ITM_UPLD_BSC_ID\r\n" +
			"	, XCL_SHT_NO\r\n" +
			"	, XCL_ROW_ID\r\n" +
			"	, XCL_COMN_ID\r\n" +
			"	, PKG_ITM_ATRI_VAL\r\n" +
			"	, WRAR_CNT\r\n" +
			"	, XCL_N1ST_CSTR_VAL\r\n" +
			"	, XCL_N2ND_CSTR_VAL\r\n" +
			"	, XCL_N3RD_CSTR_VAL\r\n" +
			"	, ITM_TY_CD\r\n" +
			"	, SEX_CD\r\n" +
			"	, CHEX_STUP_CNT\r\n" +
			"	, ITM_PRC\r\n" +
			"	, PKG_ITM_UPLD_ST_VAL\r\n" +
			"	, PKG_ITM_ERR_ST_VAL\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			")\r\n" +
			"VALUES\r\n" +
			"(\r\n" +
			"	  #{pkgItmUpldBscId}\r\n" +
			"	, #{xclShtNo}\r\n" +
			"	, #{xclRowId}\r\n" +
			"	, #{xclComnId}\r\n" +
			"	, #{pkgItmAtriVal}\r\n" +
			"	, #{wrarCnt}\r\n" +
			"	, #{xclN1stCstrVal}\r\n" +
			"	, #{xclN2ndCstrVal}\r\n" +
			"	, #{xclN3rdCstrVal}\r\n" +
			"	, #{itmTyCd}\r\n" +
			"	, #{sexCd}\r\n" +
			"	, #{chexStupCnt}\r\n" +
			"	, #{itmPrc}\r\n" +
			"	, #{pkgItmUpldStVal}\r\n" +
			"	, #{pkgItmErrStVal}\r\n" +
			"	, #{adminUserMngrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			"	, #{adminUserMngrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			")", items.stream()
			.filter(i->StringUtils.isNotEmpty(i.getPkgItmAtriVal()))
			.collect(Collectors.toList()));

		// 패키지타입 일괄업로드 기본테이블에 오류여부 설정
		repository.updatePackageItemUploadBasicError(SearchMapContextHolder.get());

		// 패키지타입 일괄업로드 기본검사/선택검사 등록
//		repository.insertPackageTypeItem(in);
//
//		// 패키지타입 일괄업로드 추가검사 등록
//		repository.insertPackageTypeItem2(in);
//
//		// 패키지타입 일괄업로드 선택검사 상세 등록
//		repository.insertPackageTypeSelectExamDetail(in);
//
//		// 패키지타입 일괄업로드 완료 처리
//		repository.updatePackageItemUploadBasicComplete(in);
//
//		// 등록결과 조회 및 반환
//		List<PackageItemUploadResultModel> resultList = repository.selectPakcageItemUploadResult(in);
//		PackageItemUploadResultModel result =  resultList.get(0);
//		result.setErrorCount(result.getTotalCount() - result.getSuccessCount());
//
//		titles = repository.selectPackageItemUploadTitle(in);
//		lists = repository.selectPackageItemUploadList(in);
//		items = repository.selectPackageItemUploadDetail(in);
//
//		Map<Integer, Map<Integer, String[]>> errors = new HashMap<>();
//		items.stream()
//		.filter(itm->itm.getPkgItmUpldStVal() == 2)
//		.forEach(itm->{
//
//			PackageItemUploadTitleModel title = titles.stream()
//				.filter(t->t.getXclComnId()==itm.getXclComnId())
//				.findFirst().get();
//
//			Map<Integer, String[]> pkgErrs = null;
//			if( errors.containsKey(title.getXclComnId()) )
//				pkgErrs = errors.get(title.getXclComnId());
//			else {
//
//				pkgErrs = new HashMap<>();
//				errors.put(title.getXclComnId(), pkgErrs);
//			}
//
//			pkgErrs.put(itm.getXclRowId(), new String[] { itm.getPkgItmAtriVal(), itm.getEtcDesc(), itm.getPkgItmErrStVal() });
//		});
//		lists.stream()
//		.filter(lst->lst.getPkgItmStVal() == 2)
//		.forEach(lst->{
//
//			errors.entrySet().stream()
//			.forEach(e->{
//
//				String[] err = null;
//				if( e.getValue().containsKey(lst.getXclRowId()) )
//					err = e.getValue().get(lst.getXclRowId());
//				else {
//
//					err = new String[3];
//					e.getValue().put(lst.getXclRowId(), err);
//				}
//				err[2] = lst.getPkgItmErrCont();
//			});
//		});
//		titles.stream()
//		.filter(ttl->ttl.getPkgTitlStVal() == 2)
//		.forEach(ttl->{
//
//			if( !errors.containsKey(ttl.getXclComnId()) )
//				errors.put(ttl.getXclComnId(), null);
//		});
//		List<Integer> pkgs = errors.keySet().stream()
//			.sorted()
//			.collect(Collectors.toList());
//		result.setHeaders(Stream.concat(
//			Arrays.asList("카테고리", "검진세부항목", "검사명").stream(),
//			pkgs.stream().flatMap(p->{
//
//				return Arrays.asList(titles.stream()
//					.filter(t->t.getXclComnId() == p)
//					.findFirst()
//					.get()
//					.getXclVal(), "비고", "오류내용").stream();
//			}))
//			.collect(Collectors.toList()));
//		result.setErrorDesc(errors.entrySet().stream()
//			.filter(e->e.getValue() != null)
//			.flatMap(e->e.getValue().keySet().stream())
//			.distinct()
//			.sorted()
//			.map(rowId->{
//
//				PackageItemUploadListModel lst = lists.stream()
//					.filter(l->l.getXclRowId() == rowId)
//					.findFirst()
//					.get();
//				PackageItemUploadErrorModel ret = PackageItemUploadErrorModel.builder()
//					.catNm(lst.getItmCatNm())
//					.subCatNm(lst.getDtlCatItmNm())
//					.examNm(lst.getExamResvItmNm())
//					.build();
//
//				for( int i=0; i<pkgs.size(); i++ ) {
//
//					try {
//
//						if( errors.get(pkgs.get(i)) == null ) {
//
//							int colId = pkgs.get(i);
//							writeError(ret, i + 1, "", "", titles.stream()
//								.filter(t->t.getXclComnId() == colId)
//								.findFirst().get().getPkgTitlErrCont());
//						}
//						else {
//
//							String[] err = errors.get(pkgs.get(i)).get(rowId);
//							writeError(ret, i + 1, err[0], err[1], err[2]);
//						}
//					}
//					catch( Exception e ) {
//
//						LOGGER.error(ExceptionUtils.getStackTrace(e));
//					}
//				}
//
//				return ret;
//			})
//			.collect(Collectors.toList()));
//
//		return result;
	}

	void checkPackageError(BatchPackageUploadModel src, boolean result, BatchPackageUploadError error, Object...args) {

		if( !result ) {

			src.setPkgRegStCd(error.getErrorCd());
			src.setPkgErrCont(src.getPkgErrCont().concat(("|") + error.getMessage(args)));
		}
	}

	private BatchPackageUploadModel validate(BatchPackageUploadModel src) {

		src.setPkgRegStCd("1");
		src.setPkgErrCont("");

		checkPackageError(src, StringUtils.isNotEmpty(src.getCuiNm()), BatchPackageUploadError.MISSING_INFORMATION, "센터명");
		checkPackageError(src, StringUtils.isNotEmpty(src.getPkgNm()), BatchPackageUploadError.MISSING_INFORMATION, "패키지명");
		checkPackageError(src, StringUtils.isNotEmpty(src.getPkgTyCont()), BatchPackageUploadError.MISSING_INFORMATION, "패키지타입");
		checkPackageError(src, StringUtils.isNotEmpty(src.getSexCdNm()), BatchPackageUploadError.MISSING_INFORMATION, "성별");
		checkPackageError(src, StringUtils.isEmpty(src.getSexCdNm()) || BatchUploadUtils.strIn(src.getSexCdNm() , "남", "여", "남여", "남녀", "공통"), BatchPackageUploadError.INVALID_INFORMATION, "성별");
		checkPackageError(src, StringUtils.isNotEmpty(src.getPkgBscPrcVal()), BatchPackageUploadError.MISSING_INFORMATION, "기본 타입 가격");
		checkPackageError(src, StringUtils.isNotEmpty(src.getPrpPridSrtDt()) ||
			StringUtils.isNotEmpty(src.getPrpPridEndDt()), BatchPackageUploadError.MISSING_INFORMATION, "제안서 기간");

		checkPackageError(src, StringUtils.isNotEmpty(src.getPkgBscPrcVal()), BatchPackageUploadError.NO_DIGIT, "금액");
		checkPackageError(src, BatchUploadUtils.numIn(src.getPkgBscPrcVal(), 1000, Integer.MAX_VALUE), BatchPackageUploadError.TOO_SMALL_PRICE);

		return src;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void packageValidate(List<RowInfo> converted, Integer clcoId, Integer yr) {

		final int mngrId = BatchUploadUtils.getCurrentMngrId();

		// 헤더 체크
		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();
		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

		if( BatchUploadColumn.stream(PackageColumn.class).anyMatch(c->c.isRequired() && !contains(headerRow.values(), c.getTitle())) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur();

		// 빈 ROW 삭제 및 값 설정
		List<BatchPackageUploadModel> pkgList = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyMap((Map<String, Object>)r.getObject()))
			.map(r->{

				BatchPackageUploadModel p = BatchUploadUtils.map((Map<String, Object>)r.getObject(),
					headerRow,
					BatchUploadColumn.table(PackageColumn.class), BatchPackageUploadModel.class);
				p.setClcoId(clcoId);
				p.setYr(yr);
				return p;
			})
			.collect(Collectors.toList());

		// 검색조건 설정
		SearchMapContextHolder.set(UstraMapUtils.getMap(
			"clcoId", clcoId,
			"yr", yr,
			"mngrId", mngrId));

		repository.updatePkgUpldBscUploadYn(SearchMapContextHolder.get());

		// 신규 등록 대상 추출
		List<BatchPackageUploadModel> forInsert = pkgList.stream()
			.filter(p->ObjectUtils.isEmpty(p.getUpldPkgId()))
			.map(p->validate(p))
			.collect(Collectors.toList());

		// 업데이트 대상 추출
		List<BatchPackageUploadModel> forUpdate = new ArrayList<>();
		List<BatchPackageUploadModel> checkUpdate = pkgList.stream()
			.filter(p->ObjectUtils.isNotEmpty(p.getUpldPkgId()))
			.collect(Collectors.toList());
		if( CollectionUtils.isNotEmpty(checkUpdate) ) {

			List<BatchPackageUploadModel> checked = repository.getPkgUpldBscForUpdate(UstraMapUtils.getMap(
				"clcoId", clcoId,
				"yr", yr,
				"mngrId", mngrId,
				"list", checkUpdate));
			forUpdate = checkUpdate.stream()
				.filter(p->checked.stream().anyMatch(ch->p.getUpldPkgId().equals(ch.getUpldPkgId())))
				.map(p->validate(p))
				.collect(Collectors.toList());

			forInsert.addAll(checkUpdate.stream()
				.filter(p->checked.stream().noneMatch(ch->p.getUpldPkgId().equals(ch.getUpldPkgId())))
				.map(p->validate(p))
				.collect(Collectors.toList()));
		}

		// 신규 등록
		batchExecutor.batchUpdate(
			"INSERT INTO T_PKG_UPLD_BSC(\r\n" +
			"	  RNK\r\n" +
			"	, YR\r\n" +
			"	, CUI_ID\r\n" +
			"	, CLCO_ID\r\n" +
			"	, PKG_NM\r\n" +
			"   , SEX_CD_NM\r\n" +
			"	, PKG_BSC_PRC_VAL\r\n" +
			"	, CUI_NM\r\n" +
			"	, PRP_PRID_SRT_DT\r\n" +
			"	, PRP_PRID_END_DT\r\n" +
			"	, PKG_REG_ST_CD\r\n" +
			"	, PKG_ERR_CONT\r\n" +
			"	, PKG_TY_CONT\r\n" +
			"	, USE_YN\r\n" +
			"	, UPLD_YN\r\n" +
			"	, DEL_YN\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			")\r\n" +
			"VALUES(\r\n" +
			"	  #{rnk}\r\n" +
			"	, #{yr}\r\n" +
			"	, #{cuiId}\r\n" +
			"	, #{clcoId}\r\n" +
			"	, #{pkgNm}\r\n" +
			"   , #{sexCdNm}\r\n" +
			"	, #{pkgBscPrcVal}\r\n" +
			"	, #{cuiNm}\r\n" +
			"	, #{prpPridSrtDt}\r\n" +
			"	, #{prpPridEndDt}\r\n" +
			"	, #{pkgRegStCd}\r\n" +
			"	, #{pkgErrCont}\r\n" +
			"	, #{pkgTyCont}\r\n" +
			"	, 1\r\n" +
			"	, 1\r\n" +
			"	, 0\r\n" +
			"	, #{lastUpdrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			"	, #{lastUpdrId}\r\n" +
			"	, 1\r\n" +
			"	, GETDATE()\r\n" +
			")", forInsert);

		// 업데이트
		batchExecutor.batchUpdate(
			"UPDATE T_PKG_UPLD_BSC\r\n" +
			"SET  RNK = #{rnk}\r\n" +
			"	, YR = #{yr}\r\n" +
			"	, CUI_ID = #{cuiId}\r\n" +
			"	, CLCO_ID = #{clcoId}\r\n" +
			"	, PKG_NM = #{pkgNm}\r\n" +
			"   , SEX_CD_NM = #{sexCdNm}\r\n" +
			"	, PKG_BSC_PRC_VAL = #{pkgBscPrcVal}\r\n" +
			"	, CUI_NM = #{cuiNm}\r\n" +
			"	, PRP_PRID_SRT_DT = #{prpPridSrtDt}\r\n" +
			"	, PRP_PRID_END_DT = #{prpPridEndDt}\r\n" +
			"	, PKG_REG_ST_CD = #{pkgRegStCd}\r\n" +
			"	, PKG_ERR_CONT = #{pkgErrCont}\r\n" +
			"	, PKG_TY_CONT = #{pkgTyCont}\r\n" +
			"	, USE_YN = 1\r\n" +
			"	, UPLD_YN = 1\r\n" +
			"	, FRST_REGR_ID = #{lastUpdrId}\r\n" +
			"	, FRST_REGR_TY_CD = 1\r\n" +
			"	, FRST_REG_DTM = GETDATE()\r\n" +
			"	, LAST_UPDR_ID = #{lastUpdrId}\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"WHERE 1=1\r\n" +
			"	AND UPLD_PKG_ID = #{upldPkgId}", forUpdate);

		// PKG_ID가 조회되지 않은 항목을 체크한다.
		repository.updatePackageUploadBasicValidate1(SearchMapContextHolder.get());

		// 추가 validation 체크
		repository.updatePackageUploadBasicValidate2(SearchMapContextHolder.get());

		// 기존 패키지 충돌 여부 체크
		repository.updatePackageUploadBasicValidate3(SearchMapContextHolder.get());

		// 검진기관 Relation 일괄 등록
		//repository.insertCheckupInstAgencyRelation(in);

		// 패키지 타입 일괄 등록
		//repository.insertPackageType(in);

		// 등록 결과 조회 및 반환
//		List<PackageUploadResultModel> resultList = repository.selectPackageUploadResult(in);
//		PackageUploadResultModel result =  resultList.get(0);
//		result.setErrorDesc(repository.selectPackageUploadBasicError(in));

//		return result;
	}

	private boolean contains(Collection<Object> values, String title) {

		return values.stream().filter(v->v.toString().replace(" ", "").equals(title)).count() > 0;
	}

	private String rmspc(String src) {

		return StringUtils.isEmpty(src) ? "" : src.replace(" ", "");
	}

	private boolean isEtc(int colId) {

		return "비고".equals(rmspc(titles.stream()
			.filter(t->t.getXclComnId() == colId)
			.findFirst().map(PackageItemUploadTitleModel::getXclVal).orElse(null)));
	}

	private String getSex(String src) {

		return commonCodeList.stream()
			.filter(c->"SEX_CD".equals(c.getGrpCd()))
			.filter(c->c.getCdNm().equals(src))
			.map(c->c.getDtlCd())
			.findFirst()
			.orElse(null);
	}

	private String getItemSex(int shtNo, int rowId) {

		String itmIdStr = lists.stream()
			.filter(l->l.getXclRowId() == rowId)
			.filter(l->l.getXclShtNo() == shtNo)
			.findFirst()
			.map(PackageItemUploadListModel::getExamNm)
			.orElse("0");

		return packageItemList.stream()
			.filter(itm->itmIdStr.equals("" + itm.getItmId()))
			.findFirst()
			.map(PackageItemModel::getSexCd)
			.orElse(null);
	}

	private PackageItemUploadListModel listCheck(PackageItemUploadListModel list) {

		PackageItemModel found = packageItemList.stream()
			.filter(pi->{
				return rmspc(pi.getCatNm()).equals(rmspc(list.getItmCatNm())) &&
					rmspc(pi.getSubCatNm()).equals(rmspc(list.getDtlCatItmNm())) &&
					rmspc(pi.getExamItmNm()).equals(rmspc(list.getExamResvItmNm()));
			})
			.findFirst()
			.orElse(null);

		if( found != null ) {

			list.setItmCatId(found.getCatId());
			list.setDtlCatItmId(found.getSubCatId());
			list.setExamNm("" + found.getItmId());
			list.setPkgItmStVal(1);
			list.setPkgItmErrCont("정상");
		}
		else {

			list.setPkgItmStVal(2);
			list.setPkgItmErrCont("존재하지 않거나 혹은 잘못되었습니다.");
		}
		return list;
	}

	private PackageItemUploadItemModel itemCheck(PackageItemUploadItemModel item, boolean isEtc) {

		if( isEtc || item.getXclShtNo() == 2 && item.getXclComnId() == 4 )
			return item;

		String xclVal = itemStringCheck(item.getPkgItmAtriVal());

		item.setPkgItmAtriVal(xclVal);
		item.setWrarCnt(countPkgItemValue(xclVal, "\n|/| |\\*|,"));
		item.setXclN1stCstrVal(splitValueCondition(xclVal, item.getWrarCnt(), 0, 2, "\n|/| |\\*|,", 0));
		item.setXclN2ndCstrVal(splitValueCondition(xclVal, item.getWrarCnt(), 1, 2, "\n|/| |\\*|,", 1));
		item.setXclN3rdCstrVal(splitValueCondition(xclVal, item.getWrarCnt(), 2, 2, "\n|/| |\\*|,", 2));

		if( StringUtils.isEmpty(xclVal) ) {

			item.setPkgItmUpldStVal(0);
		}
		else {

			PackageItemStatusModel status = itemStatusCheck(item);
			item.setItmTyCd(status.getItmTyCd());
			item.setSexCd(status.getSexCd());
			item.setItmPrc(status.getItmPrc());
			item.setPkgItmUpldStVal(status.getItemStatus().equals(PackageItemStatus.NORMAL) ? 1 : 2);
			item.setPkgItmErrStVal(status.getItemStatus().getCont());

			// 선택검사 선택 제한
			if( status.getItemStatus().equals(PackageItemStatus.NORMAL) &&
				!"0".equals(item.getItmTyCd()) && !"1".equals(item.getItmTyCd()) )
				item.setChexStupCnt(BatchFormatUtils.getSelectLimit(item.getXclN1stCstrVal()));
		}
		return item;
	}

	private PackageItemStatusModel itemStatusCheck(PackageItemUploadItemModel item) {

		List<UstraCodeModel> scds = commonCodeList.stream()
			.filter(c->"EXAM_KD_CD".equals(c.getGrpCd()))
			.filter(c->c.getCdNm().startsWith("선택검사"))
			.collect(Collectors.toList());

		// 줄바꿈 0개
		if( item.getWrarCnt() == 0 ) {

			// Sheet1은 기본검사 or 선택검사
			if( item.getXclShtNo() == 1 ) {

				// 기본검사
				if( BatchFormatUtils.isBasic(item.getXclN1stCstrVal()) )
					return PackageItemStatusModel.ofNormal("0", getItemSex(item.getXclShtNo(), item.getXclRowId()), 0);
				// 선택검사
				if( BatchFormatUtils.isSelect(item.getXclN1stCstrVal(), scds) )
					return PackageItemStatusModel.ofNormal(
						BatchFormatUtils.getSelectType(item.getXclN1stCstrVal(), scds),
						getItemSex(item.getXclShtNo(), item.getXclRowId()), 0);
			}
			// Sheet2는 추가검사금액
			else if( item.getXclShtNo() == 2 && BatchFormatUtils.isPrice(item.getXclN1stCstrVal()) )
				return PackageItemStatusModel.ofNormal("1", getItemSex(item.getXclShtNo(), item.getXclRowId()),
					BatchFormatUtils.getPrice(item.getXclN1stCstrVal()));
			// 그 외에는 오류
			return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_FORMAT_1_1);
		}
		// 줄바꿈 1개
		else if( item.getWrarCnt() == 1 ) {

			// Sheet1
			if( item.getXclShtNo() == 1 ) {

				// 기본검사/성별
				if( BatchFormatUtils.isBasic(item.getXclN1stCstrVal()) &&
					BatchFormatUtils.isSex(item.getXclN2ndCstrVal()) ) {
					return PackageItemStatusModel.ofNormal("0", getSex(item.getXclN2ndCstrVal()), 0);
				}
				// 선택검사
				else if( BatchFormatUtils.isSelect(item.getXclN1stCstrVal(), scds) ) {

					// 선택검사/성별
					if( BatchFormatUtils.isSex(item.getXclN2ndCstrVal()) )
						return PackageItemStatusModel.ofNormal(
							BatchFormatUtils.getSelectType(item.getXclN1stCstrVal(), scds),
							getSex(item.getXclN2ndCstrVal()), 0);
					// 선택검사/금액
					else if( BatchFormatUtils.isPrice(item.getXclN2ndCstrVal()) )
						return PackageItemStatusModel.ofNormal(
							BatchFormatUtils.getSelectType(item.getXclN1stCstrVal(), scds),
							getItemSex(item.getXclShtNo(), item.getXclRowId()),
							BatchFormatUtils.getPrice(item.getXclN2ndCstrVal()));
				}
				// 그 외에는 오류
				return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_FORMAT_2_2);
			}
			// Sheet2는 추가검사금액/추가검사성별
			else if( item.getXclShtNo() == 2 &&
				BatchFormatUtils.isPrice(item.getXclN1stCstrVal()) ) {
				if( BatchFormatUtils.isSex(item.getXclN2ndCstrVal()) )
					return PackageItemStatusModel.ofNormal("1",
						getSex(item.getXclN2ndCstrVal()),
						BatchFormatUtils.getPrice(item.getXclN1stCstrVal()));
				// 그 외에는 오류
				return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_FORMAT_2_2);
			}
			// 그 외에는 오류
			return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_FORMAT_1_2);
		}
		// 줄바꿈 2개
		else if( item.getWrarCnt() == 2 ) {

			// 선택검사
			if( item.getXclShtNo() == 1 &&
				BatchFormatUtils.isSelect(item.getXclN1stCstrVal(), scds) ) {

				// 성별
				if( BatchFormatUtils.isSex(item.getXclN2ndCstrVal()) ) {

					// 금액
					if( BatchFormatUtils.isPrice(item.getXclN3rdCstrVal()) )
						return PackageItemStatusModel.ofNormal(
							BatchFormatUtils.getSelectType(item.getXclN1stCstrVal(), scds),
							getSex(item.getXclN2ndCstrVal()),
							BatchFormatUtils.getPrice(item.getXclN3rdCstrVal()));
					// 그 외에는 오류
					return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_FORMAT_3_3);
				}
				// 그 외에는 오류
				return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_FORMAT_2_3);
			}
			// 그 외에는 오류
			return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_FORMAT_1_3);
		}

		// 그 외에는 오류
		return PackageItemStatusModel.ofError(PackageItemStatus.INVALID_RULE);
	}

	private String itemStringCheck(String item) {

		//item = item.replace(" ", "");
		item = item.replace("(남)", "남");
		item = item.replace("(여)", "여");
		item = item.replace("남자", "남");
		item = item.replace("여자", "여");
		item = item.replace("\r\n", "\n");
		if( item.startsWith("\n") ||
			item.startsWith("/") ||
			item.startsWith(" ") ||
			item.startsWith("*") ||
			item.startsWith(",") )
			return item.substring(1);
		return item;
	}

	private List<String> splitPkgItem(String src, String ch) {

		String[] values = src.split(ch);
		List<String> optVals = new ArrayList<>();
		for( int i=0; i<values.length; i++ ) {

			if( i < values.length - 1 && values[i].startsWith("선택") && values[i + 1].startsWith("(") ) {

				optVals.add(values[i] + values[i + 1]);
				i++;
			}
			else
				optVals.add(values[i]);
		}

		return optVals;
	}

	private int countPkgItemValue(String src, String ch) {

		List<String> optVals = splitPkgItem(src, ch);
		return optVals.size() - 1;
	}

	private String splitPkgItemValue(String src, String ch, int index) {

		List<String> optVals = splitPkgItem(src, ch);
		return index < optVals.size() ? optVals.get(index) : "";
	}

	private String splitValueCondition(String src, int target, int min, int max, String ch, int index) {

		return (target >= min && target <= max) ? splitPkgItemValue(src, ch, index) : null;
	}

	private String splitValue(String src, String ch, int index) {

		String[] values = src.split(ch);
		if( index >= 0 && index < values.length )
			return values[index];
		return "";
	}

	private String lastTitle() {

		if( CollectionUtils.isEmpty(titles) )
			return "";

		return titles.get(titles.size() - 1).getXclVal();
	}

	private PackageItemUploadTitleModel titleCheck(PackageItemUploadTitleModel title) {

		if( "1".equals(title.getPkgItmShtDvCd()) &&
			title.getXclComnId() > 3 &&
			BatchUploadUtils.charCount(title.getXclVal(), "-") != 2 &&
			title.getXclVal().startsWith("비고") )
			title.setXclVal("비고");

		if( "1".equals(title.getPkgItmShtDvCd()) ) {

			boolean error1 = title.getXclComnId() > 3 &&
				"비고".equals(title.getXclVal().replace(" ", "")) &&
				"비고".equals(lastTitle().replace(" ", ""));

			boolean error2 = title.getXclComnId() > 2 &&
				!"비고".equals(title.getXclVal().replace(" ", "")) &&
				(BatchUploadUtils.charCount(title.getXclVal(), "-") != 2 ||
					!NumberUtils.isCreatable(splitValue(title.getXclVal(), "-", 2)));

			boolean error3 = title.getXclComnId() == 3 &&
				"비고".equals(title.getXclVal().replace(" ", ""));

			if( error1 || error2 || error3 ) {

				title.setPkgTitlStVal(2);
				title.setPkgTitlErrCont("헤더값 오류");
			}
			else {

				title.setPkgTitlStVal(1);
				title.setPkgTitlErrCont("정상");
				if( title.getXclComnId() > 2 && !"비고".equals(title.getXclVal()) ) {

					title.setPkgNm(splitValue(title.getXclVal(), "-", 0));
					title.setPkgTyCont(splitValue(title.getXclVal(), "-", 1));
					title.setPkgItmAmtVal(splitValue(title.getXclVal(), "-", 2));
				}
			}
		}

		return title;
	}

	@SuppressWarnings("unchecked")
	private void processTitle(List<RowInfo> rows, int bscId, int sheetValue, int minCol, int maxCol, BatchResponseCode formatErrorCode,
		String[] columns, BatchResponseCode titleErrorCode) {

		List<String> cols = (List<String>)rows.get(0).getObject();
		if( cols.size() < minCol || cols.size() > maxCol )
			formatErrorCode.occur();

		for( int colId=0; colId<cols.size(); colId++ ) {

			String titleStr = cols.get(colId);

			if( colId < columns.length && !columns[colId].equals(titleStr.replace(" ", "")) )
				titleErrorCode.occur();

			if( sheetValue < 0 )
				continue;

			PackageItemUploadTitleModel title = titleCheck(PackageItemUploadTitleModel.builder()
				.pkgItmUpldBscId(bscId)
				.xclComnId(colId)
				.xclVal(titleStr)
				.pkgItmShtDvCd("" + sheetValue)
				.build());
			titles.add(title);
		}
	}

	@Transactional
	public List<PackageTypeItemExcelModel> getPackageTypeTemplate() {

		List<PackageItemModel> items = packageManagementService.getPackageItemList(new PackageExamRstrModel());
		return items.stream()
			.map(itm->{
				return PackageTypeItemExcelModel.builder()
					.catNm(itm.getCatNm())
					.subCatNm(itm.getSubCatNm())
					.examItmNm(itm.getExamItmNm())
					.build();
			})
			.collect(Collectors.toList());
	}

	/**
	 * 패키지 메인 리스트
	 * @param in
	 * @return PackageUploadExcelModel
	 */
	public List<PackageItemSelectModel> getPkgUploadList(PackageItemUploadBasicModel model){
		return repository.getPkgUploadList(model);
	}

	/**
	 * 패키지 상세 리스트
	 * @param in
	 * @return PackageUploadExcelModel
	 */
	public List<PackageItemSelectModel> getPkgUploadDtlList(PackageItemUploadBasicModel model){
		return repository.getPkgUploadDtlList(model);
	}

	/**
     * 패키지-타입 메인 리스트
     * @param in
     * @return List<PackageTypeItemSelectModel>
     */
    public List<PackageTypeItemSelectModel> getPkgTypeUploadList(PackageItemUploadBasicModel model){
        return repository.getPkgTypeUploadList(model);
    }

	/**
	 * 패키지 엑셀 다운로드
	 * @param in
	 * @return PackageUploadExcelModel
	 */
	public List<PackageUploadExcelModel> getPackageExcelList(PackageItemUploadBasicModel in){

		return errorExcelMsg(repository.selectPkgUpldBscExcelAll(in));
    }

	public List<PackageUploadExcelModel> getPackageExcelList(List<BatchPackageUploadModel> in) {

		if( CollectionUtils.isEmpty(in) )
			return Arrays.asList(new PackageUploadExcelModel());
		return errorExcelMsg(repository.selectPkgUpldBscExcel(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in)));
	}

	public List<ExamItemModel> getExamItemTemplateList(ExamItemModel in) {
		return repository.getExamItemTemplateList(in);
	}

	public BatchPackageUploadResultModel packageUploadResult(BatchPackageUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		BatchPackageUploadResultModel result = repository.getPkgUpldBscResult(in);
		result.setErrorCnt(result.getMissedCnt() + result.getInvalidCnt() + result.getDuplicatedCnt() + result.getEtcCnt());
		return result;
	}

	public List<BatchPackageUploadModel> getPackageUploadErrorList(BatchPackageUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		return errorMsg(repository.getPkgUpldBscErrorList(in, in.toPaginationRequest()));
	}

	private List<PackageUploadExcelModel> errorExcelMsg(List<PackageUploadExcelModel> errList) {

		errList.forEach(e->{

			String errMsg = e.getPkgErrCont();
			if( StringUtils.isEmpty(errMsg) )
				return;
			errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
			e.setPkgErrCont(errMsg.replace("|", "\r\n"));
		});
		return errList;
	}

	private List<BatchPackageUploadModel> errorMsg(List<BatchPackageUploadModel> errList) {

		errList.forEach(e->{

			String errMsg = e.getPkgErrCont();
			if( StringUtils.isEmpty(errMsg) )
				return;
			errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
			e.setPkgErrCont(errMsg.replace("|", "\r\n"));
		});
		return errList;
	}

	@Transactional
	public void packageInit(BatchPackageUploadResultRequestModel in) {

		repository.updatePkgUpldBscInit(in);
	}

	@Transactional
	public void packageRegist(PackageItemUploadBasicModel in) {

		// 검진기관 Relation 일괄 등록
		repository.insertCheckupInstAgencyRelation(in);

		// 패키지 타입 일괄 등록
		repository.insertPackageType(in);

		// 일괄 등록 완료 처리
		repository.updatePkgUpldBscRegist(in);
	}

	@Transactional
	public void packageRemove(List<BatchPackageUploadModel> in) {

		repository.updatePkgUpldBscDelete(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in));
	}

	@Transactional
	public void packageRemoveAll(PackageItemUploadBasicModel in) {

		repository.updatePkgUpldBscDeleteAll(in);
	}

	public BatchPackageUploadResultModel packageTypeUploadResult(BatchPackageUploadResultRequestModel in) {

		BatchPackageUploadResultModel result = repository.selectPkgItmUpldBscResult(in);
		result.setErrorCnt(result.getTotalCnt()- result.getNormalCnt());
		return result;
	}

	public List<BatchPackageTypeUploadErrorModel> packageTypeUploadErrorList(BatchPackageUploadResultRequestModel in) {

		return repository.selectPkgItmUpldBscErrorList(in);
	}

	@Transactional
	public void packageTypeUploadRemove(List<PackageItemUploadRemoveRequestModel> in) {

		Map<String, Object> param = UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"cuiId", in.get(0).getCuiId(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"xclShtNo", in.get(0).getXclShtNo(),
			"list", in);
		repository.updatePkgItmLstUpldDtlRemove(param);

		repository.updatePkgItmUpldDtlRemove(param);

		repository.updatePkgItmTitlUpldDtlValidate(param);

		// 패키지타입 일괄업로드 기본테이블에 오류여부 설정
		repository.updatePackageItemUploadBasicError(param);
	}

	@Transactional
	public void packageTypeUploadRemoveAll(BatchPackageUploadResultRequestModel in) {

		repository.updatePkgItmLstUpldDtlRemoveAll(in);

		repository.updatePkgItmUpldDtlRemoveAll(in);

		Map<String, Object> param = UstraMapUtils.getMap(
			"clcoId", in.getClcoId(),
			"yr", in.getYr(),
			"cuiId", in.getCuiId(),
			"mngrId", BatchUploadUtils.getCurrentMngrId());

		repository.updatePkgItmTitlUpldDtlValidate(param);

		// 패키지타입 일괄업로드 기본테이블에 오류여부 설정
		repository.updatePackageItemUploadBasicError(param);
	}

	@Transactional
	public void packageTypeRegist(PackageItemUploadBasicModel in) {

		// 패키지타입 상태 변경
		List<PackageTypeModel> pkgTypeList = repository.selectPackageTypeForRegist(in);
		pkgTypeList.forEach(pkgType->{

			pkgType.setPkgItmList(new ArrayList<>());
			pkgType.setPkgTySelectExamList(new ArrayList<>());
			pkgType.setPkgStCd(PackageTypeStatus.REGISTERD.getValue());
			packageManagementService.updatePackageType(pkgType);
		});

		titles = repository.getPkgItmTitlUpldDtl(UstraMapUtils.getMap(
			"clcoId", in.getClcoId(),
			"cuiId", in.getCuiId(),
			"yr", in.getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId()));
		titles.forEach(title->{
			title.setPkgTyId(pkgTypeList.stream()
				.filter(pkgType->pkgType.getPkgNm().equals(title.getPkgNm()))
				.filter(pkgType->pkgType.getPkgTyNm().equals(title.getPkgTyCont()))
				.findFirst().map(PackageTypeModel::getPkgTyId).orElse(title.getPkgTyId()));
		});

		batchExecutor.batchUpdate(
			"UPDATE T_PKG_ITM_TITL_UPLD_DTL\r\n" +
			"SET  PKG_TY_ID = #{pkgTyId} \r\n" +
			"	, LAST_UPDR_ID = #{adminUserMngrId}\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"WHERE 1=1\r\n" +
			"	AND PKG_ITM_UPLD_BSC_ID = #{pkgItmUpldBscId} \r\n" +
			"	AND PKG_ITM_SHT_DV_CD = #{pkgItmShtDvCd} \r\n" +
			"	AND XCL_COMN_ID = #{xclComnId} ", titles);

		// 패키지타입 일괄업로드 기본검사/선택검사 등록
		repository.insertPackageTypeItem(in);

		// 패키지타입 일괄업로드 추가검사 등록
		repository.insertPackageTypeItem2(in);

		// 패키지타입 일괄업로드 선택검사 상세 등록
		repository.insertPackageTypeSelectExamDetail(in);

		// 패키지타입 일괄업로드 완료 처리
		repository.updatePackageItemUploadBasicComplete(in);
	}
}
