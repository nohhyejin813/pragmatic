package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.HthQizBscModel;
import com.gchc.ncu.bo.care.vo.HealthQuizVo;

@Mapper
public interface HealthQuizRepository {
	List<HthQizBscModel> selectHealthQuizList(HealthQuizVo in);
	HthQizBscModel selectHealthQizDetail(HealthQuizVo in);
	int insertHealthQuiz(HthQizBscModel model);
	int updateHealthQuiz(HthQizBscModel model);
	void deleteHealthQuiz(HthQizBscModel model);
	int selectOverlapDate(HthQizBscModel model);

//	List<NtrtIndcBscModel> selectNtrtIndcList(NutritionStatusVo in);
//	List<NtrtIndcDtlModel> selectNtrtIndcDtlList(NutritionStatusVo in);
//	NtrtIndcBscModel selectNtrtIndcDetail(NutritionStatusVo in);
//	void insertNtrtIndcBsc(NtrtIndcBscModel model);
//	void updateNtrtIndcBsc(NtrtIndcBscModel model);
//	void deleteNtrtIndcBsc(NtrtIndcBscModel model);
//	void deleteNtrtIndcDtl(NtrtIndcBscModel model);
//	void insertNtrtIndcDtl(NtrtIndcDtlModel model);

}
