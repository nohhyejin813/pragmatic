package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.SrvyBscModel;
import com.gchc.ncu.bo.care.models.SrvyQstHisModel;
import com.gchc.ncu.bo.care.models.SrvyQstThmAreaDtlModel;
import com.gchc.ncu.bo.care.repository.MusculoSkeletalRepository;
import com.gchc.ncu.bo.care.vo.MusculoSkeletalVo;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;

@Service
@RequiredArgsConstructor
public class MusculoSkeletalService {

	private final MusculoSkeletalRepository musculoSkeletalRepository;


	public List<SrvyBscModel> getSrvyList() {
		return musculoSkeletalRepository.selectSrvyList();
	}

	public List<SrvyQstThmAreaDtlModel> getThmAreaitemList(MusculoSkeletalVo criteria) {
		return musculoSkeletalRepository.selectThmAreaitemList(criteria);
	}

	public List<SrvyQstThmAreaDtlModel> getQutitemList(MusculoSkeletalVo criteria) {
		return musculoSkeletalRepository.selectQutitemList(criteria);
	}

	public void saveSrvyQstHis(List<SrvyQstHisModel> list) {
		if(list != null) {
			for(SrvyQstHisModel model : list) {
				model.setLastUpdrId(GchcJwtUtil.getUserId());
				musculoSkeletalRepository.updateSrvyQstHis(model);
			}
		}
	}

	public List<SrvyBscModel> getChronicSrvyList() {
		return musculoSkeletalRepository.selectChronicSrvyList();
	}

	public List<SrvyQstThmAreaDtlModel> getChronicQutitemList(MusculoSkeletalVo criteria) {
		return musculoSkeletalRepository.selectChronicQutitemList(criteria);
	}

	public void saveChronicSrvyQstHis(List<SrvyQstHisModel> list) {
		if(list != null) {
			for(SrvyQstHisModel model : list) {
				model.setLastUpdrId(GchcJwtUtil.getUserId());
				musculoSkeletalRepository.updateChronicSrvyQstHis(model);
			}
		}
	}

}
