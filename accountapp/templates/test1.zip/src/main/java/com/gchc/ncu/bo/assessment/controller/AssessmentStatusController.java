package com.gchc.ncu.bo.assessment.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microsoft.sqlserver.jdbc.StringUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.management.exception.UstraManagementResponseCode;
import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.assessment.models.AssessmentFileModel;
import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.AssessmentTargetModel;
import com.gchc.ncu.bo.assessment.service.AssessmentService;
import com.gchc.ncu.bo.assessment.vo.AssessmentVo;

/**
 * @FileName	: AssessmentStatusController.java
 * @date		: 2021. 7. 8
 * @author		: gs_yjhan
 * @프로그램 설명	: 검진기관평가관리 > 평가현황 Controller
 * @변경이력		:
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/assessment/status")
@Api(tags = "검진기관평가관리 > 평가현황 - AssessmentStatusController")
public class AssessmentStatusController {

	private final AssessmentService service;

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 > 목록 조회
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@PostMapping("")
	@ApiOperation(value="평가현황 목록 조회", notes="평가현황 목록을 반환한다." )
	public List<AssessmentModel> getAssessmentStatusList(@RequestBody AssessmentModel in) {
		return service.getAssessmentStatusList(in);
	}


	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 > 상세 조회
	 *
	 * @param
	 *
	 * @return AssessmentVo
	 */
	@GetMapping("/{cuiAsmTgtId}")
	@ApiOperation(value="평가현황 상세 조회", notes="평가현황 상세를 반환한다." )
	public AssessmentVo getAssessmentStatusDetail(@PathVariable int cuiAsmTgtId) {
		return service.getAssessmentStatusDetail(cuiAsmTgtId);
	}

	/**
	 * 처리내용 : 검진기관평가 > 평가 문항 조회
	 *
	 * @param
	 *
	 * @return AssessmentVo
	 */
	@PostMapping("/survey/list")
	@ApiOperation(value="평가문항 조회", notes="평가문항을 반환한다." )
	public AssessmentVo getAssessmentSurvey(@RequestBody Map<String, Object> map) {
		if (map.get("yr") == null || map.get("encryptedKey") == null) {
			throw new GchcException(GchcResponseCode.INVALID_REQUEST_VALUE, "잘못된 접근입니다(파라미터 오류)");
		}

		return service.getAssessmentSurvey(map);
	}

	/**
	 * 처리내용 : 검진기관평가 > 평가 저장
	 *
	 * @param AssessmentVo
	 *
	 * @return AssessmentVo
	 */
	@PostMapping("/survey")
	@ApiOperation(value="평가 저장", notes="평가를 저장한다." )
	public ResponseCode saveSurvey(@RequestBody AssessmentVo vo) {
		try {
			service.saveSurvey(false, vo);
			return UstraManagementResponseCode.SUCCESS;
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			return UstraManagementResponseCode.CANNOT_SAVE_RECORD;
		}

	}

	/**
	 * 처리내용 : 검진기관평가 > 평가 저장
	 *
	 * @param AssessmentVo
	 *
	 * @return AssessmentVo
	 */
	@PostMapping("/survey/temp")
	@ApiOperation(value="평가 임시저장", notes="평가를 임시저장한다." )
	public ResponseCode saveTempSurvey(@RequestBody AssessmentVo vo) {
		try {
			service.saveSurvey(true, vo);
			return UstraManagementResponseCode.SUCCESS;
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			return UstraManagementResponseCode.CANNOT_SAVE_RECORD;
		}
	}

	/**
	 * 검진기관관리 - 고객사 검진기관평가관리  > 첨부파일 다운로드
	 * @param
	 * @return
	 */
	@ApiOperation(value="첨부파일 다운로드", notes = "첨부파일을 다운로드한다.")
	@GetMapping("/file-download")
	public void getDownloadFile(@ModelAttribute AssessmentFileModel vo, HttpServletRequest request, HttpServletResponse response) {
		service.getDownloadFile(vo, request, response);
	}

	/**
	 * 검진기관관리 - 고객사 검진기관평가관리  > [T] 평가현황 > 상세 > 평가일 변경
	 *
	 * @param
	 *
	 * @return
	 */
	@PutMapping("/{cuiAsmTgtId}/asmDt")
	@ApiOperation(value="평가일 변경", notes="평가일을 변경한다." )
	public ResponseCode modAsmDt(@RequestBody AssessmentTargetModel in) {
		if (service.uptAsmDt(in) < 1) {
			return UstraManagementResponseCode.CANNOT_SAVE_RECORD;
		}

		return UstraManagementResponseCode.SUCCESS;
	}

	/**
	 * TODO 검진기관관리 - 고객사 검진기관평가관리  > [T] 평가현황 > 상세 > 결과 정산
	 *
	 * @param
	 *
	 * @return
	 */
	@PostMapping("/result")
	@ApiOperation(value="평가 결과 정산", notes="평가 결과를 정산한다." )
	public ResponseCode calResultAssessment(@RequestBody List<Map<String, Object>> in) {

		AssessmentModel model = new AssessmentModel();
		model.setCuiAsmId((int)in.get(0).get("cuiAsmId"));
		model.setCuiAsmTgtId((int)in.get(0).get("cuiAsmTgtId"));
		if(StringUtils.isEmpty((CharSequence)in.get(0).get("cuiAsmEtcOpin"))) {
			model.setCuiAsmEtcOpin((String)in.get(0).get("cuiAsmEtcOpin"));
		}
		if (service.calResultAssessment(in) == in.size()) {
			service.sumResult(model);
			return UstraManagementResponseCode.SUCCESS;
		}
		return UstraManagementResponseCode.CANNOT_SAVE_RECORD;

	}

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 >  URL 발송
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@PostMapping("/send-url")
	@ApiOperation(value="평가현황 목록 조회", notes="평가현황 목록을 반환한다." )
	public int sendUrl(@RequestBody AssessmentModel in) {
		return service.sendUrl(in);
	}




}
