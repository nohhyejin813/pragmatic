package com.gchc.ncu.bo.batchupload.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.batchupload.models.BatchVaccineExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchVaccineTempModel;
import com.gchc.ncu.bo.batchupload.models.BatchVaccineUserModel;

@Mapper
public interface BatchVaccineRepository {

	int getClcoIdData(String clcoNm);

	int getCuiIdData(String cuiNm);

	BatchVaccineUserModel getVaccineUserMatch(BatchVaccineExcelModel vaccine);

	int insertVaccineBlkHvexHis(BatchVaccineExcelModel vaccine);

	List<BatchVaccineExcelModel> getVaccineBlkHvexHis(BatchVaccineExcelModel vaccine);

	int getVaccineBlkHvexHisCnt(BatchVaccineExcelModel vaccine);

	int updateBlkHvexHis(BatchVaccineExcelModel vaccine);

	int deleteSelectVaccine(BatchVaccineExcelModel vaccine);

	List<BatchVaccineExcelModel> getVaccineExcelList(BatchVaccineExcelModel src);

	List<BatchVaccineTempModel> getBatchVaccineHisList(BatchVaccineExcelModel src);

	int updateExcelVaccineDupData(BatchVaccineExcelModel src);

	int updateExcelVaccineDupNmCheck(BatchVaccineExcelModel src);
}
