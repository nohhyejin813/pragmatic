package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.NtrtIndcBscModel;
import com.gchc.ncu.bo.care.models.NtrtIndcDtlModel;
import com.gchc.ncu.bo.care.models.NtrtIngrdBscModel;
import com.gchc.ncu.bo.care.models.NtrtItrstIngrdDtlModel;
import com.gchc.ncu.bo.care.models.NutritionCdModel;
import com.gchc.ncu.bo.care.vo.NutritionStatusVo;

@Mapper
public interface NutritionStatusRepository {

	List<NtrtIngrdBscModel> nutritionStatusList(NutritionStatusVo in);
	NtrtIngrdBscModel getNutritionStatus(NutritionStatusVo in);
	void saveNutritionBsc(NtrtIngrdBscModel model);
	void updateNutritionBsc(NtrtIngrdBscModel model);
	void deleteNutritionBsc(NtrtIngrdBscModel model);


	List<NutritionCdModel> selectNutritionInterestList();
	void updateNutritionCode(NutritionCdModel model);


	List<NtrtItrstIngrdDtlModel> selectNtrtItrstIngrdList(NutritionStatusVo in);
	NtrtItrstIngrdDtlModel selectNtrtItrstDetail(NtrtItrstIngrdDtlModel model);
	void saveNutritionItrst(NtrtItrstIngrdDtlModel model);
	void updateNutritionItrst(NtrtItrstIngrdDtlModel model);
	void deleteNtrtItrst(NtrtItrstIngrdDtlModel model);


	List<NtrtIndcBscModel> selectNtrtIndcList(NutritionStatusVo in);
	List<NtrtIndcDtlModel> selectNtrtIndcDtlList(NutritionStatusVo in);
	NtrtIndcBscModel selectNtrtIndcDetail(NutritionStatusVo in);
	int insertNtrtIndcBsc(NtrtIndcBscModel model);
	int updateNtrtIndcBsc(NtrtIndcBscModel model);
	int overlapAge(NtrtIndcBscModel model);
	void deleteNtrtIndcBsc(NtrtIndcBscModel model);
	void deleteNtrtIndcDtl(NtrtIndcBscModel model);
	void insertNtrtIndcDtl(NtrtIndcDtlModel model);

}
