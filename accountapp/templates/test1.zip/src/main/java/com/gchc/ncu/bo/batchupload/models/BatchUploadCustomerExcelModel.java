package com.gchc.ncu.bo.batchupload.models;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchUploadCustomerExcelModel extends UstraManagementBaseModel {

	private String excelFileName; // 다운로드 엑셀 파일명

	private Integer yr;	// 기준년도
	private Integer clcoId;	// 고객사ID
	private String regDvVal;
	private Integer regOptnYn1;
	private Integer regOptnYn2;


	private String aempSexCd; // 성별
	private Integer row;
	@UstraExcelCellInfo(col = 0, header = "이름", required = false) // 중복체크 로직
	private String aempNm;
	@UstraExcelCellInfo(col = 1, header = "검진등급", required = false)
	private String aempCuGrdNm;
	@UstraExcelCellInfo(col = 2, header = "백신등급", required = false)
	private String aempVcnGrdNm;
	@UstraExcelCellInfo(col = 3, header = "사번", required = false)
	private String aempId;
	@UstraExcelCellInfo(col = 4, header = "임원여부", required = false)	// Integer
	private String excuYn;
	@UstraExcelCellInfo(col = 5, header = "생년월일", required = false)	// 중복체크 로직
	private String aempBrdt;
	@UstraExcelCellInfo(col = 6, header = "입사일자", required = false)
	private String encmDt;
	@UstraExcelCellInfo(col = 7, header = "패키지명", required = false)
	private String pkgNm;
	@UstraExcelCellInfo(col = 8, header = "지원금", required = false) // Integer -> 20211220 String
	private String corpSpfnVal;
	@UstraExcelCellInfo(col = 9, header = "건강보험공단지원대상여부", required = false) // Integer
	private String nhicSuptTgtYn;
	@UstraExcelCellInfo(col = 10, header = "특수검진대상여부", required = false) // Integer
	private String spcuTgtYn;
	@UstraExcelCellInfo(col = 11, header = "특수물질명(1차)", required = false)
	private String extrMttrNm1;
	@UstraExcelCellInfo(col = 12, header = "특수물질명(2차)", required = false)
	private String extrMttrNm2;
	@UstraExcelCellInfo(col = 13, header = "이메일", required = false)
	private String emlAdr;
	@UstraExcelCellInfo(col = 14, header = "휴대전화번호", required = false) // 중복체크 로직
	private String mblNo;
	@UstraExcelCellInfo(col = 15, header = "배우자명", required = false)
	private String spsrNm;
	@UstraExcelCellInfo(col = 16, header = "배우자검진등급명", required = false)
	private String spsrCuGrdNm;
	@UstraExcelCellInfo(col = 17, header = "배우자백신등급명", required = false)
	private String spsrVcnGrdNm;
	@UstraExcelCellInfo(col = 18, header = "배우자생년월일", required = false)
	private String spsrBrdt;
	@UstraExcelCellInfo(col = 19, header = "배우자회사지원금", required = false) // Integer
	private String spsrCorpSpfn;
	@UstraExcelCellInfo(col = 20, header = "배우자검진패키지", required = false)
	private String spsrPkgNm;
	@UstraExcelCellInfo(col = 21, header = "사업장", required = false)
	private String bsplNm;
	@UstraExcelCellInfo(col = 22, header = "부서1", required = false)
	private String deptNm1;
	@UstraExcelCellInfo(col = 23, header = "부서2", required = false)
	private String deptNm2;
	@UstraExcelCellInfo(col = 24, header = "부서3", required = false)
	private String deptNm3;
	@UstraExcelCellInfo(col = 25, header = "직급", required = false)
	private String jbgdNm;
	@UstraExcelCellInfo(col = 26, header = "직장전화번호", required = false)
	private String wrplTlno;
	@UstraExcelCellInfo(col = 27, header = "직장우편번호", required = false)
	private String wrplZpcd;
	@UstraExcelCellInfo(col = 28, header = "직장기본주소", required = false)
	private String wrplBscAdr;
	@UstraExcelCellInfo(col = 29, header = "직장상세주소", required = false)
	private String wrplDtlAdr;
	@UstraExcelCellInfo(col = 30, header = "자택전화번호", required = false)
	private String hsTlno;
	@UstraExcelCellInfo(col = 31, header = "자택우편번호", required = false)
	private String hsZpcd;
	@UstraExcelCellInfo(col = 32, header = "자택기본주소", required = false)
	private String hsBscAdr;
	@UstraExcelCellInfo(col = 33, header = "자택상세주소", required = false)
	private String hsDtlAdr;

	// 임직원 등록 일련번호 // Integer
	@UstraExcelCellInfo(col = 34, header = "임직원 등록 일련번호", required = false)
	private String aempRegSeq;

	@UstraExcelCellInfo(col = 35, header = "근무부서명", required = false)
	private String workDeptNm;
	@UstraExcelCellInfo(col = 36, header = "라인명", required = false)
	private String lineNm;
	@UstraExcelCellInfo(col = 37, header = "작업명", required = false)
	private String jobNm;
	@UstraExcelCellInfo(col = 38, header = "캠페인팀", required = false)
	private String teamNm;

	private String custMemo;

	// 오류
	private List<String> error;
	private Integer errorCnt;

}
