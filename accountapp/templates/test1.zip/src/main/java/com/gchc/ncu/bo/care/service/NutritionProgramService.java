package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.ncu.bo.care.models.NtrtPgmBscModel;
import com.gchc.ncu.bo.care.models.NtrtPgmDtlModel;
import com.gchc.ncu.bo.care.repository.NutritionProgramRepository;
import com.gchc.ncu.bo.care.vo.NutritionProgramVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class NutritionProgramService {

	private final NutritionProgramRepository programRepository;

	public List<NtrtPgmBscModel> getProgramList(NutritionProgramVo criteria) {
		return programRepository.selectProgramList(criteria);
	}

	public NtrtPgmBscModel getProgramDetail(NtrtPgmBscModel criteria) {
		return programRepository.selectProgramDetail(criteria);
	}

	@Transactional
	public void saveProgram(NtrtPgmBscModel model) {
		if (StringUtils.isEmpty(model.getPgmId())) {
			programRepository.insertProgram(model);
		} else {
			programRepository.updateProgram(model);
		}
	}

	@Transactional
	public void deleteProgram(List<NtrtPgmBscModel> list) {
		if (list != null) {
			for (NtrtPgmBscModel model : list) {
				programRepository.deleteProgramMissionByNtrtPgmId(model.getPgmId());
				programRepository.deleteProgram(model);
			}
		}
	}

	public List<NtrtPgmDtlModel> getProgramMissionList(NutritionProgramVo criteria) {
		return programRepository.selectProgramMissionList(criteria);
	}

	public NtrtPgmDtlModel getProgramMissionDetail(NtrtPgmDtlModel criteria) {
		return programRepository.selectProgramMissionDetail(criteria);
	}

	@Transactional
	public void saveProgramMission(NtrtPgmDtlModel model) {
		if (StringUtils.isEmpty(getProgramMissionDetail(model))) {
			programRepository.insertProgramMission(model);
		} else {
			programRepository.updateProgramMission(model);
		}
	}

	@Transactional
	public void deleteProgramMission(List<NtrtPgmDtlModel> list) {
		if (list != null) {
			for (NtrtPgmDtlModel model : list) {
				programRepository.deleteProgramMission(model);
			}
		}
	}

}
