package com.gchc.ncu.bo.admin.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ClientMiniModel {
	private int 	clcoId;
	private String 	clcoNm;
	private String 	startDate;
	private String 	endDate;
	private int 	yr;
	private String 	clientType;
	private String 	titl;
	private	int 	docId;
	private String  cuiNm;
	private String 	regDate;
	private String 	bsplNm;
}
