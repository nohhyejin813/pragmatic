package com.gchc.ncu.bo.challenge.reward.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Map;

@Getter
@Setter
@ToString
public class RewardModel extends NcuModel {
    private int rn;         		// NO
	private int uid;     			// UID
	private int cmpgId;         	// 캠페인아이디
	private int athoCmplCnt;        // 인증완료수

   	private String nm;      		// 이름
   	private String nknm;    		// 닉네임
   	private String empno;   		// 사번
   	private String brdt;    		// 생년월일
    private String cluAgrDt;    	// 약관동의일자
	private String cmpnCont;    	// 보상내용
	private String cmpnContRecs;    // 보상내용이력
	private String lastDipr;    	// 최종처리자

	// 엑셀다운로드
	private Map<String, String> dwldInfo;

	// 오류내용
	private String errMsg;
}
