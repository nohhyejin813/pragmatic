package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.SsngCsttHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttHstkBscModel;
import com.gchc.ncu.bo.care.vo.CsttHstkVo;

@Mapper
public interface CsttHstkRepository {

	List<SsngCsttHstkBscModel> selectContitutionHstkList(CsttHstkVo criteria);
	SsngCsttHstkBscModel selectContitutionHstkPop(CsttHstkVo criteria);
	List<SsngCsttHstkAnswDtlModel> selectCsttHstkAnswerList(SsngCsttHstkAnswDtlModel criteria);
	int insertContitutionBase(SsngCsttHstkBscModel model);
	void updateContitutionBase(SsngCsttHstkBscModel model);
	void insertCsttHstkAnswer(SsngCsttHstkAnswDtlModel model);

	void deleteCsttHstk(SsngCsttHstkBscModel model);
	void deleteCsttHstkAnswer(int dotiHstkId);

}
