package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.comm.*;
import com.gchc.ncu.bo.batchupload.enu.BatchMemberUploadError;
import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.CapaErrorCode;
import com.gchc.ncu.bo.batchupload.enu.MemberAdvanceResvColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberAdvanceResvRegisterRepository;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberAdvanceResvUploadRepository;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchCapaUtils;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.checkupinst.models.CapaTyCd;
import com.gchc.ncu.bo.checkupinst.service.CheckupInstScheduleService;
import com.gchc.ncu.bo.checkupinst.vo.CapaVo;
import com.gchc.ncu.bo.comm.models.CommonParametersModel;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.repository.CommonRepository;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gchc.ncu.bo.comm.util.NcuAuthenticationUtils;
import com.gchc.ncu.bo.comm.util.NcuEncUtils;
import com.gchc.ncu.bo.config.GchcDataBatchExecutor;
import com.gchc.ncu.bo.config.authentication.NcuAdminUser;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import com.gsitm.ustra.java.data.utils.ProcedureManager;
import com.gsitm.ustra.java.management.data.mapper.UstraCommonCodeDataMapper;
import com.gsitm.ustra.java.management.models.UstraCodeModel;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @FileName : BatchMemberAdvaceResvUploadService.java
 * @date : 2022. 06. 10
 * @author : 이광희
 * @프로그램 설명 : 선예약 일괄업로드 Service
 * @변경이력 :
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class BatchMemberAdvanceResvUploadService {

	private final BatchMemberUploadRepository memRepository;
	private final BatchMemberAdvanceResvUploadRepository resvRepository;
	private final BatchMemberAdvanceResvRegisterRepository registRepository;
	private final CheckupInstScheduleService checkupInstScheduleService;
	private final UstraCommonCodeDataMapper commonCodeData;


	@Autowired
	private ProcedureManager procedureManager;

	@Autowired private GchcDataBatchExecutor batchExecutor;

	@Autowired private CommonRepository commRepo;

	void checkMemberError(BatchMemberUploadAdvanceResvModel src, boolean result, BatchMemberUploadError error, Object...args) {

		if( !result ) {

			src.setUpldStVal(error.getErrorValue());
			src.setUpldErrVal(src.getUpldErrVal().concat(("|") + error.getMessage(args)));
		}
	}

	boolean isEmptyRow(BatchUploadAdvanceResvExcelModel c) {

		return StringUtils.isEmpty(c.getAempNm()) &&
			StringUtils.isEmpty(c.getAempCuGrdNm()) &&
			StringUtils.isEmpty(c.getAempId()) &&
			StringUtils.isEmpty(c.getAempBrdt()) &&
			StringUtils.isEmpty(c.getEmlAdr()) &&
			StringUtils.isEmpty(c.getMblNo());
	}


	public List<CommonParametersModel> getClcoList(CommonParametersModel model) {

		NcuAdminUser user = NcuAuthenticationUtils.getCurrentUser();
		if( "01".equals(user.getAuthType()) ||
			"02".equals(user.getAuthType()) ||
			"03".equals(user.getAuthType()) )
			model.setClcoId(user.getClcoId());
		List<CommonParametersModel> result = memRepository.getClcoList(model);
		result.stream()
				.forEach( v -> {
					if( "1".equals(v.getClcoSvcTyCd()) ) {
						v.setClcoNm(v.getClcoNm() + " (Biz)");
					} else if( "5".equals(v.getClcoSvcTyCd()) ) {
						v.setClcoNm(v.getClcoNm() + " (bizCenter)");
					} else if( "6".equals(v.getClcoSvcTyCd()) ) {
						v.setClcoNm(v.getClcoNm() + " (bizLite)");
					}
				});
		return result;
	}

	String getExamKdCd(String src) {

		if( src.equals("추가검사") || src.equals("가족추가검사") )
			return "1";

		if( !src.startsWith("선택검사") && !src.startsWith("가족선택검사") )
			return null;

		int ch = src.charAt(src.length() - 1);
		if( ch >= 'A' && ch <= 'J' )
			return String.valueOf((char)(ch - 'A' + '3'));
		if( ch >= 'a' && ch <= 'j' )
			return String.valueOf((char)(ch - 'a' + '3'));

		return null;
	}

	String fromExamKdCd(String src, String prefix) {

		if( src.equals("1") )
			return "추가검사";

		int ch = (int)src.charAt(0);
		return prefix + String.valueOf((char)(ch - '3' + 'A'));
	}

	/**
	 * 선예약 고객등록 일괄업로드 처리
	 */
	@SuppressWarnings("unchecked")
	@Transactional
	public BatchMemberAdvanceResvUploadResultModel uploadMember(List<RowInfo> converted, Integer clcoId, Integer yr, Integer cuTgtrUpdYn, Integer vcnTgtrUpdYn, Integer fmlyInitYn) {

		final int mngrId = BatchUploadUtils.getCurrentMngrId();

		// 헤더 체크
		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();
		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

		String missed = BatchUploadColumn.stream(MemberAdvanceResvColumn.class)
			.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
			.findFirst()
			.map(MemberAdvanceResvColumn::getTitle)
			.orElse(null);
		if( StringUtils.isNotEmpty(missed) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

		// 빈 ROW 삭제 및 값 설정
		List<BatchUploadAdvanceResvExcelModel> aempList = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
			.map(r->{
				BatchUploadAdvanceResvExcelModel c = BatchUploadUtils.map(
					(Map<String, Object>)r.getObject(), headerRow,
					BatchUploadColumn.table(MemberAdvanceResvColumn.class), BatchUploadAdvanceResvExcelModel.class);
				c.setClcoId(clcoId);
				c.setYr(yr);
				c.setAempBrdt(BatchUploadUtils.formattedBrdt(c.getAempBrdt()));
				c.setSpsrBrdt(BatchUploadUtils.formattedBrdt(c.getSpsrBrdt()));

				c.setSlctItmList(((Map<String, Object>)r.getObject()).entrySet().stream()
					.filter(e->getHeaderValue(e, headerRow).startsWith("선택검사") || getHeaderValue(e, headerRow).equals("추가검사"))
					.filter(e->getExamKdCd(getHeaderValue(e, headerRow)) != null)
					.filter(e->!ObjectUtils.isEmpty(e.getValue()))
					.flatMap(e->{

						return Arrays.asList(e.getValue().toString().split("\\,")).stream()
							.map(itm->{

								BatchUploadAdvanceResvSelectItemModel itemModel = new BatchUploadAdvanceResvSelectItemModel();
								itemModel.setClcoId(c.getClcoId());
								itemModel.setYr("" + c.getYr());
								itemModel.setExamItmNm(itm);
								itemModel.setExamKdCd(getExamKdCd(getHeaderValue(e, headerRow)));
								itemModel.setMngrId(mngrId);
								itemModel.setSelfYn(1);
								return itemModel;
							});
					})
					.collect(Collectors.toList()));

				c.setSpsrSlctItmList(((Map<String, Object>)r.getObject()).entrySet().stream()
					.filter(e->getHeaderValue(e, headerRow).startsWith("가족선택검사") || getHeaderValue(e, headerRow).equals("가족추가검사"))
					.filter(e->getExamKdCd(getHeaderValue(e, headerRow)) != null)
					.filter(e->!ObjectUtils.isEmpty(e.getValue()))
					.flatMap(e->{

						return Arrays.asList(e.getValue().toString().split("\\,")).stream()
							.map(itm->{

								BatchUploadAdvanceResvSelectItemModel itemModel = new BatchUploadAdvanceResvSelectItemModel();
								itemModel.setClcoId(c.getClcoId());
								itemModel.setYr("" + c.getYr());
								itemModel.setExamItmNm(itm);
								itemModel.setExamKdCd(getExamKdCd(getHeaderValue(e, headerRow)));
								itemModel.setMngrId(mngrId);
								itemModel.setSelfYn(0);
								return itemModel;
							});
					})
					.collect(Collectors.toList()));
				return c;
			})
			.filter(c->!isEmptyRow(c))
			.collect(Collectors.toList());

		// 검색조건 설정
		SearchMapContextHolder.set(UstraMapUtils.getMap(
			"clcoId", clcoId,
			"yr", yr,
			"mngrId", mngrId));

		// 지원 등급, 패키지, 사업장, 고객사 조회, 예약시간범위코드
		MemberGradeContextHolder.set(memRepository.getMemberGradeList(SearchMapContextHolder.get()));
		PackageContextHolder.set(memRepository.getPackageList(SearchMapContextHolder.get()));
		BusinessPlaceContextHolder.set(memRepository.getBsplList(SearchMapContextHolder.get()));
		ClientCompanyContextHolder.set(memRepository.getClcoBsc(SearchMapContextHolder.get()));
		ResvTmcRngContextHolder.set(commonCodeData.all().stream().filter(cd -> "TMC_RNG_CD".equals(cd.getGrpCd())).collect(Collectors.toList()));
		CheckupInstContextHolder.set(resvRepository.getCuiList(Stream.concat(aempList.stream()
				.map(aemp->aemp.getCuiNm()), aempList.stream()
				.map(aemp->aemp.getSpsrCuiNm()))
				.distinct()
				.collect(Collectors.toList())));

		// 업로드 초기화
		resvRepository.updateClcoAempAdreBlkRegTmpUploadYn(SearchMapContextHolder.get());

		// 신규 등록 대상 추출
		List<BatchMemberUploadAdvanceResvModel> forInsert = aempList.stream()
			.filter(c->StringUtils.isEmpty(c.getAempRegSeq()))
			.map(c->validateMember(BatchUploadUtils.map(c, BatchMemberUploadAdvanceResvModel.class)))
			.collect(Collectors.toList());

		// 업데이트 대상 추출
		List<BatchMemberUploadAdvanceResvModel> forUpdate = new ArrayList<>();
		List<BatchUploadAdvanceResvExcelModel> checkUpdate = aempList.stream()
			.filter(c->StringUtils.isNotEmpty(c.getAempRegSeq()))
			.collect(Collectors.toList());
		if( CollectionUtils.isNotEmpty(checkUpdate) ) {

			List<BatchMemberUploadAdvanceResvModel> checked = resvRepository.getClcoAempAdreBlkRegTmpForUpdate(UstraMapUtils.getMap(
				"clcoId", clcoId,
				"yr", yr,
				"mngrId", mngrId,
				"list", checkUpdate));
			forUpdate = checkUpdate.stream()
				.filter(c->checked.stream().anyMatch(ch->c.getAempRegSeq().equals("" + ch.getAempRegSeq())))
				.map(c->validateMember(BatchUploadUtils.map(c, BatchMemberUploadAdvanceResvModel.class)))
				.collect(Collectors.toList());

			forInsert.addAll(checkUpdate.stream()
				.filter(c->checked.stream().noneMatch(ch->c.getAempRegSeq().equals("" + ch.getAempRegSeq())))
				.map(c->validateMember(BatchUploadUtils.map(c, BatchMemberUploadAdvanceResvModel.class)))
				.collect(Collectors.toList()));
		}

		// 신규 등록
		int aempRegSeq = resvRepository.getAempAdreBlkRegTmpNextSeq(SearchMapContextHolder.get());
		for( int i=0; i<forInsert.size(); i++ ) {
			forInsert.get(i).setAempRegSeq(aempRegSeq++);
			forInsert.get(i).setMngrId(forInsert.get(i).getAdminUserMngrId());

			String tn1ResvDt = forInsert.get(i).getTn1ResvApplDt();
			if( StringUtils.isNotEmpty(tn1ResvDt) ) {
				tn1ResvDt = tn1ResvDt.substring(0, Math.min(10, tn1ResvDt.length()));
				forInsert.get(i).setTn1ResvApplDt(tn1ResvDt);
				forInsert.get(i).setTn2ResvApplDt(tn1ResvDt);
			}

			String spsrTn1ResvDt = forInsert.get(i).getTn1SpsrResvApplDt();
			if( StringUtils.isNotEmpty(spsrTn1ResvDt)) {
				spsrTn1ResvDt = spsrTn1ResvDt.substring(0, Math.min(10, spsrTn1ResvDt.length()));
				forInsert.get(i).setTn1SpsrResvApplDt(spsrTn1ResvDt);
				forInsert.get(i).setTn2SpsrResvApplDt(spsrTn1ResvDt);
			}

			int adreSlctItmSeq = 1;
			for( int j=0; j<forInsert.get(i).getSlctItmList().size(); j++ ) {

				forInsert.get(i).getSlctItmList().get(j).setAempRegSeq(forInsert.get(i).getAempRegSeq());
				forInsert.get(i).getSlctItmList().get(j).setAdreSlctItmSeq(adreSlctItmSeq++);
			}
			for( int j=0; j<forInsert.get(i).getSpsrSlctItmList().size(); j++ ) {

				forInsert.get(i).getSpsrSlctItmList().get(j).setAempRegSeq(forInsert.get(i).getAempRegSeq());
				forInsert.get(i).getSpsrSlctItmList().get(j).setAdreSlctItmSeq(adreSlctItmSeq++);
			}
		}

		batchExecutor.batchUpdate(
			"INSERT INTO MBR.T_CLCO_AEMP_ADRE_BLK_REG_TMP (\r\n" +
			"	  CLCO_ID\r\n" +
			"	, YR\r\n" +
			"	, AEMP_REG_SEQ\r\n" +
			"	, AEMP_NM\r\n" +
			"	, AEMP_CU_GRD_NM\r\n" +
			"	, AEMP_CU_GRD_ID\r\n" +
			"	, AEMP_VCN_GRD_NM\r\n" +
			"	, AEMP_ID\r\n" +
			"	, EXCU_YN\r\n" +
			"	, AEMP_BRDT\r\n" +
			"	, AEMP_SEX_CD\r\n" +
			"	, ENCM_DT\r\n" +
			"	, CUI_NM\r\n" +
			"	, PKG_NM\r\n" +
			"	, PKG_TY_NM\r\n" +
			"	, TN1_RESV_APPL_DT\r\n" +
			"	, TN1_RESV_TMC_RNG_VAL\r\n" +
			"	, TN2_RESV_APPL_DT\r\n" +
			"	, TN2_RESV_TMC_RNG_VAL\r\n" +
			"	, CORP_SPFN_VAL\r\n" +
			"	, NHIC_SUPT_TGT_YN\r\n" +
			"	, SPCU_TGT_YN\r\n" +
			"	, EXTR_MTTR_NM1\r\n" +
			"	, EXTR_MTTR_NM2\r\n" +
			"	, EML_ADR\r\n" +
			"	, MBL_NO\r\n" +
			"	, SPSR_NM\r\n" +
			"	, SPSR_CU_GRD_NM\r\n" +
			"	, SPSR_CU_GRD_ID\r\n" +
			"	, SPSR_VCN_GRD_NM\r\n" +
			"	, SPSR_BRDT\r\n" +
			"	, SPSR_SEX_CD\r\n" +
			"	, SPSR_CUI_NM\r\n" +
			"	, SPSR_PKG_TY_NM\r\n" +
			"	, TN1_SPSR_RESV_APPL_DT\r\n" +
			"	, TN1_SPSR_RESV_TMC_RNG_VAL\r\n" +
			"	, TN2_SPSR_RESV_APPL_DT\r\n" +
			"	, TN2_SPSR_RESV_TMC_RNG_VAL\r\n" +
			"	, SPSR_CORP_SPFN\r\n" +
			"	, SPSR_PKG_NM\r\n" +
			"	, BSPL_NM\r\n" +
			"	, BSPL_ID\r\n" +
			"	, DEPT_NM1\r\n" +
			"	, DEPT_NM2\r\n" +
			"	, DEPT_NM3\r\n" +
			"	, JBGD_NM\r\n" +
			"	, WRPL_TLNO\r\n" +
			"	, UPLD_ST_VAL\r\n" +
			"	, UPLD_ERR_VAL\r\n" +
			"	, ID_ENFC_UPD_YN\r\n" +
			"	, NM_ENFC_UPD_YN\r\n" +
			"	, BRDT_ENFC_UPD_YN\r\n" +
			"	, EML_ADR_ENFC_UPD_YN\r\n" +
			"	, MBL_NO_ENFC_UPD_YN\r\n" +
			"	, UPLD_YN\r\n" +
			"	, MNGR_ID\r\n" +
			"	, DEL_YN\r\n" +
			// rollback으로 인한 주석처리
			"	, ATHO_KVL\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			"	, REG_TY_VAL\r\n" +
			")\r\n" +
			"VALUES\r\n" +
			"(\r\n" +
			"	  #{clcoId}\r\n" +
			"	, #{yr}\r\n" +
			"	, #{aempRegSeq}\r\n" +
			"	, #{aempNm}\r\n" +
			"	, #{aempCuGrdNm}\r\n" +
			"	, #{aempCuGrdId}\r\n" +
			"	, #{aempVcnGrdNm}\r\n" +
			"	, #{aempId}\r\n" +
			"	, #{excuYn}\r\n" +
			"	, #{aempBrdt}\r\n" +
			"	, #{aempSexCd}\r\n" +
			"	, #{encmDt}\r\n" +
			"	, #{cuiNm}\r\n" +
			"	, #{pkgNm}\r\n" +
			"	, #{pkgTyNm}\r\n" +
			"	, #{tn1ResvApplDt}\r\n" +
			"	, #{tn1ResvTmcRngVal}\r\n" +
			"	, #{tn2ResvApplDt}\r\n" +
			"	, #{tn2ResvTmcRngVal}\r\n" +
			"	, #{corpSpfnVal}\r\n" +
			"	, #{nhicSuptTgtYn}\r\n" +
			"	, #{spcuTgtYn}\r\n" +
			"	, #{extrMttrNm1}\r\n" +
			"	, #{extrMttrNm2}\r\n" +
			"	, #{emlAdr}\r\n" +
			"	, #{mblNo}\r\n" +
			"	, #{spsrNm}\r\n" +
			"	, #{spsrCuGrdNm}\r\n" +
			"	, #{spsrCuGrdId}\r\n" +
			"	, #{spsrVcnGrdNm}\r\n" +
			"	, #{spsrBrdt}\r\n" +
			"	, #{spsrSexCd}\r\n" +
			"	, #{spsrCuiNm}\r\n" +
			"	, #{spsrPkgTyNm}\r\n" +
			"	, #{tn1SpsrResvApplDt}\r\n" +
			"	, #{tn1SpsrResvTmcRngVal}\r\n" +
			"	, #{tn2SpsrResvApplDt}\r\n" +
			"	, #{tn2SpsrResvTmcRngVal}\r\n" +
			"	, #{spsrCorpSpfn}\r\n" +
			"	, #{spsrPkgNm}\r\n" +
			"	, #{bsplNm}\r\n" +
			"	, #{bsplId}\r\n" +
			"	, #{deptNm1}\r\n" +
			"	, #{deptNm2}\r\n" +
			"	, #{deptNm3}\r\n" +
			"	, #{jbgdNm}\r\n" +
			"	, #{wrplTlno}\r\n" +
			"	, #{upldStVal}\r\n" +
			"	, #{upldErrVal}\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, 0\r\n" +
			"	, #{athoKvl}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, 1\r\n" +
			")\r\n", forInsert);

		// 업데이트
		forUpdate.forEach(c->{

			c.setMngrId(c.getAdminUserMngrId());

			int adreSlctItmSeq = 1;
			for( int j=0; j<c.getSlctItmList().size(); j++ ) {

				c.getSlctItmList().get(j).setAempRegSeq(c.getAempRegSeq());
				c.getSlctItmList().get(j).setAdreSlctItmSeq(adreSlctItmSeq++);
			}
			for( int j=0; j<c.getSpsrSlctItmList().size(); j++ ) {

				c.getSpsrSlctItmList().get(j).setAempRegSeq(c.getAempRegSeq());
				c.getSpsrSlctItmList().get(j).setAdreSlctItmSeq(adreSlctItmSeq++);
			}

			String tn1ResvDt = c.getTn1ResvApplDt();
			if( StringUtils.isNotEmpty(tn1ResvDt)) {
				tn1ResvDt = tn1ResvDt.substring(0, Math.min(10, tn1ResvDt.length()));
				c.setTn1ResvApplDt(tn1ResvDt);
				c.setTn2ResvApplDt(tn1ResvDt);
			}

			String spsrTn1ResvDt = c.getTn1SpsrResvApplDt();
			if( StringUtils.isNotEmpty(spsrTn1ResvDt)) {
				spsrTn1ResvDt = spsrTn1ResvDt.substring(0, Math.min(10, spsrTn1ResvDt.length()));
				c.setTn1SpsrResvApplDt(spsrTn1ResvDt);
				c.setTn2SpsrResvApplDt(spsrTn1ResvDt);
			}

		});
		batchExecutor.batchUpdate(
			"UPDATE MBR.T_CLCO_AEMP_ADRE_BLK_REG_TMP\r\n" +
			"SET	  CLCO_ID = #{clcoId}\r\n" +
			"	, YR = #{yr}\r\n" +
			"	, AEMP_NM = #{aempNm}\r\n" +
			"	, AEMP_CU_GRD_NM = #{aempCuGrdNm}\r\n" +
			"	, AEMP_CU_GRD_ID = #{aempCuGrdId}\r\n" +
			"	, AEMP_VCN_GRD_NM = #{aempVcnGrdNm}\r\n" +
			"	, AEMP_ID = #{aempId}\r\n" +
			"	, EXCU_YN = #{excuYn}\r\n" +
			"	, AEMP_BRDT = #{aempBrdt}\r\n" +
			"	, AEMP_SEX_CD = #{aempSexCd}\r\n" +
			"	, ENCM_DT = #{encmDt}\r\n" +
			"	, CUI_NM = #{cuiNm}\r\n" +
			"	, PKG_NM = #{pkgNm}\r\n" +
			"	, PKG_TY_NM = #{pkgTyNm}\r\n" +
			"	, TN1_RESV_APPL_DT = #{tn1ResvApplDt}\r\n" +
			"	, TN1_RESV_TMC_RNG_VAL = #{tn1ResvTmcRngVal}\r\n" +
			"	, TN2_RESV_APPL_DT = #{tn2ResvApplDt}\r\n" +
			"	, TN2_RESV_TMC_RNG_VAL = #{tn2ResvTmcRngVal}\r\n" +
			"	, CORP_SPFN_VAL = #{corpSpfnVal}\r\n" +
			"	, NHIC_SUPT_TGT_YN = #{nhicSuptTgtYn}\r\n" +
			"	, SPCU_TGT_YN = #{spcuTgtYn}\r\n" +
			"	, EXTR_MTTR_NM1 = #{extrMttrNm1}\r\n" +
			"	, EXTR_MTTR_NM2 = #{extrMttrNm2}\r\n" +
			"	, EML_ADR = #{emlAdr}\r\n" +
			"	, MBL_NO = #{mblNo}\r\n" +
			"	, SPSR_NM = #{spsrNm}\r\n" +
			"	, SPSR_CU_GRD_NM = #{spsrCuGrdNm}\r\n" +
			"	, SPSR_CU_GRD_ID = #{spsrCuGrdId}\r\n" +
			"	, SPSR_VCN_GRD_NM = #{spsrVcnGrdNm}\r\n" +
			"	, SPSR_BRDT = #{spsrBrdt}\r\n" +
			"	, SPSR_SEX_CD = #{spsrSexCd}\r\n" +
			"	, SPSR_CUI_NM = #{spsrCuiNm}\r\n" +
			"	, SPSR_PKG_TY_NM = #{spsrPkgTyNm}\r\n" +
			"	, TN1_SPSR_RESV_APPL_DT = #{tn1SpsrResvApplDt}\r\n" +
			"	, TN1_SPSR_RESV_TMC_RNG_VAL = #{tn1SpsrResvTmcRngVal}\r\n" +
			"	, TN2_SPSR_RESV_APPL_DT = #{tn2SpsrResvApplDt}\r\n" +
			"	, TN2_SPSR_RESV_TMC_RNG_VAL = #{tn2SpsrResvTmcRngVal}\r\n" +
			"	, SPSR_CORP_SPFN = #{spsrCorpSpfn}\r\n" +
			"	, SPSR_PKG_NM = #{spsrPkgNm}\r\n" +
			"	, BSPL_NM = #{bsplNm}\r\n" +
			"	, BSPL_ID = #{bsplId}\r\n" +
			"	, DEPT_NM1 = #{deptNm1}\r\n" +
			"	, DEPT_NM2 = #{deptNm2}\r\n" +
			"	, DEPT_NM3 = #{deptNm3}\r\n" +
			"	, JBGD_NM = #{jbgdNm}\r\n" +
			"	, WRPL_TLNO = #{wrplTlno}\r\n" +
			"	, UPLD_YN = 1\r\n" +
			"	, ATHO_KVL = #{athoKvl}\r\n" +
			"	, UPLD_ST_VAL = #{upldStVal}\r\n" +
			"	, UPLD_ERR_VAL = #{upldErrVal}\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPDR_ID = #{mngrId}\r\n" +
			"	, REG_TY_VAL = 1\r\n" +
			"WHERE 1=1\r\n" +
			"	AND YR = #{yr}\r\n" +
			"	AND CLCO_ID = #{clcoId}\r\n" +
			"	AND AEMP_REG_SEQ = #{aempRegSeq}", forUpdate);

		List<BatchUploadAdvanceResvSelectItemModel> slctItmList = Stream.concat(
			forInsert.stream()
			.flatMap(i->i.getSlctItmList().stream()),
			forUpdate.stream()
			.flatMap(u->u.getSlctItmList().stream()))
			.collect(Collectors.toList());

		slctItmList.addAll(Stream.concat(
				forInsert.stream()
						.flatMap(i->i.getSpsrSlctItmList().stream()),
				forUpdate.stream()
						.flatMap(u->u.getSpsrSlctItmList().stream()))
				.collect(Collectors.toList()));

		// 선택항목 삭제처리
		batchExecutor.batchUpdate(
			"DELETE\r\n" +
			"FROM MBR.T_CLCO_AEMP_ADRE_SLCT_ITM_DTL\r\n" +
			"WHERE 1=1\r\n" +
			"	AND CLCO_ID = #{clcoId}\r\n" +
			"	AND YR = #{yr}\r\n" +
			"	AND AEMP_REG_SEQ = #{aempRegSeq}\r\n", forUpdate);

		// 선택항목 임시등록
		batchExecutor.batchUpdate(
			"INSERT INTO MBR.T_CLCO_AEMP_ADRE_SLCT_ITM_DTL (\r\n" +
			"	  CLCO_ID\r\n" +
			"	, YR\r\n" +
			"	, AEMP_REG_SEQ\r\n" +
			"	, ADRE_SLCT_ITM_SEQ\r\n" +
			"	, EXAM_ITM_NM\r\n" +
			"	, PKG_TY_ITM_ID\r\n" +
			"	, SELF_YN\r\n" +
			"	, EXAM_KD_CD\r\n" +
			"	, SLCT_ITM_ST_VAL\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			")\r\n" +
			"VALUES(\r\n" +
			"	  #{clcoId}\r\n" +
			"	, #{yr}\r\n" +
			"	, #{aempRegSeq}\r\n" +
			"	, #{adreSlctItmSeq}\r\n" +
			"	, #{examItmNm}\r\n" +
			"	, 0\r\n" +
			"	, #{selfYn}\r\n" +
			"	, #{examKdCd}\r\n" +
			"	, 0\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			")\r\n", slctItmList);

		// 엑셀 내 중복 체크
		resvRepository.updateClcoAempAdreBlkRegTmpRnk(SearchMapContextHolder.get());
		resvRepository.updateClcoAempAdreBlkRegTmpValidate(SearchMapContextHolder.get());

		// 현재 DB 비교
		resvRepository.updateClcoAempAdreBlkRegTmpValidateStep2_1(SearchMapContextHolder.get());
		resvRepository.updateClcoAempAdreBlkRegTmpValidateStep2_2(SearchMapContextHolder.get());
		if( isBizCenter() )
			resvRepository.updateClcoAempAdreBlkRegTmpValidateStep2_3(SearchMapContextHolder.get());

		// 검진 예약정보가 존재하는 기존 고객
		if( cuTgtrUpdYn == 1 )
			resvRepository.updateClcoAempAdreBlkRegTmpValidateStep4(SearchMapContextHolder.get());

		// 양도금액이 존재하는 고객
		resvRepository.updateClcoAempAdreBlkRegTmpValidateStep5(SearchMapContextHolder.get());

		// 백신 예약정보가 존재하는 기존 고객
		if( vcnTgtrUpdYn == 1 )
			resvRepository.updateClcoAempAdreBlkRegTmpValidateStep6(SearchMapContextHolder.get());

		// 가족 초기화 시 가족 예약 여부 체크
		if( (cuTgtrUpdYn == 0 || vcnTgtrUpdYn == 0) && fmlyInitYn == 1 )
			resvRepository.updateClcoAempAdreBlkRegTmpValidateStep7(SearchMapContextHolder.get());

		// 검진기관, 패키지항목 유효성 체크
		resvRepository.updateClcoAempAdreBlkRegTmpPkgInf(SearchMapContextHolder.get()); // 프론트 로직 적용
		resvRepository.updateClcoAempAdreBlkRegTmpResvInf(SearchMapContextHolder.get());
		resvRepository.updateClcoAempAdreBlkRegTmpValidateResv1(SearchMapContextHolder.get());

		// 배우자 검진기관, 패키지항목 유효성 체크
		resvRepository.updateClcoAempAdreBlkRegTmpSpsrPkgInf(SearchMapContextHolder.get()); // 프론트 로직 적용
		resvRepository.updateClcoAempAdreBlkRegTmpSpsrResvInf(SearchMapContextHolder.get());
		resvRepository.updateClcoAempAdreBlkRegTmpValidateSpsrResv1(SearchMapContextHolder.get());

		// 검사항목 유효성 체크
		resvRepository.updateClcoAempAdreBlkRegTmpItemInf(SearchMapContextHolder.get());
		resvRepository.updateClcoAempAdreBlkRegTmpItemInfWithoutPkgTy(SearchMapContextHolder.get());
		resvRepository.updateClcoAempAdreBlkRegTmpValidateItem1(SearchMapContextHolder.get());
		resvRepository.updateClcoAempAdreBlkRegTmpValidateItem2(SearchMapContextHolder.get());

		return getResult(BatchMemberUploadResultRequestModel.builder()
			.clcoId(clcoId)
			.yr(yr)
			.mngrId(mngrId)
			.build());
	}

	private String getHeaderValue(Entry<String, Object> e, Map<String, Object> headerRow) {

		String key = e.getKey().toString();
		return headerRow.containsKey(key) ? Optional.ofNullable(headerRow.get(key)).map(Object::toString).orElse("") : "";
	}

	boolean isBizCenter() {

		String clcoSvcTyCd = ClientCompanyContextHolder.get().getClcoSvcTyCd();
		return "5".equals(clcoSvcTyCd) || "7".equals(clcoSvcTyCd);
	}

	boolean isBizLite() {

		String clcoSvcTyCd = ClientCompanyContextHolder.get().getClcoSvcTyCd();
		return "6".equals(clcoSvcTyCd) || "8".equals(clcoSvcTyCd);
	}

	boolean isSmartBiz() {

		String clcoSvcTyCd = ClientCompanyContextHolder.get().getClcoSvcTyCd();
		return "1".equals(clcoSvcTyCd);
	}

	String getBrdtForPwd(String brdt) {

		if( org.apache.commons.lang3.StringUtils.isEmpty(brdt) )
			return null;

		brdt = brdt.replace("-", "");
		return brdt.length() == 8 ? brdt.substring(2) : brdt;
	}

	public BatchMemberUploadAdvanceResvModel validateMember(BatchMemberUploadAdvanceResvModel src) {

		boolean bizCenter = isBizCenter();
		boolean bizLite = isBizLite();
		boolean smartBiz = isSmartBiz();
		//boolean bizCenterSkip = bizCenter && checkSkip(src);

		// 오류 초기화
		src.setUpldStVal(0);
		src.setUpldErrVal("");

		// 전화번호 형식 변경
		src.setMblNo(BatchUploadUtils.makePhone(src.getMblNo()));
		src.setHsTlno(BatchUploadUtils.makePhone(src.getHsTlno()));
		src.setWrplTlno(BatchUploadUtils.makePhone(src.getWrplTlno()));

		// 생년월일, 성별 체크
		boolean validBrdt = BatchUploadUtils.checkBrdt(src.getAempBrdt());
		checkMemberError(src, validBrdt, BatchMemberUploadError.INVALID_INFORMATION, "생년월일");
		if( Optional.ofNullable(src.getAempBrdt()).map(String::length).orElse(0) > 10 ) {

			src.setAempSexCd(src.getAempBrdt().substring(10));
			src.setAempBrdt(src.getAempBrdt().substring(0, 10));
		}

		if( StringUtils.isNotEmpty(src.getSpsrBrdt()) ) {

			boolean validSpsrBrdt = BatchUploadUtils.checkBrdt(src.getSpsrBrdt());
			checkMemberError(src, validSpsrBrdt, BatchMemberUploadError.INVALID_INFORMATION, "배우자생년월일");
			if( Optional.ofNullable(src.getSpsrBrdt()).map(String::length).orElse(0) > 10 ) {

				src.setSpsrSexCd(src.getSpsrBrdt().substring(10));
				src.setSpsrBrdt(src.getSpsrBrdt().substring(0, 10));
			}
		}

		checkMemberError(src, StringUtils.isNotEmpty(src.getAempNm()), BatchMemberUploadError.MISSING_INFORMATION, "이름");

		// 검진 등급 백신 등급 모두 없는 경우
		checkMemberError(src, StringUtils.isNotEmpty(src.getAempCuGrdNm()) ||
			StringUtils.isNotEmpty(src.getAempVcnGrdNm()), BatchMemberUploadError.MISSING_GRADE_INFORMATION);

		// 본인 검진 등급
		boolean noCheckup = StringUtils.isEmpty(src.getAempCuGrdNm());
		src.setAempCuGrdNm(noCheckup ? MemberGradeContextHolder.getDefault(true, true) : src.getAempCuGrdNm());
		checkMemberError(src, BatchUploadUtils.strIn(src.getAempCuGrdNm(), MemberGradeContextHolder.get().stream()
			.filter(g->StringUtils.isEmpty(g.getSuptTgtDvCd()) || "20".equals(g.getSuptTgtDvCd()))
			.filter(g->g.getSelfYn() == 1)
			.map(g->g.getGrdNm())
			.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "등급");
		src.setAempCuGrdId(MemberGradeContextHolder.get().stream()
			.filter(g->g.getGrdNm().equals(src.getAempCuGrdNm()))
			.findFirst()
			.map(SupportGradeModel::getMbrGrdId)
			.orElse(null));

		// 본인 백신 등급
		boolean noVaccine = StringUtils.isEmpty(src.getAempVcnGrdNm());
		src.setAempVcnGrdNm(noVaccine ? MemberGradeContextHolder.getDefault(true, false) : src.getAempVcnGrdNm());
		checkMemberError(src, BatchUploadUtils.strIn(src.getAempVcnGrdNm(), MemberGradeContextHolder.get().stream()
			.filter(g->"10".equals(g.getSuptTgtDvCd()))
			.filter(g->g.getSelfYn() == 1)
			.map(g->g.getGrdNm())
			.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "백신등급");
		src.setAempVcnGrdId(MemberGradeContextHolder.get().stream()
			.filter(g->g.getGrdNm().equals(src.getAempVcnGrdNm()))
			.findFirst()
			.map(SupportGradeModel::getMbrGrdId)
			.orElse(null));

		if( !smartBiz ) {

			if( StringUtils.isEmpty(src.getPkgNm()) )
				src.setPkgNm("검진이지패키지");
			if( StringUtils.isNotEmpty(src.getSpsrCorpSpfn()) && StringUtils.isEmpty(src.getSpsrPkgNm()) )
				src.setSpsrPkgNm("검진이지패키지");
		}


		boolean noCorpSupt = !ObjectUtils.isEmpty(src.getAempCuGrdId()) &&
			(MemberGradeContextHolder.get(src.getAempCuGrdId()).getCorpSuptYn() == 0 ||
			"특검만(지원)".equals(src.getAempCuGrdNm()));

		checkMemberError(src, noCorpSupt || StringUtils.isNotEmpty(src.getCorpSpfnVal()), BatchMemberUploadError.MISSING_SUPPORT_INFO);
		if( !noCorpSupt && StringUtils.isNotEmpty(src.getCorpSpfnVal()) )
			checkMemberError(src, BatchUploadUtils.numIn(src.getCorpSpfnVal(), 1000, Integer.MAX_VALUE), BatchMemberUploadError.INVALID_INFORMATION, "지원금");

		if( ObjectUtils.isEmpty(src.getExcuYn()) )
			src.setExcuYn(0);
		if( ObjectUtils.isEmpty(src.getNhicSuptTgtYn()) )
			src.setNhicSuptTgtYn(0);
		if( ObjectUtils.isEmpty(src.getSpcuTgtYn()) )
			src.setSpcuTgtYn(0);
		if( ObjectUtils.isEmpty(src.getBsplNm()) )
			src.setBsplNm(BusinessPlaceContextHolder.getDefault());
		checkMemberError(src, !ObjectUtils.isEmpty(src.getBsplNm()), BatchMemberUploadError.MISSING_INFORMATION, "사업장");

		if( !bizCenter ) {

			checkMemberError(src, StringUtils.isNotEmpty(src.getAempBrdt()), BatchMemberUploadError.MISSING_INFORMATION, "생년월일");

			if( !bizCenter && !bizLite )
				checkMemberError(src, StringUtils.isNotEmpty(src.getAempId()), BatchMemberUploadError.MISSING_INFORMATION, "사번");

			checkMemberError(src, !ObjectUtils.isEmpty(src.getNhicSuptTgtYn()), BatchMemberUploadError.MISSING_INFORMATION, "공단지원여부");
			checkMemberError(src, !ObjectUtils.isEmpty(src.getSpcuTgtYn()), BatchMemberUploadError.MISSING_INFORMATION, "특수지원여부");
			checkMemberError(src, StringUtils.isNotEmpty(src.getMblNo()) ||
				StringUtils.isNotEmpty(src.getEmlAdr()), BatchMemberUploadError.MISSING_MOBILE_AND_EMAIL);
		}

		if( "7".equals(ClientCompanyContextHolder.get().getClcoSvcTyCd()) ) {
			src.setAthoKvl(NcuEncUtils.encPwd(getBrdtForPwd(src.getAempBrdt())));
		}

		// 부서 lv validation
		if( ObjectUtils.isEmpty(src.getDeptNm1()) )
			checkMemberError(src, ObjectUtils.isEmpty(src.getDeptNm1()), BatchMemberUploadError.INVALID_INFORMATION, "부서");
		if( ObjectUtils.isEmpty(src.getDeptNm2()) )
			checkMemberError(src, ObjectUtils.isEmpty(src.getDeptNm3()), BatchMemberUploadError.INVALID_INFORMATION, "부서2");

		// 선예약 정보 validation
		checkMemberError(src, ObjectUtils.isEmpty(src.getTn1ResvApplDt()) || BatchUploadUtils.checkDt(src.getTn1ResvApplDt()),
				BatchMemberUploadError.INVALID_INFORMATION, "예약신청일");
		String dtlCd = ResvTmcRngContextHolder.getDtlCd(src.getTn1ResvTmcRngVal());
		checkMemberError(src, ObjectUtils.isEmpty(src.getTn1ResvApplDt()) || StringUtils.isNotEmpty(dtlCd) &&
				CheckupInstContextHolder.checkTmcRngCd(src.getCuiNm(), dtlCd), BatchMemberUploadError.INVALID_INFORMATION, "예약신청시간");
		checkMemberError(src, ObjectUtils.isEmpty(src.getPkgTyNm()) || !ObjectUtils.isEmpty(src.getCuiNm()),
				BatchMemberUploadError.MISSING_INFORMATION, "검진기관명");

		if( StringUtils.isNotEmpty(src.getSpsrCuGrdNm()) || StringUtils.isNotEmpty(src.getSpsrVcnGrdNm()) ) {

			// 배우자 검진 등급
			src.setSpsrCuGrdNm(noCheckup || StringUtils.isEmpty(src.getSpsrCuGrdNm()) ?
														MemberGradeContextHolder.getDefault(false, true) : src.getSpsrCuGrdNm());
			checkMemberError(src, BatchUploadUtils.strIn(src.getSpsrCuGrdNm(), MemberGradeContextHolder.get().stream()
				.filter(g->StringUtils.isEmpty(g.getSuptTgtDvCd()) || "20".equals(g.getSuptTgtDvCd()))
				.filter(g->g.getSelfYn() == 0)
				.map(g->g.getGrdNm())
				.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "배우자 등급");
			src.setSpsrCuGrdId(MemberGradeContextHolder.get().stream()
				.filter(g->g.getGrdNm().equals(src.getSpsrCuGrdNm()))
				.findFirst()
				.map(SupportGradeModel::getMbrGrdId)
				.orElse(null));

			// 배우자 백신 등급
			src.setSpsrVcnGrdNm(noVaccine || StringUtils.isEmpty(src.getSpsrVcnGrdNm()) ?
														MemberGradeContextHolder.getDefault(false,  false) : src.getSpsrVcnGrdNm());
			checkMemberError(src, BatchUploadUtils.strIn(src.getSpsrVcnGrdNm(), MemberGradeContextHolder.get().stream()
				.filter(g->"10".equals(g.getSuptTgtDvCd()))
				.filter(g->g.getSelfYn() == 0)
				.map(g->g.getGrdNm())
				.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "배우자 백신등급");
			src.setSpsrVcnGrdId(MemberGradeContextHolder.get().stream()
				.filter(g->g.getGrdNm().equals(src.getSpsrVcnGrdNm()))
				.findFirst()
				.map(SupportGradeModel::getMbrGrdId)
				.orElse(null));
		}

		checkMemberError(src, ObjectUtils.isEmpty(src.getSpsrCuGrdId()) ||
			(MemberGradeContextHolder.get(src.getSpsrCuGrdId()).getCorpSuptYn() == 0 ||
			StringUtils.isNotEmpty(src.getSpsrCorpSpfn())), BatchMemberUploadError.MISSING_FAMILY_SUPPORT_INFO);

		checkMemberError(src, StringUtils.isEmpty(src.getSpsrCorpSpfn()) ||	BatchUploadUtils.numIn(src.getSpsrCorpSpfn(), 1000, Integer.MAX_VALUE),
				BatchMemberUploadError.INVALID_INFORMATION, "배우자 지원금");

		// 배우자 선예약 정보 validation
		checkMemberError(src, ObjectUtils.isEmpty(src.getTn1SpsrResvApplDt()) || BatchUploadUtils.checkDt(src.getTn1SpsrResvApplDt()),
				BatchMemberUploadError.INVALID_INFORMATION, "배우자 예약신청일");
		String spsrDtlCd = ResvTmcRngContextHolder.getDtlCd(src.getTn1SpsrResvTmcRngVal());
		checkMemberError(src, ObjectUtils.isEmpty(src.getTn1SpsrResvApplDt()) || StringUtils.isNotEmpty(spsrDtlCd) &&
				CheckupInstContextHolder.checkTmcRngCd(src.getCuiNm(), spsrDtlCd), BatchMemberUploadError.INVALID_INFORMATION, "배우자 예약신청시간");
		checkMemberError(src, ObjectUtils.isEmpty(src.getSpsrPkgTyNm()) || !ObjectUtils.isEmpty(src.getSpsrCuiNm()),
				BatchMemberUploadError.MISSING_INFORMATION, "배우자 검진기관명");

		checkMemberError(src, BatchUploadUtils.isPhone(src.getMblNo()), BatchMemberUploadError.INVALID_INFORMATION, "핸드폰번호");
		checkMemberError(src, BatchUploadUtils.isPhone(src.getHsTlno()), BatchMemberUploadError.INVALID_INFORMATION, "집전화번호");
		checkMemberError(src, BatchUploadUtils.isPhone(src.getWrplTlno()), BatchMemberUploadError.INVALID_INFORMATION, "회사전화번호");

		checkMemberError(src, StringUtils.isEmpty(src.getPkgNm()) ||
			!ObjectUtils.isEmpty(PackageContextHolder.get(src.getPkgNm())), BatchMemberUploadError.INVALID_AEMP_PACKAGE);
		checkMemberError(src, StringUtils.isEmpty(src.getSpsrPkgNm()) ||
			!ObjectUtils.isEmpty(PackageContextHolder.get(src.getSpsrPkgNm())), BatchMemberUploadError.INVALID_FAMILY_PACKAGE);

		// 사업장 매핑
		if( StringUtils.isEmpty(src.getBsplNm()) && BusinessPlaceContextHolder.get().size() == 1 )
			src.setBsplNm(BusinessPlaceContextHolder.get().get(0).getBsplNm());
		src.setBsplId(Optional.ofNullable(BusinessPlaceContextHolder.get(src.getBsplNm())).map(BsplModel::getBsplId).orElse(null));
		checkMemberError(src, StringUtils.isEmpty(src.getBsplNm()) ||
			!ObjectUtils.isEmpty(src.getBsplId()), BatchMemberUploadError.INVALID_INFORMATION, "사업장 정보");

		return src;
	}

	private boolean checkSkip(BatchMemberUploadAdvanceResvModel src) {

		return StringUtils.isNotEmpty(src.getAempNm()) &&
			StringUtils.isEmpty(src.getAempId()) &&
			StringUtils.isEmpty(src.getAempBrdt()) &&
			StringUtils.isEmpty(src.getEmlAdr()) &&
			StringUtils.isEmpty(src.getMblNo());
	}


	List<BatchAdvanceResvExcelModel> errorExcelMsg(List<BatchAdvanceResvExcelModel> errList) {

		errList.forEach(e->{

			String errMsg = e.getUpldErrVal();
			if( StringUtils.isEmpty(errMsg) )
				return;
			errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
			e.setUpldErrVal(errMsg.replace("|", "\r\n"));
		});
		return errList;
	}

	List<BatchMemberUploadAdvanceResvModel> errorMsg(List<BatchMemberUploadAdvanceResvModel> errList) {

		errList.forEach(e->{

			String errMsg = e.getUpldErrVal();
			if( StringUtils.isEmpty(errMsg) )
				return;
			errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
			e.setUpldErrVal(errMsg.replace("|", "\r\n"));
		});

		if( CollectionUtils.isEmpty(errList) )
			return errList;
		errList.get(0).setSlctItmHdrList(errList.stream()
			.flatMap(e->{

				return Stream.concat(Optional.ofNullable(e.getSlctItmList()).orElse(new ArrayList<>()).stream()
					.map(itm->fromExamKdCd(itm.getExamKdCd(), "선택검사")), Optional.ofNullable(e.getSpsrSlctItmList()).orElse(new ArrayList<>()).stream()
					.map(itm->fromExamKdCd(itm.getExamKdCd(), "가족선택검사")));
			})
			.distinct()
			.collect(Collectors.toList()));
		return errList;
	}

	/**
	 * 처리내용 : 업로드 결과 조회
	 *
	 * @param in
	 * @return
	 */
	public BatchMemberAdvanceResvUploadResultModel getResult(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		BatchMemberAdvanceResvUploadResultModel result = resvRepository.getBatchMemberAdvanceResvUploadResult(in);
		result.setErrorCnt(result.getDupCnt() + result.getMissingCnt() + result.getEtcCnt());
		return result;
	}

	public List<BatchMemberUploadAdvanceResvModel> getErrorList(BatchMemberUploadErrorRequestModel in) {
		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		if( in.getState() == 5 )
			return errorMsg(resvRepository.getClcoAempBlkRegTmpErrorDuplicated(in, in.toPaginationRequest()));
		return errorMsg(resvRepository.getClcoAempBlkRegTmpError(in, in.toPaginationRequest()));
	}

	/**
	 *
	 * 처리내용 : 일괄업로드 작업 내역 초기화
	 *
	 * @param in
	 */
	@Transactional
	public void init(BatchMemberUploadInitRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		resvRepository.updateClcoAempBlkRegTmpInit(in);
	}

	/**
	 * 처리내용 : 업로드 결과 삭제
	 *
	 * @param in
	 * @return
	 */
	@Transactional
	public void remove(List<BatchMemberUploadAdvanceResvModel> in) {

		resvRepository.updateClcoAempBlkRegTmpRemove(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in));
	}

	@Transactional
	public void removeAll(CustomerExcelDownModel in) {

		in.setMngrId("" + BatchUploadUtils.getCurrentMngrId());
		resvRepository.updateClcoAempBlkRegTmpRemoveAll(in);
	}

	CapaErrorCode checkCapaError(Integer cuiId, Integer clcoId, Integer yr, Integer aempRegSeq, Integer pkgTyId, String resvApplDt, String resvApplTmc, List<BatchUploadAdvanceResvSelectItemModel> itmList,
						   Map<String, List<CapaVo>> capaCache, Map<Integer, List<Map<String, Object>>> pkgTyCache,
						   List<UstraCodeModel> tmcRngCds, List<ResvInfoModel> prevResv) {

		String yearMonth = resvApplDt.substring(0, 7);
		String cuiCapaDt = resvApplDt;

		List<CapaVo> capaList;
		String capaKey = "" + cuiId + "_" + resvApplDt;

		if( capaCache.containsKey(capaKey) ) {
			capaList = capaCache.get(capaKey);
		}
		else {

			capaList = checkupInstScheduleService.getCapaList(yearMonth, cuiId, clcoId, 0, cuiCapaDt, 0);

			// 차감로직을 적용하기 전까지는 cache를 사용할 수 없다.
			capaCache.put(capaKey, capaList);
		}

		List<Map<String, Object>> basicItems = new ArrayList<>();
		if( pkgTyCache.containsKey(pkgTyId) )
			basicItems = pkgTyCache.get(pkgTyId);
		else {

			basicItems = registRepository.selectPkgTyItmDtlBasic(pkgTyId);
			pkgTyCache.put(pkgTyId, basicItems);
		}

		// 묶음 검사로 인해 다시 한번 select 필요
		List<BatchUploadAdvanceResvSelectItemModel> slctItmIds = CollectionUtils.isEmpty(itmList) ? new ArrayList<>() : registRepository.selectPkgTyItmDtlItmIds(UstraMapUtils.getMap(
				"clcoId", clcoId,
				"yr", yr,
				"aempRegSeq", aempRegSeq,
				"list", itmList));

		String tmcRngCd = tmcRngCds.stream().filter(cd->resvApplTmc.equals(cd.getCdNm())).findFirst().map(UstraCodeModel::getEtc1).orElse("");


		boolean updatedResv = CollectionUtils.isNotEmpty(prevResv) && prevResv.get(0).getResvApplDt().equals(resvApplDt) && prevResv.get(0).getResvTmcRngCd().equals(tmcRngCd);

		List<String> capaTypeCds = new ArrayList<>();
		if( !updatedResv ) {
			capaTypeCds.add(CapaTyCd.CAPA_TY_CD_09);
			if ("1".equals(basicItems.get(0).get("CU_DV_CD")))
				capaTypeCds.add(CapaTyCd.CAPA_TY_CD_19);
		}

		List<Pair<Integer, String>> itmIds = Stream.concat(basicItems.stream()
						.filter(m->!updatedResv)
						.map(m->Pair.of(((BigDecimal)m.get("ITM_ID")).intValue(), m.get("EXAM_ITM_NM").toString())), slctItmIds.stream()
						.filter(s->!updatedResv || CollectionUtils.isEmpty(prevResv) || prevResv.stream().noneMatch(itm->itm.getItmId().equals(s.getItmId())))
						.map(s->Pair.of(s.getItmId(), s.getExamItmNm())))
						.collect(Collectors.groupingBy(Pair::getKey))
				.entrySet().stream()
				.map(e->Pair.of(e.getKey(), e.getValue().get(0).getRight()))
				.collect(Collectors.toList());

		List<CapaVo> available = checkupInstScheduleService.getAvailableCapacityList(capaList, itmIds.stream().map(p->p.getKey()).collect(Collectors.toList()), capaTypeCds);

		// capa check success
		if( available.stream().filter(capa->capa.getViewDate().equals(cuiCapaDt)).filter(capa->"12".equals(tmcRngCd) ? capa.getCapaAm() > 0 : capa.getCapaPm() > 0).count() > 0 ) {

			final List<String> capaTyCdList = capaTypeCds.stream().map(each -> CapaTyCd.getBaseCapaTyCd(each)).collect(Collectors.toList());

		   	capaList.stream()
					.filter(each->{
						if (capaTyCdList.contains(CapaTyCd.getBaseCapaTyCd(each.getCapaTyCd()))) {
							return true;
						}
						if (itmIds.contains(each.getItmId())) {
							return true;
						}
						return false;
					})
					.forEach(each->{
						if( "12".equals(tmcRngCd) )
							each.setCapaAm(Math.max(0, each.getCapaAm() - 1));
						else
							each.setCapaPm(Math.max(0, each.getCapaPm() - 1));
					});

			return CapaErrorCode.NORMAL;
		}

		if( LocalDate.parse(cuiCapaDt).isBefore(LocalDate.now()) ) {

			return CapaErrorCode.PAST;
		}

		if( available.stream().anyMatch(each->Arrays.asList("1", "96", "98").contains(each.getCapaTyCd()))) {

			return CapaErrorCode.HOLIDAY;
		}

		String exam = itmIds.stream()
				.filter(itm->itm.getLeft() != 0)
				.filter(itm->BatchCapaUtils.isClose(capaList, itm.getLeft(), tmcRngCd))
				.findFirst()
				.map(Pair::getValue)
				.orElse("");

		boolean basic = capaTypeCds.stream()
				.anyMatch(tp->BatchCapaUtils.isClose(capaList, tp, tmcRngCd));

		CapaErrorCode result = CapaErrorCode.BASIC;
		if( StringUtils.isNotEmpty(exam) && basic ) {

			result = CapaErrorCode.BOTH;
		}
		else if( StringUtils.isNotEmpty(exam) ) {

			result = CapaErrorCode.ITEM;
		}

		result.setItemNm(exam);
		return result;
	}

	/**
	 *
	 * 처리내용 : 일괄업로드 등록
	 *
	 * @param in
	 * @throws IOException
	 */

	@Transactional
	public void regist(BatchMemberUploadRegistRequestModel in) {

		Map<String, Object> params = UstraMapUtils.getMap(
			"clcoId", in.getClcoId(),
			"yr", in.getYr(),
			"managerId", BatchUploadUtils.getCurrentMngrId(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"regTyVal", "1",
			"cuTgtrUpdYn", in.isCuTgtrUpdYn() ? 1 : 0,
			"vcnTgtrUpdYn", in.isVcnTgtrUpdYn() ? 1 : 0,
			"spcuMttr1UpdYn", in.isSpcuMttr1UpdYn() ? 1 : 0,
			"spcuMttr2UpdYn", in.isSpcuMttr2UpdYn() ? 1: 0,
			"fmlyInitYn", in.isFmlyInitYn() ? 1 : 0);

		int targetCnt = registRepository.updateClcoAempBlkRegTmpRegistTypeForAdre(params);

		// 건수 체크 후 특정 카운트 이상이면 배치 작업 처리
		if( targetCnt > 999 ) {

			registRepository.updateClcoAempBlkRegTmpRegistWithBatch(params);
			return;
		}

		// 케파 체크 미 필요 대상자 일괄 처리
		registProcess(in, params);

		// 케파 체크 필요 대상자 개별 처리
		Map<String, List<CapaVo>> capaCache = new HashMap<>();
		Map<Integer, List<Map<String, Object>>> pkgTyCache = new HashMap<>();
		List<UstraCodeModel> tmcRngCds = commonCodeData.all().stream().filter(cd -> "TMC_RNG_CD".equals(cd.getGrpCd())).collect(Collectors.toList());

		List<BatchMemberUploadAdvanceResvModel> aempList = registRepository.selectClcoAempAdreBlkRegTempRegistWithCapa(params);
		aempList.forEach(aemp -> {

			CapaErrorCode chkCapaRes = CapaErrorCode.NORMAL;
			if (!ObjectUtils.isEmpty(aemp.getCuiId()) && !ObjectUtils.isEmpty(aemp.getPkgTyId())) {

				chkCapaRes = checkCapaError(aemp.getCuiId(), in.getClcoId(), in.getYr(), aemp.getAempRegSeq(), aemp.getPkgTyId(), aemp.getTn1ResvApplDt(), aemp.getTn1ResvTmcRngVal(), aemp.getSlctItmList(),
						capaCache, pkgTyCache, tmcRngCds,
						registRepository.selectClcoAempAdreBlkRegTempResvInfo(aemp));
			}

			CapaErrorCode chkSpsrCapaRes = CapaErrorCode.NORMAL;
			if (!ObjectUtils.isEmpty(aemp.getSpsrCuiId()) && !ObjectUtils.isEmpty(aemp.getSpsrPkgTyId())) {

				chkSpsrCapaRes = checkCapaError(aemp.getSpsrCuiId(), in.getClcoId(), in.getYr(), aemp.getAempRegSeq(), aemp.getSpsrPkgTyId(), aemp.getTn1SpsrResvApplDt(), aemp.getTn1SpsrResvTmcRngVal(),
						aemp.getSpsrSlctItmList(), capaCache, pkgTyCache, tmcRngCds,
						registRepository.selectClcoAempAdreBlkRegTempSpsrResvInfo(aemp));
			}

			if( chkCapaRes != CapaErrorCode.NORMAL || chkSpsrCapaRes != CapaErrorCode.NORMAL ) {

				if( chkCapaRes != CapaErrorCode.NORMAL ) {

					aemp.setUpldErrVal(chkCapaRes.getMessage("임직원"));
					registRepository.updateClcoAempAdreBlkRegTmpCapaError(aemp);
				}
				if( chkSpsrCapaRes != CapaErrorCode.NORMAL ) {

					aemp.setUpldErrVal(chkCapaRes.getMessage("배우자"));
					registRepository.updateClcoAempAdreBlkRegTmpCapaError(aemp);
				}
				return;
			}

//			registProcess(in, UstraMapUtils.getMap(
//					"clcoId", in.getClcoId(),
//					"yr", in.getYr(),
//					"managerId", BatchUploadUtils.getCurrentMngrId(),
//					"mngrId", BatchUploadUtils.getCurrentMngrId(),
//					"aempRegSeq", aemp.getAempRegSeq(),
//					"cuTgtrUpdYn", in.isCuTgtrUpdYn() ? 1 : 0,
//					"vcnTgtrUpdYn", in.isVcnTgtrUpdYn() ? 1 : 0,
//					"spcuMttr1UpdYn", in.isSpcuMttr1UpdYn() ? 1 : 0,
//					"spcuMttr2UpdYn", in.isSpcuMttr2UpdYn() ? 1: 0,
//					"fmlyInitYn", in.isFmlyInitYn() ? 1 : 0));
		});

		// 케파 체크 완료 대상자 일괄 처리
		params.put("regTyVal", "2");
		registProcess(in, params);
	}

	private void registProcess(BatchMemberUploadRegistRequestModel in, Map<String, Object> params) {

		registRepository.updateClcoAempBlkRegTmpUpldStPrevForAdre(params);

		// 부서 생성 (신규 프로시저 생성 필요)
		procedureManager.callSp("dbo", "SP_CLCO_AEMP_BLK_REG_TMP_DEPT_FORADVRSV", params);

		// 직급 생성 (신규 프로시저 생성 필요)
		procedureManager.callSp("dbo", "SP_CLCO_AEMP_BLK_REG_TMP_JBGD_FORADVRSV", params);

		// 사업장ID, 부서ID, 회원ID 업데이트 (1, 4)
		registRepository.updateClcoBlkRegTmpIdForAdre(params);

		// 신규이면서 UID가 있으면 ST_VAL 별도 처리
		registRepository.updateClcoBlkRegTmpUpldStForAdre(params);

		// 사업장ID, 부서ID, 업데이트 (14)
		registRepository.updateClcoBlkRegTmpId2ForAdre(params);

		// 회원 정보 등록
		registRepository.insertMbrBscForAdre(params);

		// 회원 부가 정보 등록
		registRepository.insertMbrAddInfDtlForAdre(params);

		// 회원 부가 정보 업데이트
		registRepository.updateMbrAddInfDtlForAdre(params);

		// ST_VAL 복구 (타 고객사)
		registRepository.updateClcoBlkRegTmpUpldSt3ForAdre(params);

		// 회원 고객사 관계 등록
		registRepository.insertMbrClcoRltnForAdre(params);

		// 회원 고객사 관계 변경이력
		registRepository.insertMbrClcoRltnChgRecsForAdre(params);

		// ST_VAL 복구
		registRepository.updateClcoBlkRegTmpUpldSt2ForAdre(params);

		// 회원정보 변경 여부 체크
		registRepository.updateClcoBlkRegTmpUpdYnForAdre(params);

		// 휴대폰 번호 변경 이력 등록
		registRepository.insertMbrChgRecsMblForAdre(params);

		// 이메일 변경 이력 등록
		registRepository.insertMbrChgRecsEmlForAdre(params);

		// 이름 변경 이력 등록
		registRepository.insertMbrChgRecsNmForAdre(params);

		// 생년월일 변경 이력 등록
		registRepository.insertMbrChgRecsBrdtForAdre(params);

		// 성별 변경 이력 등록
		registRepository.insertMbrChgRecsSexForAdre(params);

		// 사번 변경 여부 체크 - 미사용
		registRepository.updateClcoBlkRegTmpIdUpdYnForAdre(params);

		// 사번 변경 이력 등록
		registRepository.insertMbrChgRecsIdForAdre(params);

		// 회원 정보 업데이트
		registRepository.updateMbrBscForAdre(params);

		// 회원 고객사 관계 업데이트
		registRepository.updateMbrClcoRltnForAdre(params);

		// 회원 고객사 관계 변경 이력
		registRepository.insertMbrClcoRltnChgRecs2ForAdre(params);

		// 회원 건강서비스정보 등록
		registRepository.insertMbrHthSvcInfHisForAdre(params);

		// 건강위험평가 검진관계 등록
		registRepository.insertHthRistAsmCuRltnForAdre(params);

		// 사업장 변경 시 사업장 내역 삭제
		registRepository.deleteMbrBsplHisForAdre(params);

		// 사업장 내역 등록
		registRepository.insertMbrBsplHisForAdre(params);

		// 검진대상 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpTgtIdForAdre(params);

		// 검진대상 등록
		registRepository.insertCuTgtHisForAdre(params);

		// 특수검진대상 변경이력
		registRepository.insertCustInfEmpRecsForTgtForAdre(params);

		// 임원여부, 특수검진여부 업데이트
		registRepository.updateCuTgtHisExcuYnForAdre(params);

		// 검진대상 아이디 업데이트
		registRepository.updateClcoAempBlkRegTmpTgtId2ForAdre(params);

		// 1차 특수검진대상 삭제
		if( in.isSpcuMttr1UpdYn() )
			registRepository.updateExtrHndlMttrResvTgtDeleteForAdre(params);

		// 2차 특수검진대상 삭제
		if( in.isSpcuMttr2UpdYn() )
			registRepository.updateExtrHndlMttrResvTgtDelete2ForAdre(params);

		// 신규 특수물질 등록
		registRepository.insertExtrHndlMttrForAdre(params);

		// 특수검진대상 이력 등록
		registRepository.insertExtrHndlMttrResvTgtRecsForAdre(params);

		// 특수검진대상 등록 1차
		if( in.isSpcuMttr1UpdYn() )
			registRepository.insertExtrHndlMttrResvTgtForAdre(params);

		// 특수검진대상 등록 2차
		if( in.isSpcuMttr2UpdYn() )
			registRepository.insertExtrHndlMttrResvTgt2ForAdre(params);

		// 특수검진대상 이력 등록 2차
		registRepository.insertExtrHndlMttrResvTgtRecs2ForAdre(params);

		// 검진대상자 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpTgtrIdForAdre(params);

		// 백신대상자 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpVcnTgtrIdForAdre(params);

		// 검진대상자 및 백신대상자 등록 (with 이력)
		registRepository.insertCuTgtrHisForAdre(params);

		// 검진대상자 변경이력
		registRepository.insertCustInfEmpRecsForAdre(params);

		if( in.isCuTgtrUpdYn() ) {

			// 검진대상자 변경 이력 (갱신)
			registRepository.insertCuTgtrRecsForAdre(params);

			// 검진대상자 업데이트
			registRepository.updateCuTgtrHisForAdre(params);

			// 검진대상자 중복 건 업데이트 처리
			registRepository.updateCuTgtrHisInfoForAdre(params);
		}

		// 종합지원금 등록
		registRepository.insertMbrSpfnSyntInfBscForAdre(params);

		if( in.isCuTgtrUpdYn() ) {

			// 종합지원금 업데이트
			registRepository.updateMbrSpfnSyntInfBscForAdre(params);
		}

		if( in.isVcnTgtrUpdYn() ) {

			// 백신대상자 변경 이력 (갱신)
			registRepository.insertVcnTgtrChgRecsForAdre(params);

			// 백신대상자 업데이트
			registRepository.updateVcnTgtrBscForAdre(params);

			// 백신대상자 중복 건 업데이트 처리
			registRepository.updateVcnTgtrBscInfoForAdre(params);
		}

		if( in.isFmlyUpdYn() ) {

			if (in.isFmlyInitYn()) {

				// 가족 정보 삭제이력
				registRepository.insertCustInfEmpRecsFmlyInitForAdre(params);

				// 배우자 정보 삭제
				registRepository.deleteClcoAempBlkRegTmpSpsrTgtrForAdre(params);
			}

			// 배우자 검진대상자 존재여부 체크
			registRepository.updateClcoAempBlkRegTmpSpsrTgtrIdForAdre(params);

			// 배우자 백신대상자 존재여부 체크
			registRepository.updateClcoAempBlkRegTmpSpsrVcnTgtrIdForAdre(params);

			// 배우자 검진대상자 및 백신대상자 등록 (with 이력)
			registRepository.insertCuTgtrHisSpsrForAdre(params);

			// 배우자 검진대상자 변경이력
			registRepository.insertCustInfEmpRecsForSpsrForAdre(params);

			if (in.isCuTgtrUpdYn()) {

				// 배우자 검진대상자 변경 이력 (갱신)
				registRepository.insertCuTgtrRecsSpsrForAdre(params);

				// 배우자 검진대상자 업데이트
				registRepository.updateCuTgtrHisSpsrForAdre(params);
			}

			// 배우자 종합지원금 등록
			registRepository.insertMbrSpfnSyntInfBscSpsrForAdre(params);

			if (in.isCuTgtrUpdYn()) {

				// 배우자 종합지원금 업데이트
				registRepository.updateMbrSpfnSyntInfBscSpsrForAdre(params);
			}

			if (in.isVcnTgtrUpdYn()) {

				// 배우자 백신대상자 변경 이력 (갱신)
				registRepository.insertVcnTgtrChgRecsSpsrForAdre(params);

				// 배우자 백신대상자 업데이트
				registRepository.updateVcnTgtrBscSpsrForAdre(params);
			}
		}

		// 기존 회원고객사 관계 업데이트
		registRepository.updateMbrClcoRltn2ForAdre(params);

		// 기존 회원고객사 관계 변경이력 등록
		registRepository.insertMbrClcoRltnChgRecs3ForAdre(params);

		// 기존 회원사업장 이력 업데이트
		registRepository.updateMbrBsplHisForAdre(params);

		// 기존 회원부가정보 업데이트
		registRepository.updateMbrAddInfDtl2ForAdre(params);

		/* 선예약 관련 코드 추가 by.LKH(22.07.11) */
		// 임직원 예약정보 추가(임직원 선택검사 추가)
		registRepository.insertAempResvForAdre(params);

		// 가족 예약정보 추가(가족 선택검사 추가)
		registRepository.insertSpsrResvForAdre(params);

		// 임시테이블 이메일 휴대폰번호 업데이트
		registRepository.updateClcoAempBlkRegTmpInfoForAdre(params);

		// 등록 완료 처리
		registRepository.updateClcoAempBlkRegTmpRegistForAdre(params);
	}

	/**
	 *
	 * 처리내용 : 선택된 중복 오류 항목 신규 내용으로 등록
	 *
	 * @param in
	 * @throws IOException
	 */

	@Transactional
	public void registUploadedMember(BatchMemberUploadRegistRequestModel in) throws IOException {

		if( CollectionUtils.isEmpty(in.getList()) )
			return;

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		resvRepository.updateClcoAempBlkRegTmpBackup(in);

		// 업로드 상태를 14로 변경하여 처리한다.
		in.getList().forEach(e->{
			e.setUpldStVal(14);
		});
		resvRepository.updateClcoAempBlkRegTmpUpldStVal(in);

		regist(in);

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		resvRepository.updateClcoAempBlkRegTmpRestore(in);
	}

	/**
	 *
	 * 처리내용 : 선택 년도 모든 고객 다운로드 (for Test)
	 *
	 * @param in
	 * @return
	 */
	public List<BatchAdvanceResvExcelModel> getTestCustomerList(CustomerExcelDownModel in) {

		in.setMngrId("" + BatchUploadUtils.getCurrentMngrId());
		return resvRepository.selectCustomerTmpTestExcelList(in);
	}

	public List<BatchAdvanceResvExcelModel> selectCustomerTmpExcelList(CustomerExcelDownModel in) {
		// TODO Auto-generated method stub
		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());
		in.setMngrId(String.valueOf(managerDtl.getMngrId()));

		List<BatchAdvanceResvExcelModel> list = errorExcelMsg(resvRepository.selectCustomerTmpExcelList(in));

		return list;
	}

	public Map<String, Object> getBatchCustomerList(CustomerExcelDownModel vo) {
		Map<String, Object> result = new HashMap<>();
		List<BatchAdvanceResvExcelModel> dupList = new ArrayList<BatchAdvanceResvExcelModel>();
		List<BatchAdvanceResvExcelModel> missingList = new ArrayList<BatchAdvanceResvExcelModel>();
		List<BatchAdvanceResvExcelModel> etcList = new ArrayList<BatchAdvanceResvExcelModel>();
		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());

		vo.setMngrId(String.valueOf(managerDtl.getMngrId()));
		// T_CLCO_AEMP_BLK_REG_TMP
		vo.setResultFlag("dup");
		dupList = resvRepository.getClcoAempBlkRegTmp(vo);
		vo.setResultFlag("missing");
		missingList = resvRepository.getClcoAempBlkRegTmp(vo);
		vo.setResultFlag("etc");
		etcList = resvRepository.getClcoAempBlkRegTmp(vo);

		result.put("dupCnt", dupList.size());
		result.put("missingCnt", missingList.size());
		result.put("etcCnt", etcList.size());

		result.put("dupList", dupList);
		result.put("missingList", missingList);
		result.put("etcList", etcList);

		return result;
	}

	/**
	 *
	 * 처리내용 : 예약 정보 체크
	 *
	 * @param in
	 * @return
	 */

	public BatchMemberUploadReserveInfoModel checkReserve(BatchMemberUploadRegistRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		if( CollectionUtils.isNotEmpty(in.getList()) )
			return resvRepository.getClcoAempBlkRegTmpReserveForList(in);
		return resvRepository.getClcoAempBlkRegTmpReserve(in);
	}

	public List<BatchAdvanceResvExcelModel> getCustomerListForDownload(List<BatchMemberUploadAdvanceResvModel> in) {

		if( CollectionUtils.isEmpty(in) )
			return Arrays.asList(new BatchAdvanceResvExcelModel());
		return errorExcelMsg(resvRepository.selectClcoAempBlkRegTmpExcelList(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in)));
	}


	public List<BatchAdvanceResvExcelModel> selectDuplicatedCustomer(CustomerExcelDownModel in) {

		in.setMngrId(String.valueOf(BatchUploadUtils.getCurrentMngrId()));
		return errorExcelMsg(resvRepository.selectClcoAempBlkRegTmpDuplicatedExcel(in));
	}

	public List<BatchAdvanceResvExcelModel> selectDuplicatedCustomerList(List<BatchMemberUploadAdvanceResvModel> in) {
		return errorExcelMsg(resvRepository.selectClcoAempBlkRegTmpDuplicatedExcelList(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in)));
	}
}