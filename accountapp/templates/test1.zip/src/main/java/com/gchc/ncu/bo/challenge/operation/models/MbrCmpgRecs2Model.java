package com.gchc.ncu.bo.challenge.operation.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gchc.common.util.GchcMaskType;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;

@Data
@EqualsAndHashCode(callSuper=false)
public class MbrCmpgRecs2Model extends UstraManagementBaseModel {

	private Integer cmpgId;
	@Masked(MaskingType.ID)
	private String uid;
	private String cluAgrDt;
	@Masked(MaskingType.NAME)
	private String nknm;
	private Integer rnk;
	private Integer acmlStpCnt;
	private Integer avgStpCnt;
	private Double indvPgrsRt;
	private Integer bsplId;
	private String cmpnCont;

	@Masked(MaskingType.NAME)
	private String nm;
	@Masked(MaskingType.ID)
	private String empno;
	@Masked(GchcMaskType.DATE)
	private String brdt;

	private String no;
	private String dt;
	private String mblNo;
	private String pfrmStpCnt;
	private String teamNm;
	private Integer teamRnk;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp stpSyncDtm;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
