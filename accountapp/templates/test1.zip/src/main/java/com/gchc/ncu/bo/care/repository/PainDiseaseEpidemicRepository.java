package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.NrsnDssEpidDtlModel;
import com.gchc.ncu.bo.care.vo.PainDiseaseEpidemicVo;

@Mapper
public interface PainDiseaseEpidemicRepository {

	List<NrsnDssEpidDtlModel> selectPainDiseaseEpidemicList(PainDiseaseEpidemicVo criteria);
	List<NrsnDssEpidDtlModel> selectPainDiseaseEpidemicMonthList(NrsnDssEpidDtlModel model);
	void insertPainDiseaseEpidemicMonth(NrsnDssEpidDtlModel model);
	void deletePainDiseaseEpidemicMonth(int nrsnDssId);

}
