package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.PoisRsltDtlModel;
import com.gchc.ncu.bo.care.repository.AddictionResultTypeRepository;
import com.gchc.ncu.bo.care.vo.AddictionResultTypeVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AddictionResultTypeService {

	private final AddictionResultTypeRepository AddictionResultTypeRepository;

	public List<PoisRsltDtlModel> getAddictionResultTypeList(AddictionResultTypeVo criteria) {
		return AddictionResultTypeRepository.selectAddictionResultTypeList(criteria);
	}

	public PoisRsltDtlModel getAddictionResultTypeDetail(PoisRsltDtlModel criteria) {
		return AddictionResultTypeRepository.selectAddictionResultTypeDetail(criteria);
	}

	public void saveAddictionResultType(PoisRsltDtlModel model) {
		AddictionResultTypeRepository.saveAddictionResultType(model);
	}

	@Transactional
	public void deleteAddictionResultType(List<PoisRsltDtlModel> list) {
		if (list != null) {
			for (PoisRsltDtlModel model : list) {
				AddictionResultTypeRepository.deleteAddictionResultType(model);
			}
		}
	}

}
