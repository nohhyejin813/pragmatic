package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
public class BatchCenterVaccineUploadModel extends NcuModel {

	private Integer cuiBlkVcnId;

	private Integer yr;

	private String cuiNm;

	private Integer cuiId;

	private String clcoNm;

	private Integer clcoId;

	private String bsplNm;

	private String bsplId;

	private String vcnNm;

	private Integer vcnId;

	private Integer vcnAmt;

	private Integer vcnDcAmt;

	private String etcMsgCont;

	private Integer upldStVal;

	private String upldErrVal;

	private Integer useYn;

	private Integer delYn;

	private Integer upldYn;

	private Integer mngrId;
}
