package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class SkinAgeSearchVo extends UstraManagementBaseModel {

	private String genderCd;
	private String title;
	private String startTime;
	private String endTime;
	private String startAge;
	private String endAge;

	private Integer skinAgId;
	private Integer cnntId;
	private Integer skinAgRsltId;

}
