package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.StndBodyBscModel;
import com.gchc.ncu.bo.care.repository.DailyStndBodyRepository;
import com.gchc.ncu.bo.care.vo.DailyStndBodyVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DailyStndBodyService {

	private final DailyStndBodyRepository dailyStndBodyRepository;

	public List<StndBodyBscModel> getDailyStndBodyList(DailyStndBodyVo criteria) {
		return dailyStndBodyRepository.selectDailyStndBodyList(criteria);
	}

	@Transactional
	public void saveDailyStndBody(List<StndBodyBscModel> list) {
		if (list != null) {
			for (StndBodyBscModel model : list) {
				dailyStndBodyRepository.saveDailyStndBody(model);
			}
		}
	}

}
