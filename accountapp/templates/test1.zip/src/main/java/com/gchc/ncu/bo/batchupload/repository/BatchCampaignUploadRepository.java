package com.gchc.ncu.bo.batchupload.repository;

import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * @FileName : BatchCampaignUploadRepository.java
 * @date : 2023. 02. 01
 * @author : jclee
 * @프로그램 설명 : 부가정보변경 일괄업로드 Repository
 * @변경이력 :
 */
@Mapper
public interface BatchCampaignUploadRepository {
    int getClcoTeamBscRegYn(Map<String, Object> map);

    void insertClcoTeamBsc(Map<String, Object> map);

    int updateCmpgTeamId(Map<String, Object> map);

    int insertCmpgMbrMuscDeptHis(Map<String, Object> map);

    int updateCmpgMbrMuscDeptHis(Map<String, Object> map);

    int getCmpgWorkDeptNmRegYn(Map<String, Object> map);

    int getCmpgLineRegYn(Map<String, Object> map);

    int getCmpgJobRegYn(Map<String, Object> map);

    int insertCmpgWorkDeptNm(Map<String, Object> map);

    int insertCmpgLine(Map<String, Object> map);

    int insertCmpgJob(Map<String, Object> map);

    String getCuTgtHisYn(Map<String, Object> map);

    int getCmpgMbrMuscDeptHisYn(Map<String, Object> map);

}
