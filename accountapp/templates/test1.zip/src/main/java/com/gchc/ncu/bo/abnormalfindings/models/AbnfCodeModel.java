package com.gchc.ncu.bo.abnormalfindings.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AbnfCodeModel
{
	private String dtlCd;
	private String cdNm;
	private String etc1;
}