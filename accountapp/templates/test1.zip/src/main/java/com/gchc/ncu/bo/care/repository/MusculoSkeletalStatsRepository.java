package com.gchc.ncu.bo.care.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.MusculoSkeletalStatsModel;
import com.gchc.ncu.bo.care.models.MusculoSkeletalStatusModel;
import com.gchc.ncu.bo.care.vo.MusculoSkeletalStatsVo;

@Mapper
public interface MusculoSkeletalStatsRepository {

	List<Map<String, Object>> selectYearList();
	List<Map<String, Object>> selectClcoListByYear(Map<String, Object> params);
	List<Map<String, Object>> selectBsplListByClcoId(Map<String, Object> params);

	List<MusculoSkeletalStatsModel> selectStatisticsListByAge(MusculoSkeletalStatsVo vo);
	List<MusculoSkeletalStatsModel> selectStatisticsListByGender(MusculoSkeletalStatsVo vo);
	List<MusculoSkeletalStatsModel> selectStatisticsListByNow(MusculoSkeletalStatsVo vo);
	List<MusculoSkeletalStatsModel> selectStatisticsListByPast(MusculoSkeletalStatsVo vo);
	List<MusculoSkeletalStatsModel> selectStatisticsListByBurden(MusculoSkeletalStatsVo vo);
	List<MusculoSkeletalStatsModel> selectStatisticsListByPain(MusculoSkeletalStatsVo vo);

	List<MusculoSkeletalStatusModel> selectStatisticsListStatus(MusculoSkeletalStatsVo vo);

}
