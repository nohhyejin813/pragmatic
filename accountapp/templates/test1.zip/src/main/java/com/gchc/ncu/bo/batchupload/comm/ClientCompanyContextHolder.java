package com.gchc.ncu.bo.batchupload.comm;

import com.gchc.ncu.bo.member.models.ClientModel;

public class ClientCompanyContextHolder {

	private static final ThreadLocal<ClientModel> contextHolder = new ThreadLocal<ClientModel>();

	public static ClientModel get() {

		return contextHolder.get();
	}

	public static void set(ClientModel client) {

		contextHolder.set(client);
	}

	public static void clear() {

		if( get() != null )
			contextHolder.remove();
	}

	public static boolean bizCenter() {

		if( get() == null )
			return false;
		return "5".equals(get().getClcoSvcTyCd());
	}
}
