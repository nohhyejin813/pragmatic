package com.gchc.ncu.bo.admin.service;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gchc.ncu.bo.admin.models.*;
import com.gchc.ncu.bo.comm.service.ApiProxyInterfaceService;
import com.gchc.ncu.bo.comm.util.NcuEncUtils;
import com.gchc.ncu.bo.member.repository.ClientRepository;
import io.netty.util.internal.StringUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import com.gchc.common.message.model.MessageUnion;
import com.gchc.common.message.model.MessageUnion.RecvChangData;
import com.gchc.ncu.bo.admin.repository.AdminRepository;
import com.gchc.ncu.bo.config.authentication.DefinedSmsString;
import com.gchc.ncu.bo.member.models.ClientModel;
import com.gchc.ncu.bo.message.service.MessageService;
import com.gchc.ncu.bo.message.vo.MessageSendVo;

/**
 * 프로토타입 Service
 *
 * @author gs_hskim@gchealthcare.com
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class AdminService {

	@Autowired
	private AdminRepository repository;

	@Autowired
    MessageService messageService;

	@Autowired
	private ApiProxyInterfaceService apiProxyInterfaceService;

	@Value("${ustra.proxyapi.pay.mid}")
	private String mid;

	@Value("${ustra.proxyapi.pay.merchantkey}")
	private String merchantkey;

	@Value("${ustra.proxyapi.pay.method}")
	private String method;

	public List<AdminModel> getHowcareMainGraphData(){
		List<AdminModel> list = repository.getHowcareMainGraphData();
		return list.stream()
			.map(l->{
				l.setEmptyResrvationValue(l.getTotalReservationValue() - l.getReservationCompleteValue() - l.getCheckupCompleteValue());
				l.setEmptyResrvationRate(l.getEmptyResrvationValue() * 100 / l.getTotalReservationValue());
				l.setReservationCompleteRate(l.getReservationCompleteValue() * 100 / l.getTotalReservationValue());
				l.setCheckupCompleteRate(l.getCheckupCompleteValue() * 100 / l.getTotalReservationValue());

				if( l.getEmpTotalReservationValue() > 0 ) {

					l.setEmpEmptyResrvationValue(l.getEmpTotalReservationValue() - l.getEmpReservationCompleteValue() - l.getEmpCheckupCompleteValue());
					l.setEmpEmptyResrvationRate(l.getEmpEmptyResrvationValue() * 100 / l.getEmpTotalReservationValue());
					l.setEmpReservationCompleteRate(l.getEmpReservationCompleteValue() * 100 / l.getEmpTotalReservationValue());
					l.setEmpCheckupCompleteRate(l.getEmpCheckupCompleteValue() * 100 / l.getEmpTotalReservationValue());
				}
				return l;
			})
			.collect(Collectors.toList());
	}

	public List<AdminModel> getMainInstGraphData(Integer cuiId){
		return repository.getMainInstGraphData(cuiId);
	}

	public List<AdminModel> getCheckupinstGraphData(Integer clcoId){
		return repository.getCheckupinstGraphData(clcoId);
	}

	/**
	 * 처리내용 : 검진이지, 기관이지 고객사 기본정보
	 *
	 * @param model
	 * @return
	 */
	public ClientModel getEasyClient(ClientModel model) {
		return repository.getEasyClient(model);
	}

	/**
	 * 메인화면 - 진행도 플래그 조회
	 *
	 * @param clcoId
	 * @return
	 */
	public AdminProgressModel getAdminProgressFlag(Integer clcoId) {
		return repository.getAdminProgressFlag(clcoId);
	}

	/**
	 * 메인화면 - 오픈하기 팝업 데이터 로드
	 *
	 * @param clcoId
	 * @return
	 */
	public AdminOpenPopupModel getOpenPopupData(Integer clcoId) {
		return repository.getOpenPopupData(clcoId);
	}

	/**
	 * 메인화면 - 오픈하기 팝업 추가 데이터 로드
	 *
	 * @param clcoId
	 * @return
	 */
	public AdminOpenPopupModel getOpenAddPopupData(Integer clcoId) {
		AdminOpenPopupModel model = new AdminOpenPopupModel();
		String bsplNm = repository.getBsplNm(clcoId);
		List<ClientMiniModel> addBspl = repository.getAddBspl(clcoId);
		String addBsplNm = "";
		if(addBspl.size() > 0) {
			addBsplNm = addBspl.get(0).getBsplNm() + "외" + (addBspl.size()-1) + "(건)";
		}else {

		}
		model.setBsplNm(bsplNm);
		model.setAddBsplNm(addBsplNm);
		return model;
	}

	/**
	 * 오픈하기 - flag수정
	 *
	 * @param clcoId
	 * @return
	 */
	public int modClcoOpenFlag(Integer clcoId) {
		int save = 0;

		AdminOpenMailModel openMail = repository.getOpenMailFowardInfo(clcoId);

		if (openMail != null) {
			List<AdminOpenMailTargetModel> target = null;
			if(openMail.getClcoSvcTyCd().equals("5")) {		// BizCenter
				target = repository.getBizCenterOpenMailTarget(clcoId);

			} else if(openMail.getClcoSvcTyCd().equals("6")) {		// BizLite
				target = repository.getOpenMailTarget(clcoId);

			} else {
				target = null;
			}

		    // 대상자가 1명 이상이면 메일 발송
			if(target != null && target.size() > 0) {

				String atchFileId = repository.atchFileId(clcoId);
				String content = "";
				// ['@{회원명}', '@{고객사명}', '@{사업장명}', '@{사번}', '@{검진센터명}']
				// 언제 오픈했고,
//				content += "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
//				content += "<head>";
//				content += "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";
//				content += "<title></title>";
//				content += "</head>";
//				content += "<body>";

				content += "안녕하세요 <br>";
				content += "어떠케어 검진 오픈 안내입니다.<br>";
				content += "귀하의 검진센터로 #고객사명# 에서 검진을 오픈하였습니다.<br><br>";
				content += "■ 고객사명: #고객사명# <br>";
				content += "■ 사업자번호: #사업자번호# <br>";
				content += "■ 사업장주소: #사업장주소# <br>";
				content += "■ 담당자명: #회원명# / #전화번호# / #이메일# <br><br>";
				content += "■ 검진기간: #검진시작일# ~ #검진종료일#<br><br><br>";
				content += "원활한 검진을 위한 준비를 진행해주시기 바랍니다.<br>";
				content += "감사합니다.";

//				content += "</body>";
//				content += "</html>";

				MessageUnion messageUnion = new MessageUnion();

				messageUnion.setSysDvCd("UMS");
			    messageUnion.setSndDvCd("2"); // 발송구분(1: 문자(SMS) 2: 메일, 3:카카오알림톡, 4:앱푸쉬 5:문자(MMS))
			    messageUnion.setSndKdCd(0); // 메세지유형(SND_KD_CD: 0-메일, 1-SMS, 2-PNS)
			    messageUnion.setSndEmlAdr(DefinedSmsString.EMAIL_SENDER); //발송자 이메일주소
			    messageUnion.setMsgCatGrpCd("1");
			    messageUnion.setMsgCatDtlCd("0701"); // 안내 메시지
			    messageUnion.setTitl("어떠케어 검진 오픈 안내");
			    messageUnion.setCont(content);
			    messageUnion.setAtchFileId(atchFileId);
			    messageUnion.setSvcDmnNm("");
			    messageUnion.setResvStCd(0);// 예약상태코드(RESV_ST_CD): 0-즉시발송, 1-예약전송, 2-예약취소
			    messageUnion.setResvDtm("");
			    messageUnion.setRcvrTyCd(0);						// 수신자 유형코드	(0-개별, 1-그룹, 2-엑셀)
			    //messageUnion.setSndMngrId(999999999);
			    messageUnion.setLinkKvl("0");						// 링크 키값
				messageUnion.setLinkUrl("");						// 링크 URL
				messageUnion.setSvcDmnNm("");						// 서비스 도메인 명
			    messageUnion.setFrstRegrTyCd("0");
			    messageUnion.setFrstRegrId("ADMIN");


			    ArrayList<String> rcvUserList = new ArrayList<String>();
			    ArrayList<RecvChangData> recvChangData = new ArrayList<RecvChangData>();
				for(int i=0; i<target.size(); i++) {
					// 받는 사람 정보 처리
					if(!ObjectUtils.isEmpty(target.get(i).getEmail())) {
						rcvUserList.add(target.get(i).getEmail()); // 메일 수신 받을 대상자
					}
			        RecvChangData recvChangItem = new RecvChangData();
			        HashMap<String, String> mapData = new HashMap<String, String>();
			        mapData.put("#고객사명#", openMail.getClcoNm());
			        mapData.put("#사업자번호#", openMail.getBrno());
			        mapData.put("#사업장주소#", openMail.getBscAdr());
			        mapData.put("#회원명#", openMail.getChrgrNm());

			        mapData.put("#전화번호#", openMail.getChrgrTlno());
			        mapData.put("#이메일#", openMail.getChrgrEmlAdr());
			        mapData.put("#검진시작일#", openMail.getCtraSrtDt());
			        mapData.put("#검진종료일#", openMail.getCtraEndDt());

			        recvChangItem.setData(mapData);
			        recvChangItem.setRecv(target.get(i).getEmail()); //rcvUserList와 동일한 조건으로
			        recvChangData.add(recvChangItem);
				}
				messageUnion.setRcvUserList(rcvUserList); //세팅 위치 중함
			    messageUnion.setRecvChangData(recvChangData);

			    int msgId = messageService.insertMessage(messageUnion);
			    if(msgId > 0) {
			    	_sendPush(msgId);
			    }
			    save = 1;
			}
		}
		return save;
	}



	private void _sendPush(Integer msgId) {
		//if (msgId == null || msgId > 0) return;
		System.out.println("######## _sendPush================================"+msgId);

		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(msgId);

		MessageSendVo messageSendVo = new MessageSendVo();
		messageSendVo.setMsgIdList(list);


		Integer result = messageService.sendMessage(messageSendVo);
		LOGGER.info("### messageService.sendMessage() result = {}", result);
	}

	/**
	 * 오픈/종료 예정 클라이언트 리스트
	 *	오픈 탑5 / 종료 탑5 총 10개 반환
	 * @param yr
	 * @return
	 */
	public List<ClientMiniModel> getClientList(Integer yr) {
		return repository.getClientList(yr);
	}

	/**
	 * 고객사 오픈 예정 테이블 내용 조회
	 * @param cuiId
	 * @return
	 */
	public List<ClientMiniModel> getOpenClientNoticeData(Integer cuiId, Integer yr) {
		return repository.getOpenClientNoticeData(cuiId, yr);
	}


	public ClientPaymentModel getOpenClientPaymentData(Integer cuiId) throws Exception {
		ClientPaymentModel result = new ClientPaymentModel();
		AdminOpenMailModel adminOpenMailModel = new AdminOpenMailModel();
		adminOpenMailModel.setClcoId(cuiId);
		adminOpenMailModel = repository.getOpenMailFowardInfo(cuiId);

		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMddHHmmssSSS");

		Date currentTime = new Date();
		String toDay = format.format(currentTime);
		String toDaySec = format2.format(currentTime);
		String amt = adminOpenMailModel.getStlAmt();

		String encPaySignData = NcuEncUtils.encPaySignData(toDay + mid + amt + merchantkey);
		result.setClcoId(cuiId);
		result.setClcoNm(adminOpenMailModel.getClcoNm());
		result.setYr(toDay.substring(0,4));
		if (!StringUtils.isEmpty(adminOpenMailModel.getCuImplSrtDt())) {
			result.setCuImplSrtDt(adminOpenMailModel.getCuImplSrtDt().replaceAll("-",""));
		}
		if (!StringUtils.isEmpty(adminOpenMailModel.getCuImplEndDt())) {
			result.setCuImplEndDt(adminOpenMailModel.getCuImplEndDt().replaceAll("-", ""));
		}
		result.setGoodsName("비즈라이트 서비스요금");
		result.setAmt(amt);
		result.setStlTyCd(adminOpenMailModel.getStlTyCd());
		result.setMid(mid);
		result.setEdiDate(toDay);
		result.setMoid(toDaySec+cuiId);
		result.setSignData(encPaySignData);
		result.setPayMethod(method);
		result.setBuyerName(adminOpenMailModel.getClcoNm());
		result.setBuyerTel(adminOpenMailModel.getChrgrTlno());
		result.setBuyerEmail(adminOpenMailModel.getChrgrEmlAdr());
		result.setCharSet("utf-8");
		result.setCurrencyCode("KRW");
		result.setTransType("0");
		result.setLogoImage("https://dev.howcare.co.kr/images/gccare-logo.png");

		// 1. 결제내역 신청요청 저장 & 고객사원장 결제요청 상태 update
		this.insAthoPayHst("01", result);
		ClcoAthoStlTrscHisModel clcoAthoStlTrscHisModel = new ClcoAthoStlTrscHisModel();
		clcoAthoStlTrscHisModel.setClcoCtraId(adminOpenMailModel.getClcoCtraId());
		clcoAthoStlTrscHisModel.setTrscUniqDstgVal(result.getMoid());
		repository.updateClcoCtraStlHis(clcoAthoStlTrscHisModel);

		return result;
	}

	private void insAthoPayHst(String div, ClientPaymentModel resResult) throws JsonProcessingException, JSONException, InvocationTargetException, IllegalAccessException {

		ClientPaymentModel result = new ClientPaymentModel();
		BeanUtils.copyProperties(result, resResult);
		ObjectMapper om = new ObjectMapper();
		if (!ObjectUtils.isEmpty(result.getBuyerName())) {
			result.setBuyerName("");
		}
		if (!ObjectUtils.isEmpty(result.getBuyerTel())) {
			result.setBuyerTel("");
		}
		if (!ObjectUtils.isEmpty(result.getBuyerEmail())) {
			result.setBuyerEmail("");
		}
		if ("04".equals(div)) {
			if (!ObjectUtils.isEmpty(result.getTranResData())) {
				String strTranResData = result.getTranResData();
				System.out.println("strTranResData="+strTranResData);
				System.out.println("strTranResData string="+strTranResData.toString());
				JSONObject jsonResContent = new JSONObject(strTranResData);
				String strPayMethod = (String) jsonResContent.get("PayMethod");
				if ("CARD".equals(strPayMethod)) {
					if (!ObjectUtils.isEmpty(jsonResContent.get("CardName"))) {
						jsonResContent.put("CardName", "");
					}
					if (!ObjectUtils.isEmpty(jsonResContent.get("CardNo"))) {
						jsonResContent.put("CardNo", "");
					}
					if (!ObjectUtils.isEmpty(jsonResContent.get("AcquCardName"))) {
						jsonResContent.put("AcquCardName", "");
					}
				}
				if (!ObjectUtils.isEmpty(jsonResContent.get("BuyerName"))) {
					jsonResContent.put("BuyerName", "");
				}
				if (!ObjectUtils.isEmpty(jsonResContent.get("BuyerTel"))) {
					jsonResContent.put("BuyerTel", "");
				}
				if (!ObjectUtils.isEmpty(jsonResContent.get("BuyerEmail"))) {
					jsonResContent.put("BuyerEmail", "");
				}
				result.setTranResData(jsonResContent.toString());
			}
		} else if ("05".equals(div)) {
			result.setTranResData("");
		}

		String jsonModel = om.writeValueAsString(result);
		ClcoAthoStlTrscHisModel clcoAthoStlTrscHisModel = new ClcoAthoStlTrscHisModel();
		clcoAthoStlTrscHisModel.setClcoId(result.getClcoId());
		clcoAthoStlTrscHisModel.setTrscYr(result.getYr());
		clcoAthoStlTrscHisModel.setTrscUniqDstgVal(result.getMoid());
		clcoAthoStlTrscHisModel.setClcoStlTrscDvCd(div);
		clcoAthoStlTrscHisModel.setTrscDatCont(jsonModel);



		repository.insClcoAthoStlTrscHis(clcoAthoStlTrscHisModel);
	}

	public ClientPaymentModel exeOpenClientPaymentApproval(ClientPaymentModel model) throws Exception {

		// 2. api호출 후 호출결과 저장 & 고객사원장 결제인증 결과 상태 update
		this.insAthoPayHst("02", model);

		boolean paySuccess = false;
		String authResultCode 	= model.getAuthResultCode();
		String authToken = model.getAuthToken();
		String sMid = model.getMid();
		String amt = model.getAmt();
		String ediDate = model.getEdiDate();
		String signData = NcuEncUtils.encPaySignData(authToken + sMid + amt + ediDate + merchantkey);
		String authComparisonSignature = NcuEncUtils.encPaySignData(authToken + sMid + amt + merchantkey);
		String netCancelURL = model.getNetCancelURL();
		String authSignature = model.getSignature();


		// NICETOKN5B295AD531A638AB20CE34010B8C3750
		//

		ClcoAthoStlTrscHisModel clcoAthoStlTrscHisModel = new ClcoAthoStlTrscHisModel();
		clcoAthoStlTrscHisModel.setClcoCtraId(model.getClcoCtraId());
		clcoAthoStlTrscHisModel.setStlTrscIdVal(model.getTxTid());

		if (!authResultCode.equals("0000")) {
			clcoAthoStlTrscHisModel.setStlStCd("9");
			repository.updateClcoCtraStlHis(clcoAthoStlTrscHisModel);
			return model;
		}
		/*
		** NICE 인증결제 솔루션 오류로 인해 추가 검증 주석처리 추후 솔루션 패치 후 재검증 처리 필요. 20230116 해결
		*/
		if (!authSignature.equals(authComparisonSignature)) {
			clcoAthoStlTrscHisModel.setStlStCd("9");
			model.setAuthResultCode("A252");
			model.setAuthResultMsg("Signature 생성에 실패하였습니다.");
			repository.updateClcoCtraStlHis(clcoAthoStlTrscHisModel);
			return model;
		}

		StringBuffer requestData = new StringBuffer();
		requestData.append("TID=").append(model.getTxTid()).append("&");
		requestData.append("AuthToken=").append(authToken).append("&");
		requestData.append("MID=").append(sMid).append("&");
		requestData.append("Amt=").append(amt).append("&");
		requestData.append("EdiDate=").append(ediDate).append("&");
		requestData.append("SignData=").append(signData);
		model.setTranReqData(requestData.toString());

		this.insAthoPayHst("03", model);
		ResponseEntity<String> resResult = apiProxyInterfaceService.getPayApproval(model.getNextAppURL(), requestData.toString());

		model.setTranResData(resResult.getBody());
		this.insAthoPayHst("04", model);
		if (resResult.getStatusCode().value() == 200) {

			JSONObject jsonResContent = new JSONObject(resResult.getBody());

			String payMethod 	= (String)jsonResContent.get("PayMethod");	// 결제수단
			String resultCode 	= (String)jsonResContent.get("ResultCode");	// 결과코드 (정상 결과코드:3001, 0000)
			String resultMsg 	= (String)jsonResContent.get("ResultMsg");	// 결과메시지
			String authCode     = (String)jsonResContent.get("AuthCode");	// 승인번호
			model.setPayMethod(payMethod);
			model.setAuthResultCode(resultCode);
			model.setAuthResultMsg(resultMsg);

			clcoAthoStlTrscHisModel.setStlMthNm(payMethod);

			// 3.승인api호출 후 호출결과 저장 & 고객사원장 승인 결과 상태 update

			if (payMethod.equals("CARD") && resultCode.equals("3001")){
				paySuccess = true;
			} else if (payMethod.equals("BANK") && resultCode.equals("4000")){
				paySuccess = true;
			} else if (payMethod.equals("VBANK") && resultCode.equals("4100")){
				paySuccess = true;
			} else {
				if (resultCode.equals("0000")) {
					paySuccess = true;
				}
			}
			if (!paySuccess) {
				clcoAthoStlTrscHisModel.setStlStCd("9");
				repository.updateClcoCtraStlHis(clcoAthoStlTrscHisModel);
				// 망취소 요청
				requestData.append("&").append("NetCancel=1");
				model.setTranReqData(requestData.toString());
				this.insAthoPayHst("05", model);
				ResponseEntity<String> resCancelResult = apiProxyInterfaceService.getPayApproval(netCancelURL, requestData.toString());
				model.setTranResData(resCancelResult.getBody());
				this.insAthoPayHst("06", model);

				JSONObject jsonResCancelContent = new JSONObject(resCancelResult.getBody());
				resultCode 	= (String)jsonResCancelContent.get("ResultCode");	// 결과코드 (정상 결과코드:3001, 4001, 0000)
				resultMsg 	= (String)jsonResCancelContent.get("ResultMsg");	// 결과메시지
				amt 	= (String)jsonResCancelContent.get("CancelAmt");	// 취소금액
				//model.setAuthResultCode(resultCode);
				//model.setAuthResultMsg(resultMsg);
				//model.setCancelAmt(amt);

				//4. 승인 실패 시 망취소api호출 후 호출결과 저장
			} else {
				clcoAthoStlTrscHisModel.setStlStCd("1");
				clcoAthoStlTrscHisModel.setStlTrscIdVal(authCode);
				clcoAthoStlTrscHisModel.setRealStlTyCd(model.getStlTyCd());
				clcoAthoStlTrscHisModel.setRealStlAmt(model.getAmt());
				repository.updateClcoCtraStlHis(clcoAthoStlTrscHisModel);
				int updCnt = this.updClcoBsplHis(model);
				if (updCnt > 0) {
					// 승인 완료 & 예약일 upd건 있을 시 api 결과코드 1000으로 전달
					model.setAuthResultCode("1000");
				} else {
					// 승인 완료 시 api 결과코드 0000으로 전달
					model.setAuthResultCode("0000");
				}
			}
		}
		return model;
	}

	@Transactional
	public int updClcoBsplHis(ClientPaymentModel model) {

		AdminClcoCtraModel updAdminClcoCtraModel = new AdminClcoCtraModel();
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		Date currentTime = new Date();
		cal.add(Calendar.DATE, 1);
		String newRescStrDt = format2.format(cal.getTime());
		int toDayDate = Integer.parseInt(format.format(currentTime));

		List<AdminClcoCtraModel> adminClcoCtraModelList = repository.selectClcoCtraHis(model);
		int updCnt = 0;
		for(int i=0; i<adminClcoCtraModelList.size(); i++) {
			AdminClcoCtraModel adminClcoCtraModel= adminClcoCtraModelList.get(i);

			if (i == 0) {
				// 미지원등급검진예약시작일자
				String unspGrdCuResvSrtDt = "";
				if (!ObjectUtils.isEmpty(adminClcoCtraModel.getUnspGrdCuResvSrtDt())) {
					if (Integer.parseInt(adminClcoCtraModel.getUnspGrdCuResvSrtDt()) <= toDayDate) {
						updCnt++;
						unspGrdCuResvSrtDt = newRescStrDt;
					}
				}

				// 임원검진예약시작일자
				String excuResvSrtDt = "";
				if (!ObjectUtils.isEmpty(adminClcoCtraModel.getExcuResvSrtDt())) {
					if (Integer.parseInt(adminClcoCtraModel.getExcuResvSrtDt()) <= toDayDate) {
						updCnt++;
						excuResvSrtDt = newRescStrDt;
					}
				}

				if (!ObjectUtils.isEmpty(unspGrdCuResvSrtDt) || !ObjectUtils.isEmpty(excuResvSrtDt)) {
					updAdminClcoCtraModel.setClcoCtraId(adminClcoCtraModel.getClcoCtraId());
					updAdminClcoCtraModel.setUnspGrdCuResvSrtDt(unspGrdCuResvSrtDt);
					updAdminClcoCtraModel.setExcuResvSrtDt(excuResvSrtDt);
					repository.updateClcoCtraHisResvSrtDt(updAdminClcoCtraModel);
				}
			}

			// 예약시작일자
			String resvSrtDt = "";
			if (!ObjectUtils.isEmpty(adminClcoCtraModel.getResvSrtDt())) {
				if (Integer.parseInt(adminClcoCtraModel.getResvSrtDt()) <= toDayDate) {
					updCnt++;
					resvSrtDt = newRescStrDt;
				}
			}

			// 임직원제외지원예약시작일자
			String aempExcsSuptResvSrtDt = "";
			if (!ObjectUtils.isEmpty(adminClcoCtraModel.getAempExcsSuptResvSrtDt())) {
				if (Integer.parseInt(adminClcoCtraModel.getAempExcsSuptResvSrtDt()) <= toDayDate) {
					updCnt++;
					aempExcsSuptResvSrtDt = newRescStrDt;
				}
			}

			// 특수검진예약시작일자
			String spcuResvSrtDt = "";
			if (!ObjectUtils.isEmpty(adminClcoCtraModel.getSpcuResvSrtDt())) {
				if (Integer.parseInt(adminClcoCtraModel.getSpcuResvSrtDt()) <= toDayDate) {
					updCnt++;
					spcuResvSrtDt = newRescStrDt;
				}
			}

			if (!ObjectUtils.isEmpty(resvSrtDt) || !ObjectUtils.isEmpty(aempExcsSuptResvSrtDt) || !ObjectUtils.isEmpty(spcuResvSrtDt)) {
				updAdminClcoCtraModel.setClcoId(adminClcoCtraModel.getClcoId());
				updAdminClcoCtraModel.setYr(adminClcoCtraModel.getYr());
				updAdminClcoCtraModel.setResvSrtDt(resvSrtDt);
				updAdminClcoCtraModel.setAempExcsSuptResvSrtDt(aempExcsSuptResvSrtDt);
				updAdminClcoCtraModel.setSpcuResvSrtDt(spcuResvSrtDt);
				repository.updateClcoBsplHisResvSrtDt(updAdminClcoCtraModel);
			}
		}
		return updCnt;
	}
}
