package com.gchc.ncu.bo.batchupload.models;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchUploadTemplateModel extends UstraManagementBaseModel {
	/* T_TMPL_FILE_HIS [헬스케어_템플릿파일내역] */
	@ApiModelProperty(value="템플릿파일아이디 NN")
	private Integer tmplFileId;
	@ApiModelProperty(value="템플릿파일명 NN")
	private String tmplFileNm;
	@ApiModelProperty(value="버전")
	private String ver;
	@ApiModelProperty(value="파일템플릿경로")
	private String fileTmplPath;
	@ApiModelProperty(value="최초등록일시 NN")
	private String frstRegDtm;
	@ApiModelProperty(value="최종수정일시 NN")
	private String lastUpdDtm;
}
