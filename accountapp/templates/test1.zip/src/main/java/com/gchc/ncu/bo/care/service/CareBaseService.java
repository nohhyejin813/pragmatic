package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gchc.ncu.bo.care.models.CareDssCdModel;
import com.gchc.ncu.bo.care.models.LifeStyleCdModel;
import com.gchc.ncu.bo.care.repository.CareBaseRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CareBaseService {

	private final CareBaseRepository careBaseRepository;

	public List<CareDssCdModel> getCareDiseaseCodeList() {
		return careBaseRepository.selectCareDiseaseCodeList();
	}

	public void saveCareDiseaseCode(CareDssCdModel model) {
		careBaseRepository.updateCareDiseaseCode(model);
	}

	public List<LifeStyleCdModel> getLifeStyleCodeList() {
		return careBaseRepository.selectLifeStyleCodeList();
	}

	public void saveLifeStyleCode(LifeStyleCdModel model) {
		careBaseRepository.updateLifeStyleCode(model);
	}

}
