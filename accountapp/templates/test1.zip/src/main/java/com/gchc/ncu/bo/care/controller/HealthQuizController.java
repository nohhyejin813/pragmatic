package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.HthQizBscModel;
import com.gchc.ncu.bo.care.service.HealthQuizService;
import com.gchc.ncu.bo.care.vo.HealthQuizVo;

@RestController
@RequestMapping("/api/bo/care/health-quiz")
@RequiredArgsConstructor
public class HealthQuizController {

	private final HealthQuizService service;

	@GetMapping("/healthQuizList")
	public List<HthQizBscModel> getHealthQuizList(@ModelAttribute HealthQuizVo in) {
		return service.getHealthQuizList(in);
	}

	@GetMapping("/healthQuizDetail")
	public HthQizBscModel getHealthQizDetail(@ModelAttribute HealthQuizVo in) {
		return service.getHealthQizDetail(in);
	}

	@PostMapping("/saveHealthQuiz")
	public RestResult<?> saveHealthQuiz(@RequestBody HthQizBscModel model) {
		int result = service.saveQuiz(model);

		return GchcRestResult.of(result, GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/deleteHealthQuiz")
	public RestResult<?> deleteHealthQuiz(@RequestBody List<HthQizBscModel> list) {
		service.deleteHealthQuiz(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}


}
