package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class PackageUploadExcelModel extends UstraManagementBaseModel {


	private int upldPkgId;

	private int pkgId;

	private int rnk;

	private String yr;

	private int cuiId;

	private int clcoId;

	private String pkgNm;

	private String sexCdNm;

	private String pkgBscPrcVal;

	private String cuiNm;

	private String prpPridSrtDt;

	private String prpPridEndDt;

	private String pkgRegStCd;

	private String pkgErrCont;

	private String pkgTyCont;

	private int useYn;

	private String fileGrpId;

	private String fileId;

	private int fileNo;
}
