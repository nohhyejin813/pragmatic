package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.comm.*;
import com.gchc.ncu.bo.batchupload.enu.*;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberTransferUploadRepository;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.config.GchcDataBatchExecutor;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Service
public class BatchMemberTransferUploadService {

	@Autowired private BatchMemberUploadRepository memberUploadRepository;

	@Autowired private BatchMemberTransferUploadRepository repository;

	@Autowired private GchcDataBatchExecutor batchExecutor;

	boolean isEmptyRow(Object src) {

		try {

			List<Method> mths = Arrays.asList(src.getClass().getDeclaredMethod("getAempNm"), src.getClass().getDeclaredMethod("getAempId"));
			return mths.stream().allMatch(mth->{

				try {

					return ObjectUtils.isEmpty(mth.invoke(src));
				}
				catch( Exception e ) {

					return true;
				}
			});
		}
		catch( Exception e ) {

			return true;
		}
	}

	String toString(Object obj) {

		if( ObjectUtils.isEmpty(obj) )
			return null;
		return obj.toString();
	}

	String getStr(Object src, String methodName, int num) throws Exception {

		return toString(src.getClass().getDeclaredMethod(methodName + num).invoke(src));
	}

	boolean isNotEmpty(Object src, String methodName, int num) {

		try {

			return StringUtils.isNotEmpty(getStr(src, methodName, num));
		}
		catch( Exception e ) {

			LOGGER.debug(e.getMessage());
		}
		return false;
	}

	String getFamilyStr(Object src, String key, int n) {

		try {

			return getStr(src, "get" + key + "Nm", n) +
				getStr(src, "get" + key + "Brdt", n) +
				getStr(src, "get" + key + "SexCd", n);
		}
		catch( Exception e ) {
			LOGGER.debug(e.getMessage());
		}
		return null;
	}

	Object makeBrdt(Object src) {

		Arrays.asList(src.getClass().getDeclaredMethods()).stream()
		.filter(m->m.getName().startsWith("get"))
		.filter(m->m.getName().contains("Brdt"))
		.forEach(m->{

			try {

				String brdt = BatchUploadUtils.formattedBrdt(Objects.toString(m.invoke(src)));
				Method setter = src.getClass().getDeclaredMethod(m.getName().replace("get", "set"), m.getReturnType());
				if( setter != null )
					setter.invoke(src, brdt);
			}
			catch( Exception e ) {

				LOGGER.debug(e.getMessage());
			}
		});
		return src;
	}

	long getFamilyCnt(BatchMemberUploadCustomerDetailModel src, String nm) {

		return IntStream.range(1,  10).boxed()
			.filter(n->isNotEmpty(src, "get" + nm + "Nm", n) ||
				isNotEmpty(src, "get" + nm + "Brdt", n) ||
				isNotEmpty(src, "get" + nm + "SexCd", n))
			.count();
	}

	boolean isMatch(BatchMemberUploadCustomerDetailModel target, BatchUploadTransferFamilyExcelModel family) {

		return target.getAempNm().equals(family.getAempNm()) && target.getAempId().equals(family.getAempId());
	}

	boolean isMatch(BatchMemberUploadCustomerDetailModel target, BatchUploadMultiFamilyExcelModel family) {

		return target.getAempNm().equals(family.getAempNm()) && target.getAempId().equals(family.getAempId());
	}

	BatchMemberUploadCustomerDetailModel connect(BatchMemberUploadCustomerDetailModel target,
		List<BatchUploadTransferFamilyExcelModel> familyList, List<BatchUploadMultiFamilyExcelModel> familyList2) {

		return BatchUploadUtils.copy(BatchUploadUtils.copy(target,
			familyList.stream().filter(r->isMatch(target, r)).findFirst().orElse(null)),
			familyList2.stream().filter(r->isMatch(target, r)).findFirst().orElse(null));
	}

	void checkDetailError(BatchMemberUploadCustomerDetailModel src, boolean result, BatchMemberUploadError error, Object...args) {

		if( !result ) {

			src.setUpldStVal(error.getErrorValue());
			src.setUpldErrVal(src.getUpldErrVal().concat(("|") + error.getMessage(args)));
		}
	}

	List<BatchMemberUploadCustomerDetailModel> errorMsg(List<BatchMemberUploadCustomerDetailModel> errList) {

		return errList.stream()
			.map(e->{
				String errMsg = e.getUpldErrVal();
				if( StringUtils.isEmpty(errMsg) )
					return e;
				errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
				e.setUpldErrVal(errMsg.replace("|", "\r\n"));
				return e;
			})
			.collect(Collectors.toList());
	}

	BatchMemberUploadCustomerDetailModel validate(BatchMemberUploadCustomerDetailModel src) {

		// 오류 초기화
		src.setUpldStVal(1);
		src.setUpldErrVal("");

		// 생년월일, 성별 체크
		Arrays.asList(src.getClass().getDeclaredMethods()).stream()
		.filter(m->m.getName().startsWith("get"))
		.filter(m->m.getName().contains("Brdt"))
		.forEach(m->{

			try {

				String brdt = BatchUploadUtils.toString(m.invoke(src));
				if( StringUtils.isEmpty(brdt) )
					return;
				boolean validBrdt = BatchUploadUtils.checkBrdt(brdt);
				checkDetailError(src, validBrdt, BatchMemberUploadError.INVALID_INFORMATION, "가족" + m.getName().substring(m.getName().length() - 1) + "생년월일");
				if( Optional.ofNullable(brdt).map(String::length).orElse(0) > 10 ) {

					Method brdtSetter = src.getClass().getDeclaredMethod(m.getName().replace("get", "set"), m.getReturnType());
					Method sexSetter = src.getClass().getDeclaredMethod(m.getName().replace("get", "set").replace("Brdt", "SexCd"), m.getReturnType());
					sexSetter.invoke(src, brdt.substring(10));
					brdtSetter.invoke(src, brdt.subSequence(0, 10));
				}
			}
			catch( Exception e ) {
				LOGGER.debug(e.getMessage());
			}
		});

		// 임직원 이름, 사번 체크
		checkDetailError(src, StringUtils.isNotEmpty(src.getAempNm()), BatchMemberUploadError.MISSING_INFORMATION, "이름");
		checkDetailError(src, StringUtils.isNotEmpty(src.getAempId()), BatchMemberUploadError.MISSING_INFORMATION, "사번");

		// 각 정책 사용여부 default
		src.setTnsfYn(src.getTnsfYn() == null ? 0 : src.getTnsfYn());
		src.setSlctSpfnUseYn(src.getSlctSpfnUseYn() == null ? 0 : src.getSlctSpfnUseYn());
		src.setMltiYn(src.getMltiYn() == null ? 0 : src.getMltiYn());

		// 양도 정책을 사용하지 않는 고객사 & 양도여부 Y
		checkDetailError(src, ClcoCtraContextHolder.get().getTnsfSpfnUseYn() == 1 || src.getTnsfYn() == 0,
			BatchMemberUploadError.NO_SUPPORT_TNSF);

		// 양도 그룹이 설정되지 않은 고객사 & 양도여부Y
		if( src.getTnsfYn() != 0 && SupportedFuncGroupContextHolder.isEmpty(SpfnGrpType.TRANSFER) )
			BatchResponseCode.NOT_REGISTERED_TRANSFER_GROUP.occur();

		List<String> targets = new ArrayList<>();

		// 양도여부 Y & 양도 그룹명 존재
		if( ClcoCtraContextHolder.get().getTnsfSpfnUseYn() == 1 && src.getTnsfYn() == 1 &&
			StringUtils.isNotEmpty(src.getSpfnTnsfGrpNm()) ) {

			// 양도 그룹명 체크
			SpfnGrpInfModel inf = SupportedFuncGroupContextHolder.get(SpfnGrpType.TRANSFER, src.getSpfnTnsfGrpNm());
			if( inf != null )
				src.setSpfnTnsfGrpId(inf.getGrpId());
			else
				checkDetailError(src, false, BatchMemberUploadError.INVALID_INFORMATION, "양도 그룹명");

			checkDetailError(src, StringUtils.isNotEmpty(src.getFmlyGrdNm()), BatchMemberUploadError.MISSING_INFORMATION, "가족 등급");

			// 가족 등급 체크
			if( StringUtils.isNotEmpty(src.getFmlyGrdNm()) ) {

				checkDetailError(src, BatchUploadUtils.strIn(src.getFmlyGrdNm(), MemberGradeContextHolder.get().stream()
					.filter(g->StringUtils.isEmpty(g.getSuptTgtDvCd()) || "20".equals(g.getSuptTgtDvCd()))
					.filter(g->g.getSelfYn() == 0)
					.filter(g->g.getCorpSuptYn() == 1)
					.map(g->g.getGrdNm())
					.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "가족 등급");
				src.setFmlyGrdId(MemberGradeContextHolder.get().stream()
					.filter(g->g.getGrdNm().equals(src.getFmlyGrdNm()))
					.findFirst()
					.map(SupportGradeModel::getMbrGrdId)
					.orElse(null));
			}

			// 10명의 대상자 정보 중 이름, 생년월일, 성별 중 하나라도 값이 있는 경우
			List<Integer> nums = IntStream.range(1, 10).boxed()
			.filter(n->isNotEmpty(src, "getTnsfTgtFmlyNm", n) ||
				isNotEmpty(src, "getTnsfTgtFmlyBrdt", n) ||
				isNotEmpty(src, "getTnsfTgtFmlySexCd", n))
			.collect(Collectors.toList());

			// 누락된 정보가 있는 지 체크
			if( CollectionUtils.isNotEmpty(nums) ) {

				checkDetailError(src, nums.stream().anyMatch(n->isNotEmpty(src, "getTnsfTgtFmlyNm", n)),
					BatchMemberUploadError.MISSING_INFORMATION, "양도대상자 가족이름");
				checkDetailError(src, nums.stream().anyMatch(n->isNotEmpty(src, "getTnsfTgtFmlyBrdt", n)),
					BatchMemberUploadError.MISSING_INFORMATION, "양도대상자 가족생년월일");
				checkDetailError(src, nums.stream().anyMatch(n->isNotEmpty(src, "getTnsfTgtFmlySexCd", n)),
					BatchMemberUploadError.MISSING_INFORMATION, "양도대상자 가족성별");
			}

			// 중복체크를 위해 이름+생년월일+성별코드 문자열 list에 저장
			targets.addAll(nums.stream().map(n->getFamilyStr(src, "TnsfTgtFmly", n)).collect(Collectors.toList()));
		}

		// 선택 정책을 사용하지 않는 고객사 & 선택여부 Y
		checkDetailError(src, ClcoCtraContextHolder.get().getSlctSpfnUseYn() == 1 || src.getSlctSpfnUseYn() == 0,
			BatchMemberUploadError.NO_SUPPORT_SLCT);

		// 선택 그룹이 설정되지 않은 고객사 & 양도여부Y
		if( src.getSlctSpfnUseYn() != 0 && SupportedFuncGroupContextHolder.isEmpty(SpfnGrpType.SELECT) )
			BatchResponseCode.NOT_REGISTERED_SELECT_GROUP.occur();

		// 선택여부 Y & 선택 그룹명 존재
		if( ClcoCtraContextHolder.get().getSlctSpfnUseYn() == 1 && src.getSlctSpfnUseYn() == 1 &&
			StringUtils.isNotEmpty(src.getSlctSpfnSuptSlctGrpNm()) ) {

			// 선택 그룹명 체크
			SpfnGrpInfModel inf = SupportedFuncGroupContextHolder.get(SpfnGrpType.SELECT, src.getSlctSpfnSuptSlctGrpNm());
			if( inf != null )
				src.setSlctSpfnSuptSlctGrpId(inf.getGrpId());
			else
				checkDetailError(src, false, BatchMemberUploadError.INVALID_INFORMATION, "선택 그룹명");
		}

		// 다중지원을 사용하지 않는 고객사 & 다중여부 Y
		checkDetailError(src, ClcoCtraContextHolder.get().getTnsfTgtrSlctRngCd().equals("2") || src.getMltiYn() == 0,
			BatchMemberUploadError.NO_SUPPORT_MULTI);

		// 다중여부 Y
		if( ClcoCtraContextHolder.get().getTnsfTgtrSlctRngCd().equals("2") && src.getMltiYn() == 1 ) {

			// 패키지명, 가족등급 누락 체크
			checkDetailError(src, StringUtils.isNotEmpty(src.getPkgNm()), BatchMemberUploadError.MISSING_INFORMATION, "패키지");
			checkDetailError(src, StringUtils.isNotEmpty(src.getFmlyGrdNm()), BatchMemberUploadError.MISSING_INFORMATION, "가족 등급");

			// 지원자 수, 지원금 체크
			checkDetailError(src, BatchUploadUtils.numIn(src.getMltiSlctTgtrCnt(), 1, 2),
				BatchMemberUploadError.INVALID_INFORMATION, "다중 지원자 수");
			checkDetailError(src, BatchUploadUtils.numIn(src.getCorpSpfn(), src.getMltiSlctTgtrCnt() * 1000, Integer.MAX_VALUE),
				BatchMemberUploadError.INVALID_INFORMATION, "다중 지원금");

			// 가족 등급 체크
			if( StringUtils.isNotEmpty(src.getFmlyGrdNm()) ) {

				checkDetailError(src, BatchUploadUtils.strIn(src.getFmlyGrdNm(), MemberGradeContextHolder.get().stream()
					.filter(g->StringUtils.isEmpty(g.getSuptTgtDvCd()) || "20".equals(g.getSuptTgtDvCd()))
					.filter(g->g.getSelfYn() == 0)
					.filter(g->g.getCorpSuptYn() == 1)
					.map(g->g.getGrdNm())
					.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "가족 등급");
				src.setFmlyGrdId(MemberGradeContextHolder.get().stream()
					.filter(g->g.getGrdNm().equals(src.getFmlyGrdNm()))
					.findFirst()
					.map(SupportGradeModel::getMbrGrdId)
					.orElse(null));
			}

			// 패키지명 체크
			checkDetailError(src, StringUtils.isEmpty(src.getPkgNm()) ||
				!ObjectUtils.isEmpty(PackageContextHolder.get(src.getPkgNm())), BatchMemberUploadError.INVALID_MULTI_PACKAGE);

			// 10명의 대상자 정보 중 이름, 생년월일, 성별 중 하나라도 값이 있는 경우
			List<Integer> nums = IntStream.range(1, 10).boxed()
				.filter(n->isNotEmpty(src, "getFmlyNm", n) ||
					isNotEmpty(src, "getFmlyBrdt", n) ||
					isNotEmpty(src, "getFmlySexCd", n))
				.collect(Collectors.toList());

			// 누락된 정보가 있는 지 체크
			if( CollectionUtils.isNotEmpty(nums) ) {

				checkDetailError(src, nums.stream().anyMatch(n->isNotEmpty(src, "getFmlyNm", n)),
					BatchMemberUploadError.MISSING_INFORMATION, "다중대상자 가족이름");
				checkDetailError(src, nums.stream().anyMatch(n->isNotEmpty(src, "getFmlyBrdt", n)),
					BatchMemberUploadError.MISSING_INFORMATION, "다중대상자 가족생년월일");
				checkDetailError(src, nums.stream().anyMatch(n->isNotEmpty(src, "getFmlySexCd", n)),
					BatchMemberUploadError.MISSING_INFORMATION, "다중대상자 가족성별");
			}

			// 중복체크를 위해 이름+생년월일+성별코드 문자열 list에 저장
			targets.addAll(nums.stream().map(n->getFamilyStr(src, "Fmly", n)).collect(Collectors.toList()));
		}

		// 가족 중복 체크
		checkDetailError(src, targets.stream().allMatch(new HashSet<>()::add), BatchMemberUploadError.DUPLICATED_FAMILY);

		return src;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void memberValidate(Map<Object, List<RowInfo>> converted, Integer clcoId, Integer yr) {

		final int mngrId = BatchUploadUtils.getCurrentMngrId();

		// 헤더 영역 체크
		Map<Object, Map<String, Object>> headerRows = new HashMap<>();
		converted.entrySet().forEach(e->{

			headerRows.put(e.getKey(), (Map<String, Object>)e.getValue().get(0).getObject());
			if( e.getKey().equals(0) ) {

				String missed = BatchUploadColumn.stream(TransferAempColumn.class)
					.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRows.get(e.getKey()).values()))
					.findFirst()
					.map(BatchUploadColumn::getTitle)
					.orElse(null);
				if( StringUtils.isNotEmpty(missed) )
					BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);
			}
			else {

				String missed = BatchUploadColumn.stream(TransferFamilyColumn.class)
					.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRows.get(e.getKey()).values()))
					.findFirst()
					.map(BatchUploadColumn::getTitle)
					.orElse(null);
				if( StringUtils.isNotEmpty(missed) )
					BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);
			}
		});

		// 빈 ROW 삭제 및 값 설정
		List<BatchUploadTransferExcelModel> aempList = converted.get(0).subList(1, converted.get(0).size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
			.map(r->{

				BatchUploadTransferExcelModel o = BatchUploadUtils.map((Map<String, Object>)r.getObject(),
					headerRows.get(0), BatchUploadColumn.table(TransferAempColumn.class), BatchUploadTransferExcelModel.class);
				o.setClcoId(clcoId);
				o.setYr(yr);
				return o;
			})
			.filter(r->!isEmptyRow(r))
			.collect(Collectors.toList());

		if( CollectionUtils.isEmpty(aempList) )
			BatchResponseCode.INVALID_SHEET.occur();

		// 검색조건 설정
		SearchMapContextHolder.set(UstraMapUtils.getMap(
			"clcoId", clcoId,
			"yr", yr,
			"mngrId", mngrId));

		// 지원 등급, 패키지, 고객사 계약 정보, 양도/선택 그룹 정보 조회
		MemberGradeContextHolder.set(memberUploadRepository.getMemberGradeList(SearchMapContextHolder.get()));
		PackageContextHolder.set(memberUploadRepository.getPackageList(SearchMapContextHolder.get()));
		ClcoCtraContextHolder.set(repository.getClcoCtraInfo(SearchMapContextHolder.get()));
		SupportedFuncGroupContextHolder.clear();
		SupportedFuncGroupContextHolder.add(SpfnGrpType.TRANSFER, repository.getSpfnGrpList(SearchMapContextHolder.get()));
		SupportedFuncGroupContextHolder.add(SpfnGrpType.SELECT, repository.getSpfnSlctGrpList(SearchMapContextHolder.get()));

		// 양도대상자 목록
		List<BatchUploadTransferFamilyExcelModel> tnsfFmlyList = converted.get(1).subList(1, converted.get(1).size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
			.map(r->(BatchUploadTransferFamilyExcelModel)makeBrdt(BatchUploadUtils.map((Map<String, Object>)r.getObject(),
				headerRows.get(1), BatchUploadColumn.table(TransferFamilyColumn.class), BatchUploadTransferFamilyExcelModel.class)))
			.filter(r->!isEmptyRow(r))
			.collect(Collectors.toList());

		// 다중대상자 목록
		List<BatchUploadMultiFamilyExcelModel> mltiFmlyList = converted.get(2).subList(1, converted.get(2).size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
			.map(r->(BatchUploadMultiFamilyExcelModel)makeBrdt(BatchUploadUtils.map((Map<String, Object>)r.getObject(),
				headerRows.get(2), BatchUploadColumn.table(TransferMultiColumn.class), BatchUploadMultiFamilyExcelModel.class)))
			.filter(r->!isEmptyRow(r))
			.collect(Collectors.toList());

		// 업로드 초기화
		repository.updateClcoAempDtlBlkRegTmpUploadYn(SearchMapContextHolder.get());

		// 신규 등록 대상 추출
		List<BatchMemberUploadCustomerDetailModel> forInsert = aempList.stream()
			.filter(c->StringUtils.isEmpty(c.getAempDtlRegSeq()))
			.map(c->validate(connect(BatchUploadUtils.map(c, BatchMemberUploadCustomerDetailModel.class), tnsfFmlyList, mltiFmlyList)))
			.collect(Collectors.toList());

		// 업데이트 대상 추출
		List<BatchMemberUploadCustomerDetailModel> forUpdate = new ArrayList<>();
		List<BatchUploadTransferExcelModel> checkUpdate = aempList.stream()
			.filter(c->StringUtils.isNotEmpty(c.getAempDtlRegSeq()))
			.collect(Collectors.toList());
		if( CollectionUtils.isNotEmpty(checkUpdate) ) {

			List<BatchMemberUploadCustomerDetailModel> checked = repository.getClcoAempDtlBlkRegTmpForUpdate(UstraMapUtils.getMap(
				"clcoId", clcoId,
				"yr", yr,
				"mngrId", mngrId,
				"list", checkUpdate));
			forUpdate = checkUpdate.stream()
				.filter(c->checked.stream().anyMatch(ch->c.getAempDtlRegSeq().equals("" + ch.getAempDtlRegSeq())))
				.map(c->validate(connect(BatchUploadUtils.map(c, BatchMemberUploadCustomerDetailModel.class), tnsfFmlyList, mltiFmlyList)))
				.collect(Collectors.toList());

			forInsert.addAll(checkUpdate.stream()
				.filter(c->checked.stream().noneMatch(ch->c.getAempDtlRegSeq().equals("" + ch.getAempDtlRegSeq())))
				.map(c->validate(connect(BatchUploadUtils.map(c, BatchMemberUploadCustomerDetailModel.class), tnsfFmlyList, mltiFmlyList)))
				.collect(Collectors.toList()));
		}

		// 신규 등록
		int aempDtlRegSeq = repository.getAempDtlBlkRegTmpNextSeq(SearchMapContextHolder.get());
		for( int i=0; i<forInsert.size(); i++ ) {

			forInsert.get(i).setAempDtlRegSeq(aempDtlRegSeq++);
			forInsert.get(i).setMngrId(forInsert.get(i).getAdminUserMngrId());
		}

		batchExecutor.batchUpdate(
			"INSERT INTO MBR.T_CLCO_AEMP_DTL_BLK_REG_TMP (\r\n" +
			"	  CLCO_ID\r\n" +
			"	, YR\r\n" +
			"	, CU_TGT_ID\r\n" +
			"	, AEMP_DTL_REG_SEQ\r\n" +
			"	, AEMP_NM\r\n" +
			"	, AEMP_GRD_NM\r\n" +
			"	, AEMP_ID\r\n" +
			"	, TNSF_YN\r\n" +
			"	, SPFN_TNSF_GRP_NM\r\n" +
			"	, SPFN_TNSF_GRP_ID\r\n" +
			"	, SLCT_SPFN_USE_YN\r\n" +
			"	, SLCT_SPFN_SUPT_SLCT_GRP_NM\r\n" +
			"	, SLCT_SPFN_SUPT_SLCT_GRP_ID\r\n" +
			"	, MLTI_YN\r\n" +
			"	, PKG_NM\r\n" +
			"	, CORP_SPFN\r\n" +
			"	, MLTI_SLCT_TGTR_CNT\r\n" +
			"	, FMLY_GRD_NM\r\n" +
			"	, FMLY_GRD_ID\r\n" +
			"	, FMLY_NM1\r\n" +
			"	, FMLY_BRDT1\r\n" +
			"	, FMLY_SEX_CD1\r\n" +
			"	, FMLY_NM2\r\n" +
			"	, FMLY_BRDT2\r\n" +
			"	, FMLY_SEX_CD2\r\n" +
			"	, FMLY_NM3\r\n" +
			"	, FMLY_BRDT3\r\n" +
			"	, FMLY_SEX_CD3\r\n" +
			"	, FMLY_NM4\r\n" +
			"	, FMLY_BRDT4\r\n" +
			"	, FMLY_SEX_CD4\r\n" +
			"	, FMLY_NM5\r\n" +
			"	, FMLY_BRDT5\r\n" +
			"	, FMLY_SEX_CD5\r\n" +
			"	, FMLY_NM6\r\n" +
			"	, FMLY_BRDT6\r\n" +
			"	, FMLY_SEX_CD6\r\n" +
			"	, FMLY_NM7\r\n" +
			"	, FMLY_BRDT7\r\n" +
			"	, FMLY_SEX_CD7\r\n" +
			"	, FMLY_NM8\r\n" +
			"	, FMLY_BRDT8\r\n" +
			"	, FMLY_SEX_CD8\r\n" +
			"	, FMLY_NM9\r\n" +
			"	, FMLY_BRDT9\r\n" +
			"	, FMLY_SEX_CD9\r\n" +
			"	, FMLY_NM10\r\n" +
			"	, FMLY_BRDT10\r\n" +
			"	, FMLY_SEX_CD10\r\n" +
			"	, TNSF_TGT_FMLY_NM1\r\n" +
			"	, TNSF_TGT_FMLY_BRDT1\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD1\r\n" +
			"	, TNSF_TGT_FMLY_NM2\r\n" +
			"	, TNSF_TGT_FMLY_BRDT2\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD2\r\n" +
			"	, TNSF_TGT_FMLY_NM3\r\n" +
			"	, TNSF_TGT_FMLY_BRDT3\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD3\r\n" +
			"	, TNSF_TGT_FMLY_NM4\r\n" +
			"	, TNSF_TGT_FMLY_BRDT4\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD4\r\n" +
			"	, TNSF_TGT_FMLY_NM5\r\n" +
			"	, TNSF_TGT_FMLY_BRDT5\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD5\r\n" +
			"	, TNSF_TGT_FMLY_NM6\r\n" +
			"	, TNSF_TGT_FMLY_BRDT6\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD6\r\n" +
			"	, TNSF_TGT_FMLY_NM7\r\n" +
			"	, TNSF_TGT_FMLY_BRDT7\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD7\r\n" +
			"	, TNSF_TGT_FMLY_NM8\r\n" +
			"	, TNSF_TGT_FMLY_BRDT8\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD8\r\n" +
			"	, TNSF_TGT_FMLY_NM9\r\n" +
			"	, TNSF_TGT_FMLY_BRDT9\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD9\r\n" +
			"	, TNSF_TGT_FMLY_NM10\r\n" +
			"	, TNSF_TGT_FMLY_BRDT10\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD10\r\n" +
			"	, UPLD_YN\r\n" +
			"	, MNGR_ID\r\n" +
			"	, USE_YN\r\n" +
			"	, DEL_YN\r\n" +
			"	, UPLD_ST_VAL\r\n" +
			"	, UPLD_ERR_VAL\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			")\r\n" +
			"VALUES (\r\n" +
			"	  #{clcoId}\r\n" +
			"	, #{yr}\r\n" +
			"	, 0\r\n" +
			"	, #{aempDtlRegSeq}\r\n" +
			"	, #{aempNm}\r\n" +
			"	, #{aempGrdNm}\r\n" +
			"	, #{aempId}\r\n" +
			"	, #{tnsfYn}\r\n" +
			"	, #{spfnTnsfGrpNm}\r\n" +
			"	, #{spfnTnsfGrpId}\r\n" +
			"	, #{slctSpfnUseYn}\r\n" +
			"	, #{slctSpfnSuptSlctGrpNm}\r\n" +
			"	, #{slctSpfnSuptSlctGrpId}\r\n" +
			"	, #{mltiYn}\r\n" +
			"	, #{pkgNm}\r\n" +
			"	, #{corpSpfn}\r\n" +
			"	, #{mltiSlctTgtrCnt}\r\n" +
			"	, #{fmlyGrdNm}\r\n" +
			"	, #{fmlyGrdId}\r\n" +
			"	, #{fmlyNm1}\r\n" +
			"	, #{fmlyBrdt1}\r\n" +
			"	, #{fmlySexCd1}\r\n" +
			"	, #{fmlyNm2}\r\n" +
			"	, #{fmlyBrdt2}\r\n" +
			"	, #{fmlySexCd2}\r\n" +
			"	, #{fmlyNm3}\r\n" +
			"	, #{fmlyBrdt3}\r\n" +
			"	, #{fmlySexCd3}\r\n" +
			"	, #{fmlyNm4}\r\n" +
			"	, #{fmlyBrdt4}\r\n" +
			"	, #{fmlySexCd4}\r\n" +
			"	, #{fmlyNm5}\r\n" +
			"	, #{fmlyBrdt5}\r\n" +
			"	, #{fmlySexCd5}\r\n" +
			"	, #{fmlyNm6}\r\n" +
			"	, #{fmlyBrdt6}\r\n" +
			"	, #{fmlySexCd6}\r\n" +
			"	, #{fmlyNm7}\r\n" +
			"	, #{fmlyBrdt7}\r\n" +
			"	, #{fmlySexCd7}\r\n" +
			"	, #{fmlyNm8}\r\n" +
			"	, #{fmlyBrdt8}\r\n" +
			"	, #{fmlySexCd8}\r\n" +
			"	, #{fmlyNm9}\r\n" +
			"	, #{fmlyBrdt9}\r\n" +
			"	, #{fmlySexCd9}\r\n" +
			"	, #{fmlyNm10}\r\n" +
			"	, #{fmlyBrdt10}\r\n" +
			"	, #{fmlySexCd10}\r\n" +
			"	, #{tnsfTgtFmlyNm1}\r\n" +
			"	, #{tnsfTgtFmlyBrdt1}\r\n" +
			"	, #{tnsfTgtFmlySexCd1}\r\n" +
			"	, #{tnsfTgtFmlyNm2}\r\n" +
			"	, #{tnsfTgtFmlyBrdt2}\r\n" +
			"	, #{tnsfTgtFmlySexCd2}\r\n" +
			"	, #{tnsfTgtFmlyNm3}\r\n" +
			"	, #{tnsfTgtFmlyBrdt3}\r\n" +
			"	, #{tnsfTgtFmlySexCd3}\r\n" +
			"	, #{tnsfTgtFmlyNm4}\r\n" +
			"	, #{tnsfTgtFmlyBrdt4}\r\n" +
			"	, #{tnsfTgtFmlySexCd4}\r\n" +
			"	, #{tnsfTgtFmlyNm5}\r\n" +
			"	, #{tnsfTgtFmlyBrdt5}\r\n" +
			"	, #{tnsfTgtFmlySexCd5}\r\n" +
			"	, #{tnsfTgtFmlyNm6}\r\n" +
			"	, #{tnsfTgtFmlyBrdt6}\r\n" +
			"	, #{tnsfTgtFmlySexCd6}\r\n" +
			"	, #{tnsfTgtFmlyNm7}\r\n" +
			"	, #{tnsfTgtFmlyBrdt7}\r\n" +
			"	, #{tnsfTgtFmlySexCd7}\r\n" +
			"	, #{tnsfTgtFmlyNm8}\r\n" +
			"	, #{tnsfTgtFmlyBrdt8}\r\n" +
			"	, #{tnsfTgtFmlySexCd8}\r\n" +
			"	, #{tnsfTgtFmlyNm9}\r\n" +
			"	, #{tnsfTgtFmlyBrdt9}\r\n" +
			"	, #{tnsfTgtFmlySexCd9}\r\n" +
			"	, #{tnsfTgtFmlyNm10}\r\n" +
			"	, #{tnsfTgtFmlyBrdt10}\r\n" +
			"	, #{tnsfTgtFmlySexCd10}\r\n" +
			"	, #{upldYn}\r\n" +
			"	, #{mngrId}\r\n" +
			"	, 1\r\n" +
			"	, 0\r\n" +
			"	, #{upldStVal}\r\n" +
			"	, #{upldErrVal}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			")", forInsert);
//		int index = 0;
//		while( index < forInsert.size() ) {
//
//			repository.insertClcoAempDtlBlkRegTmp(BatchUploadUtils.bulkInsert(forInsert, index, 35));
//			index += 35;
//		}

		// 업데이트
		forUpdate.forEach(c->c.setMngrId(c.getAdminUserMngrId()));
		batchExecutor.batchUpdate(
			"UPDATE MBR.T_CLCO_AEMP_DTL_BLK_REG_TMP\r\n" +
			"SET  CLCO_ID = #{clcoId}\r\n" +
			"	, YR = #{yr}\r\n" +
			"	, AEMP_DTL_REG_SEQ = #{aempDtlRegSeq}\r\n" +
			"	, AEMP_NM = #{aempNm}\r\n" +
			"	, AEMP_GRD_NM = #{aempGrdNm}\r\n" +
			"	, AEMP_ID = #{aempId}\r\n" +
			"	, TNSF_YN = #{tnsfYn}\r\n" +
			"	, SPFN_TNSF_GRP_NM = #{spfnTnsfGrpNm}\r\n" +
			"	, SPFN_TNSF_GRP_ID = #{spfnTnsfGrpId}\r\n" +
			"	, SLCT_SPFN_USE_YN = #{slctSpfnUseYn}\r\n" +
			"	, SLCT_SPFN_SUPT_SLCT_GRP_NM = #{slctSpfnSuptSlctGrpNm}\r\n" +
			"	, SLCT_SPFN_SUPT_SLCT_GRP_ID = #{slctSpfnSuptSlctGrpId}\r\n" +
			"	, MLTI_YN = #{mltiYn}\r\n" +
			"	, PKG_NM = #{pkgNm}\r\n" +
			"	, CORP_SPFN = #{corpSpfn}\r\n" +
			"	, MLTI_SLCT_TGTR_CNT = #{mltiSlctTgtrCnt}\r\n" +
			"	, FMLY_GRD_NM = #{fmlyGrdNm}\r\n" +
			"	, FMLY_GRD_ID = #{fmlyGrdId}\r\n" +
			"	, FMLY_NM1 = #{fmlyNm1}\r\n" +
			"	, FMLY_BRDT1 = #{fmlyBrdt1}\r\n" +
			"	, FMLY_SEX_CD1 = #{fmlySexCd1}\r\n" +
			"	, FMLY_NM2 = #{fmlyNm2}\r\n" +
			"	, FMLY_BRDT2 = #{fmlyBrdt2}\r\n" +
			"	, FMLY_SEX_CD2 = #{fmlySexCd2}\r\n" +
			"	, FMLY_NM3 = #{fmlyNm3}\r\n" +
			"	, FMLY_BRDT3 = #{fmlyBrdt3}\r\n" +
			"	, FMLY_SEX_CD3 = #{fmlySexCd3}\r\n" +
			"	, FMLY_NM4 = #{fmlyNm4}\r\n" +
			"	, FMLY_BRDT4 = #{fmlyBrdt4}\r\n" +
			"	, FMLY_SEX_CD4 = #{fmlySexCd4}\r\n" +
			"	, FMLY_NM5 = #{fmlyNm5}\r\n" +
			"	, FMLY_BRDT5 = #{fmlyBrdt5}\r\n" +
			"	, FMLY_SEX_CD5 = #{fmlySexCd5}\r\n" +
			"	, FMLY_NM6 = #{fmlyNm6}\r\n" +
			"	, FMLY_BRDT6 = #{fmlyBrdt6}\r\n" +
			"	, FMLY_SEX_CD6 = #{fmlySexCd6}\r\n" +
			"	, FMLY_NM7 = #{fmlyNm7}\r\n" +
			"	, FMLY_BRDT7 = #{fmlyBrdt7}\r\n" +
			"	, FMLY_SEX_CD7 = #{fmlySexCd7}\r\n" +
			"	, FMLY_NM8 = #{fmlyNm8}\r\n" +
			"	, FMLY_BRDT8 = #{fmlyBrdt8}\r\n" +
			"	, FMLY_SEX_CD8 = #{fmlySexCd8}\r\n" +
			"	, FMLY_NM9 = #{fmlyNm9}\r\n" +
			"	, FMLY_BRDT9 = #{fmlyBrdt9}\r\n" +
			"	, FMLY_SEX_CD9 = #{fmlySexCd9}\r\n" +
			"	, FMLY_NM10 = #{fmlyNm10}\r\n" +
			"	, FMLY_BRDT10 = #{fmlyBrdt10}\r\n" +
			"	, FMLY_SEX_CD10 = #{fmlySexCd10}\r\n" +
			"	, TNSF_TGT_FMLY_NM1 = #{tnsfTgtFmlyNm1}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT1 = #{tnsfTgtFmlyBrdt1}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD1 = #{tnsfTgtFmlySexCd1}\r\n" +
			"	, TNSF_TGT_FMLY_NM2 = #{tnsfTgtFmlyNm2}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT2 = #{tnsfTgtFmlyBrdt2}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD2 = #{tnsfTgtFmlySexCd2}\r\n" +
			"	, TNSF_TGT_FMLY_NM3 = #{tnsfTgtFmlyNm3}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT3 = #{tnsfTgtFmlyBrdt3}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD3 = #{tnsfTgtFmlySexCd3}\r\n" +
			"	, TNSF_TGT_FMLY_NM4 = #{tnsfTgtFmlyNm4}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT4 = #{tnsfTgtFmlyBrdt4}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD4 = #{tnsfTgtFmlySexCd4}\r\n" +
			"	, TNSF_TGT_FMLY_NM5 = #{tnsfTgtFmlyNm5}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT5 = #{tnsfTgtFmlyBrdt5}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD5 = #{tnsfTgtFmlySexCd5}\r\n" +
			"	, TNSF_TGT_FMLY_NM6 = #{tnsfTgtFmlyNm6}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT6 = #{tnsfTgtFmlyBrdt6}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD6 = #{tnsfTgtFmlySexCd6}\r\n" +
			"	, TNSF_TGT_FMLY_NM7 = #{tnsfTgtFmlyNm7}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT7 = #{tnsfTgtFmlyBrdt7}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD7 = #{tnsfTgtFmlySexCd7}\r\n" +
			"	, TNSF_TGT_FMLY_NM8 = #{tnsfTgtFmlyNm8}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT8 = #{tnsfTgtFmlyBrdt8}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD8 = #{tnsfTgtFmlySexCd8}\r\n" +
			"	, TNSF_TGT_FMLY_NM9 = #{tnsfTgtFmlyNm9}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT9 = #{tnsfTgtFmlyBrdt9}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD9 = #{tnsfTgtFmlySexCd9}\r\n" +
			"	, TNSF_TGT_FMLY_NM10 = #{tnsfTgtFmlyNm10}\r\n" +
			"	, TNSF_TGT_FMLY_BRDT10 = #{tnsfTgtFmlyBrdt10}\r\n" +
			"	, TNSF_TGT_FMLY_SEX_CD10 = #{tnsfTgtFmlySexCd10}\r\n" +
			"	, UPLD_YN = 1\r\n" +
			"	, MNGR_ID = #{mngrId}\r\n" +
			"	, DEL_YN = 0\r\n" +
			"	, UPLD_ST_VAL = #{upldStVal}\r\n" +
			"	, UPLD_ERR_VAL = #{upldErrVal}\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPDR_ID = #{mngrId}\r\n" +
			"WHERE 1=1\r\n" +
			"	AND YR = #{yr}\r\n" +
			"	AND CLCO_ID = #{clcoId}\r\n" +
			"	AND AEMP_DTL_REG_SEQ = #{aempDtlRegSeq}", forUpdate);

		// 고객사 내 중복 체크
		repository.updateClcoAempDtlBlkRegTmpValidate(SearchMapContextHolder.get());

		// CU_TGT_ID 설정
		repository.updateClcoAempDtlBlkRegTmpTgtId(SearchMapContextHolder.get());

		// CU_TGT_ID 가 없는 경우 오류 (회원 정보를 찾을 수 없습니다.)
		repository.updateClcoAempDtlBlkRegTmpValidate2(SearchMapContextHolder.get());

		// 양도가능 등급 체크
		repository.updateClcoAempDtlBlkRegTmpValidateGrd(SearchMapContextHolder.get());

		// 이미 존재하는 가족 정보 체크
		repository.updateClcoAempDtlBlkRegTmpValidate3(SearchMapContextHolder.get());

		// 공단 비대상 연도만 양도 가능한 경우  체크
		if( "2".equals(ClcoCtraContextHolder.get().getSpfnTnsfDvCd()) )
			repository.updateClcoAempDtlBlkRegTmpValidate4(SearchMapContextHolder.get());
	}

	public BatchMemberTransferUploadResultModel getResult(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		BatchMemberTransferUploadResultModel result = repository.getClcoAempDtlBlkRegTmpResult(in);
		result.setErrorCnt(result.getMissedCnt() + result.getInvalidCnt() + result.getDuplicatedCnt() + result.getEtcCnt());
		return result;
	}

	public List<BatchMemberUploadCustomerDetailModel> getErrorList(BatchMemberUploadDetailErrorRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());

		List<BatchMemberUploadCustomerDetailModel> list = repository.getClcoAempDtlBlkRegTmp(in, in.toPaginationRequest());
		list.forEach(e->{
			e.setTnsfFmlyCnt((int)getFamilyCnt(e, "TnsfTgtFmly"));
			e.setMltiFmlyCnt((int)getFamilyCnt(e, "Fmly"));
		});
		return errorMsg(list);
	}

	@Transactional
	public void init(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		repository.updateClcoAempDtlBlkRegTmpInit(in);
	}

	@Transactional
	public void remove(List<BatchMemberUploadCustomerDetailModel> in) {

		repository.updateClcoAempDtlBlkRegTmpRemove(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in));
	}

	@Transactional
	public void regist(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());

		// 회원지원금종합정보기본 없는 경우 INSERT
		repository.insertMbrSpfnSyntInfBsc(in);

		// 지원금 양도 그룹 설정정보 저장
		repository.updateMbrSpfnSyntInfBscTnsfGrp(in);

		// 지원금 선택 그룹 설정정보 저장
		repository.updateMbrSpfnSyntInfBscSlctGrp(in);

		// 회원지원금종합정보기본 이력 등록
		repository.insertMbrSpfnSyntInfChgRecs(in);

		// 추가지원대상설정기본 없는 경우 INSERT
		repository.insertCuTgtSpfnTgtHis(in);

		// 다중 지원 설정정보 저장
		repository.updateCuTgtSpfnTgtHis(in);

		// 다중 지원 설정이력 저장
		repository.insertCuTgtSpfnTgtChgRecs(in);

		// 검진 대상자 등록
		repository.insertCuTgtrHis(in);

		// 임시테이블 등록완료 처리
		repository.updateClcoAempDtlBlkRegTmpRegist(in);
	}

	public List<BatchMemberUploadCustomerDetailModel> selectCustomerDetailTmpExcelList(
		BatchMemberUploadReentryDownloadRequestModel in) {
		in.setMngrId("" + BatchUploadUtils.getCurrentMngrId());
		return errorMsg(repository.selectClcoAempDtlBlkRegTmpExcelList(in));
	}

	public List<BatchMemberUploadCustomerDetailModel> selectCustomerDetailTmpExcelList(
		List<BatchMemberUploadCustomerDetailModel> in) {

		if( CollectionUtils.isEmpty(in) )
			return Arrays.asList(new BatchMemberUploadCustomerDetailModel());

		return errorMsg(repository.selectClcoAempDtlBlkRegTmpExcelList2(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in)));
	}

	@Transactional
	public void removeAll(BatchMemberUploadDetailErrorRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		repository.updateClcoAempDtlBlkRegTmpRemoveAll(in);
	}
}
