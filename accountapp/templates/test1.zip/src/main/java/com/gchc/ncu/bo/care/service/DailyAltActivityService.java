package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.AltActMsnBscModel;
import com.gchc.ncu.bo.care.repository.DailyAltActivityRepository;
import com.gchc.ncu.bo.care.vo.DailyAltActivityVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DailyAltActivityService {

	private final DailyAltActivityRepository dailyAltActivityRepository;

	public List<AltActMsnBscModel> getDailyAltActivityList(DailyAltActivityVo criteria) {
		return dailyAltActivityRepository.selectDailyAltActivityList(criteria);
	}

	public AltActMsnBscModel getDailyAltActivityDetail(AltActMsnBscModel criteria) {
		return dailyAltActivityRepository.selectDailyAltActivityDetail(criteria);
	}

	public void saveDailyAltActivity(AltActMsnBscModel model) {
		dailyAltActivityRepository.saveDailyAltActivity(model);
	}

	@Transactional
	public void deleteDailyAltActivity(List<AltActMsnBscModel> list) {
		if (list != null) {
			for (AltActMsnBscModel model : list) {
				dailyAltActivityRepository.deleteDailyAltActivity(model);
			}
		}
	}

}
