package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.microsoft.sqlserver.jdbc.StringUtils;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.MidFeelBscModel;
import com.gchc.ncu.bo.care.repository.MindHstkRepository;
import com.gchc.ncu.bo.care.vo.MindHstkVo;

@Service
@RequiredArgsConstructor
public class MindHstkService {

	private final MindHstkRepository mindHstkRepository;

	public List<MidFeelBscModel> getMidFeelBsc(MindHstkVo criteria) {
		return mindHstkRepository.selectMindBsc(criteria);
	}

	public MidFeelBscModel getMidFeelDtl(MindHstkVo criteria) {
		return mindHstkRepository.selectMindDtl(criteria);
	}

	public void saveBsc(MidFeelBscModel model) {
		if(StringUtils.isEmpty(model.getFeelId())) {
			mindHstkRepository.insertMindHstkBsc(model);
		} else {
			mindHstkRepository.updateMindHstkBsc(model);
		}
	}

	public void deleteBsc(List<MidFeelBscModel> list) {
		if(list != null && list.size() > 0) {
			for(MidFeelBscModel model : list) {
				mindHstkRepository.deleteMindHstkBsc(model);
			}
		}
	}



}
