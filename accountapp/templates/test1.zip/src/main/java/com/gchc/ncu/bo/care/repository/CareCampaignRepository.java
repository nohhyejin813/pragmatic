package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.CmpgBscModel;
import com.gchc.ncu.bo.care.models.CmpgCmpnDtlModel;
import com.gchc.ncu.bo.care.models.CmpgCtraBscModel;
import com.gchc.ncu.bo.care.models.CmpgNtfcBscModel;
import com.gchc.ncu.bo.care.models.CmpgNtfcDtlModel;
import com.gchc.ncu.bo.care.models.CmpgTeamRecsModel;
import com.gchc.ncu.bo.care.models.MbrCmpgRecsModel;
import com.gchc.ncu.bo.care.vo.CareCampaignVo;

@Mapper
public interface CareCampaignRepository {

	List<CmpgCtraBscModel> selectCampaignContractList(CareCampaignVo vo);
	CmpgCtraBscModel selectCampaignContract(CareCampaignVo vo);
	void insertCampaignContract(CmpgCtraBscModel model);
	void updateCampaignContract(CmpgCtraBscModel model);
	void deleteCampaignContract(int cmpgCtraId);

	int selectCampaignClientCount(CmpgCtraBscModel model);
	int selectCampaignWorkplaceCount(CmpgCtraBscModel model);

	int selectUsedCampaignContractCount(int cmpgCtraId);
	int selectUsedCampaignMemberCount(int cmpgId);
	int selectOverlappedDateCount(CmpgBscModel model);

	void deleteCampaignRewardByCmpgId(int cmpgId);
	void deleteCampaignNotificationByCmpgId(int cmpgCtraId);

	List<CmpgBscModel> selectContractTermList(CareCampaignVo vo);
	void insertContractTerm(CmpgBscModel model);
	void updateContractTerm(CmpgBscModel model);
	void deleteContractTerm(int cmpgId);

	List<CmpgNtfcDtlModel> selectContractNoticeList(CareCampaignVo vo);
	void insertContractNotice(CmpgNtfcDtlModel model);
	void updateContractNotice(CmpgNtfcDtlModel model);
	void deleteContractNotice(int ntfcId);

	List<CmpgCmpnDtlModel> selectCampaignRewardList(CareCampaignVo vo);
	void insertCampaignReward(CmpgCmpnDtlModel model);
	void updateCampaignReward(CmpgCmpnDtlModel model);
	void deleteCampaignReward(int cmpgCmpnId);

	List<MbrCmpgRecsModel> selectCampaignRewardMemberList(CareCampaignVo vo);

	void updateCampaignRewardConfirmForRank(CareCampaignVo vo);
	void updateCampaignRewardConfirmForDraw(CmpgCmpnDtlModel model);
	void updateCampaignRewardAfterWork(CareCampaignVo vo);
	void updateCampaignRewardMemberCancel(CareCampaignVo vo);
	void updateCampaignRewardCancel(CareCampaignVo vo);
	void updateCampaignRewardPrize(MbrCmpgRecsModel model);

	List<CmpgBscModel> selectOperManagementList(CareCampaignVo vo);
	CmpgBscModel selectOperManagementDetail(CareCampaignVo vo);
	List<MbrCmpgRecsModel> selectOperManagementPeople(CareCampaignVo vo);
	List<MbrCmpgRecsModel> selectOperNoenterPeople(CareCampaignVo vo);
	List<MbrCmpgRecsModel> selectOperPersonDetail(CareCampaignVo vo);

	List<CmpgNtfcBscModel> selectCampaignNoticeList(CareCampaignVo vo);
	CmpgNtfcBscModel selectCampaignNotice(CareCampaignVo vo);
	void insertCampaignNotice(CmpgNtfcBscModel model);
	void updateCampaignNotice(CmpgNtfcBscModel model);
	void deleteCampaignNotice(int msgId);
	//걷기캠페인 팀전
	List<CmpgTeamRecsModel> selectOperationDetailTeam(CareCampaignVo vo);
	List<CmpgTeamRecsModel> selectOperTeamPersonDetail(CareCampaignVo vo);
	void updateCampaignTeamInfoUpdate(CareCampaignVo vo);
	CmpgBscModel selectOperationTeamCount(CareCampaignVo vo);

	void deleteMbrCmpgRecs(CareCampaignVo vo);
	void insertRestriction(CareCampaignVo vo);
	void deleteRestriction(CareCampaignVo vo);
}
