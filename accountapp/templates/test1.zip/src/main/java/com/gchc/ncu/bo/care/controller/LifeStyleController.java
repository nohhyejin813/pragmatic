package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import com.gchc.ncu.bo.care.models.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.service.CareCommApiService;
import com.gchc.ncu.bo.care.service.LifeStyleService;
import com.gchc.ncu.bo.care.vo.LifeStyleVo;

@RestController
@RequestMapping("/api/bo/care/lifestyle")
@RequiredArgsConstructor
public class LifeStyleController {

	private final LifeStyleService lifeStyleService;
	private final CareCommApiService apiService;

	@GetMapping("/schedule/list")
	public List<LifeHbtScdlBscModel> getScheduleList(@ModelAttribute LifeStyleVo criteria) {
		return lifeStyleService.getScheduleList(criteria);
	}

	@GetMapping("/schedule/detail")
	public LifeHbtScdlBscModel getSchedule(@ModelAttribute LifeHbtScdlBscModel criteria) {
		return lifeStyleService.getSchedule(criteria);
	}

	@PostMapping("/schedule/save")
	public RestResult<?> setSchedule(@RequestBody @Valid LifeHbtScdlBscModel model) {
		lifeStyleService.setSchedule(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/schedule/remove")
	public RestResult<?> removeSchedule(@RequestBody List<LifeHbtScdlBscModel> list) {
		lifeStyleService.removeSchedule(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/contract/list")
	public List<LifeHbtCtraBscModel> getContractList(@ModelAttribute LifeStyleVo criteria) {
		return lifeStyleService.getContractList(criteria);
	}

	@GetMapping("/contract/detail")
	public LifeHbtCtraBscModel getContract(@ModelAttribute LifeHbtCtraBscModel criteria) {
		return lifeStyleService.getContract(criteria);
	}

	@PostMapping("/contract/save")
	public RestResult<?> setContract(@RequestBody @Valid LifeHbtCtraBscModel model) {
		lifeStyleService.setContract(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/contract/remove")
	public RestResult<?> removeContract(@RequestBody List<LifeHbtCtraBscModel> list) {
		lifeStyleService.removeContract(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/contract/hbtlist")
	public List<LifeHbtCtraDtlModel> getContractHbtDtlList(@ModelAttribute LifeHbtCtraBscModel criteria) {
		return lifeStyleService.getContractHbtDtlList(criteria);
	}

	@GetMapping("/contract/cmmcdlist")
	public List<LifeStyleCdModel> getContractCommCdList() {
		return lifeStyleService.getContractCommCdList();
	}

	@PostMapping("/contract/hbtsave")
	public RestResult<?> setContractHbtDtlSave(@RequestBody List<LifeHbtCtraDtlModel> list) {
		lifeStyleService.setContractHbtDtlSave(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/application/list")
	public List<LifeHbtApplBscModel> getApplicationList(@ModelAttribute LifeStyleVo criteria) {
		return lifeStyleService.getApplicationList(criteria);
	}

	@GetMapping("/application/detail/list")
	public List<LifeHbtApplScdlDtlModel> getApplicationDetailList(@ModelAttribute LifeStyleVo criteria) {
		return lifeStyleService.getApplicationDetailList(criteria);
	}

	@PostMapping("/guide")
	public RestResult<Integer> sendGuide(@RequestBody Integer[] contractIds) {
		int resultCount = 0;

		for (int id : contractIds) {
			resultCount += apiService.sendLifeStyleAppl(id).getBody().get("SUCCESS");
		}

		return GchcRestResult.of(resultCount);
	}

	@GetMapping("/program/list")
	public List<DwCnntScwdDatBscModel> getProgramList() {
		return lifeStyleService.getProgramList();
	}

	@GetMapping("/category/list")
	public List<DwCnntScwdDatBscModel> getCategoryList(@ModelAttribute DwCnntScwdDatBscModel model) {
		return lifeStyleService.getCategoryList(model);
	}

	@GetMapping("/content/list")
	public List<DwCnntScwdDatBscModel> getContentList(@ModelAttribute DwCnntScwdDatBscModel model) {
		return lifeStyleService.getContentList(model);
	}

	@GetMapping("/year/list")
	public List<LifeHbtScdlBscModel> getScheduleYearList(@ModelAttribute LifeHbtScdlBscModel model) {
		return lifeStyleService.getScheduleYearList(model);
	}

	@PostMapping("/copy/save")
	public LifeHbtScdlBscModel saveScheduleCopy(@RequestBody @Valid LifeHbtScdlBscModel model) {
		return lifeStyleService.saveScheduleCopy(model);
	}

	// 컨텐츠 등록여부
	@GetMapping("/schedule/save/yn")
	public LifeHbtScdlBscModel getScheduleSaveYn(@ModelAttribute LifeHbtScdlBscModel model) {
		return lifeStyleService.getScheduleSaveYn(model);
	}

}
