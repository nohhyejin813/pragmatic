package com.gchc.ncu.bo.batchupload.utils;

import com.gsitm.ustra.java.management.models.UstraCodeModel;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.math.NumberUtils;

import java.util.List;

@UtilityClass
public class BatchFormatUtils {

	public boolean isBasic(String src) {

		return "●".equals(src) || "○".equals(src) || "O".equals(src) || "0".equals(src) || "o".equals(src);
	}

	public boolean isSelect(String src, List<UstraCodeModel> selectCodes) {

		int ns = src.indexOf("(");
		int ne = src.indexOf(")");
		if( ns < 0 || ne < 0 ) return false;
		String strN = src.substring(ns + 1, ne);
		strN = strN.replace("선택", "");
		strN = strN.replace("택", "");
		return src.length() >= 6 &&
				selectCodes.stream()
					.map(c->c.getCdNm() + "(")
					.anyMatch(c->c.equals(src.substring(0, 6)) || c.equals(src.substring(0, 2) + "검사" + src.substring(2, 4))) &&
			")".equals(src.substring(src.length() - 1, src.length())) &&
			NumberUtils.isCreatable(strN);
	}

	public String getSelectType(String src, List<UstraCodeModel> selectCodes) {

		return selectCodes.stream()
			.filter(c->c.getCdNm().equals(src.substring(0, 5)) || c.getCdNm().equals(src.substring(0, 2) + "검사" + src.substring(2, 3)))
			.findFirst()
			.map(UstraCodeModel::getDtlCd)
			.orElse(null);
	}

	public int getSelectLimit(String src) {

		return NumberUtils.toInt(src.substring(6, src.length() - 1));
	}

	public boolean isBasicOrSelect(String src, List<UstraCodeModel> selectCodes) {

		return isBasic(src) || isSelect(src, selectCodes);
	}

	public boolean isPrice(String src) {

		src = src.replace(",", "");
		src = src.replace("원", "");
		if( !NumberUtils.isCreatable(src) )
			return false;
		int prc = NumberUtils.toInt(src);
		return !src.contains(".") &&
			src.length() <= 8 &&
			prc >= 1000 &&
			prc <= 10000000;
	}

	public int getPrice(String src) {

		return NumberUtils.toInt(src.replace(",", "").replace("원", ""));
	}

	public boolean isSex(String src) {

		return "남".equals(src) || "여".equals(src);
	}
}
