package com.gchc.ncu.bo.batchupload.models;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class PackageItemUploadErrorModel {

	int rowNum;

	String catNm;

	String subCatNm;

	String examNm;

	String xclVal1;

	String etcVal1;

	String errorCont1;

	String xclVal2;

	String etcVal2;

	String errorCont2;

	String xclVal3;

	String etcVal3;

	String errorCont3;

	String xclVal4;

	String etcVal4;

	String errorCont4;

	String xclVal5;

	String etcVal5;

	String errorCont5;

	String xclVal6;

	String etcVal6;

	String errorCont6;

	String xclVal7;

	String etcVal7;

	String errorCont7;

	String xclVal8;

	String etcVal8;

	String errorCont8;

	String xclVal9;

	String etcVal9;

	String errorCont9;

	String xclVal10;

	String etcVal10;

	String errorCont10;
}
