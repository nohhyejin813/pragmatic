package com.gchc.ncu.bo.abnormalfindings.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.gchc.ncu.bo.abnormalfindings.repository.HmsCommonRepository;
import com.gchc.ncu.bo.checkupinst.models.CodeModel;
import com.gsitm.ustra.java.data.mybatis.executor.Many;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 약관 관리 Service
 *
 * @author 2021.08.12 목 /Yi Geon-Jin
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class HmsCommonService {

	@Autowired
	private HmsCommonRepository hmsCommonRepository;


	/** 복호화 Before */
	public void exeKeyOpen() {
		hmsCommonRepository.exeKeyOpen();
	}
	/** 복호화 After */
	public void exeKeyClose() {
		hmsCommonRepository.exeKeyClose();
	}

	/** 고객사 */
	@Many public List<CodeModel> getClcoList() {
		return hmsCommonRepository.getClcoList();
	}

	/** 근무지역 */
	@Many public List<CodeModel> getWorkRgnList(Integer clcoId) {
		return hmsCommonRepository.getWorkRgnList(clcoId);
	}

	/** 사업장 */
	@Many public List<CodeModel> getWorkPlaceList(Integer clcoId) {
		return hmsCommonRepository.getWorkPlaceList(clcoId);
	}
}
