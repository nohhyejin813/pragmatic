package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.ActPgmBscModel;
import com.gchc.ncu.bo.care.models.ActPgmDtlModel;
import com.gchc.ncu.bo.care.service.ActivityProgramService;
import com.gchc.ncu.bo.care.vo.ActivityProgramVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/activity/program")
@RequiredArgsConstructor
public class ActivityProgramController {

	private final ActivityProgramService programService;

	@GetMapping("/list")
	public List<ActPgmBscModel> list(@ModelAttribute ActivityProgramVo criteria) {
		return programService.getProgramList(criteria);
	}

	@GetMapping("/detail")
	public ActPgmBscModel detail(@ModelAttribute ActPgmBscModel criteria) {
		return programService.getProgramDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid ActPgmBscModel model) {
		programService.saveProgram(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<ActPgmBscModel> list) {
		programService.deleteProgram(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/mission/list")
	public List<ActPgmDtlModel> missionList(@ModelAttribute ActivityProgramVo criteria) {
		return programService.getProgramMissionList(criteria);
	}

	@GetMapping("/mission/detail")
	public ActPgmDtlModel missionDetail(@ModelAttribute ActPgmDtlModel criteria) {
		return programService.getProgramMissionDetail(criteria);
	}

	@PostMapping("/mission/save")
	public RestResult<?> saveMission(@RequestBody @Valid ActPgmDtlModel model) {
		programService.saveProgramMission(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/mission/delete")
	public RestResult<?> deleteMission(@RequestBody List<ActPgmDtlModel> list) {
		programService.deleteProgramMission(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
