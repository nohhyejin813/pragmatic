package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.batchupload.annotation.BulkInsert;
import com.gchc.ncu.bo.comm.models.NcuModel;
import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
public class BatchCampaignUploadCustomerModel extends NcuModel {

	@BulkInsert(1)
	@UstraExcelCellInfo(col = 0, header = "고객사", required = false)
	private String clcoNm;

	@BulkInsert(2)
	@UstraExcelCellInfo(col = 1, header = "이름", required = false)
	private String aempNm;

	@BulkInsert(3)
	@UstraExcelCellInfo(col = 2, header = "사번", required = false)
	private String aempId;

	@BulkInsert(4)
	@UstraExcelCellInfo(col = 3, header = "근무부서", required = false)
	private String workDeptNm;

	@BulkInsert(5)
	@UstraExcelCellInfo(col = 4, header = "라인", required = false)
	private String lineNm;

	@BulkInsert(6)
	@UstraExcelCellInfo(col = 5, header = "작업", required = false)
	private String jobNm;

	@BulkInsert(7)
	@UstraExcelCellInfo(col = 6, header = "캠페인팀", required = false)
	private String teamNm;

	@BulkInsert(8)
	@ApiModelProperty(value="업로드상태값 기본값 0")
	private Integer upldStVal;

	@BulkInsert(9)
	@ApiModelProperty(value="업로드오류값")
	private String upldErrVal;


}
