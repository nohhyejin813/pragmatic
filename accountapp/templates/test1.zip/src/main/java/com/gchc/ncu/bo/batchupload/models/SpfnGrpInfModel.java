package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.batchupload.enu.SpfnGrpType;

@Getter
@Setter
public class SpfnGrpInfModel {

	SpfnGrpType type;

	Integer grpId;

	String grpNm;
}
