package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PoisRsltDtlModel extends UstraManagementBaseModel {

	private Integer poisRsltId;
	@NotNull(message = "중독유형은 필수값입니다.")
	private Integer poisTyId;
	private String poisTyVal;
	private Integer lwstScr;
	private Integer topScr;
	@NotNull(message = "중독결과제목은 필수값입니다.")
	private String poisRsltTitl;
	private String poisRsltDesc;
	private Integer prir;
	private String careMsnDvCd;
	private Integer poisRsltImgFileId;
	private Integer actPgmId;
	private String poisDiagMthCd;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
