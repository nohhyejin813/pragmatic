package com.gchc.ncu.bo.batchupload.comm;

import com.gsitm.ustra.java.management.models.UstraCodeModel;

import java.util.List;

public class ResvTmcRngContextHolder {

    private static final ThreadLocal<List<UstraCodeModel>> contextHolder = new ThreadLocal<List<UstraCodeModel>>();


    public static List<UstraCodeModel> get() {

        return contextHolder.get();
    }


    public static void set(List<UstraCodeModel> codes) {

        contextHolder.set(codes);
    }

    public static void clear() {

        if (get() != null)
            contextHolder.remove();
    }

    public static String getDtlCd(String nm) {

        return get().stream().filter(c->c.getCdNm().equals(nm)).findFirst().map(UstraCodeModel::getDtlCd).orElse("");
    }
}
