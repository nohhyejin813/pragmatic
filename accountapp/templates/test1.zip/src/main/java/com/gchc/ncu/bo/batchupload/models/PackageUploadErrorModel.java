package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PackageUploadErrorModel {

	int rowNum;

	int upldPkgId;			// 업로드 패키지 아이디

	String cuiNm;			// 센터명

	String pkgNm;			// 패키지명

	String pkgTyNm;			// 패키지 타입명

	String pkgBscPrcVal;	// 패키지기본타입가격

	String clcoSpfn;

	String cuiExpoPrcVal;

	String clcoExpoPrcVal;

	String prpPridSrtDt;	// 제안서기간시작일

	String prpPridEndDt;	// 제안서기간종료일

	String pkgErrCont;
}
