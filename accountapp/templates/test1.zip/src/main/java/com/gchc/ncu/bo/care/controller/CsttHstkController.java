package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.SsngCsttHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttHstkBscModel;
import com.gchc.ncu.bo.care.service.CsttHstkService;
import com.gchc.ncu.bo.care.vo.CsttHstkVo;

@RestController
@RequestMapping("/api/bo/care/constitution/hstk")
@RequiredArgsConstructor
public class CsttHstkController {

	private final CsttHstkService hstkService;

	@GetMapping("/list")
	public List<SsngCsttHstkBscModel> list(@ModelAttribute CsttHstkVo criteria) {
		return hstkService.getContitutionHstkList(criteria);
	}

	@GetMapping("/popSearch")
	public SsngCsttHstkBscModel popSearch(@ModelAttribute CsttHstkVo criteria) {
		return hstkService.getContitutionHstkPop(criteria);
	}

	@GetMapping("/findPopDetail")
	public List<SsngCsttHstkAnswDtlModel> findPopDetail(@ModelAttribute SsngCsttHstkAnswDtlModel criteria) {
		return hstkService.getCsttHstkAnswerList(criteria);
	}

	@PostMapping("/save")
	public int save(@RequestBody @Valid SsngCsttHstkBscModel model) {
		return hstkService.saveContitutionHstk(model);
	}

	@PostMapping("/saveAnswer")
	public RestResult<?> saveAnswer(@RequestBody @Valid List<SsngCsttHstkAnswDtlModel> list) {
		hstkService.saveCsttHstkAnswer(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<SsngCsttHstkBscModel> list) {
		hstkService.deleteCsttHstk(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
