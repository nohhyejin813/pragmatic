package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PackageItemUploadBasicModel extends NcuModel {

	private Integer pkgItmUpldBscId;

	private Integer pkgId;

	private Integer clcoId;

	private Integer cuiId;

	private Integer yr;

	private Integer addExamAbvYn;

	private Integer examLibAbvYn;

	private Integer titlAbvYn;

	private Integer pkgRegUseYn;

	private String fileGrpId;

	private String fileId;

	private Integer fileNo;

	private String resultFlag;	// 엑셀 업로드결과 구분 (0:전체, 1:성공, 2:에러)
}
