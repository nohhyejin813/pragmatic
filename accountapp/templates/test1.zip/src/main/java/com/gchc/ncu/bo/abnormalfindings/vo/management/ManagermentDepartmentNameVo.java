package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;




@Getter
@Setter
@ToString
public class ManagermentDepartmentNameVo extends GchcVo
{
	@ApiModelProperty(value="고객사 ID")
	private Integer clcoId;

	@ApiModelProperty(value="사업장아이디")
	private Integer bsplId;

	@ApiModelProperty(value="부서 깊이(1, 2)")
	private Integer deptDpth;

	@ApiModelProperty(value="부서 ID(부서 깊이가 1일경우 보내지 않음)")
	private Integer uprDeptId;


}
