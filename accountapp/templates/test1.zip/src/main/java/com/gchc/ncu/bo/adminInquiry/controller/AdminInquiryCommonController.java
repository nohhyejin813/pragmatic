package com.gchc.ncu.bo.adminInquiry.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import com.gchc.ncu.bo.checkup.models.CommonSelectBoxModel;
import com.gchc.ncu.bo.checkup.models.GradeModel;
import com.gchc.ncu.bo.checkup.service.CheckupCommonService;
import com.gchc.ncu.bo.checkup.vo.ClientPackageVo;
import com.gchc.ncu.bo.checkup.vo.GradeVo;

import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.adminInquiry.service.AdminInquiryCommonService;
import com.gchc.ncu.bo.adminInquiry.models.WebInquiryModel;


@Slf4j
@RequiredArgsConstructor
@RestController
@Api(tags = "관리자문의 1:1 API")
@RequestMapping("/api/bo/adminInquiry")
public class AdminInquiryCommonController {

	private final AdminInquiryCommonService AdminInquiryCommonService;

	/**
	 * 처리내용 : 1:1 문의 내역 등록
	 *
	 * @param vo - 1:1 문의 내역 등록 파라미터
	 * @return
	 */
	@PostMapping("/adminInquiry")
	@ApiOperation(value="1:1 문의 내역 등록", notes="1:1 문의 내역 등록")
	public RestResult<ResponseCode> insertInquiry(@RequestBody @Valid WebInquiryModel vo) {

		AdminInquiryCommonService.insertAdminInquiry(vo);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
