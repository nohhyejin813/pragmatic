package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class StndBodyBscModel extends UstraManagementBaseModel {

	private String sexCd;
	private String careAgDvCd;
	private Integer avgHtVal;
	private Integer avgBwVal;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;
}
