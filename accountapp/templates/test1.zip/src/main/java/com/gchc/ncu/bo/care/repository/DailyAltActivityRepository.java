package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.AltActMsnBscModel;
import com.gchc.ncu.bo.care.vo.DailyAltActivityVo;

@Mapper
public interface DailyAltActivityRepository {

	List<AltActMsnBscModel> selectDailyAltActivityList(DailyAltActivityVo criteria);
	AltActMsnBscModel selectDailyAltActivityDetail(AltActMsnBscModel criteria);
	void saveDailyAltActivity(AltActMsnBscModel model);
	void deleteDailyAltActivity(AltActMsnBscModel model);

}
