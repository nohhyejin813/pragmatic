package com.gchc.ncu.bo.abnormalfindings.repository;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestBody;

import com.gchc.ncu.bo.abnormalfindings.models.target.AbnfTargetModel;
import com.gchc.ncu.bo.abnormalfindings.vo.target.AbnfTargetVo;
import com.gchc.ncu.bo.checkupinst.models.CodeModel;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.mybatis.executor.Many;


/**
 *
 * @author spm
 *
 */
@Mapper
public interface TargetRepository
{
	@Many List<CodeModel> getClcoList();

	@Many List<AbnfTargetModel> getTargetList(@Param("model")AbnfTargetVo targetVo, PaginationRequest pr);

	@Many List<AbnfTargetModel> getTargetListExcelDownload(@Param("model")AbnfTargetVo targetVo);

	@Many Integer updateNpcPvntGrpNm(@RequestBody AbnfTargetVo targetVo);
}
