package com.gchc.ncu.bo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(tags = "Sample테스트를 위한 임시 Controller")
public class BaseSampleController {

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	@PostMapping("/api/bo/test")
	public Map<String, String> test() {
		Map<String, String> result = new HashMap<>();
		result.put("project", "bonus-bo");

		return result;
	}


	@GetMapping("/api/bo/redis-test")
	public Map<String, String> redisTest() {
		ValueOperations<String, String> vop = redisTemplate.opsForValue();
		vop.set("testval", "test1");
		vop.set("testval2",  "test2");

		Map<String, String> result = new HashMap<>();
		result.put("project", "bonus-bo");

		return result;
	}


	/**
	 * 처리내용 : redis input 테스트 코드
	 *
	 * @return
	 */
	@ApiOperation(value = "redis value 조회", notes = "API호출  시 지정된 key의 값을  redis에서 조회하여 리턴합니다..")
	@ApiImplicitParams({
		@ApiImplicitParam(name="key", value="redis key 값", example = "1")
	})
	@GetMapping("/api/bo/redis-test/{key}")
	public Map<String, String> redisGetValueTest(@PathVariable String key) {
		ValueOperations<String, String> vop = redisTemplate.opsForValue();
		String value = vop.get(key);


		Map<String, String> result = new HashMap<>();
		result.put("key value", value);

		return result;
	}


}