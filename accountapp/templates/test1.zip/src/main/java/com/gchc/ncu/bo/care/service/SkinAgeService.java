package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.SkinAgBscModel;
import com.gchc.ncu.bo.care.models.SkinAgCnntDtlModel;
import com.gchc.ncu.bo.care.models.SkinAgRsltBscModel;
import com.gchc.ncu.bo.care.repository.SkinAgeRepository;
import com.gchc.ncu.bo.care.vo.SkinAgeSearchVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SkinAgeService {

	private final SkinAgeRepository repository;

	public List<SkinAgBscModel> getSkinAgeBaseList(SkinAgeSearchVo vo) {
		return repository.selectSkinAgeBaseList(vo);
	}

	public List<SkinAgCnntDtlModel> getSkinAgeContentList(SkinAgeSearchVo vo) {
		return repository.selectSkinAgeContentList(vo);
	}

	public SkinAgBscModel getSkinAgeBaseItem(SkinAgeSearchVo vo) {
		return repository.selectSkinAgeBaseItem(vo);
	}

	public SkinAgCnntDtlModel getSkinAgeContentItem(SkinAgeSearchVo vo) {
		return repository.selectSkinAgeContentItem(vo);
	}

	public void setSkinAgeBaseItem(SkinAgBscModel model) {
		Integer checkCount = repository.selectSkinAgeBaseConflictCheck(model);

		if (checkCount > 0) {
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "나이대가 이미 등록된 값과 중복됩니다.");
		}

		if (model.getSkinAgId() == null || model.getSkinAgId() < 1) {
			repository.insertSkinAgeBaseItem(model);
		} else {
			repository.updateSkinAgeBaseItem(model);
		}
	}

	@Transactional
	public void removeSkinAgeBaseList(List<SkinAgBscModel> models) {
		for (SkinAgBscModel model : models) {
			repository.deleteSkinAgeBaseItem(model);
		}
	}

	public void setSkinAgeContentItem(SkinAgCnntDtlModel model) {
		if (model.getCnntId() == null || model.getCnntId() < 1) {
			repository.insertSkinAgeContentItem(model);
		} else {
			repository.updateSkinAgeContentItem(model);
		}
	}

	@Transactional
	public void removeSkinAgeContentList(List<SkinAgCnntDtlModel> models) {
		for (SkinAgCnntDtlModel model : models) {
			repository.deleteSkinAgeContentItem(model);
		}
	}

	public List<SkinAgRsltBscModel> getSkinAgeResultBaseList(SkinAgeSearchVo vo) {
		return repository.selectSkinAgeResultBaseList(vo);
	}

	public SkinAgRsltBscModel getSkinAgeResultBaseItem(SkinAgeSearchVo vo) {
		return repository.selectSkinAgeResultBaseItem(vo);
	}

	public void setSkinAgeResultBaseItem(SkinAgRsltBscModel model) {
		Integer checkCount = repository.selectSkinAgeResultConflictCheck(model);

		if (checkCount > 0) {
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "시간대나 나이대가 이미 등록된 값과 중복됩니다.");
		}

		if (model.getSkinAgRsltId() == null || model.getSkinAgRsltId() < 1) {
			repository.insertSkinAgeResultBaseItem(model);
		} else {
			repository.updateSkinAgeResultBaseItem(model);
		}
	}

	@Transactional
	public void removeSkinAgeResultBaseList(List<SkinAgRsltBscModel> models) {
		for (SkinAgRsltBscModel model : models) {
			repository.deleteSkinAgeResultBaseItem(model);
		}
	}

}
