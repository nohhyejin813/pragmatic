package com.gchc.ncu.bo.batchupload.models;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Getter
@Setter
public class PackageUploadResultModel extends UstraManagementBaseModel {

	int totalCount;

	int successCount;

	int errorCount;

	List<PackageUploadErrorModel> errorDesc;
}
