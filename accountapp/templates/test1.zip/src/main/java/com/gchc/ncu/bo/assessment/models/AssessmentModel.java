package com.gchc.ncu.bo.assessment.models;

import com.gchc.ncu.bo.comm.models.NcuModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentModel extends NcuModel {// UstraManagementBaseModel {

	private int 		rowNum;

	/* T_EASY_CUI_ASM_MNG_BSC [헬스케어_검진이지검진기관평가관리기본] */
	private int			yr; 					//년도
	private int			cuiAsmId; 				//검진기관평가아이디
	private int			cuiAsmTgtId; 			//검진기관평가대상아이디

	private int			clcoId;					//고객사아이디
	private String		clcoNm;					//고객사명
	private int 		cuiId;    				//검진기관아이디
	private String 		cuiNm;    				//검진기관명
	private String 		cuiTyCd;    			//검진기관유형코드
	private String 		rgnNm1;    				//지역명1
	private String 		rgnNm2;    				//지역명2

	private String 		cuiAsmEtcOpin;			//특이사항

	private String		score;
	private String		grade;
	private String		status;
	private String		statusCode;

	private double 		kndnStdgScrAvg;    		//친절만족도점수
	private double 		trsStdgScrAvg;    		//신뢰만족도점수
	private double 		fcltStdgScrAvg;    		//시설만족도점수
	private double 		examItmStdgScrAvg;  	//검사항목만족도점수
	private double 		rcmnAvg;    			//추천점수
	private String 		rcmnPer;    			//추천퍼센트
	private double 		notRcmnPer;    			//비추천퍼센트

	private int 		partlnCnt;    			//참여자수
	private int 		targetCnt;    			//수검자수

	private String		asmSrtDt; 				//평가시작일자
	private String		asmEndDt; 				//평가종료일자
	private boolean		qstnRegCmplYn; 			//문항등록완료여부
	private String 		qstAnswBscTyCd;			//질문답변기본유형코드
	private boolean		wholCuiTgtYn; 			//전체검진기관대상여부
	private String		slctCuiLstCont; 		//선택검진기관목록내용
	private int 		slctItmAllwScr;			//선택형 항목별 배점
	private String 		slctItmCont;			//예시내용
	private int[]		cuiIdList; 			//선택검진기관목록내용
	private int 		allwPsblMxScr;

	private int			delYn; 					//삭제여부

//	private String 		frstRegDtm; 			//최초등록일시
//	private String 		frstRegrTyCd; 			//최초등록자유형코드
//	private String 		frstRegrId; 			//최초등록자아이디
//	private String 		lastUpdDtm; 			//최종수정일시
//	private String 		lastUpdrTyCd;			//최종수정자유형코드
//	private String 		lastUpdrId;				//최종수정자아이디

	private int			totCnt;
	private int			s1;
	private int			s2;
	private int			s3;
	private int			s4;
	private int			s5;

	private int 		cuiAsmSrvyId;      		//검진기관평가설문아이디

	/* 평가문항관리 */
	/* T_EASY_CUI_ASM_TGT_DTL [헬스케어_검진이지검진기관평가대상상세] */
	private	String	scrDtm;			//점수등록일자
	private	String	asmDtm;			//평가응답일자
	private	String	asmKvl;			//평가키값
	private	String	asmStCd;		//평가상태코드
	private	String	cuiChrgrNm;		//검진기관담당자이름


	/* T_SRVY_BSC [헬스케어_설문기본] */
	private int			srvyId; 		//설문아이디
	private String		srvyTitl; 		//설문제목
	private int			answSrvyTgtId;	//답변설문대상 ID
	private int			srvyQstId;		//설문질문ID
	private int			srvyQstNo;		//설문질문ID
	private String		srvyQstCont; 	//문항내용
	private int 		srvyAnswId;
	private String 		srvyAnswInptCont;
	private String		thmAreaTitl;	//주제영역 제목
	private int			srvyQstSlctItmId; //검진기관평가보기아이디
	private int			srvyQstThmAreaId;
	private int 		cuiAsmTotScr;



	/* search parameter */
	private int 		srchYr;    				//년도

	private String 		srchRgnNm1;    			//지역1
	private String 		srchRgnNm2;    			//지역2

	private int		srchClcoId;				//고객사
	private int		srchCuiId;				//검진기관

	private int			srchKndnStdgMinScr; 	//친절만족도점수(min)
	private int			srchKndnStdgMaxScr; 	//친절만족도점수(max)

	private int			srchTrsStdgMinScr; 		//신뢰만족도점수(min)
	private int			srchTrsStdgMaxScr; 		//신뢰만족도점수(max)

	private int			srchFcltStdgMinScr; 	//시설만족도점수(min)
	private int			srchFcltStdgMaxScr; 	//시설만족도점수(max)

	private int			srchExamItmStdgMinScr; 	//검사항목만족도점수(min)
	private int			srchExamItmStdgMaxScr; 	//검사항목만족도점수(max)

	private String		srchGrade;
	private int			srchStatus;
	private int			srchMinScr;				// 점수(min)
	private int			srchMaxScr;				// 점수(max)

		//NcuUserDetail model의 일부만
	private String		usrNm;
	private String		cphNo;
	private String 		email;
	private String 		usrId;

}
