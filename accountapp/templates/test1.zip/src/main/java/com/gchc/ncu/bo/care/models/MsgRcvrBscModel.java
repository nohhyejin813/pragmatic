package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MsgRcvrBscModel extends UstraManagementBaseModel {

	private Integer regSeq;
	@NotNull(message = "수신자이름은 필수값입니다.")
	private String rcvrNm;
	@NotNull(message = "수신자이메일주소는 필수값입니다.")
	private String rcvrEmlAdr;
	private String rcvrMblNo;
	private String msgDvVal;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
