package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.DotiHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.DotiHstkBscModel;
import com.gchc.ncu.bo.care.service.DotiHstkService;
import com.gchc.ncu.bo.care.vo.DotiHstkVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/doti/hstk")
@RequiredArgsConstructor
public class DotiHstkController {

	private final DotiHstkService dotiHstkService;

	@GetMapping("/list")
	public List<DotiHstkBscModel> list(@ModelAttribute DotiHstkVo criteria) {
		return dotiHstkService.getDotiHstkList(criteria);
	}

	@GetMapping("/detail")
	public DotiHstkBscModel detail(@ModelAttribute DotiHstkBscModel criteria) {
		return dotiHstkService.getDotiHstkDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid DotiHstkBscModel model) {
		dotiHstkService.saveDotiHstk(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<DotiHstkBscModel> list) {
		dotiHstkService.deleteDotiHstk(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/answer/list")
	public List<DotiHstkAnswDtlModel> answerList(@ModelAttribute DotiHstkBscModel criteria) {
		return dotiHstkService.getDotiHstkAnswerList(criteria);
	}

	@PostMapping("/answer/save/{dotiHstkId}")
	public RestResult<?> saveAnswer(@PathVariable(name = "dotiHstkId", required = true) int dotiHstkId, @RequestBody @Valid List<DotiHstkAnswDtlModel> list) {
		dotiHstkService.saveDotiHstkAnswer(dotiHstkId, list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
