package com.gchc.ncu.bo.batchupload.repository;

import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.comm.models.CommonParametersModel;
import com.gchc.ncu.bo.member.models.ClientModel;
import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @FileName : BatchMemberAdvanceResvUploadRepository.java
 * @date : 2022. 06. 10
 * @author : 이광희
 * @프로그램 설명 : 선예약 일괄업로드 Controller
 * @변경이력 :
 */
@Mapper
public interface BatchMemberAdvanceResvUploadRepository {

	/**
	 *
	 * 처리내용 : 시퀃스 목록으로 DB 조회
	 *
	 * @param checkUpdate
	 * @return
	 */
	List<BatchMemberUploadAdvanceResvModel> getClcoAempAdreBlkRegTmpForUpdate(Map<String, Object> checkUpdate);

	/**
	 *
	 * 처리내용 : 배치 테이블에 insert
	 *
	 * @param list
	 */
	void insertClcoAempBlkRegTmp(Map<String, Object> list);

	/**
	 *
	 * 처리내용 : 배치 테이블 update
	 *
	 * @param customer
	 */
	void updateClcoAempBlkRegTmp(BatchMemberUploadAdvanceResvModel customer);

	/**
	 *
	 * 처리내용 : 배치 테이블 시퀀스 채번
	 * @param map
	 *
	 * @return
	 */
	int getAempAdreBlkRegTmpNextSeq(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 중복 체크를 위해 PRIR 업데이트
	 *
	 * @param map
	 */

	void updateClcoAempAdreBlkRegTmpRnk(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 중복 체크
	 *
	 * @param map
	 */

	void updateClcoAempAdreBlkRegTmpValidate(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : upldYn 초기화
	 *
	 * @param map
	 */

	void updateClcoAempAdreBlkRegTmpUploadYn(Map<String, Object> map);

	/**
	 *
	 * 처리내용 : 일괄업로드 결과 조회
	 *
	 * @param in
	 * @return
	 */

	BatchMemberAdvanceResvUploadResultModel getBatchMemberAdvanceResvUploadResult(BatchMemberUploadResultRequestModel in);

	/**
	 *
	 * 처리내용 : 일괄업로드 오류 조회
	 *
	 * @param in
	 * @param pr
	 * @return
	 */

	PaginationList<BatchMemberUploadAdvanceResvModel> getClcoAempBlkRegTmpError(@Param("model") BatchMemberUploadErrorRequestModel in, PaginationRequest pr);


	PaginationList<BatchMemberUploadAdvanceResvModel> getClcoAempBlkRegTmpErrorDuplicated(@Param("model") BatchMemberUploadErrorRequestModel in,
		PaginationRequest paginationRequest);

	/**
	 *
	 * 처리내용 : 오류 삭제 처리
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpRemove(Map<String, Object> in);

	/**
	 *
	 * 처리내용 : 일괄업로드 현재db 비교
	 *
	 * @param in
	 */

	void updateClcoAempAdreBlkRegTmpValidateStep2_1(Map<String, Object> in);

	void updateClcoAempAdreBlkRegTmpValidateStep2_2(Map<String, Object> in);

	void updateClcoAempAdreBlkRegTmpValidateStep2_3(Map<String, Object> stringObjectMap);

	/**
	 *
	 * 처리내용 : 배우자가 임직원 정보에 중복되는지 체크
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpValidateStep3(Map<String, Object> in);

	/**
	 *
	 * 처리내용 : 예약 정보가 존재하는 회원인지 체크
	 *
	 * @param in
	 */

	void updateClcoAempAdreBlkRegTmpValidateStep4(Map<String, Object> in);

	void updateClcoAempAdreBlkRegTmpValidateStep5(Map<String, Object> in);

	void updateClcoAempAdreBlkRegTmpValidateStep6(Map<String, Object> in);

	void updateClcoAempAdreBlkRegTmpValidateStep7(Map<String, Object> in);

	/**
	 *
	 * 처리내용 : 일괄업로드 작업내역 초기화
	 *
	 * @param in
	 * @return
	 */

	void updateClcoAempBlkRegTmpInit(BatchMemberUploadInitRequestModel in);

	/**
	 *
	 * 처리내용 : 당해년도 모든 고객 다운로드 (for Test)
	 *
	 * @param in
	 * @return
	 */

	List<BatchAdvanceResvExcelModel> selectCustomerTmpTestExcelList(CustomerExcelDownModel in);

	/**
	 *
	 * 처리내용 : 중복 항목 신규 내용으로 업데이트를 위해 상태 값 변경 (upldStVal = 14)
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpUpldStVal(BatchMemberUploadRegistRequestModel in);

	void updateClcoAempBlkRegTmpUpldStVal2(BatchMemberUploadRegistRequestModel in);

	List<BatchAdvanceResvExcelModel> selectCustomerTmpExcelList(CustomerExcelDownModel in);

	List<BatchAdvanceResvExcelModel> getClcoAempBlkRegTmp(CustomerExcelDownModel vo);

	/**
	 *
	 * 처리내용 : 현재 정상인 건수들의 예약 정보를 조회한다.
	 *
	 * @param in
	 * @return
	 */

	BatchMemberUploadReserveInfoModel getClcoAempBlkRegTmpReserve(BatchMemberUploadRegistRequestModel in);

	/**
	 *
	 * 처리내용 : 선택된 중복 오류 건들의 예약 정보를 조회한다.
	 *
	 * @param in
	 * @return
	 */

	BatchMemberUploadReserveInfoModel getClcoAempBlkRegTmpReserveForList(BatchMemberUploadRegistRequestModel in);

	/**
	 *
	 * 처리내용 : upldStVal 1과 4를 백업
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpBackup(BatchMemberUploadRegistRequestModel in);

	/**
	 *
	 * 처리내용 : upldStVal 1과 4를 복구
	 *
	 * @param in
	 */

	void updateClcoAempBlkRegTmpRestore(BatchMemberUploadRegistRequestModel in);

	void updateClcoAempBlkRegTmpMerge(Map<String, Object> map);

	List<BatchAdvanceResvExcelModel> selectClcoAempBlkRegTmpExcelList(Map<String, Object> map);

	void updateClcoAempBlkRegTmpRemoveAll(CustomerExcelDownModel in);

	ClientModel getClcoBsc(Map<String, Object> map);

	List<CommonParametersModel> getClcoList(CommonParametersModel model);

	List<BatchAdvanceResvExcelModel> selectClcoAempBlkRegTmpDuplicatedExcel(CustomerExcelDownModel in);

	List<BatchAdvanceResvExcelModel> selectClcoAempBlkRegTmpDuplicatedExcelList(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpPkgInf(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpResvInf(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpValidateResv1(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpItemInf(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpValidateItem1(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpValidateItem2(Map<String, Object> map);

    List<BatchCheckupInstModel> getCuiList(List<String> cuiList);

    void updateClcoAempAdreBlkRegTmpItemInfWithoutPkgTy(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpSpsrPkgInf(Map<String, Object> map);

	void updateClcoAempAdreBlkRegTmpValidateSpsrResv1(Map<String, Object> map);

    void updateClcoAempAdreBlkRegTmpSpsrResvInf(Map<String, Object> map);
}
