package com.gchc.ncu.bo.abnormalfindings.models;

import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;

import com.gchc.common.model.GchcPageableVo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@Builder
@EqualsAndHashCode(callSuper=true)
@NoArgsConstructor
@AllArgsConstructor
public class AbnfMemberModel extends GchcPageableVo
{
	@ApiModelProperty(value="rowNum")
	private Integer rowNum;

	@ApiModelProperty(value="퇴사 여부")
	private String exitGrade;

	@ApiModelProperty(value="유저 고유 아이디")
	private Integer uid;

	@ApiModelProperty(value="균관리 고유 아이디")
	private Integer mbrSvcId;

	@ApiModelProperty(value="사번")
	private String empno;

	@Masked(MaskingType.NAME)
	@ApiModelProperty(value="이름")
	private String nm;


	@ApiModelProperty(value="나이")
	private Integer age;

	@ApiModelProperty(value="성별")
	private String sex;


	@ApiModelProperty(value="고객사명")
	private String clcoNm;

	@ApiModelProperty(value="부서명칭")
	private String deptNm;


	@ApiModelProperty(value="근무지역명")
	private String workRgnNm;


	@ApiModelProperty(value="근무지역세부명")
	private String workRgnEtcCont;


	@ApiModelProperty(value="근무지1")
	private String workRgnNm1;

	@ApiModelProperty(value="근무지2")
	private String workRgnNm2;



	@ApiModelProperty(value="서비스군(확정군)")
	private Integer svcgCd;

	@ApiModelProperty(value="서비스군 명(확정군_분류)")
	private String svcgCdNm;


	@ApiModelProperty(value="임시 서비스 운영군")
	private Integer tmpSvcgCd;


	@ApiModelProperty(value="임시 서비스 운영군 명")
	private String tmpSvcgCdNm;


	@ApiModelProperty(value="임시서비스군상세")
	private Integer tmpSvcgDtlCd;

	@ApiModelProperty(value="운영군세부명칭")
	private String tmpSvcgDtlCdNm;


	@ApiModelProperty(value="고객진행상태")
	private Integer custPgrsStCd;

	@ApiModelProperty(value="군진행상태")
	private String custPgrsStCdNm;


	@ApiModelProperty(value="HRA_PK")
	private String hraPk;


	@ApiModelProperty(value="위험군분류표코드")
	private String rgrpGrclPrirCode;


	@ApiModelProperty(value="건강평가")
	private String hthAsm;

	@ApiModelProperty(value="평가시작일")
	private String asmDt;

	@ApiModelProperty(value="평가상태")
	private Integer asmSt;

	@ApiModelProperty(value="평가상태명")
	private String asmStNm;


	@ApiModelProperty(value="검진기록ID")
	private String cuRec;

	@ApiModelProperty(value="최근검진일")
	private String cuDt;

	@ApiModelProperty(value="")
	private String stChgDt;


	@ApiModelProperty(value="주요질병여부")
	private String mjrDssYn;



	@ApiModelProperty(value="주요질병VIEW")
	private String mjrDssView;

	@ApiModelProperty(value="이메일")
	private String emlAdr;

	@ApiModelProperty(value="위험군")
	private String rgrp;

	public Integer totalItemCount;

}
