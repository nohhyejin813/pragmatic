package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.CstmCuBscItmBscModel;
import com.gchc.ncu.bo.care.models.SsngCsttBscModel;
import com.gchc.ncu.bo.care.models.SsngCsttCuItmDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttUseDescDtlModel;
import com.gchc.ncu.bo.care.repository.CsttMngRepository;
import com.gchc.ncu.bo.care.vo.CsttMngVo;

@Service
@RequiredArgsConstructor
public class CsttMngService {

	private final CsttMngRepository csttMngRepository;

	public SsngCsttBscModel getCsttMngBase(CsttMngVo criteria) {
		return csttMngRepository.selectCsttMngBase(criteria);
	}

	public List<SsngCsttDtlModel> searchDtl(CsttMngVo criteria) {
		return csttMngRepository.selectCsttMngDtl(criteria);
	}

	public List<SsngCsttCuItmDtlModel> searchCuItemDtl(CsttMngVo criteria) {
		return csttMngRepository.selectCsttMngCuItemDtl(criteria);
	}

	@Transactional
	public void saveBase(SsngCsttBscModel model) {
		csttMngRepository.updateCsttBase(model);
	}

	@Transactional
	public void saveDtlPop(SsngCsttDtlModel model) {
		if (StringUtils.isEmpty(model.getSsngCsttDtlId())) {
			csttMngRepository.insertCsttDtl(model);
		} else {
			csttMngRepository.updateCsttDtl(model);
		}
	}

	@Transactional
	public void deleteDetail(List<SsngCsttDtlModel> list) {
		if(list != null) {
			for(SsngCsttDtlModel model : list) {
				csttMngRepository.deleteCsttDtl(model);
			}
		}
	}

	@Transactional
	public void saveCuItm(SsngCsttCuItmDtlModel model) {
		if (StringUtils.isEmpty(model.getFrstRegDtm())) {
			csttMngRepository.insertCsttCuItm(model);
		} else {
			csttMngRepository.updateCsttCuItm(model);
		}
	}

	@Transactional
	public void deleteCuItm(List<SsngCsttCuItmDtlModel> list) {
		if(list != null) {
			for(SsngCsttCuItmDtlModel model : list) {
				csttMngRepository.deleteCuItm(model);
			}
		}
	}

	public List<SsngCsttUseDescDtlModel> searchUseDescDtl(CsttMngVo criteria) {
		return csttMngRepository.selectUseDescDtl(criteria);
	}

	@Transactional
	public void saveUseDescDtl(SsngCsttUseDescDtlModel model) {
		if (StringUtils.isEmpty(model.getUseDescId())) {
			csttMngRepository.insertUseDescDtl(model);
		} else {
			csttMngRepository.updateUseDescDtl(model);
		}
	}

	@Transactional
	public void deleteUseDescDtl(List<SsngCsttUseDescDtlModel> list) {
		if(list != null) {
			for(SsngCsttUseDescDtlModel model : list) {
				csttMngRepository.deleteUseDescDtl(model);
			}
		}
	}

	public List<CstmCuBscItmBscModel> getSearchCd() {
		return csttMngRepository.selectCuCdList();
	}
}
