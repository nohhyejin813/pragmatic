package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.ExaminationColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.BatchExminationExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchExminationTempModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadExcelExaminationModel;
import com.gchc.ncu.bo.batchupload.models.ExaminationSrcModel;
import com.gchc.ncu.bo.batchupload.repository.BatchExaminationUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.repository.CommonRepository;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gchc.ncu.bo.inspection.models.InspectionUserModel;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BatchExaminationUploadService {

	@Autowired
	BatchExaminationUploadRepository uploadRepository;

	@Autowired
	private CommonRepository commRepo;

	@SuppressWarnings("unchecked")
	public Map<String, Object> setCheckupExaminationData(List<RowInfo> converted, Integer yr) {
		Map<String, Object> result = new HashMap<>();
		BatchUploadExcelExaminationModel upload = new BatchUploadExcelExaminationModel();
		final ExaminationSrcModel src = new ExaminationSrcModel();

		List<InspectionUserModel> userList = null;
		List<BatchExminationTempModel> temp = new ArrayList<BatchExminationTempModel>();

		List<BatchExminationExcelModel> allList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> totalList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> nomalList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> missingList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> unMatchList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> etcList = new ArrayList<BatchExminationExcelModel>();

		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());
		String brdtArr[];
		String brdt = "";
		String sexCd = "";
		String datStCd = "";
		String errorTxt = "";
		int clcoYn = 0;
		int clcoId = 0;
		int cuiYn = 0;
		int cuiId = 0;
		int retVal = 0;

		// 헤더 체크
		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();
		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

		String missed = BatchUploadColumn.stream(ExaminationColumn.class)
			.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
			.findFirst()
			.map(BatchUploadColumn::getTitle)
			.orElse(null);
		if( StringUtils.isNotEmpty(missed) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

		List<BatchUploadExcelExaminationModel> in = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyMap((Map<String, Object>)r.getObject()))
			.map(r->{

				BatchUploadExcelExaminationModel model = BatchUploadUtils.map((Map<String, Object>)r.getObject(), headerRow,
					BatchUploadColumn.table(ExaminationColumn.class), BatchUploadExcelExaminationModel.class);
				model.setYr(yr);
				model.setBrdt(BatchUploadUtils.formattedBrdt(model.getBrdt()));
				return model;
			})
			.collect(Collectors.toList());

		// 수검결과 일괄업로드 테이블과 동일한 타깃으로 작업 진행 하기로 함.
		// T_BLK_UPLD_EXAM_TMP <<< 헬스케어_일괄업로드검사임시
		// 엑셀의 데이터를 가져온다.
		for(int i = 0; i<in.size(); i++) {
			brdt = "";
			sexCd = "";
			datStCd = "1";
			errorTxt = "";
			upload = new BatchUploadExcelExaminationModel();
			upload = in.get(i);

			// 등록자 정보
			src.setFrstRegrId(String.valueOf(managerDtl.getMngrId()));
			src.setFrstRegrTyCd(managerDtl.getFrstRegrTyCd());
			src.setLastUpdrId(String.valueOf(managerDtl.getMngrId()));
			src.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());
			src.setYr(String.valueOf(yr));

			src.setClcoNm(upload.getClcoNm()); // 고객사명

			clcoYn = uploadRepository.getMatchClcoYn(src);

			if(0 != clcoYn) {// 고객사 정보 체크
				clcoId = uploadRepository.getMatchClcoId(src.getClcoNm());
				src.setClcoId(clcoId);
			} else {
				errorTxt += "고객사명이 잘못되었습니다.\n";
				datStCd = "3";
			}

			src.setCuiNm(upload.getCuiNm()); // 검진기관명

			cuiYn = uploadRepository.getMatchCuiYn(src);

			if(0 != cuiYn) { // 검진센터Id 여부 체크
				cuiId = uploadRepository.getMatchCuiId(src.getCuiNm());
				src.setCuiId(cuiId);
			} else {
				errorTxt += "검진기관정보가 잘못되었습니다.\n";
				datStCd = "3";
			}

			src.setExmrNm(upload.getExmrNm()); // 성명

			boolean valid = BatchUploadUtils.checkBrdt(upload.getBrdt());
			if( !valid ) {

				errorTxt += "주민번호 양식이 잘못 되었습니다.\n";
				datStCd = "4";
			}
			if( StringUtils.isNotEmpty(upload.getBrdt()) && upload.getBrdt().length() > 10 ) {
				src.setBrdt(upload.getBrdt().substring(0, 10));
				src.setSexCd(upload.getBrdt().substring(10, 11));
			}
			else
				src.setBrdt(upload.getBrdt());

			// rollback으로 인한 주석 추가
			upload.setHvexCmplDt(BatchUploadUtils.makeDt(upload.getHvexCmplDt()));
			boolean validDt = BatchUploadUtils.checkDt(upload.getHvexCmplDt());
			if( !validDt ) {

				errorTxt += "검진일자 정보가 잘못 되었습니다.\n";
				datStCd = "4";
			}

			try {
				Date cuCmpl = DateUtils.parseDate(upload.getHvexCmplDt(), "yyyy-MM-dd");
				if (cuCmpl.compareTo(new Date()) > 0) {

					errorTxt += "검진일자가 유효하지 않습니다.\n";
					datStCd = "4";
				}
			}
			catch( ParseException e ) {
				LOGGER.error(ExceptionUtils.getStackTrace(e));
			}

//			if(8 == upload.getBrdt().length()) {
//				brdtArr = upload.getBrdt().split("-");
//				brdt = brdtArr[0].substring(0,2)+"-"+brdtArr[0].substring(2,4)+"-"+brdtArr[0].substring(4); // ex 2021-10-21
//				if("1".equals(brdtArr[1])) {
//					sexCd = "1";
//					brdt = "19"+brdt;
//				}else if("2".equals(brdtArr[1])) {
//					sexCd = "2";
//					brdt = "19"+brdt;
//				}else if("3".equals(brdtArr[1])) {
//					sexCd = "1";
//					brdt = "20"+brdt;
//				}else if("4".equals(brdtArr[1])) {
//					sexCd = "2";
//					brdt = "20"+brdt;
//				}else if("5".equals(brdtArr[1])) { //혹시나 하는 외국인
//					sexCd = "1";
//					brdt = "19"+brdt;
//				}else if("6".equals(brdtArr[1])) { //혹시나 하는 외국인
//					sexCd = "2";
//					brdt = "19"+brdt;
//				}
//				src.setBrdt(brdt);
//				src.setSexCd(sexCd);
//			} else {
//				errorTxt += "주민번호 양식이 잘못 되었습니다.\n";
//				datStCd = "4";
//			}

			src.setHvexCmplDt(BatchUploadUtils.strCut(upload.getHvexCmplDt(), 10)); // 수검완료일자
			src.setCorpSpfn(NumberUtils.toInt(upload.getCorpSpfn()));
			src.setCuiYn(String.valueOf(cuiYn));
			src.setUseYn("1"); // 사용여부
			src.setDelYn("0"); // 삭제여부
			src.setUpldCmplYn("1"); // 업로드 완료 여부
			src.setUsrKdCd(managerDtl.getUseDvCd()); // 사용자종류코드
			src.setMngrId(managerDtl.getMngrId()); // 관리자 아이디

			userList = uploadRepository.getExaminationUserMatch(src);
			List<InspectionUserModel> targets = userList.stream()
					.filter(u->!u.getResvStCd().equals("13"))
					//.filter(u->NumberUtils.toInt(u.getCorpSpfn(), 0) == src.getCorpSpfn())
					.collect(Collectors.toList());
			List<InspectionUserModel> apiPkgTargets = userList.stream()
					.filter(u->!u.getApiUpldYn().equals(1))
					.collect(Collectors.toList());

			if(CollectionUtils.isNotEmpty(apiPkgTargets)){
				errorTxt += "API 연동 패키지\n";
				datStCd = "4";
			}

			if(CollectionUtils.isNotEmpty(targets) && targets.size() == 1) {
				//src.setCorpSpfn(NumberUtils.toInt(user.getCorpSpfn()));
				InspectionUserModel user = targets.get(0);
				src.setUid(NumberUtils.toInt(user.getUid()));
				src.setCuTgtrId(NumberUtils.toInt(user.getCuTgtrId()));
				src.setResvId(NumberUtils.toInt(user.getResvId()));
				src.setResvStCd(user.getResvStCd());
				src.setSelfYn(user.getSelfYn());
				src.setSuptYn(user.getCorpSuptYn());
			} else if(CollectionUtils.isNotEmpty(targets)) {
				errorTxt += "대상자가 중복으로 체크됩니다.\n";
				datStCd = "3";
//			} else if( userList.stream().anyMatch(u->NumberUtils.toInt(u.getCorpSpfn(), 0) == src.getCorpSpfn()) ) {
//				errorTxt += "이미 검진완료 처리되었습니다.\n";
//				datStCd = "3";
			} else if( CollectionUtils.isNotEmpty(userList) ) {
				errorTxt += "이미 검진완료 처리되었습니다.\n";
				datStCd = "3";
//				errorTxt += "회사지원금이 일치하지 않습니다.\n";
//				datStCd = "3";
			} else {
				//src.setCorpSpfn(0);
				// src.setUid(null);
				// src.setCuTgtrId();
				// src.setResvId();
				//src.setResvStCd(user.getResvStCd());
				//src.setSelfYn(user.getSelfYn());
				//src.setSuptYn(user.getCorpSuptYn());
				errorTxt += "고객정보가 존재하지 않습니다.\n";
				datStCd = "3";
			}

			if("".equals(src.getExmrNm()) || "".equals(src.getCuiNm()) || "".equals(src.getClcoNm())) {
				datStCd = "2";
			}
			src.setDatStCd(datStCd); // 데이터 상태코드
			src.setUpldErrCausCont(errorTxt);

			// 정보 저장
			retVal = uploadRepository.insertCheckupExaminationBatch(src); // 이거 하다 중지
//			System.out.println(retVal);
			// 개별적인 처리 형태로 진행 예정
			// temp 테이블을 맵 리스트 형태로 가져온다.
			//BatchExminationTempModel temp
		}

		temp = uploadRepository.getBatchExaminationTempList(managerDtl.getMngrId());

		System.out.println(temp);
		System.out.println(temp.size());
		for(int i = 0; i<temp.size(); i++) {

			ExaminationSrcModel model2 = new ExaminationSrcModel();
			model2.setFrstRegrId(String.valueOf(managerDtl.getMngrId()));
			model2.setFrstRegrTyCd(managerDtl.getFrstRegrTyCd());
			model2.setLastUpdrId(String.valueOf(managerDtl.getMngrId()));
			model2.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());
			model2.setYr(String.valueOf(yr));
			model2.setMngrId(managerDtl.getMngrId());
			model2.setCuTgtrId(temp.get(i).getCuTgtrId());
			model2.setBlkUpldExamId(String.valueOf(temp.get(i).getBlkUpldExamId()));

			// CASE 1. 엑셀에 중복값이 존재한경우
			if(2 == temp.get(i).getExcelSameRnk()) {
				uploadRepository.updateExcelDupData(model2);
			}
			// CASE 2. 동명 이인이 존재 할 경우 이건 마지막에 한번 더 처리.
			//uploadRepository.updateExcelDupNmCheck(model2);
			// CASE 3. 나머지 모두 UPDATE 기본적으로 상단 로직에서 처리 된 내용.
			// CASE 4. 등록된 회원이 아닐경우 -- TargetLinkID IS NULL 상단에서 처리
			// CASE 5. 센터 정보가 다를경우 상단에서 처리
			// CASE 6. 미예약자 이면서 TargetLink에 패키지 정보가 없는 경우
			if(0 == temp.get(i).getResvId() && null == temp.get(i).getPkgNm()) {
				uploadRepository.updateExcelDidntReserveUser(model2);
			}
			// CASE 7. Request에 패키지 정보가 없을 경우 입력된 패키지 정보가 없을 경우
			uploadRepository.updateExcelRequestPakgesCheck(model2);

			// CASE 8. 정산 데이터 확인중인경우 기타 오류로 표기
			// 정산관련 테이블 미구현 이슈로 인해 건너뜀.
		}
		ExaminationSrcModel model = new ExaminationSrcModel();
		model.setFrstRegrId(String.valueOf(managerDtl.getMngrId()));
		model.setFrstRegrTyCd(managerDtl.getFrstRegrTyCd());
		model.setLastUpdrId(String.valueOf(managerDtl.getMngrId()));
		model.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());
		model.setYr(String.valueOf(yr));
		model.setMngrId(managerDtl.getMngrId());

		// ExaminationValidationInsert 프로시저 Start
		//uploadRepository.insertResvSlctItmRecs(src);

		//uploadRepository.deleteResvSlctItmBsc(src);

		uploadRepository.updateResvBsc(model);

		uploadRepository.insertResvRecs(model);

		// CASE 5. TargetLink는 존재하나 RequestID가 존재 하지 않을 경우(미예약자 이므로 예약을 진행해야함)
		//uploadRepository.insertIsNotExResvBsc(src);

		//
		uploadRepository.insertCuTgtrHis(model);
		//오류로 나온데이터 다시 입력 시 삭제
		uploadRepository.deleteErrorDataControl(model);
		//  0 : 미진행
		//  1 : 정상
		//  2 : 누락
		//  3 : 데이터불일치(정보)
		//  4 : 기타(형식 오류..등)
		// datStCd = "1,2,3,4";
		model.setDatStCd("99");
		allList = uploadRepository.selectBlkUpldExamTmp(model);
		model.setDatStCd("");
		totalList = uploadRepository.selectBlkUpldExamTmp(model); // 오류 전체
		model.setDatStCd("1");
		nomalList = uploadRepository.selectBlkUpldExamTmp(model); //
		model.setDatStCd("2");
		missingList = uploadRepository.selectBlkUpldExamTmp(model);
		model.setDatStCd("3");
		unMatchList = uploadRepository.selectBlkUpldExamTmp(model);
		model.setDatStCd("4");
		etcList = uploadRepository.selectBlkUpldExamTmp(model);

		result.put("allList", allList); // 전체
		result.put("totalList", totalList); // 전체
		result.put("nomalList", nomalList); // 일반(성공)
		result.put("missingList", missingList); // 누락
		result.put("unMatchList", unMatchList); // 매칭 안됨.
		result.put("etcList", etcList); // 기타

		result.put("allSize", allList.size());
		result.put("totalSize", totalList.size());
		result.put("nomalSize", nomalList.size());
		result.put("missingSize", missingList.size());
		result.put("unMatchSize", unMatchList.size());
		result.put("etcSize", etcList.size());

		// 필요한 목록 중복, 내용누락, 기타
		result.put("success", "good");
		return result;
	}

	public List<BatchExminationExcelModel> getExaminationExcelList(ExaminationSrcModel src) {

		src.setMngrId(BatchUploadUtils.getCurrentMngrId());
		return uploadRepository.getExaminationExcelList(src);
	}

	public Map<String, Object> deleteSelectCheckup(List<BatchExminationExcelModel> in) {
		Map<String, Object> result = new HashMap<>();
		ExaminationSrcModel src = new ExaminationSrcModel();

		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());

		for(int i=0;i<in.size();i++) {
			src = new ExaminationSrcModel();
			src.setBlkUpldExamId(String.valueOf(in.get(i).getBlkUpldExamId()));
			src.setMngrId(managerDtl.getMngrId()); // 관리자 아이디
			src.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());

			uploadRepository.deleteSelectCheckup(src);
		}
		// 필요한 목록 중복, 내용누락, 기타
		result.put("success", "good");
		return result;
	}

	public Map<String, Object> getBatchExaminationList(ExaminationSrcModel vo) {
		Map<String, Object> result = new HashMap<>();

		List<BatchExminationExcelModel> allList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> totalList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> nomalList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> missingList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> unMatchList = new ArrayList<BatchExminationExcelModel>();
		List<BatchExminationExcelModel> etcList = new ArrayList<BatchExminationExcelModel>();

		Integer mngrId = BatchUploadUtils.getCurrentMngrId();
		vo.setMngrId(mngrId);

		vo.setDatStCd("99");
		allList = uploadRepository.selectBlkUpldExamTmp(vo);
		vo.setDatStCd("");
		totalList = uploadRepository.selectBlkUpldExamTmp(vo); // 오류 전체
		vo.setDatStCd("1");
		nomalList = uploadRepository.selectBlkUpldExamTmp(vo); //
		vo.setDatStCd("2");
		missingList = uploadRepository.selectBlkUpldExamTmp(vo);
		vo.setDatStCd("3");
		unMatchList = uploadRepository.selectBlkUpldExamTmp(vo);
		vo.setDatStCd("4");
		etcList = uploadRepository.selectBlkUpldExamTmp(vo);

		result.put("allList", allList); // 전체
		result.put("totalList", totalList); // 전체
		result.put("nomalList", nomalList); // 일반(성공)
		result.put("missingList", missingList); // 누락
		result.put("unMatchList", unMatchList); // 매칭 안됨.
		result.put("etcList", etcList); // 기타

		result.put("allSize", allList.size());
		result.put("totalSize", totalList.size());
		result.put("nomalSize", nomalList.size());
		result.put("missingSize", missingList.size());
		result.put("unMatchSize", unMatchList.size());
		result.put("etcSize", etcList.size());

		return result;
	}

	public Map<String, Object> initExaminationList(ExaminationSrcModel vo) {

		Map<String, Object> result = new HashMap<>();

		vo.setMngrId(BatchUploadUtils.getCurrentMngrId());
		uploadRepository.initExamination(vo);

		result.put("success", "good");
		return result;
	}
}
