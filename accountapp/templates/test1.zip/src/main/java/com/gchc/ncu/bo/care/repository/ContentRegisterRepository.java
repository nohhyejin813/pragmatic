package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.CnntAbvBscModel;
import com.gchc.ncu.bo.care.models.MsgRcvrBscModel;
import com.gchc.ncu.bo.care.vo.ContentRegisterVo;

@Mapper
public interface ContentRegisterRepository {

	List<CnntAbvBscModel> selectRegisterList(ContentRegisterVo criteria);
	CnntAbvBscModel selectDetail(ContentRegisterVo criteria);

	void updateDetail(ContentRegisterVo criteria);

	List<MsgRcvrBscModel> selectManager();
	void saveManager(MsgRcvrBscModel model);
	void deleteManager(MsgRcvrBscModel model);

}
