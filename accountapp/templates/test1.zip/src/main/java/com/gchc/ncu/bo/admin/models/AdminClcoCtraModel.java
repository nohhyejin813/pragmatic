package com.gchc.ncu.bo.admin.models;

import com.gchc.ncu.bo.comm.models.NcuPageableVo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AdminClcoCtraModel extends NcuPageableVo {

	private int clcoCtraId;
	private int clcoId;
	private String yr;
	private String unspGrdCuResvSrtDt;
	private String unspGrdCuResvEndDt;
	private String excuResvSrtDt;
	private String excuResvEndDt;
	private String resvSrtDt;
	private String resvEndDt;
	private String aempExcsSuptResvSrtDt;
	private String aempExcsSuptResvEndDt;
	private String spcuResvSrtDt;
	private String spcuResvEndDt;
}
