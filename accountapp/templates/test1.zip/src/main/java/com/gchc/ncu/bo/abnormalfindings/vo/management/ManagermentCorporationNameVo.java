package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;




@Getter
@Setter
@ToString
public class ManagermentCorporationNameVo extends GchcVo {
	@ApiModelProperty(value="유소견 관리 고객사 여부(Y-true, N-false)")
	private Boolean isMenuAbnfManage;

	private Integer nMenuAbnfManage;

	@ApiModelProperty(value="조회할 연도", example = "2020")
	private String yr;

	private Integer tgtClcoId;
}