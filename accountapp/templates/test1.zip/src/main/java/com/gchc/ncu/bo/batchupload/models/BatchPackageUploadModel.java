package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import com.gchc.ncu.bo.comm.models.NcuPageableVo;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BatchPackageUploadModel extends NcuPageableVo {

	Integer upldPkgId;

	Integer pkgId;

	Integer rnk;

	Integer yr;

	Integer cuiId;

	Integer clcoId;

	String pkgNm;

	String sexCdNm;

	String pkgBscPrcVal;

	String cuiNm;

	String prpPridSrtDt;

	String prpPridEndDt;

	String pkgRegStCd;

	String pkgErrCont;

	String pkgTyCont;

	int useYn;

	String fileGrpId;

	String fileId;

	int fileNo;
}
