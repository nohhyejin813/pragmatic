package com.gchc.ncu.bo.batchupload.controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;

@Slf4j
@Service
public class BatchXlsHistProcess {

	@Autowired	private XlsDownloadRecordService xlsDownloadRecordServicce;

	public void insertHistXlsDownload(XlsDownloadHistModel histModel) {

		try {
			XlsDownloadRecordModel record = new XlsDownloadRecordModel();
			record.setDwldPageNm(histModel.getDwldPageNm());
			record.setDwldPageUrl(histModel.getDwldPageUrl());
			if(histModel.getDwldCont().length() > 200)
				record.setDwldCont(histModel.getDwldCont().substring(0, 200));
			else
				record.setDwldCont(histModel.getDwldCont());
			record.setDwldCont(histModel.getDwldCont());
			record.setDwldMemo(histModel.getDwldMemo()); // 메모
			record.setInnfHndlPlcyAgrYn(false);
	//		record.setDwldActiCont(model.getDwldMemo());
			record.setDwldRsnCd("90");
			if(!ObjectUtils.isEmpty(histModel.getDwldCustNm()))
				record.setCustNm(histModel.getDwldCustNm()+" 외 "+(histModel.getInnfVwCnt()-1)+"명");
			record.setInnfVwCnt(histModel.getInnfVwCnt()); //개인정보 Download 건수.
			xlsDownloadRecordServicce.insert(record);
		}
		// SPARROW 1490525 IMPROPER_CHECK_FOR_UNUSUAL_OR_EXCEPTIONAL_CONDITION
		catch( NullPointerException e ) {

			// SPARROW 1490524 EMPTY_CATCH_BLOCK
			LOGGER.error(ExceptionUtils.getStackTrace(e));
		}
	}
}
