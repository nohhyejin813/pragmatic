
package com.gchc.ncu.bo.challenge.auth.models;

import com.gchc.common.model.GchcPageableVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.util.Map;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class AuthBoardSearchModel extends GchcPageableVo {

	private int postId;	// 게시글아이디
	private int clcoId;	// 고객사아이디
	private int bsplId;	// 사업장아이디
	private int ono;	// 차수

	private String baseYear;	// 기준년도
	private String svcId;		// 서비스아이디
	private String svcNm;		// 서비스명
	private String sonoId;		// 기수아이디
	private String searchCode;	// 검색코드
	private String brdCatCd;	// 웰보드종류코드(100:웰톡, 200:웰스토리)
	private String division;	// 구분
 	private String chalCatCd;	// 챌린지카테고리코드
 	private String searchName;	// 검색명
 	private String boardState;  // 게시물상태

	@ApiModelProperty(value = "엑셀다운로드")
	private Map<String, String> dwldInfo;

}
