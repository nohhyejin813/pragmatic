package com.gchc.ncu.bo.assessment.controller;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.management.exception.UstraManagementResponseCode;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;

import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.AssessmentTargetModel;
import com.gchc.ncu.bo.assessment.service.AssessmentService;
import com.gchc.ncu.bo.assessment.vo.AssessmentQuestionTypeVo;
import com.gchc.ncu.bo.assessment.vo.AssessmentVo;
import com.gchc.ncu.bo.unicmm.models.SurveyModel;

/**
 * @FileName	: AssessmentManagementController.java
 * @date		: 2021. 7. 8
 * @author		: gs_yjhan
 * @프로그램 설명	: 검진기관평가관리 > 평가문항관리 Controller
 * @변경이력		:
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/assessment/management")
@Api(tags = "검진기관평가관리 > 평가문항관리 - AssessmentManagementController")
public class AssessmentManagementController {

	private final AssessmentService service;

	@Autowired
	private FileOperationManager fileOperationManager;

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가문항관리 > 목록 조회
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@GetMapping("")
	@ApiOperation(value="평가문항관리 목록 조회", notes="평가문항관리 목록을 조회한다." )
	public List<AssessmentModel> getAssessmentManagementList() {
		return service.getAssessmentManagementList();
	}

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 > 상세 > 검진기관 리스트 조회
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@GetMapping("/targets")
	@ApiOperation(value="평가문항관리 검진기관 목록 조회", notes="평가문항관리 검진기관 목록을 조회한다." )
	public List<AssessmentTargetModel> getAssessmentManagementTargetList(@RequestParam int yr) {
		return service.getAssessmentManagementTargetList(yr);
	}

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 > 상세 조회
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@GetMapping("/{cuiAsmId}")
	@ApiOperation(value="평가문항관리 상세 조회", notes="평가문항관리 상세를 조회한다." )
	public AssessmentVo getAssessmentManagement(@PathVariable int cuiAsmId) {
		return service.getAssessmentManagement(cuiAsmId);
	}

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 > 임시저장
	 *
	 * @param ㅑㅜㅅ cuiAsmId
	 * @param AssessmentVo asmVo
	 *
	 * @return ResponseCode
	 */
	@PostMapping("/{cuiAsmId}/temp")
	@ApiOperation(value="평가문항관리 임시저장", notes="평가문항관리 정보를 임시저장한다." )
	public ResponseCode saveAssessmentManagementTemp(@PathVariable int cuiAsmId, @RequestBody AssessmentVo asmVo) {
		try {
			service.saveAssessmentManagement(true, asmVo);

		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException
			| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
			| UnsupportedEncodingException e) {
			return UstraManagementResponseCode.CANNOT_SAVE_RECORD;
		}

		return UstraManagementResponseCode.SUCCESS;
	}

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 > 상세 조회
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@PostMapping("/{cuiAsmId}")
	@ApiOperation(value="평가문항관리 최종등록", notes="평가문항관리 정보를 최종등록한다." )
	public ResponseCode saveAssessmentManagement(@PathVariable int cuiAsmId, @RequestBody AssessmentVo asmVo) {
		try {
			service.saveAssessmentManagement(false, asmVo);

		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException
			| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
			| UnsupportedEncodingException e) {
			return UstraManagementResponseCode.CANNOT_SAVE_RECORD;
		}

		return UstraManagementResponseCode.SUCCESS;
	}

	/**
	* 처리내용 : 검진기관평가관리 > [T] 평가현황 > 상세 조회 > 작년문항 불러오기
	 *
	 * @param
	 *
	 * @return List<AssessmentModel>
	 */
	@GetMapping("/last-year")
	@ApiOperation(value="작년 평가문항 불러오기", notes="작년 평가문항관리 정보를 조회한다." )
	public List<AssessmentQuestionTypeVo> getAssessmentManagementByLastYear(@RequestParam int yr) {
		return service.getAssessmentManagementByLastYear(yr);
	}

	/**
	 * 검진기관 평가 관리 - 평가 문항 연결
	 *
	 * @param
	 *
	 * @return
	 */
	@GetMapping("/assessment-list")
	@ApiOperation(value="평가 문항 연결", notes="평가 문항 연결 리스트를 조회한다." )
	public List<SurveyModel> getAssessmentQuestionList() {
		return service.getAssessmentQuestionList();
	}


	/**
	 *
	 * 처리내용 : 검진기관평가관리 - 평가문항관리 - 엑셀다운로드
	 *
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	@ApiOperation(value = "평가문항관리 엑셀 다운로드", notes = "평가문항관리 목록 조회")
	@PostMapping("/download-excel/list")
	public ResponseEntity<?> getAssessmentManagementListExcelDownload(HttpServletRequest request, HttpServletResponse response) {

		final List<AssessmentModel> resultList = service.getAssessmentManagementList();
		List<Map<String, Object>> mapDataList = new ArrayList<Map<String, Object>>();

		// 공통백신결과 List MAP 처리
		for (int i = 0; i < resultList.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			AssessmentModel modelRow = resultList.get(i);

			map.put("col1", modelRow.getRowNum()); //No
			map.put("col2", modelRow.getYr()); // 평가연도
			map.put("col3", modelRow.getTargetCnt()); //대상 검진기관 수
			map.put("col4", modelRow.getAsmSrtDt()); // 평가기간 시작
			map.put("col5", modelRow.getAsmEndDt()); // 평가기간 종료
			map.put("col6", modelRow.getSrvyId()); 	// 설문아이디
			map.put("col7", modelRow.getSrvyTitl()); // 설문제목

			mapDataList.add(map);
		}

		// ===============================================================
		UstraExcelModel excelModel;
		/* 셀 정보*/
		//List<UstraExcelCellInfoModel> cellInfoList;

		// [[ 1번 SHEET ]] ########################################################################
		excelModel = UstraExcelModel.of(
			mapDataList, //데이타, List<Map<String, Object>> data
			Arrays.asList( //셀, List<UstraExcelCellInfoModel> cells
				//선택다운로드 방식, 추출항목 : 상담일자/고객사/문의구분/제목/내용
				new UstraExcelCellInfoModel("col1", "No")
				, new UstraExcelCellInfoModel("col2", "평가연도") // 답변일 10 :)최초등록일시         N  :frstRegDtm   datetime()
				, new UstraExcelCellInfoModel("col3", "대상 검진기관 수") // 10 :)고객사명                  :clcoNm           nvarchar(200)
				, new UstraExcelCellInfoModel("col4", "평가기간(시작일)") // 3  :)문의구분           N  :inqyTyCd         nvarchar(4)
				, new UstraExcelCellInfoModel("col5", "평가기간(종료일)") // 15 :)문의제목               N  :inqyTitl         nvarchar(200)
				, new UstraExcelCellInfoModel("col6", "설문아이디") // 16 :)문의내용               N  :inqyCont         ntext(1073741823)
				, new UstraExcelCellInfoModel("col7", "설문제목") // 8  :)이름                      :nm               nvarchar(50)
			))
			.withSheetName("목록"); // 시트명

		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel), "평가문항관리.xls", request, response)
				.build());
	}

}
