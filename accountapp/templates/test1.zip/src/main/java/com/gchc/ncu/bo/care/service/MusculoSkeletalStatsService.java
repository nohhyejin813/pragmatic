package com.gchc.ncu.bo.care.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gchc.ncu.bo.comm.util.NcuAuthenticationUtils;
import com.gchc.ncu.bo.config.authentication.NcuAdminUser;
import org.springframework.stereotype.Service;

import com.gchc.ncu.bo.care.models.MusculoSkeletalStatsModel;
import com.gchc.ncu.bo.care.models.MusculoSkeletalStatusModel;
import com.gchc.ncu.bo.care.repository.MusculoSkeletalStatsRepository;
import com.gchc.ncu.bo.care.vo.MusculoSkeletalStatsVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MusculoSkeletalStatsService {

	public enum SEARCH_ITEMS_TYPE {
		AGE,
		GENDER,
	    DURATION_OF_JOB_NOW,
	    DURATION_OF_JOB_PAST,
	    BURDEN_OF_JOB,
	    PAIN
	    ;
	}

	public enum SEARCH_TYPE {
		DEPT,
		LINE,
		JOB
		;
	}

	private final MusculoSkeletalStatsRepository repository;

	public List<Map<String, Object>> getYearList() {
		return repository.selectYearList();
	}

	public List<Map<String, Object>> getClcoListByYear(String year) {

		Map<String, Object> params = new HashMap<>();

		params.put("year", year);

		NcuAdminUser currentUser = NcuAuthenticationUtils.getCurrentUser();

		String authTypeCd = currentUser.getAuthType();

		if( !"04".equals(authTypeCd)){

			params.put("clcoId", currentUser.getClcoId());
		}
		return repository.selectClcoListByYear(params);
	}

	public List<Map<String, Object>> getBsplListByClcoId(Map<String, Object> params) {
		return repository.selectBsplListByClcoId(params);
	}

	public List<MusculoSkeletalStatsModel> getStatisticsItems(MusculoSkeletalStatsVo vo) {
		if (vo.getSearchItemType().equals(SEARCH_ITEMS_TYPE.AGE.name())) {
			return repository.selectStatisticsListByAge(vo);
		} else if (vo.getSearchItemType().equals(SEARCH_ITEMS_TYPE.GENDER.name())) {
			return repository.selectStatisticsListByGender(vo);
		} else if (vo.getSearchItemType().equals(SEARCH_ITEMS_TYPE.DURATION_OF_JOB_NOW.name())) {
			return repository.selectStatisticsListByNow(vo);
		} else if (vo.getSearchItemType().equals(SEARCH_ITEMS_TYPE.DURATION_OF_JOB_PAST.name())) {
			return repository.selectStatisticsListByPast(vo);
		} else if (vo.getSearchItemType().equals(SEARCH_ITEMS_TYPE.BURDEN_OF_JOB.name())) {
			return repository.selectStatisticsListByBurden(vo);
		} else if (vo.getSearchItemType().equals(SEARCH_ITEMS_TYPE.PAIN.name())) {
			return repository.selectStatisticsListByPain(vo);
		}

		return null;
	}

	public List<MusculoSkeletalStatusModel> getStatisticsListStatus(MusculoSkeletalStatsVo vo) {
		return repository.selectStatisticsListStatus(vo);
	}

}
