package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CareCampaignVo extends UstraManagementBaseModel {

    private String crteYr;
    private String cmpgKindCd;
    private Integer clcoId;
    private Integer bsplId;
    private String clcoNm;
    private String useYn;
    private String title;
    private String msgType;

    private Integer cmpgCtraId;
    private Integer cmpgId;
    private Integer cmpgCmptId;
    private Integer msgId;

	private String cmpgStCd;
	private String mbrNm;

	private String pgrsSrtDt;
	private String pgrsEndDt;
	private String uid;

	private String searchCd;
	private String searchNm;

	private String teamNm;
	private String cmpgCd;

    private String cmpnWayCd;
}
