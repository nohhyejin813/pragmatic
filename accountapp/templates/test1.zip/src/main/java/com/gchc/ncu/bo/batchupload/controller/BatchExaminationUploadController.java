package com.gchc.ncu.bo.batchupload.controller;

import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.batchupload.enu.ExaminationUploadState;
import com.gchc.ncu.bo.batchupload.models.BatchExminationExcelModel;
import com.gchc.ncu.bo.batchupload.models.ExaminationExcelDownModel;
import com.gchc.ncu.bo.batchupload.models.ExaminationSrcModel;
import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.batchupload.service.BatchExaminationUploadService;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@RequiredArgsConstructor
@Api(tags = "수검 일괄업로드 컨트롤러")
@RestController
@RequestMapping("/api/bo/batchupload")
public class BatchExaminationUploadController {

	@Autowired
	private FileOperationManager fileOperationManager;

	private final BatchExaminationUploadService examinationService;

	@Autowired private BatchXlsHistProcess batchXlsHistProcess;

	@PostMapping("/examination/download_excel")
	public ResponseEntity<?> excelDownload(@RequestBody ExaminationExcelDownModel in, HttpServletRequest request, HttpServletResponse response) {
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		ExaminationSrcModel src = new ExaminationSrcModel();
		// 1. 결과 목록호출 resultFlag (0:전체, 1:성공, 2:에러)
		System.out.println("##### getResultFlag() = "+in.getResultFlag());

		// SPARROW 1490497,1490498,1490499 FORBIDEN_ASSIGN_LITERAL
		ExaminationUploadState datStCd = ExaminationUploadState.ERROR;
		if("0".equals(in.getResultFlag())) { // 전체
			datStCd = ExaminationUploadState.ALL;
		} else if("1".equals(in.getResultFlag())) { // 성공
			datStCd = ExaminationUploadState.SUCCESS;
		}

		src.setDatStCd(datStCd.getValue());
		src.setYr(in.getYr());

		//List<PackageUploadExcelModel> pkgList = examinationService.getPackageExcelList(in);
		List<BatchExminationExcelModel> examinationList = examinationService.getExaminationExcelList(src);
		System.out.println("############# excelList.size = "+examinationList.size());
		String brdtArr[];
		String bryr = "";
		String brdt = "";
		String sexCd = "";

		// 2. 공통백신결과 List MAP 처리
		for(int i=0; i<examinationList.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			BatchExminationExcelModel exMap = examinationList.get(i);				// 패키지 조회결과 리스트
			if(!ObjectUtils.isEmpty(exMap.getBrdt())) {
				sexCd = exMap.getSexCd();
				brdtArr = exMap.getBrdt().split("-");
				bryr = brdtArr[0].substring(0,2); // ex 1981-12-13 -> 19  출생년도 앞자리 두개 추출
				brdt = brdtArr[0].substring(2) + brdtArr[1] + brdtArr[2]; // 엑셀 업로드 양식 811213 형태로 변경
				if("1".equals(sexCd)) {
					if("19".equals(bryr)) {
						brdt = brdt + "-1";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-3";
					}
				} else {
					if("19".equals(bryr)) {
						brdt = brdt + "-2";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-4";
					}
				}
			}
			System.out.println(brdt);
			map.put("col1"	, exMap.getClcoNm());		// 고객사명
			map.put("col2"	, exMap.getCuiNm());		// 검진센터명
			map.put("col3"	, exMap.getExmrNm());		// 이름
			map.put("col4"	, brdt);					// 생일
			map.put("col5"	, exMap.getCorpSpfn());		// 회사지원금
			map.put("col6"	, exMap.getHvexCmplDt());	// 수검날짜
			map.put("col7"	, exMap.getUid());			// MemberId
			map.put("col8" 	, exMap.getUpldErrCausCont());

			list.add(map);
		}
		System.out.println("#### list = "+list.toString());

		String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
		String pageNm = "수검-수검완료";
		String cont = "고객사명, 검진센터명, 이름, 주민번호, 회사지원금, 수검날짜, MemberId";
		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		histModel.setDwldPageUrl(tagretUrl);
		histModel.setInnfVwCnt(list.size());
		histModel.setDwldPageNm(pageNm);
		histModel.setDwldCont(cont);
		histModel.setDwldCustNm(list.get(0).get("col3").toString());
		batchXlsHistProcess.insertHistXlsDownload(histModel);

		// 3. 헤더 값   매핑
		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사명"),
				new UstraExcelCellInfoModel("col2"	, "검진센터명"),
				new UstraExcelCellInfoModel("col3"	, "이름"),
				new UstraExcelCellInfoModel("col4"	, "주민번호"),
				new UstraExcelCellInfoModel("col5"	, "회사지원금"),
				new UstraExcelCellInfoModel("col6"	, "수검날짜"),
				new UstraExcelCellInfoModel("col7"	, "MemberId"),
				new UstraExcelCellInfoModel("col8"	, "오류내용")
			))
//		.withCellGenerator(new com.gsitm.ustra.java.data.poi.generator.ColoredHeaderUstraExcelCellGenerator())	// 색칠
//		.withAdditionalData("data", commVcnList)
//		.withTitle("공통백신정보")		// 제목
		.withCellGenerator(new BatchUploadCellGenerator(getSpecialCellList()))
		.withSheetName("수검완료");	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel), "수검완료", request, response)
				.build());
	}

	private List<String> getSpecialCellList() {
		return Arrays.asList(
				"고객사명",
				"검진센터명",
				"이름",
				"주민번호",
				"회사지원금"
			);
	}

	@SuppressWarnings("null")
	@PostMapping("/examination/deleteSelectCheckup")
	@ApiOperation(value="수검완료 목록 삭제", notes="수검완료 목록 삭제한다.")
	public Map<String, Object> deleteSelectCheckup(@RequestBody List<BatchExminationExcelModel> in) {
		Map<String, Object> result = new HashMap<>();

		result = examinationService.deleteSelectCheckup(in);
		return result;
	}


	@PostMapping("/examination/selected_download_excel")
	public ResponseEntity<?> selectedDownloadExcelExamination(@RequestBody List<BatchExminationExcelModel> in, HttpServletRequest request, HttpServletResponse response) {
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		String datStCd = "";

		// System.out.println("############# excelList.size = "+examinationList.size());
		String brdtArr[];
		String bryr = "";
		String brdt = "";
		String sexCd = "";

		// 2. 공통백신결과 List MAP 처리
		for(int i=0; i<in.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			BatchExminationExcelModel exMap = in.get(i);				// 수검완료 체크 리스트
			if(!ObjectUtils.isEmpty(exMap.getBrdt())) {
				sexCd = exMap.getSexCd();
				brdtArr = exMap.getBrdt().split("-");
				bryr = brdtArr[0].substring(0,2); // ex 1981-12-13 -> 19  출생년도 앞자리 두개 추출
				brdt = brdtArr[0].substring(2) + brdtArr[1] + brdtArr[2]; // 엑셀 업로드 양식 811213 형태로 변경
				if("1".equals(sexCd)) {
					if("19".equals(bryr)) {
						brdt = brdt + "-1";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-3";
					}
				} else {
					if("19".equals(bryr)) {
						brdt = brdt + "-2";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-4";
					}
				}
			}
			System.out.println(brdt);
			map.put("col1"	, exMap.getClcoNm());		// 고객사명
			map.put("col2"	, exMap.getCuiNm());		// 검진센터명
			map.put("col3"	, exMap.getExmrNm());		// 이름
			map.put("col4"	, brdt);					// 생일
			map.put("col5"	, exMap.getCorpSpfn());		// 회사지원금
			map.put("col6"	, exMap.getHvexCmplDt());	// 수검날짜
			map.put("col7"	, exMap.getUid());			// MemberId
			map.put("col8"	, exMap.getUpldErrCausCont());

			list.add(map);
		}
		System.out.println("#### list = "+list.toString());

		String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
		String pageNm = "수검-수검완료";
		String cont = "고객사명, 검진센터명, 이름, 주민번호, 회사지원금, 수검날짜, MemberId";
		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		histModel.setDwldPageUrl(tagretUrl);
		histModel.setInnfVwCnt(list.size());
		histModel.setDwldPageNm(pageNm);
		histModel.setDwldCont(cont);
		histModel.setDwldCustNm(list.get(0).get("col3").toString());
		batchXlsHistProcess.insertHistXlsDownload(histModel);

		// 3. 헤더 값   매핑
		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사명"),
				new UstraExcelCellInfoModel("col2"	, "검진센터명"),
				new UstraExcelCellInfoModel("col3"	, "이름"),
				new UstraExcelCellInfoModel("col4"	, "주민번호"),
				new UstraExcelCellInfoModel("col5"	, "회사지원금"),
				new UstraExcelCellInfoModel("col6"	, "수검날짜"),
				new UstraExcelCellInfoModel("col7"	, "MemberId"),
				new UstraExcelCellInfoModel("col8"	, "오류내용")
			))
//		.withCellGenerator(new com.gsitm.ustra.java.data.poi.generator.ColoredHeaderUstraExcelCellGenerator())	// 색칠
//		.withAdditionalData("data", commVcnList)
//		.withTitle("공통백신정보")		// 제목
		.withCellGenerator(new BatchUploadCellGenerator(getSpecialCellList()))
		.withSheetName("수검완료");	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel), "수검완료", request, response)
				.build());
	}

	@SuppressWarnings("null")
	@PostMapping("/examination/getBatchExaminationList")
	@ApiOperation(value="수검완료 목록 삭제", notes="수검완료 목록 삭제한다.")
	public Map<String, Object> getBatchExaminationList(@RequestBody ExaminationSrcModel vo) {
		Map<String, Object> result = new HashMap<>();
		System.out.println(vo);
		result = examinationService.getBatchExaminationList(vo);
		return result;
	}

	@PostMapping("/examination/init")
	public Map<String, Object> initExaminationList(@RequestBody ExaminationSrcModel vo) {

		return examinationService.initExaminationList(vo);
	}

	@PostMapping("/examination/examination_template_download")
	public ResponseEntity<?> downloadTemplateExcelExamination(@RequestBody BatchExminationExcelModel in, HttpServletRequest request, HttpServletResponse response) {
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.

		// 3. 헤더 값   매핑
		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사명"),
				new UstraExcelCellInfoModel("col2"	, "검진센터명"),
				new UstraExcelCellInfoModel("col3"	, "이름"),
				new UstraExcelCellInfoModel("col4"	, "주민번호"),
				new UstraExcelCellInfoModel("col5"	, "회사지원금"),
				new UstraExcelCellInfoModel("col6"	, "수검날짜"),
				new UstraExcelCellInfoModel("col7"	, "MemberId"),
				new UstraExcelCellInfoModel("col8"	, "오류내용")
			))
//		.withCellGenerator(new com.gsitm.ustra.java.data.poi.generator.ColoredHeaderUstraExcelCellGenerator())	// 색칠
//		.withAdditionalData("data", commVcnList)
//		.withTitle("공통백신정보")		// 제목
		.withCellGenerator(new BatchUploadCellGenerator(getSpecialCellList()))
		.withSheetName("수검완료");	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel), "일괄업로드수검등록_V3_2", request, response)
				.build());
	}

}
