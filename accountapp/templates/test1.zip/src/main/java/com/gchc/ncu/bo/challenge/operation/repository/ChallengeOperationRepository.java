package com.gchc.ncu.bo.challenge.operation.repository;

import com.gchc.ncu.bo.care.models.CmpgBscModel;
import com.gchc.ncu.bo.care.models.CmpgCmpnDtlModel;
import com.gchc.ncu.bo.care.models.CmpgNtfcDtlModel;
import com.gchc.ncu.bo.care.models.*;
import com.gchc.ncu.bo.challenge.operation.models.CmpgCtraBsc2Model;
import com.gchc.ncu.bo.challenge.operation.vo.ChallengeOperationVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ChallengeOperationRepository {

	CmpgCtraBsc2Model selectCampaignContract(ChallengeOperationVo vo);
	void deleteCampaignContract(int cmpgCtraId);
	int selectUsedCampaignContractCount(int cmpgCtraId);
	int selectUsedCampaignMemberCount(int cmpgId);
	int selectOverlappedDateCount(CmpgBscModel model);

	void deleteCampaignRewardByCmpgId(int cmpgId);
	void deleteCampaignNotificationByCmpgId(int cmpgCtraId);

	List<CmpgBscModel> selectContractTermList(ChallengeOperationVo vo);
	void insertContractTerm(CmpgBscModel model);
	void updateContractTerm(CmpgBscModel model);
	void deleteContractTerm(int cmpgId);

	List<CmpgNtfcDtlModel> selectContractNoticeList(ChallengeOperationVo vo);
	void insertContractNotice(CmpgNtfcDtlModel model);
	void updateContractNotice(CmpgNtfcDtlModel model);
	void deleteContractNotice(int ntfcId);

	List<CmpgCmpnDtlModel> selectCampaignRewardList(ChallengeOperationVo vo);
	void insertCampaignReward(CmpgCmpnDtlModel model);
	void updateCampaignReward(CmpgCmpnDtlModel model);
	void deleteCampaignReward(int cmpgCmpnId);

	List<MbrCmpgRecsModel> selectCampaignRewardMemberList(ChallengeOperationVo vo);

	void updateCampaignRewardConfirmForRank(ChallengeOperationVo vo);
	void updateCampaignRewardConfirmForDraw(CmpgCmpnDtlModel model);
	void updateCampaignRewardAfterWork(ChallengeOperationVo vo);
	void updateCampaignRewardMemberCancel(ChallengeOperationVo vo);
	void updateCampaignRewardCancel(ChallengeOperationVo vo);
	void updateCampaignRewardPrize(MbrCmpgRecsModel model);

	List<CmpgBscModel> selectOperManagementList(ChallengeOperationVo vo);
	CmpgCtraBsc2Model selectOperManagementDetail(ChallengeOperationVo vo);
	List<MbrCmpgRecsModel> selectOperManagementPeople(ChallengeOperationVo vo);
	List<MbrCmpgRecsModel> selectOperNoenterPeople(ChallengeOperationVo vo);
	List<MbrCmpgRecsModel> selectOperPersonDetail(ChallengeOperationVo vo);

	List<CmpgNtfcBscModel> selectCampaignNoticeList(ChallengeOperationVo vo);
	CmpgNtfcBscModel selectCampaignNotice(ChallengeOperationVo vo);
	void insertCampaignNotice(CmpgNtfcBscModel model);
	void updateCampaignNotice(CmpgNtfcBscModel model);
	void deleteCampaignNotice(int msgId);
	//걷기캠페인 팀전
	List<CmpgTeamRecsModel> selectOperationDetailTeam(ChallengeOperationVo vo);
	List<CmpgTeamRecsModel> selectOperTeamPersonDetail(ChallengeOperationVo vo);
	void updateCampaignTeamInfoUpdate(ChallengeOperationVo vo);
	CmpgBscModel selectOperationTeamCount(ChallengeOperationVo vo);

}
