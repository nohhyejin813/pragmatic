package com.gchc.ncu.bo.assessment.repository;



import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gchc.ncu.bo.assessment.models.AssessmentFileModel;
import com.gchc.ncu.bo.assessment.models.AssessmentGradeModel;
import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.AssessmentQuestionModel;
import com.gchc.ncu.bo.assessment.models.AssessmentScoreModel;
import com.gchc.ncu.bo.assessment.models.AssessmentTargetModel;
import com.gchc.ncu.bo.checkupinst.models.ZipModel;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.unicmm.models.SurveyModel;

/**
 * 프로토타입 Repository
 *
 * @author gs_hykim@gchealthcare.com
 */
@Mapper
public interface AssessmentRepository {

	int 							getAssessmentLastYear();
	int[]							getAssessmentYearList();

	List<ZipModel>					getAssessmentSidoList(AssessmentModel in);
	List<ZipModel>					getAssessmentGugunList(AssessmentModel in);
	List<AssessmentModel>			getAssessmentClcoList(int srchYr);
	List<AssessmentModel>			getAssessmentCuiList(AssessmentModel in);

	List<AssessmentModel> 			getAssessmentStatusList(AssessmentModel in);

	int 							uptAsmDt(AssessmentTargetModel in);
	int 							calResultAssessment(Object object);


	Integer							getCuiAsmTgtId(AssessmentModel asm);
	int 							getCuiAsmIdByCuiAsmTgtId(int cuiAsmTgtId);
	int 							sumResult(AssessmentModel model);
	AssessmentModel					getAssessmentStatusDetail(int cuiAsmTgtId);
	int								saveAssessmentStatusDetail(AssessmentModel in);
//	AssessmentModel					getAssessmentStatusDetail(AssessmentModel in);
	AssessmentFileModel 			getFileDownload(AssessmentFileModel vo);
	List<AssessmentQuestionModel>	getAssessmentQuestionResponseExampleList(AssessmentModel in);

	//2022-01-04 새 테이블로 설문 문항 getter
	List<AssessmentQuestionModel>	getAssessmentQuestionSurveyList(AssessmentModel in);

	List<AssessmentScoreModel>		getAssessmentStatusResultList(AssessmentModel in);
	List<AssessmentScoreModel>		getAssessmentStatusYearScoreList(int cuiId);
	List<AssessmentFileModel>		getAssessmentStatusFileList(int cuiAsmTgtId);
	List<AssessmentFileModel>		getAssessmentStatusFileListTobeTable(int cuiAsmTgtId);
	Double 							getAssessmentStatusSatisfactionLevel(AssessmentModel in);

	List<AssessmentTargetModel>		getAssessmentManagementTargetList(int yr);
	
	//2022-02-20 해당 cuiId별 과거 평가 타겟 리스트
	List<AssessmentTargetModel>		getAssessmentTargetHistoryList(AssessmentModel in);
	
	int								getCuiAsmIdByLastYear(int yr);
	List<AssessmentModel> 			getAssessmentManagementList();
	AssessmentModel					getAssessmentManagementDetail(int cuiAsmId);
	List<AssessmentQuestionModel> 	getAssessmentQuestionExampleList(int cuiAsmId);

	int								addAssessmentManagement(AssessmentModel in);
	int								uptAssessmentManagement(AssessmentModel in);
	int								delAssessmentQuestionExampleList(AssessmentModel in);
	int								addAssessmentQuestion(AssessmentQuestionModel in);
	int								addAssessmentQuestionExample(AssessmentQuestionModel in);





	int								addAssessmentTarget(AssessmentTargetModel in);
	int								uptAssessmentTarget(AssessmentTargetModel in);



	List<AssessmentQuestionModel> 	getAssessmentManagementQuestion(int cuiAsmTgtId);


	List<AssessmentGradeModel>		getAssessmentGradeList(int yr);
	int								saveAssessmentGrade(AssessmentGradeModel in);

	List<AssessmentScoreModel>		getAssessmentDivisionList(int yr);
	List<String>					getAssessmentConnectClcoList(AssessmentModel in);

	List<SurveyModel> 				getAssessmentQuestionList();

	int								saveQuestionAnswerFile(AssessmentFileModel in);
	int								saveAssessmentQuestionResponse(AssessmentModel in);
	AssessmentModel					getAssessmentQuestionResponseBasic(AssessmentModel in);
	int								delQuestionAnswers(AssessmentModel in);
	int								saveQuestionAnswer(AssessmentQuestionModel in);
}
