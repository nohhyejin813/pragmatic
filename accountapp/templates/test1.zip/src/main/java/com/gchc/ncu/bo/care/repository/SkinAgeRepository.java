package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.SkinAgBscModel;
import com.gchc.ncu.bo.care.models.SkinAgCnntDtlModel;
import com.gchc.ncu.bo.care.models.SkinAgRsltBscModel;
import com.gchc.ncu.bo.care.vo.SkinAgeSearchVo;

@Mapper
public interface SkinAgeRepository {

	List<SkinAgBscModel> selectSkinAgeBaseList(SkinAgeSearchVo vo);
	List<SkinAgCnntDtlModel> selectSkinAgeContentList(SkinAgeSearchVo vo);
	SkinAgBscModel selectSkinAgeBaseItem(SkinAgeSearchVo vo);
	SkinAgCnntDtlModel selectSkinAgeContentItem(SkinAgeSearchVo vo);
	void insertSkinAgeBaseItem(SkinAgBscModel model);
	void insertSkinAgeContentItem(SkinAgCnntDtlModel model);
	void updateSkinAgeBaseItem(SkinAgBscModel model);
	void updateSkinAgeContentItem(SkinAgCnntDtlModel model);
	void deleteSkinAgeBaseItem(SkinAgBscModel model);
	void deleteSkinAgeContentItem(SkinAgCnntDtlModel model);
	Integer selectSkinAgeBaseConflictCheck(SkinAgBscModel model);
	List<SkinAgRsltBscModel> selectSkinAgeResultBaseList(SkinAgeSearchVo vo);
	SkinAgRsltBscModel selectSkinAgeResultBaseItem(SkinAgeSearchVo vo);
	void insertSkinAgeResultBaseItem(SkinAgRsltBscModel model);
	void updateSkinAgeResultBaseItem(SkinAgRsltBscModel model);
	void deleteSkinAgeResultBaseItem(SkinAgRsltBscModel model);
	Integer selectSkinAgeResultConflictCheck(SkinAgRsltBscModel model);

}
