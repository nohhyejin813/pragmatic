package com.gchc.ncu.bo.challenge.contract.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

@Data
@EqualsAndHashCode(callSuper=false)
public class ChalCmpgCtraBscModel extends UstraManagementBaseModel {

	private Integer cmpgCtraId;
	@NotNull(message = "캠페인종류는 필수값입니다.")
	private String cmpgKdCd;
	private String cmpgKdNm;
	@NotNull(message = "캠페인명은 필수값입니다.")
	private String cmpgNm;
	@NotNull(message = "기준년도는 필수값입니다.")
	private String crteYr;
	private String ctraSrtDt;
	private String ctraEndDt;
	@NotNull(message = "고객사는 필수값입니다.")
	private Integer clcoId;
	private String clcoNm;
	private Integer bsplId;
	private String bsplNm;
	private Integer goalStpCnt;
	private Integer cluId;
	private Integer stdgSrvyId;
	private String guidSrtDt;
	private String guidEndDt;
	private String titl;
	private String prtcTgtCont;
	private String prtcMthCont;
	private Integer cmpnImgFileId;
	private String pctnCont;
	private String expoLocVal;
	private String cmpnWayCd;
	private String cmpnWayNm;
	private Integer rnkExpoYn;
	private Integer autoExtnAplcYn;
	private Integer useYn;
	private Integer srtBfGuidYn;
	private String cmpgCd;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

	private String copyContact;
	private Integer copyCmpgCtraId;

	private String frstNm;
	private String lastNm;


}
