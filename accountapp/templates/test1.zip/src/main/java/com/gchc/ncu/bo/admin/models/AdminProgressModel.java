package com.gchc.ncu.bo.admin.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AdminProgressModel {

	private int stlFlag;
	private int customerFlag;
	private int packageFlag;
	private int adminFlag;
	private int openFlag;
	private int clcoId;

}
