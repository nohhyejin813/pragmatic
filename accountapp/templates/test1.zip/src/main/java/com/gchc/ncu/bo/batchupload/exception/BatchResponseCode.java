package com.gchc.ncu.bo.batchupload.exception;

import com.gchc.ncu.bo.batchupload.comm.BatchException;
import com.gsitm.ustra.java.core.exception.ResponseCode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;

@Slf4j
public enum BatchResponseCode implements ResponseCode {

	UPLOAD_FAILURE("5000", "업로드에 실패하였습니다."),

	INVALID_SHEET("5001", "데이터가 존재하지 않거나 엑셀 Sheet가 잘못되었습니다."),

	INVALID_SHEET_COUNT("5002", "Sheet가 2개가 아닙니다."),

	INVALID_SHEET_NAME("5003", "잘못된 Sheet명입니다."),

	INVALID_SHEET_FORMAT("5004", "엑셀 양식이 잘못되었습니다.(-2)"),

	INVALID_ADDITIONAL_SHEET_FORMAT("5005", "추가검사개인비용 Sheet의 엑셀 양식이 잘못되었습니다."),

	INVALID_SHEET_TITLE("5006", "타이틀 영역에 {0}이(가) 누락되었습니다."),

	INVALID_ADDITIONAL_SHEET_TITLE("5007", "검사추가항목 타이틀 영역이 카테고리/검진세부항목/검사명/추가검사선택시비용으로 기재되었는지 확인해주세요."),

	INVALID_FILE_INFORMATION("5010", "잘못된 업로드 정보입니다."),

	NOT_REGISTERD_PACKAGE_NAME("5011", "등록되지 않은 패키지명입니다.\r\n고객사정보에서 패키지명을 등록하거나 엑셀에서 삭제 후 진행 가능합니다."),

	CANNOT_FOUND_PACKAGE_TYPE("5012", "패키지 타입이 존재하지 않습니다.\r\n엑셀에서 삭제 및 수정 후 진행 가능합니다.\r\n{0}"),

	INVALID_PACKAGE_TYPE_STATE("5013", "미등록 상태가 아닙니다.\r\n엑셀에서 미등록 상태 패키지타입을 삭제 후 진행 가능합니다.\r\n{0}"),

	ALREADY_REGISTERD_PACKAGE_TYPE("5014", "{0}"),

	DUPLICATED_PACKAGE_TYPE("5015", "중복된 패키지 타입이 존재합니다.\r\n엑셀에서 중복된 패키지타입을 삭제 후 진행 가능합니다.\r\n{0}"),

	NOT_REGISTERED_TRANSFER_GROUP("5020", "양도그룹이 설정되지 않았습니다."),

	NOT_REGISTERED_SELECT_GROUP("5021", "선택그룹이 설정되지 않았습니다."),

	MEMBER_REGIST_FAILURE("5101", "등록에 실패하였습니다."),

	RESULT_REGIST_DUPLICATED("5202", "중복된 예약자 정보가 존재합니다.<br>{0}"),

	INVALID_DATE_FORMAT("5203", " 검진일자에 잘못된 형식이 존재합니다.<br>{0}"),

	EMPTY_HEADER_EXIST("5204", "{0} 다음 헤더가 빈 값입니다."),

	DUP_BASIC_HEADER("5205", "기본 헤더가 중복으로 존재합니다.<br>{0}"),

	NO_MERGE_MEMBER("5999", "처리 가능한 회원이 없습니다."),

	EXIST_ERROR_MEMBER("5998", "처리 불가능한 회원이 존재합니다."),
	;

	private String code;

	private String message;

	private Class<BatchException> exceptionClass;

	BatchResponseCode(String code, String message) {

		this.code = code;
		this.message = message;
	}

	BatchResponseCode(String code, String message, Class<BatchException> exceptionClass) {

		this.code = code;
		this.message = message;
		this.exceptionClass = exceptionClass;
	}

	@Override
	public String getCode() {

		return this.code;
	}

	@Override
	public String getMessage() {

		return this.message;
	}

	public void occur() {

		if( exceptionClass != null )
			try {

				throw this.exceptionClass.newInstance();
			} catch (InstantiationException | IllegalAccessException e) {

				// SPARROW 1490482 EMPTY_CATCH_BLOCK
				LOGGER.error(ExceptionUtils.getStackTrace(e));
			}

		throw new BatchException(this);
	}

	public void occur(Object...arguments) {

		throw new BatchException(this, arguments);
	}
}
