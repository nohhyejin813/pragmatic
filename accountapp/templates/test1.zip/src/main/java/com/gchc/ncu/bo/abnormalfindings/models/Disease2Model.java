package com.gchc.ncu.bo.abnormalfindings.models;

import com.gchc.common.model.GchcPageableVo;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 * 검진결과:유소견관리(신) Model
 *
 * @since	2021.11.22
 * @author 	gs_tskwon@gchealthcare.com
 */
@Data
@Builder
@EqualsAndHashCode(callSuper=true)
@NoArgsConstructor
@AllArgsConstructor
//public class Disease2Model extends NcuPageableVo{          //페이징처리 용, 로그인정보 반영
public class Disease2Model extends GchcPageableVo {
	public Integer totalItemCount;

	/** 생성일From */
	private String frstRegDtmFrom;
	/** 생성일To */
	private String frstRegDtmTo;
	/** 검진일From */
	private String cuDtmFrom;
	/** 검진일To */
	private String cuDtmTo;

	private Integer rowNum;
	/** 관리로그ID */
	private Integer abnfMngLogId;
	/** 회원ID */
	private String uid;
	/** 회원 명 */
	@Masked(MaskingType.NAME)
	private String nm;
	/** 성별(남,여) */
	private String gender;
	/** 생년월일(YYYY-MM-DD) */
	private String brdt;
	/** 이메일 */
	@Masked(MaskingType.EMAIL)
	private String emlAdr;
	/** 핸드폰번호 */
	@Masked(MaskingType.PHONE)
	private String mblNo;
	/** 검진기록ID */
	private Integer cuRecId;
	/** 질병관리결과ID */
	private Integer dssMngRsltId;
	/** 문자제목 */
	private String charTitl;
	/** 문자내용 */
	private String charCont;
	/** 생성일(YY.MM.DD) */
	private String frstRegDtm;
	/** 검진일(YY.MM.DD) */
	private String cuDtm;
	/** 최근검진일(YY.MM.DD) */
	private String latestCuDtm;
	/** 검진기관 명*/
	private String cuiNm;
	/** 검진기관ID */
	private String cuiId;
	/** 고객사 명 */
	private String clcoNm;
	/** 고객사ID */
	private String clcoId;

	/** 고객사ID */
	private Integer[] clcoIds;

	/** 근무지역 */
	private String workRgnNm;
	/** 근무지역ID */
	private String workRgnId;
	/** 사업장ID */
	private String bsplId;
	/** 사업장 명 */
	private String bsplNm;
	/** 사번 */
	@Masked(MaskingType.ID)
	private String empno;
	/** 위험군분류코드(GRP_CD:807) */
	private String rgrpClsfCd;
	/** 위험군분류 명 */
	private String rgrpClsfNm;
	/** 검진결과 코드(공통코드 없음)
	 *  정상 (4),건강주의군 (0),건강주의군L (1),대사증후군 (2),대사증후군L (3)
	 */
	private Integer cuRsltCd;
	/** 검진결과(AS-IS:운영군) */
	private String cuRsltNm;

	/** SBP(수축기혈압) */
	private Float sbp;
	/** DBP(이완기혈압) */
    private Float dbp;
    /** 혈당 */
    private Float blsg;
    /** TC(총콜레스테롤) */
    private Float tc;
    /** HDL */
    private Float hdl;
    /** LDL */
    private Float ldl;
    /** 중성지방 */
    private Float tg;
    private Float bmi;
    /** 신장 */
    private Float height;
    /** 체중 */
    private Float weight;
    /** 허리둘레 */
    private Float lmbc;
    /** AST */
    private Float ast;
    /** ALT */
    private Float alt;
    /** rGTP */
    private Float rgtp;

	/** 비만_위험인자 */
	private Integer fatFctr;
	/** 혈압_위험인자 */
	private Integer bpFctr;
	/** 혈당_위험인자 */
	private Integer blsgFctr;
	/** HDL_위험인자 */
	private Integer hdlFctr;
	/** 중성지방_위험인자 */
	private Integer ntftFctr;
	/** 간수치_위험인자 */
	private Integer lvrFctr;

}
