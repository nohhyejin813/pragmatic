package com.gchc.ncu.bo.assessment.vo;

import java.util.List;

import com.gchc.ncu.bo.assessment.models.AssessmentQuestionModel;
import com.gsitm.ustra.java.mvc.rest.model.RestVo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@RequiredArgsConstructor
public class AssessmentQuestionVo extends RestVo {
	private int								cuiAsmQstId;		//검진기관평가질문아이디

	private AssessmentQuestionModel			qstRspnInfo;

	private List<AssessmentQuestionModel> 	exmList;

	private boolean							delYn;
	private boolean							chkYn;

	private	boolean							inserted;
	private	boolean							updated;
	private	boolean							deleted;

	private String							regUsrId = "admin";

	@java.beans.ConstructorProperties({"cuiAsmQstId", "qstRspnInfo", "exmList"})
	public AssessmentQuestionVo(int cuiAsmQstId, AssessmentQuestionModel qstRspnInfo, List<AssessmentQuestionModel> exmList) {
		this.cuiAsmQstId = cuiAsmQstId;
		this.qstRspnInfo = qstRspnInfo;
		this.exmList = exmList;
	}

}