package com.gchc.ncu.bo.care.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.NrsnClsfSxRltnModel;
import com.gchc.ncu.bo.care.models.NrsnDssSxRltnModel;
import com.gchc.ncu.bo.care.models.NrsnSxBscModel;
import com.gchc.ncu.bo.care.repository.PainSymptomRepository;
import com.gchc.ncu.bo.care.vo.PainSymptomVo;

@Service
@RequiredArgsConstructor
public class PainSymptomService {

	private final PainSymptomRepository symptomRepository;

	public List<NrsnSxBscModel> getSymptomList(PainSymptomVo criteria) {
		return symptomRepository.selectSymptomList(criteria);
	}

	public NrsnSxBscModel getSymptomDetail(NrsnSxBscModel criteria) {
		return symptomRepository.selectSymptomDetail(criteria);
	}

	@Transactional
	public void saveSymptom(@Valid NrsnSxBscModel model) {
		if (StringUtils.isEmpty(model.getNrsnSxId())) {
			symptomRepository.insertSymptom(model);
		} else {
			symptomRepository.updateSymptom(model);
		}
	}

	@Transactional
	public void deleteSymptom(List<NrsnSxBscModel> list) {
		if (list != null) {
			for (NrsnSxBscModel model : list) {
				deleteSymptomPart(model.getNrsnSxId());
				deleteSymptomDisease(model.getNrsnSxId());

				symptomRepository.deleteSymptom(model);
			}
		}
	}

	public List<NrsnClsfSxRltnModel> getSymptomPartList(NrsnSxBscModel criteria) {
		return symptomRepository.selectSymptomPartList(criteria);
	}

	public void saveSymptomPart(int nrsnSxId, List<NrsnClsfSxRltnModel> list) {
		deleteSymptomPart(nrsnSxId);

		if (list != null) {
			for (NrsnClsfSxRltnModel model : list) {
				symptomRepository.insertSymptomPart(model);
			}
		}
	}

	protected void deleteSymptomPart(int nrsnSxId) {
		symptomRepository.deleteSymptomPart(nrsnSxId);
	}

	public List<NrsnDssSxRltnModel> getSymptomDiseaseList(NrsnSxBscModel criteria) {
		return symptomRepository.selectSymptomDiseaseList(criteria);
	}

	public void saveSymptomDisease(int nrsnSxId, List<NrsnDssSxRltnModel> list) {
		deleteSymptomDisease(nrsnSxId);

		if (list != null) {
			for (NrsnDssSxRltnModel model : list) {
				symptomRepository.insertSymptomDisease(model);
			}
		}
	}

	protected void deleteSymptomDisease(int nrsnSxId) {
		symptomRepository.deleteSymptomDisease(nrsnSxId);
	}


}
