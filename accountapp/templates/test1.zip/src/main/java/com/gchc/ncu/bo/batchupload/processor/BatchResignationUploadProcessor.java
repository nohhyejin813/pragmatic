package com.gchc.ncu.bo.batchupload.processor;

import com.gchc.ncu.bo.batchupload.comm.BatchException;
import com.gchc.ncu.bo.batchupload.exception.BatchRestResult;
import com.gchc.ncu.bo.batchupload.service.BatchResignationUploadService;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gsitm.ustra.java.data.file.processor.convert.ExcelDataPostProcessor;
import com.gsitm.ustra.java.data.file.processor.convert.ExcelFileToDataProcessConverter.Option;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component("batchResignationUploadProcessor")
public class BatchResignationUploadProcessor implements ExcelDataPostProcessor<Map<String, Object>> {

	@Autowired
	private BatchResignationUploadService service;

	@Override
	public Object doProcess(Option<Map<String, Object>> option, List<Map<String, Object>> excelReadDatas, List<RowInfo> converted) {

		Map<String, String> params = BatchUploadUtils.parseParameter(option.getExcelDataPostProcessorParameter());

		if( !params.containsKey("yr") || "-1".equals(params.get("yr")) || !NumberUtils.isCreatable(params.get("yr")) )
			return BatchRestResult.of("9999", "연도를 선택해야 합니다.");
		if( !params.containsKey("clcoId") || "-1".equals(params.get("clcoId")) || !NumberUtils.isCreatable(params.get("clcoId")) )
			return BatchRestResult.of("9999", "고객사를 선택해야 합니다.");
		try {
			// 파일 업로드
			return service.uploadResignation(converted, NumberUtils.toInt(params.get("clcoId")), NumberUtils.toInt(params.get("yr")), NumberUtils.toInt(params.get("uploadFlag")));
		}catch( BatchException e ){
			LOGGER.debug(ExceptionUtils.getStackTrace(e));
			return BatchRestResult.of(e.getCode(), e.getMessage());
		}
	}
}
