package com.gchc.ncu.bo.abnormalfindings.models;

import java.util.List;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@EqualsAndHashCode(callSuper=true)
@NoArgsConstructor
@AllArgsConstructor
public class MemberCodeModel extends UstraManagementBaseModel
{
	@ApiModelProperty(value="1차군 선택 리스트")
	private List<AbnfCodeModel> tmpSvcgCdList;

	@ApiModelProperty(value="2차군 선택 리스트")
	private List<AbnfCodeModel> svcgDtlCdList;

	@ApiModelProperty(value="고객상태 리스트")
	private List<AbnfCodeModel> pgrsStCdList;


}
