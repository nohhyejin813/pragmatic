package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.PoisTyBscModel;
import com.gchc.ncu.bo.care.repository.AddictionTypeRepository;
import com.gchc.ncu.bo.care.vo.AddictionTypeVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AddictionTypeService {

	private final AddictionTypeRepository addictionTypeRepository;

	public List<PoisTyBscModel> getAddictionTypeList(AddictionTypeVo criteria) {
		return addictionTypeRepository.selectAddictionTypeList(criteria);
	}

	public PoisTyBscModel getAddictionTypeDetail(PoisTyBscModel criteria) {
		return addictionTypeRepository.selectAddictionTypeDetail(criteria);
	}

	@Transactional
	public void saveAddictionType(PoisTyBscModel model) {
		if (StringUtils.isEmpty(model.getPoisTyId())) {
			addictionTypeRepository.insertAddictionType(model);
		} else {
			addictionTypeRepository.updateAddictionType(model);
		}
	}

	@Transactional
	public void deleteAddictionType(List<PoisTyBscModel> list) {
		if (list != null) {
			for (PoisTyBscModel model : list) {
				List<Integer> usedCountList = addictionTypeRepository.selectUsedAddictionTypeCount(model);

				for (int usedCount : usedCountList) {
					if (usedCount > 0) {
						throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "이미 사용 중인 항목입니다.[" + model.getPoisTyNm() + "]");
					}
				}

				addictionTypeRepository.deleteAddictionType(model);
			}
		}
	}

}
