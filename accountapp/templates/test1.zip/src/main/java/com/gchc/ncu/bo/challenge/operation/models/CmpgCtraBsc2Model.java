package com.gchc.ncu.bo.challenge.operation.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;

@Data
@EqualsAndHashCode(callSuper=false)
public class CmpgCtraBsc2Model extends UstraManagementBaseModel {

	private Integer cmpgCtraId;
	private Integer cmpgId;
	private String clcoNm;
	private String bsplNm;
	private String cmpgNm;
	private String chalThmNm;
	private String cmpnWayCd;
	private String cmpnWayNm;
	private Integer ono;
	private String pgrsSrtDt;
	private String pgrsEndDt;
	private Integer tgtrCnt; //대상자 수
	private Integer ptcprCnt; //참여자 수
	private double ptcprRt; //참여율
	private Integer goalAthoCnt; //목표인증수
	private Integer postCnt; //게시물수
	private Integer ptcprCmplPcnt; //목표달성인원
	private double avgAthoRt; //평균인증수
	private String cmpgStCd;
	private String cmpgStNm;

	/*
	private String titl;
	private String prtcTgtCont;
	private String prtcMthCont;
	private Integer cmpnImgFileId;
	private String pctnCont;
	private String expoLocVal;
	private String cmpnWayCd;
	private String cmpnWayNm;
	private Integer rnkExpoYn;
	private Integer autoExtnAplcYn;
	private Integer useYn;
	*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
