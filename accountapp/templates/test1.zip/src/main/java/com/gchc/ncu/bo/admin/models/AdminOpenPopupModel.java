package com.gchc.ncu.bo.admin.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AdminOpenPopupModel {


	//팝업 - 기본 정보설정
    private String clcoNm; //-- '고객사명'
    private int ctraAempCnt; // --'총검진인원'
    private String supply;  //-- '검진비지원'    -- 어떤 로직인지 알수 없음
    private String cuImplSrtDt; // -- '검진기간시작'
    private String cuImplEndDt; //-- '검진기간종료'


    // 검진센터 / 검진패키지 선택
    private int  centerCount;
	private int  pkgCount;

    // 임직원 등록
    private int totalCount; // 총인원수
    private int tgtrCount; // 검진비 지원대상
    private int nonTgtrCount; // 검진비 미지원 대상
    private String bsplNm;
    private String addBsplNm;
    private String clcoSvcTyCd;
    private String stlTyCd;
    private String stlStCd;
    private String yr;
    private String clcoCtraId;
}
