package com.gchc.ncu.bo.abnormalfindings.models;

import com.gchc.common.message.model.MessageBasicModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class MemberInfoModel extends MessageBasicModel
{

	@ApiModelProperty(value="회원 UID")
	private Integer uid;


	@ApiModelProperty(value="이름")
	private String nm;

	@ApiModelProperty(value="생일")
	private String brdt;

	@ApiModelProperty(value="전화번호")
	private String mblNo;

	@ApiModelProperty(value="이메일")
	private String emlAdr;


	@ApiModelProperty(value="주소")
	private String hsBscAdr;

	@ApiModelProperty(value="주소 상세")
	private String hsDtlAdr;

	@ApiModelProperty(value="우편 주소")
	private String hsZpCd;

	@ApiModelProperty(value="전화번호")
	private String hsTlno;

	@ApiModelProperty(value="시번")
	private String empNo;

	@ApiModelProperty(value="부서")
	private String bsplNm;

	@ApiModelProperty(value="암")
	private String cncr;

	@ApiModelProperty(value="질병")
	private String dss;

}
