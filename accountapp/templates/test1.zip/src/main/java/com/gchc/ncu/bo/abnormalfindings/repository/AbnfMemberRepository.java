package com.gchc.ncu.bo.abnormalfindings.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gchc.ncu.bo.abnormalfindings.models.AbnfCodeModel;
import com.gchc.ncu.bo.abnormalfindings.models.AbnfMemberModel;
import com.gchc.ncu.bo.abnormalfindings.models.HthSvcModel;
import com.gchc.ncu.bo.abnormalfindings.models.MemberInfoModel;
import com.gchc.ncu.bo.abnormalfindings.vo.AbnfMemberVo;
import com.gchc.ncu.bo.comm.models.CommonApprovalStatusCodeModel;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.mybatis.executor.Many;


/**
 *
 * @author spm
 *
 */
@Mapper
public interface AbnfMemberRepository
{
	@Many List<AbnfMemberModel> getMemberList(@Param("model")AbnfMemberVo abnfMemberVo, PaginationRequest pr);
	@Many List<AbnfMemberModel> getMemberListExcelDownload(@Param("model")AbnfMemberVo abnfMemberVo);

	@Many List<AbnfCodeModel> getTmpSvcgCdList();
	@Many List<AbnfCodeModel> getSvcgDtlCdList();
	@Many List<AbnfCodeModel> getPgrsStCdList();






	MemberInfoModel getMemberInfo(@Param("uid") Integer uid);


	@Many List<HthSvcModel> getHthSvcHistList(HthSvcModel hthSvcModel);

	HthSvcModel getHthSvcInfo(HthSvcModel htcSvcModel);

	Integer updateHthSvc(HthSvcModel htcSvcModel);
	Integer insertHthSvcHst(HthSvcModel htcSvcModel);


	@Many List<AbnfCodeModel> getSvcgCdList();
	@Many List<AbnfCodeModel> getCustPgrStCdList();
	Integer insertClcoStHst(HthSvcModel htcSvcModel);


}

