package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.comm.*;
import com.gchc.ncu.bo.batchupload.enu.BatchMemberUploadError;
import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.MemberColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberRegisterRepository;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.comm.models.CommonParametersModel;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.repository.CommonRepository;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gchc.ncu.bo.comm.util.NcuAuthenticationUtils;
import com.gchc.ncu.bo.comm.util.NcuEncUtils;
import com.gchc.ncu.bo.config.GchcDataBatchExecutor;
import com.gchc.ncu.bo.config.authentication.NcuAdminUser;
import com.gchc.ncu.bo.member.repository.DormantRepository;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import com.gsitm.ustra.java.data.utils.ProcedureManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @FileName : BatchUploadService.java
 * @date : 2021. 10. 12
 * @author : hykim
 * @프로그램 설명 : 일괄업로드 Service
 * @변경이력 :
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class BatchMemberUploadService {

	private final BatchMemberUploadRepository repository;

	private final BatchMemberRegisterRepository registRepository;

	@Autowired
	private DormantRepository dormantRepository;

	@Autowired
	private ProcedureManager procedureManager;

	@Autowired private GchcDataBatchExecutor batchExecutor;

	@Autowired private CommonRepository commRepo;

	void checkMemberError(BatchMemberUploadCustomerModel src, boolean result, BatchMemberUploadError error, Object...args) {

		if( !result ) {

			src.setUpldStVal(error.getErrorValue());
			src.setUpldErrVal(src.getUpldErrVal().concat(("|") + error.getMessage(args)));
		}
	}

	boolean isEmptyRow(BatchUploadCustomerExcelModel c) {

		return StringUtils.isEmpty(c.getAempNm()) &&
			StringUtils.isEmpty(c.getAempCuGrdNm()) &&
			StringUtils.isEmpty(c.getAempId()) &&
			StringUtils.isEmpty(c.getAempBrdt()) &&
			StringUtils.isEmpty(c.getBsplNm()) &&
			StringUtils.isEmpty(c.getEmlAdr()) &&
			StringUtils.isEmpty(c.getMblNo());
	}

	boolean isBizCenter() {

		String clcoSvcTyCd = ClientCompanyContextHolder.get().getClcoSvcTyCd();
		return "5".equals(clcoSvcTyCd) || "7".equals(clcoSvcTyCd);
	}

	boolean isBizLite() {

		String clcoSvcTyCd = ClientCompanyContextHolder.get().getClcoSvcTyCd();
		return "6".equals(clcoSvcTyCd) || "8".equals(clcoSvcTyCd);
	}

	boolean isSmartBiz() {

		String clcoSvcTyCd = ClientCompanyContextHolder.get().getClcoSvcTyCd();
		return "1".equals(clcoSvcTyCd);
	}

	// rollback으로 인한 주석처리
	String getBrdtForPwd(String brdt) {

		if( org.apache.commons.lang3.StringUtils.isEmpty(brdt) )
			return null;

		brdt = brdt.replace("-", "");
		return brdt.length() == 8 ? brdt.substring(2) : brdt;
	}

	public BatchMemberUploadCustomerModel validateMember(BatchMemberUploadCustomerModel src) {

		boolean bizCenter = isBizCenter();
		boolean bizLite = isBizLite();
		boolean smartBiz = isSmartBiz();
		//boolean bizCenterSkip = bizCenter && checkSkip(src);

		// 오류 초기화
		src.setUpldStVal(0);
		src.setUpldErrVal("");

		// 전화번호 형식 변경
		src.setMblNo(BatchUploadUtils.makePhone(src.getMblNo()));
		src.setHsTlno(BatchUploadUtils.makePhone(src.getHsTlno()));
		src.setWrplTlno(BatchUploadUtils.makePhone(src.getWrplTlno()));

		// 생년월일, 성별 체크
		boolean validBrdt = BatchUploadUtils.checkBrdt(src.getAempBrdt());
		checkMemberError(src, validBrdt, BatchMemberUploadError.INVALID_INFORMATION, "생년월일");
		if( Optional.ofNullable(src.getAempBrdt()).map(String::length).orElse(0) > 10 ) {

			src.setAempSexCd(src.getAempBrdt().substring(10));
			src.setAempBrdt(src.getAempBrdt().substring(0, 10));
		}

		if( StringUtils.isNotEmpty(src.getSpsrBrdt()) ) {

			boolean validSpsrBrdt = BatchUploadUtils.checkBrdt(src.getSpsrBrdt());
			checkMemberError(src, validSpsrBrdt, BatchMemberUploadError.INVALID_INFORMATION, "배우자생년월일");
			if( Optional.ofNullable(src.getSpsrBrdt()).map(String::length).orElse(0) > 10 ) {

				src.setSpsrSexCd(src.getSpsrBrdt().substring(10));
				src.setSpsrBrdt(src.getSpsrBrdt().substring(0, 10));
			}
		}

		checkMemberError(src, StringUtils.isNotEmpty(src.getAempNm()), BatchMemberUploadError.MISSING_INFORMATION, "이름");

		if( "1".equals(src.getRegDvVal()) ) {

			// 검진 등급 백신 등급 모두 없는 경우
			checkMemberError(src, StringUtils.isNotEmpty(src.getAempCuGrdNm()) ||
					StringUtils.isNotEmpty(src.getAempVcnGrdNm()), BatchMemberUploadError.MISSING_GRADE_INFORMATION);

			if( ObjectUtils.isEmpty(src.getNhicSuptTgtYn()) )
				src.setNhicSuptTgtYn(0);
			if( ObjectUtils.isEmpty(src.getSpcuTgtYn()) )
				src.setSpcuTgtYn(0);

			if( ObjectUtils.isEmpty(src.getBsplNm()) )
				src.setBsplNm(BusinessPlaceContextHolder.getDefault());
			checkMemberError(src, !ObjectUtils.isEmpty(src.getBsplNm()), BatchMemberUploadError.MISSING_INFORMATION, "사업장");

			if( !smartBiz && StringUtils.isEmpty(src.getPkgNm()) )
				src.setPkgNm("검진이지패키지");

			boolean noCorpSupt = !ObjectUtils.isEmpty(src.getAempCuGrdId()) &&
				(MemberGradeContextHolder.get(src.getAempCuGrdId()).getCorpSuptYn() == 0 ||
				"특검만(지원)".equals(src.getAempCuGrdNm()));
			checkMemberError(src, noCorpSupt || StringUtils.isNotEmpty(src.getCorpSpfnVal()) && StringUtils.isNotEmpty(src.getPkgNm()), BatchMemberUploadError.MISSING_SUPPORT_INFO);

			if( !smartBiz && StringUtils.isNotEmpty(src.getSpsrCorpSpfn()) && StringUtils.isEmpty(src.getSpsrPkgNm()) )
				src.setSpsrPkgNm("검진이지패키지");

			checkMemberError(src, ObjectUtils.isEmpty(src.getSpsrCuGrdId()) ||
				(MemberGradeContextHolder.get(src.getSpsrCuGrdId()).getCorpSuptYn() == 0 ||
				StringUtils.isNotEmpty(src.getSpsrCorpSpfn()) && StringUtils.isNotEmpty(src.getSpsrPkgNm())), BatchMemberUploadError.MISSING_FAMILY_SUPPORT_INFO);
		}

		if( "1".equals(src.getRegDvVal()) || "4".equals(src.getRegDvVal()) && src.getRegOptnYn1() == 1 ) {

			// 본인 검진 등급
			boolean noCheckup = StringUtils.isEmpty(src.getAempCuGrdNm()) && "1".equals(src.getRegDvVal());
			src.setAempCuGrdNm(noCheckup ? MemberGradeContextHolder.getDefault(true, true) : src.getAempCuGrdNm());
			checkMemberError(src, !"1".equals(src.getRegDvVal()) && StringUtils.isEmpty(src.getAempCuGrdNm()) || BatchUploadUtils.strIn(src.getAempCuGrdNm(), MemberGradeContextHolder.get().stream()
				.filter(g->StringUtils.isEmpty(g.getSuptTgtDvCd()) || "20".equals(g.getSuptTgtDvCd()))
				.filter(g->g.getSelfYn() == 1)
				.map(g->g.getGrdNm())
				.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "등급");
			src.setAempCuGrdId(MemberGradeContextHolder.get().stream()
				.filter(g->g.getGrdNm().equals(src.getAempCuGrdNm()))
				.findFirst()
				.map(SupportGradeModel::getMbrGrdId)
				.orElse(null));

			if( StringUtils.isNotEmpty(src.getCorpSpfnVal()) )
				checkMemberError(src, BatchUploadUtils.numIn(src.getCorpSpfnVal(), 1000, Integer.MAX_VALUE), BatchMemberUploadError.INVALID_INFORMATION, "지원금");
		}

		if( "1".equals(src.getRegDvVal()) || "5".equals(src.getRegDvVal()) && src.getRegOptnYn1() == 1 ) {

			// 본인 백신 등급
			boolean noVaccine = StringUtils.isEmpty(src.getAempVcnGrdNm()) && "1".equals(src.getRegDvVal());
			src.setAempVcnGrdNm(noVaccine ? MemberGradeContextHolder.getDefault(true, false) : src.getAempVcnGrdNm());
			checkMemberError(src, !"1".equals(src.getRegDvVal()) && StringUtils.isEmpty(src.getAempVcnGrdNm()) || BatchUploadUtils.strIn(src.getAempVcnGrdNm(), MemberGradeContextHolder.get().stream()
					.filter(g -> "10".equals(g.getSuptTgtDvCd()))
					.filter(g -> g.getSelfYn() == 1)
					.map(g -> g.getGrdNm())
					.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "백신등급");
			src.setAempVcnGrdId(MemberGradeContextHolder.get().stream()
					.filter(g -> g.getGrdNm().equals(src.getAempVcnGrdNm()))
					.findFirst()
					.map(SupportGradeModel::getMbrGrdId)
					.orElse(null));
		}

		if( "1".equals(src.getRegDvVal()) && !bizCenter ) {

			checkMemberError(src, StringUtils.isNotEmpty(src.getAempBrdt()), BatchMemberUploadError.MISSING_INFORMATION, "생년월일");

			if( !bizCenter && !bizLite )
				checkMemberError(src, StringUtils.isNotEmpty(src.getAempId()), BatchMemberUploadError.MISSING_INFORMATION, "사번");

			checkMemberError(src, StringUtils.isNotEmpty(src.getMblNo()) ||
				StringUtils.isNotEmpty(src.getEmlAdr()), BatchMemberUploadError.MISSING_MOBILE_AND_EMAIL);
		}
		else if( !"1".equals(src.getRegDvVal()) ) {

			boolean key4Chk = StringUtils.isNotEmpty(src.getAempBrdt()) && (StringUtils.isNotEmpty(src.getEmlAdr()) || StringUtils.isNotEmpty(src.getMblNo()));
			checkMemberError(src, StringUtils.isNotEmpty(src.getAempId()) || key4Chk, BatchMemberUploadError.MISSING_UPDATE_INFORMATION);
		}

		if( "7".equals(ClientCompanyContextHolder.get().getClcoSvcTyCd()) ) {
			src.setAthoKvl(NcuEncUtils.encPwd(getBrdtForPwd(src.getAempBrdt())));
		}

		checkMemberError(src, !"특검만(지원)".equals(src.getAempCuGrdNm()) || src.getSpcuTgtYn() == 1, BatchMemberUploadError.INVALID_SPCU_TGT);

		checkMemberError(src, ObjectUtils.nullSafeEquals(src.getSpcuTgtYn(), 1) || StringUtils.isEmpty(src.getExtrMttrNm1()) && StringUtils.isEmpty(src.getExtrMttrNm2()), BatchMemberUploadError.INVALID_EXTR_MTTR);

		// 부서 lv validation
		if( ObjectUtils.isEmpty(src.getDeptNm1()) )
			checkMemberError(src, ObjectUtils.isEmpty(src.getDeptNm2()) && ObjectUtils.isEmpty(src.getDeptNm3()), BatchMemberUploadError.INVALID_INFORMATION, "부서1");
		if( ObjectUtils.isEmpty(src.getDeptNm2()) )
			checkMemberError(src, ObjectUtils.isEmpty(src.getDeptNm3()), BatchMemberUploadError.INVALID_INFORMATION, "부서2");

		if( StringUtils.isNotEmpty(src.getSpsrCuGrdNm()) || StringUtils.isNotEmpty(src.getSpsrVcnGrdNm()) ) {

			if( StringUtils.equalsAny(src.getRegDvVal(), "1", "2") || "4".equals(src.getRegDvVal()) && src.getRegOptnYn2() == 1 ) {

				// 배우자 검진 등급
				boolean noCheckup = StringUtils.isEmpty(src.getAempCuGrdNm()) && "1".equals(src.getRegDvVal());
				src.setSpsrCuGrdNm(noCheckup || StringUtils.isEmpty(src.getSpsrCuGrdNm()) ?
															MemberGradeContextHolder.getDefault(false, true) : src.getSpsrCuGrdNm());
				checkMemberError(src, !"1".equals(src.getRegDvVal()) && StringUtils.isEmpty(src.getSpsrCuGrdNm()) || BatchUploadUtils.strIn(src.getSpsrCuGrdNm(), MemberGradeContextHolder.get().stream()
					.filter(g->StringUtils.isEmpty(g.getSuptTgtDvCd()) || "20".equals(g.getSuptTgtDvCd()))
					.filter(g->g.getSelfYn() == 0)
					.map(g->g.getGrdNm())
					.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "배우자 등급");
				src.setSpsrCuGrdId(MemberGradeContextHolder.get().stream()
					.filter(g->g.getGrdNm().equals(src.getSpsrCuGrdNm()))
					.findFirst()
					.map(SupportGradeModel::getMbrGrdId)
					.orElse(null));

				checkMemberError(src, StringUtils.isEmpty(src.getSpsrCorpSpfn()) ||
					BatchUploadUtils.numIn(src.getSpsrCorpSpfn(), 1000, Integer.MAX_VALUE), BatchMemberUploadError.INVALID_INFORMATION, "배우자 지원금");
			}

			if( StringUtils.equalsAny(src.getRegDvVal(), "1", "2") || "5".equals(src.getRegDvVal()) && src.getRegOptnYn2() == 1 ) {

				// 배우자 백신 등급
				boolean noVaccine = StringUtils.isEmpty(src.getAempVcnGrdNm()) && "1".equals(src.getRegDvVal());
				src.setSpsrVcnGrdNm(noVaccine || StringUtils.isEmpty(src.getSpsrVcnGrdNm()) ?
															MemberGradeContextHolder.getDefault(false,  false) : src.getSpsrVcnGrdNm());
				checkMemberError(src, !"1".equals(src.getRegDvVal()) && StringUtils.isEmpty(src.getSpsrVcnGrdNm()) || BatchUploadUtils.strIn(src.getSpsrVcnGrdNm(), MemberGradeContextHolder.get().stream()
					.filter(g->"10".equals(g.getSuptTgtDvCd()))
					.filter(g->g.getSelfYn() == 0)
					.map(g->g.getGrdNm())
					.collect(Collectors.toList())), BatchMemberUploadError.INVALID_INFORMATION, "배우자 백신등급");
				src.setSpsrVcnGrdId(MemberGradeContextHolder.get().stream()
					.filter(g->g.getGrdNm().equals(src.getSpsrVcnGrdNm()))
					.findFirst()
					.map(SupportGradeModel::getMbrGrdId)
					.orElse(null));
			}
		}

		checkMemberError(src, BatchUploadUtils.isPhone(src.getMblNo()), BatchMemberUploadError.INVALID_INFORMATION, "핸드폰번호");
		checkMemberError(src, BatchUploadUtils.isPhone(src.getHsTlno()), BatchMemberUploadError.INVALID_INFORMATION, "집전화번호");
		checkMemberError(src, BatchUploadUtils.isPhone(src.getWrplTlno()), BatchMemberUploadError.INVALID_INFORMATION, "회사전화번호");

		checkMemberError(src, StringUtils.isEmpty(src.getPkgNm()) ||
			!ObjectUtils.isEmpty(PackageContextHolder.get(src.getPkgNm())), BatchMemberUploadError.INVALID_AEMP_PACKAGE);
		checkMemberError(src, StringUtils.isEmpty(src.getSpsrPkgNm()) ||
			!ObjectUtils.isEmpty(PackageContextHolder.get(src.getSpsrPkgNm())), BatchMemberUploadError.INVALID_FAMILY_PACKAGE);

		src.setBsplId(Optional.ofNullable(BusinessPlaceContextHolder.get(src.getBsplNm())).map(BsplModel::getBsplId).orElse(null));
		checkMemberError(src, StringUtils.isEmpty(src.getBsplNm()) ||
			!ObjectUtils.isEmpty(src.getBsplId()), BatchMemberUploadError.INVALID_INFORMATION, "사업장 정보");

		return src;
	}

	private boolean checkSkip(BatchMemberUploadCustomerModel src) {

		return StringUtils.isNotEmpty(src.getAempNm()) &&
			StringUtils.isNotEmpty(src.getCorpSpfnVal()) &&
			StringUtils.isEmpty(src.getAempId()) &&
			StringUtils.isEmpty(src.getAempBrdt()) &&
			StringUtils.isEmpty(src.getEmlAdr()) &&
			StringUtils.isEmpty(src.getMblNo());
	}


	List<BatchCustomerExcelModel> errorExcelMsg(List<BatchCustomerExcelModel> errList) {

		errList.forEach(e->{

			String errMsg = e.getUpldErrVal();
			if( StringUtils.isEmpty(errMsg) )
				return;
			errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
			e.setUpldErrVal(errMsg.replace("|", "\r\n"));
		});
		return errList;
	}

	List<BatchMemberUploadCustomerModel> errorMsg(List<BatchMemberUploadCustomerModel> errList) {

		errList.forEach(e->{

			String errMsg = e.getUpldErrVal();
			if( StringUtils.isEmpty(errMsg) )
				return;
			errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
			e.setUpldErrVal(errMsg.replace("|", "\r\n"));
		});
		return errList;
	}

	/**
	 * 처리내용 : 업로드 결과 조회
	 *
	 * @param in
	 * @return
	 */
	public BatchMemberUploadResultModel getResult(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());
		BatchMemberUploadResultModel result = repository.getBatchMemberUploadResult(in);
		result.setErrorCnt(result.getDupCnt() + result.getMissingCnt() + result.getEtcCnt() + result.getDmcyCnt());
		return result;
	}

	public List<BatchMemberUploadCustomerModel> getErrorList(BatchMemberUploadErrorRequestModel in) {
		in.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());
		if( in.getState() == 5 )
			return errorMsg(repository.getClcoAempBlkRegTmpErrorDuplicated(in, in.toPaginationRequest()));
		return errorMsg(repository.getClcoAempBlkRegTmpError(in, in.toPaginationRequest()));
	}

	public List<BatchMemberUploadCustomerModel> getAllErrorList(BatchMemberUploadErrorRequestModel in) {

		return errorMsg(repository.getClcoAempBlkRegTmpError2(in));
	}

	/**
	 *
	 * 처리내용 : 일괄업로드 작업 내역 초기화
	 *
	 * @param in
	 */
	@Transactional
	public void init(BatchMemberUploadInitRequestModel in) {

		in.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());
		repository.updateClcoAempBlkRegTmpInit(in);
	}

	/**
	 * 처리내용 : 업로드 결과 삭제
	 *
	 * @param in
	 * @return
	 */
	@Transactional
	public void remove(List<BatchMemberUploadCustomerModel> in) {

		repository.updateClcoAempBlkRegTmpRemove(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
			"list", in));
	}

	@Transactional
	public void removeAll(CustomerExcelDownModel in) {

		in.setMngrId("" + NcuAuthenticationUtils.getCurrentUser().getMngrId());
		repository.updateClcoAempBlkRegTmpRemoveAll(in);
	}

	/**
	 * 고객등록 일괄업로드 처리
	 */
	@SuppressWarnings("unchecked")
	@Transactional
	public BatchMemberUploadResultModel uploadMember(List<RowInfo> converted,
													 Integer clcoId, Integer yr, String regDvVal, Integer regOptnYn1, Integer regOptnYn2) {

		final int mngrId = NcuAuthenticationUtils.getCurrentUser().getMngrId();

		// 헤더 체크
		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();
		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

		String missed = BatchUploadColumn.stream(MemberColumn.class)
			.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
			.findFirst()
			.map(BatchUploadColumn::getTitle)
			.orElse(null);
		if( StringUtils.isNotEmpty(missed) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

		// 빈 ROW 삭제 및 값 설정
		List<BatchUploadCustomerExcelModel> aempList = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
			.map(r->{
				BatchUploadCustomerExcelModel c = BatchUploadUtils.map(
					(Map<String, Object>)r.getObject(), headerRow,
					BatchUploadColumn.table(MemberColumn.class), BatchUploadCustomerExcelModel.class);
				c.setClcoId(clcoId);
				c.setYr(yr);
				c.setRegDvVal(regDvVal);
				c.setRegOptnYn1(regOptnYn1);
				c.setRegOptnYn2(regOptnYn2);
				c.setAempBrdt(BatchUploadUtils.formattedBrdt(c.getAempBrdt()));
				c.setSpsrBrdt(BatchUploadUtils.formattedBrdt(c.getSpsrBrdt()));
				return c;
			})
			.filter(c->!isEmptyRow(c))
			.collect(Collectors.toList());

		// 검색조건 설정
		SearchMapContextHolder.set(UstraMapUtils.getMap(
				"clcoId", clcoId,
				"yr", yr,
				"mngrId", mngrId,
				"regDvVal", regDvVal));

		// 지원 등급, 패키지, 사업장, 고객사 조회
		MemberGradeContextHolder.set(repository.getMemberGradeList(SearchMapContextHolder.get()));
		PackageContextHolder.set(repository.getPackageList(SearchMapContextHolder.get()));
		BusinessPlaceContextHolder.set(repository.getBsplList(SearchMapContextHolder.get()));
		ClientCompanyContextHolder.set(repository.getClcoBsc(SearchMapContextHolder.get()));

		// 업로드 초기화
		repository.updateClcoAempBlkRegTmpUploadYn(SearchMapContextHolder.get());

		// 신규 등록 대상 추출
		List<BatchMemberUploadCustomerModel> forInsert = aempList.stream()
			.filter(c->StringUtils.isEmpty(c.getAempRegSeq()))
			.map(c->validateMember(BatchUploadUtils.map(c, BatchMemberUploadCustomerModel.class)))
			.collect(Collectors.toList());

		// 업데이트 대상 추출
		List<BatchMemberUploadCustomerModel> forUpdate = new ArrayList<>();
		List<BatchUploadCustomerExcelModel> checkUpdate = aempList.stream()
			.filter(c->StringUtils.isNotEmpty(c.getAempRegSeq()))
			.collect(Collectors.toList());
		if( CollectionUtils.isNotEmpty(checkUpdate) ) {

			List<BatchMemberUploadCustomerModel> checked = repository.getClcoAempBlkRegTmpForUpdate(UstraMapUtils.getMap(
				"clcoId", clcoId,
				"yr", yr,
				"mngrId", mngrId,
				"list", checkUpdate));
			forUpdate = checkUpdate.stream()
				.filter(c->checked.stream().anyMatch(ch->c.getAempRegSeq().equals("" + ch.getAempRegSeq())))
				.map(c->validateMember(BatchUploadUtils.map(c, BatchMemberUploadCustomerModel.class)))
				.collect(Collectors.toList());

			forInsert.addAll(checkUpdate.stream()
				.filter(c->checked.stream().noneMatch(ch->c.getAempRegSeq().equals("" + ch.getAempRegSeq())))
				.map(c->validateMember(BatchUploadUtils.map(c, BatchMemberUploadCustomerModel.class)))
				.collect(Collectors.toList()));
		}

		// 신규 등록
		int aempRegSeq = repository.getAempBlkRegTmpNextSeq(SearchMapContextHolder.get());
		for( int i=0; i<forInsert.size(); i++ ) {
			forInsert.get(i).setAempRegSeq(aempRegSeq++);
			forInsert.get(i).setMngrId(forInsert.get(i).getAdminUserMngrId());
		}

		batchExecutor.batchUpdate(
			"INSERT INTO MBR.T_CLCO_AEMP_BLK_REG_TMP (\r\n" +
			"	  CLCO_ID\r\n" +
			"	, YR\r\n" +
			"	, REG_DV_VAL\r\n" +
			"	, REG_OPTN_YN1\r\n" +
			"	, REG_OPTN_YN2\r\n" +
			"	, AEMP_REG_SEQ\r\n" +
			"	, AEMP_NM\r\n" +
			"	, AEMP_CU_GRD_NM\r\n" +
			"	, AEMP_CU_GRD_ID\r\n" +
			"	, AEMP_VCN_GRD_NM\r\n" +
			"	, AEMP_VCN_GRD_ID\r\n" +
			"	, AEMP_ID\r\n" +
			"	, EXCU_YN\r\n" +
			"	, AEMP_BRDT\r\n" +
			"	, AEMP_SEX_CD\r\n" +
			"	, ENCM_DT\r\n" +
			"	, PKG_NM\r\n" +
			"	, CORP_SPFN_VAL\r\n" +
			"	, NHIC_SUPT_TGT_YN\r\n" +
			"	, SPCU_TGT_YN\r\n" +
			"	, EXTR_MTTR_NM1\r\n" +
			"	, EXTR_MTTR_NM2\r\n" +
			"	, EML_ADR\r\n" +
			"	, MBL_NO\r\n" +
			"	, SPSR_NM\r\n" +
			"	, SPSR_CU_GRD_NM\r\n" +
			"	, SPSR_CU_GRD_ID\r\n" +
			"	, SPSR_VCN_GRD_NM\r\n" +
			"	, SPSR_VCN_GRD_ID\r\n" +
			"	, SPSR_BRDT\r\n" +
			"	, SPSR_SEX_CD\r\n" +
			"	, SPSR_CORP_SPFN\r\n" +
			"	, SPSR_PKG_NM\r\n" +
			"	, BSPL_NM\r\n" +
			"	, BSPL_ID\r\n" +
			"	, DEPT_NM1\r\n" +
			"	, DEPT_NM2\r\n" +
			"	, DEPT_NM3\r\n" +
			"	, JBGD_NM\r\n" +
			"	, WRPL_TLNO\r\n" +
			"	, WRPL_ZPCD\r\n" +
			"	, WRPL_BSC_ADR\r\n" +
			"	, WRPL_DTL_ADR\r\n" +
			"	, HS_TLNO\r\n" +
			"	, HS_ZPCD\r\n" +
			"	, HS_BSC_ADR\r\n" +
			"	, HS_DTL_ADR\r\n" +
			"	, CUST_MEMO\r\n" +
//			"	, WORK_DEPT_NM\r\n" +
//			"	, LINE_NM\r\n" +
//			"	, JOB_NM\r\n" +
//			"	, TEAM_NM\r\n" +
			"	, UPLD_ST_VAL\r\n" +
			"	, UPLD_ERR_VAL\r\n" +
			"	, ID_ENFC_UPD_YN\r\n" +
			"	, NM_ENFC_UPD_YN\r\n" +
			"	, BRDT_ENFC_UPD_YN\r\n" +
			"	, EML_ADR_ENFC_UPD_YN\r\n" +
			"	, MBL_NO_ENFC_UPD_YN\r\n" +
			"	, UPLD_YN\r\n" +
			"	, MNGR_ID\r\n" +
			"	, DEL_YN\r\n" +
			"	, ATHO_KVL\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			")\r\n" +
			"VALUES\r\n" +
			"(\r\n" +
			"	  #{clcoId}\r\n" +
			"	, #{yr}\r\n" +
			"	, #{regDvVal}\r\n" +
			"	, #{regOptnYn1}\r\n" +
			"	, #{regOptnYn2}\r\n" +
			"	, #{aempRegSeq}\r\n" +
			"	, #{aempNm}\r\n" +
			"	, #{aempCuGrdNm}\r\n" +
			"	, #{aempCuGrdId}\r\n" +
			"	, #{aempVcnGrdNm}\r\n" +
			"	, #{aempVcnGrdId}\r\n" +
			"	, #{aempId}\r\n" +
			"	, #{excuYn}\r\n" +
			"	, #{aempBrdt}\r\n" +
			"	, #{aempSexCd}\r\n" +
			"	, #{encmDt}\r\n" +
			"	, #{pkgNm}\r\n" +
			"	, #{corpSpfnVal}\r\n" +
			"	, #{nhicSuptTgtYn}\r\n" +
			"	, #{spcuTgtYn}\r\n" +
			"	, #{extrMttrNm1}\r\n" +
			"	, #{extrMttrNm2}\r\n" +
			"	, #{emlAdr}\r\n" +
			"	, #{mblNo}\r\n" +
			"	, #{spsrNm}\r\n" +
			"	, #{spsrCuGrdNm}\r\n" +
			"	, #{spsrCuGrdId}\r\n" +
			"	, #{spsrVcnGrdNm}\r\n" +
			"	, #{spsrVcnGrdId}\r\n" +
			"	, #{spsrBrdt}\r\n" +
			"	, #{spsrSexCd}\r\n" +
			"	, #{spsrCorpSpfn}\r\n" +
			"	, #{spsrPkgNm}\r\n" +
			"	, #{bsplNm}\r\n" +
			"	, #{bsplId}\r\n" +
			"	, #{deptNm1}\r\n" +
			"	, #{deptNm2}\r\n" +
			"	, #{deptNm3}\r\n" +
			"	, #{jbgdNm}\r\n" +
			"	, #{wrplTlno}\r\n" +
			"	, #{wrplZpcd}\r\n" +
			"	, #{wrplBscAdr}\r\n" +
			"	, #{wrplDtlAdr}\r\n" +
			"	, #{hsTlno}\r\n" +
			"	, #{hsZpcd}\r\n" +
			"	, #{hsBscAdr}\r\n" +
			"	, #{hsDtlAdr}\r\n" +
			"	, #{custMemo}\r\n" +
//			"	, #{workDeptNm}\r\n" +
//			"	, #{lineNm}\r\n" +
//			"	, #{jobNm}\r\n" +
//			"	, #{teamNm}\r\n" +
			"	, #{upldStVal}\r\n" +
			"	, #{upldErrVal}\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 0\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, 0\r\n" +
			"	, #{athoKvl}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			")\r\n", forInsert);


		// 업데이트
		forUpdate.forEach(c->{
			c.setMngrId(c.getAdminUserMngrId());
		});
		batchExecutor.batchUpdate(
			"UPDATE MBR.T_CLCO_AEMP_BLK_REG_TMP\r\n" +
			"SET	  CLCO_ID = #{clcoId}\r\n" +
			"	, YR = #{yr}\r\n" +
			"	, REG_OPTN_YN1 = #{regOptnYn1}\r\n" +
			"	, REG_OPTN_YN2 = #{regOptnYn2}\r\n" +
			"	, AEMP_NM = #{aempNm}\r\n" +
			"	, AEMP_CU_GRD_NM = #{aempCuGrdNm}\r\n" +
			"	, AEMP_CU_GRD_ID = #{aempCuGrdId}\r\n" +
			"	, AEMP_VCN_GRD_NM = #{aempVcnGrdNm}\r\n" +
			"	, AEMP_VCN_GRD_ID = #{aempVcnGrdId}\r\n" +
			"	, AEMP_ID = #{aempId}\r\n" +
			"	, EXCU_YN = #{excuYn}\r\n" +
			"	, AEMP_BRDT = #{aempBrdt}\r\n" +
			"	, AEMP_SEX_CD = #{aempSexCd}\r\n" +
			"	, ENCM_DT = #{encmDt}\r\n" +
			"	, PKG_NM = #{pkgNm}\r\n" +
			"	, CORP_SPFN_VAL = #{corpSpfnVal}\r\n" +
			"	, NHIC_SUPT_TGT_YN = #{nhicSuptTgtYn}\r\n" +
			"	, SPCU_TGT_YN = #{spcuTgtYn}\r\n" +
			"	, EXTR_MTTR_NM1 = #{extrMttrNm1}\r\n" +
			"	, EXTR_MTTR_NM2 = #{extrMttrNm2}\r\n" +
			"	, EML_ADR = #{emlAdr}\r\n" +
			"	, MBL_NO = #{mblNo}\r\n" +
			"	, SPSR_NM = #{spsrNm}\r\n" +
			"	, SPSR_CU_GRD_NM = #{spsrCuGrdNm}\r\n" +
			"	, SPSR_CU_GRD_ID = #{spsrCuGrdId}\r\n" +
			"	, SPSR_VCN_GRD_NM = #{spsrVcnGrdNm}\r\n" +
			"	, SPSR_VCN_GRD_ID = #{spsrVcnGrdId}\r\n" +
			"	, SPSR_BRDT = #{spsrBrdt}\r\n" +
			"	, SPSR_SEX_CD = #{spsrSexCd}\r\n" +
			"	, SPSR_CORP_SPFN = #{spsrCorpSpfn}\r\n" +
			"	, SPSR_PKG_NM = #{spsrPkgNm}\r\n" +
			"	, BSPL_NM = #{bsplNm}\r\n" +
			"	, BSPL_ID = #{bsplId}\r\n" +
			"	, DEPT_NM1 = #{deptNm1}\r\n" +
			"	, DEPT_NM2 = #{deptNm2}\r\n" +
			"	, DEPT_NM3 = #{deptNm3}\r\n" +
			"	, JBGD_NM = #{jbgdNm}\r\n" +
			"	, WRPL_TLNO = #{wrplTlno}\r\n" +
			"	, WRPL_ZPCD = #{wrplZpcd}\r\n" +
			"	, WRPL_BSC_ADR = #{wrplBscAdr}\r\n" +
			"	, WRPL_DTL_ADR = #{wrplDtlAdr}\r\n" +
			"	, HS_TLNO = #{hsTlno}\r\n" +
			"	, HS_ZPCD = #{hsZpcd}\r\n" +
			"	, HS_BSC_ADR = #{hsBscAdr}\r\n" +
			"	, HS_DTL_ADR = #{hsDtlAdr}\r\n" +
			"	, CUST_MEMO = #{custMemo}\r\n" +
//			"	, WORK_DEPT_NM = #{workDeptNm}\r\n" +
//			"	, LINE_NM = #{lineNm}\r\n" +
//			"	, JOB_NM = #{jobNm}\r\n" +
//			"	, TEAM_NM = #{teamNm}\r\n" +
			"	, UPLD_YN = 1\r\n" +
			"	, ATHO_KVL = #{athoKvl}\r\n" +
			"	, UPLD_ST_VAL = #{upldStVal}\r\n" +
			"	, UPLD_ERR_VAL = #{upldErrVal}\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPDR_ID = #{mngrId}\r\n" +
			"WHERE 1=1\r\n" +
			"	AND YR = #{yr}\r\n" +
			"	AND CLCO_ID = #{clcoId}\r\n" +
			"	AND REG_DV_VAL = #{regDvVal}\r\n" +
			"	AND AEMP_REG_SEQ = #{aempRegSeq}", forUpdate);

		// 엑셀 내 중복 체크
		repository.updateClcoAempBlkRegTmpRnk(SearchMapContextHolder.get());
		repository.updateClcoAempBlkRegTmpValidate(SearchMapContextHolder.get());

		// 현재 DB 비교
		if( "1".equals(regDvVal) ) {

			repository.updateClcoAempBlkRegTmpValidateStep2_1(SearchMapContextHolder.get());
			repository.updateClcoAempBlkRegTmpValidateStep2_2(SearchMapContextHolder.get());
		}
		else {

			repository.updateClcoAempBlkRegTmpValidateStep2_4(SearchMapContextHolder.get());
		}
		if( isBizCenter() )
			repository.updateClcoAempBlkRegTmpValidateStep2_3(SearchMapContextHolder.get());

		// 일반 등록이 아닌 경우 임직원 매칭 필수
		if (!"1".equals(regDvVal))
			repository.updateClcoAempBlkRegTmpValidateStep3(SearchMapContextHolder.get());

		// 가족 정보 업데이트 시 가족 매칭 필수
		if (StringUtils.equalsAny(regDvVal, "4", "5") && regOptnYn2 == 1) {
			repository.updateClcoAempBlkRegTmpValidateStep3_2(SearchMapContextHolder.get());
		}

		if ("1".equals(regDvVal) || "4".equals(regDvVal) && regOptnYn1 == 1) {

			// 임원검진 사용하지 않는 경우 임원여부 오류
			repository.updateClcoAempBlkRegTmpExcuYn(SearchMapContextHolder.get());
		}

		// 배우자가 임직원인 경우
		//repository.updateClcoAempBlkRegTmpValidateStep3(SearchMapContextHolder.get());

		if ("1".equals(regDvVal) || "2".equals(regDvVal) && regOptnYn1 == 0) {

			// 배우자가 다른대상자로 이미 등록된 경우
			repository.updateClcoAempBlkRegTmpOtherTgtr(SearchMapContextHolder.get());
		}

		// 휴면회원에 정보가 존재하는 고객
		repository.updateClcoAempBlkRegTmpDmcy(SearchMapContextHolder.get());

		// 퇴사 상태인 기존 고객
		repository.updateClcoAempBlkRegTmpHffc(SearchMapContextHolder.get());

		// 임직원의 검진 예약정보가 존재하는 기존 고객
		if( StringUtils.equalsAny(regDvVal, "1", "6") || "4".equals(regDvVal) && regOptnYn1 == 1 )
			repository.updateClcoAempBlkRegTmpValidateStep4_1(SearchMapContextHolder.get());
		// 가족의 검진 예약정보가 존재하는 기존 고객
		if( StringUtils.equalsAny(regDvVal, "1", "2") || "4".equals(regDvVal) && regOptnYn2 == 1 )
			repository.updateClcoAempBlkRegTmpValidateStep4_2(SearchMapContextHolder.get());

		// 임직원의 백신 예약정보가 존재하는 기존 고객
		if( "1".equals(regDvVal) || "5".equals(regDvVal) && regOptnYn1 == 1 )
			repository.updateClcoAempBlkRegTmpValidateStep4_3(SearchMapContextHolder.get());
		// 가족의 백신 예약정보가 존재하는 기존 고객
		if( StringUtils.equalsAny(regDvVal, "1", "2") || "5".equals(regDvVal) && regOptnYn2 == 1 )
			repository.updateClcoAempBlkRegTmpValidateStep4_4(SearchMapContextHolder.get());

		// 양도금액이 존재하는 고객
		if (!"3".equals(regDvVal))
			repository.updateClcoAempBlkRegTmpValidateStep5(SearchMapContextHolder.get());

		return getResult(BatchMemberUploadResultRequestModel.builder()
			.clcoId(clcoId)
			.yr(yr)
			.mngrId(mngrId)
			.build());
	}

	/**
	 *
	 * 처리내용 : 일괄업로드 등록
	 *
	 * @param in
	 * @throws IOException
	 */

	public void regist(BatchMemberUploadRegistRequestModel in) {

		regist(in, true);
	}

	@Transactional
	public void regist(BatchMemberUploadRegistRequestModel in, boolean cmplPrcs) {

		Map<String, Object> params = UstraMapUtils.getMap(
				"clcoId", in.getClcoId(),
				"yr", in.getYr(),
				"managerId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"regDvVal", in.getRegDvVal()
			);

		// 정상 건 상태 값 일제 4로 변경 (104, 204 => 4)
		registRepository.updateClcoAempBlkRegTmpUpldStPrev(params);

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "3") ) {

			// 부서 생성
			procedureManager.callSp("dbo", "SP_CLCO_AEMP_BLK_REG_TMP_DEPT", params);

			// 직급 생성
			procedureManager.callSp("dbo", "SP_CLCO_AEMP_BLK_REG_TMP_JBGD", params);
		}


		// 사업장ID, 부서ID, 회원ID 업데이트 (1, 4)
		registRepository.updateClcoAempBlkRegTmpId(params);

		// 신규이면서 UID가 있으면 ST_VAL 별도 처리
		registRepository.updateClcoAempBlkRegTmpUpldSt(params);

		// 사업장ID, 부서ID, 업데이트 (14)
		registRepository.updateClcoAempBlkRegTmpId2(params);

		if( "1".equals(in.getRegDvVal()) ) {

			// 회원 정보 등록
			registRepository.insertMbrBsc(params);

			// 회원 부가 정보 등록
			registRepository.insertMbrAddInfDtl(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "3") ) {

			// 회원 부가 정보 업데이트
			registRepository.updateMbrAddInfDtl(params);
		}

		// ST_VAL 복구 (타 고객사)
		registRepository.updateClcoAempBlkRegTmpUpldSt3(params);

		if( "1".equals(in.getRegDvVal()) ) {

			// 회원 고객사 관계 변경이력
			registRepository.insertMbrClcoRltnChgRecs(params);

			// 회원 고객사 관계 등록
			registRepository.insertMbrClcoRltn(params);
		}

		// ST_VAL 복구
		registRepository.updateClcoAempBlkRegTmpUpldSt2(params);

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "3") ) {

			// 회원정보 변경 여부 체크
			registRepository.updateClcoAempBlkRegTmpUpdYn(params);

			// 휴대폰 번호 변경 이력 등록
			registRepository.insertMbrChgRecsMbl(params);

			// 이메일 변경 이력 등록
			registRepository.insertMbrChgRecsEml(params);
		}

		if( "1".equals(in.getRegDvVal()) ) {

			// 이름 변경 이력 등록
			registRepository.insertMbrChgRecsNm(params);

			// 생년월일 변경 이력 등록
			registRepository.insertMbrChgRecsBrdt(params);

			// 성별 변경 이력 등록
			registRepository.insertMbrChgRecsSex(params);

			// 사번 변경 여부 체크
			registRepository.updateClcoAempBlkRegTmpIdUpdYn(params);

			// 사번 변경 이력 등록
			registRepository.insertMbrChgRecsId(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "3") ) {

			// 회원 정보 업데이트
			registRepository.updateMbrBsc(params);

			// 회원 고객사 관계 변경 이력
			registRepository.insertMbrClcoRltnChgRecs2(params);

			// 회원 고객사 관계 업데이트
			registRepository.updateMbrClcoRltn(params);
		}

		if( "1".equals(in.getRegDvVal()) ) {

			// 회원 건강서비스정보 등록
			registRepository.insertMbrHthSvcInfHis(params);

			// 건강위험평가 검진관계 등록
			registRepository.insertHthRistAsmCuRltn(params);

			// 사업장 변경 시 사업장 내역 삭제
			registRepository.deleteMbrBsplHis(params);

			// 사업장 내역 등록
			registRepository.insertMbrBsplHis(params);
		}

		// 검진대상 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpTgtId(params);

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "4", "6") ) {

			if( "1".equals(in.getRegDvVal()) ) {

				// 검진대상 등록
				registRepository.insertCuTgtHis(params);
			}

			// 특수검진대상 변경이력
			registRepository.insertCustInfEmpRecsForTgt(params);

			// 임원여부, 특수검진여부 업데이트
			registRepository.updateCuTgtHisExcuYn(params);

			// 검진대상 아이디 업데이트
			registRepository.updateClcoAempBlkRegTmpTgtId2(params);

			// 1차 특수검진대상 삭제
			registRepository.updateExtrHndlMttrResvTgtDelete(params);

			// 2차 특수검진대상 삭제
			registRepository.updateExtrHndlMttrResvTgtDelete2(params);

			// 신규 특수물질 등록
			registRepository.insertExtrHndlMttr(params);

			// 특수검진대상 이력 등록
			registRepository.insertExtrHndlMttrResvTgtRecs(params);

			// 특수검진대상 등록 1차
			registRepository.insertExtrHndlMttrResvTgt(params);

			// 특수검진대상 등록 2차
			registRepository.insertExtrHndlMttrResvTgt2(params);

			// 특수검진대상 이력 등록 2차
			registRepository.insertExtrHndlMttrResvTgtRecs2(params);
		}
		else if( "3".equals(in.getRegDvVal()) ) {

			// 어떠케어 특이사항 업데이트
			registRepository.updateCuTgtHisMemo(params);
		}

		// 검진대상자 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpTgtrId(params);

		// 백신대상자 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpVcnTgtrId(params);

		if( "1".equals(in.getRegDvVal()) ) {

			// 검진대상자 및 백신대상자 등록 (with 이력)
			registRepository.insertCuTgtrHis(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "3", "4") ) {

			// 검진대상자 변경이력
			registRepository.insertCustInfEmpRecs(params);

			// 검진대상자 변경 이력 (갱신)
			registRepository.insertCuTgtrRecs(params);

			// 검진대상자 업데이트
			registRepository.updateCuTgtrHis(params);

			// 검진대상자 중복 건 업데이트 처리
			//registRepository.updateCuTgtrHisInfo(params);
		}

		if( "1".equals(in.getRegDvVal()) ) {

			// 종합지원금 등록
			registRepository.insertMbrSpfnSyntInfBsc(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "4") ) {

			// 종합지원금 업데이트
			registRepository.updateMbrSpfnSyntInfBsc(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "3", "5") ) {

			// 백신대상자 변경 이력 (갱신)
			registRepository.insertVcnTgtrChgRecs(params);

			// 백신대상자 업데이트
			registRepository.updateVcnTgtrBsc(params);

			// 백신대상자 중복 건 업데이트 처리
			//registRepository.updateVcnTgtrBscInfo(params);
		}

		if( "2".equals(in.getRegDvVal()) ) {

			// 가족 정보 삭제이력
			registRepository.insertCustInfEmpRecsFmlyInit(params);

			// 배우자 정보 삭제
			registRepository.deleteClcoAempBlkRegTmpSpsrTgtr(params);
		}

		// 배우자 검진대상자 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpSpsrTgtrId(params);

		// 배우자 백신대상자 존재여부 체크
		registRepository.updateClcoAempBlkRegTmpSpsrVcnTgtrId(params);


		if ( StringUtils.equalsAny(in.getRegDvVal(), "1", "2") ) {

			// 배우자 검진대상자 및 백신대상자 등록 (with 이력)
			registRepository.insertCuTgtrHisSpsr(params);

			// 가족 초대 회원 대상자 자동 추가
			registRepository.insertCuTgtrHisOther(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "2", "4") ) {

			// 배우자 검진대상자 변경이력
			registRepository.insertCustInfEmpRecsForSpsr(params);

			// 배우자 검진대상자 변경 이력 (갱신)
			registRepository.insertCuTgtrRecsSpsr(params);

			// 배우자 검진대상자 업데이트
			registRepository.updateCuTgtrHisSpsr(params);
		}

		if ( StringUtils.equalsAny(in.getRegDvVal(), "1", "2") ) {

			// 배우자 종합지원금 등록
			registRepository.insertMbrSpfnSyntInfBscSpsr(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "2", "4") ) {

			// 배우자 종합지원금 업데이트
			registRepository.updateMbrSpfnSyntInfBscSpsr(params);
		}

		if( StringUtils.equalsAny(in.getRegDvVal(), "1", "2", "5") ) {

			// 배우자 백신대상자 변경 이력 (갱신)
			registRepository.insertVcnTgtrChgRecsSpsr(params);

			// 배우자 백신대상자 업데이트
			registRepository.updateVcnTgtrBscSpsr(params);
		}

		// 기존 회원고객사 관계 업데이트
		//registRepository.updateMbrClcoRltn2(params);

		// 기존 회원고객사 관계 변경이력 등록
		//registRepository.insertMbrClcoRltnChgRecs3(params);

		// 기존 회원사업장 이력 업데이트
		//registRepository.updateMbrBsplHis(params);

		// 기존 회원부가정보 업데이트
		//registRepository.updateMbrAddInfDtl2(params);

		// 임시테이블 이메일 휴대폰번호 업데이트
		registRepository.updateClcoAempBlkRegTmpInfo(params);

/*
		// 고객사근무부서 등록
		registRepository.insertClcoWorkDept(params);

		// 고객사라인 등록
		registRepository.insertClcoLine(params);

		// 고객사작업 등록
		registRepository.insertClcoJob(params);

		// 회원근골격계 부서내역 등록
		registRepository.insertMbrMuscDeptHis(params);

		// 회원근골격계 부서내역 수정
		registRepository.updateMbrMuscDeptHis(params);

		// 고객사팀 등록
		registRepository.insertClcoTeam(params);

		// 회원고객사관계 팀아이디 수정
		registRepository.updateMbrClcoRltnTeamId(params);
*/

		if(cmplPrcs) {

			// 등록 완료 처리
			registRepository.updateClcoAempBlkRegTmpRegist(params);
		}
	}

	/**
	 *
	 * 처리내용 : 선택된 중복 오류 항목 신규 내용으로 등록
	 *
	 * @param in
	 * @throws IOException
	 */

	@Transactional
	public void registUploadedMember(BatchMemberUploadRegistRequestModel in) {

		if( CollectionUtils.isEmpty(in.getList()) )
			return;

		in.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpBackup(in);

		// 업로드 상태를 14로 변경하여 처리한다.
		in.getList().forEach(e->{
			e.setUpldStVal(14);
		});
		repository.updateClcoAempBlkRegTmpUpldStVal(in);

		repository.DmcyBlkRlsPrcs(in);

		regist(in, false);

		repository.DmcyBlkRstPrcs(in);

		Map<String, Object> params = UstraMapUtils.getMap(
				"clcoId", in.getClcoId(),
				"yr", in.getYr(),
				"managerId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"regDvVal", in.getRegDvVal());

		registRepository.updateClcoAempBlkRegTmpRegist(params);

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpRestore(in);
	}

	@Transactional
	public void registSavedMember(BatchMemberUploadRegistRequestModel in) {

		if( CollectionUtils.isEmpty(in.getList()) )
			return;

		in.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpBackup(in);

		// 업로드 상태를 24로 변경하여 처리한다.
		in.getList().forEach(e->{
			e.setUpldStVal(24);
		});
		repository.updateClcoAempBlkRegTmpUpldStVal2(in);

		repository.DmcyBlkRlsPrcs(in);

		regist(in, false);

		repository.DmcyBlkRstPrcs(in);

		Map<String, Object> params = UstraMapUtils.getMap(
				"clcoId", in.getClcoId(),
				"yr", in.getYr(),
				"managerId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"regDvVal", in.getRegDvVal());

		registRepository.updateClcoAempBlkRegTmpRegist(params);

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpRestore(in);
	}

	@Transactional
	public void registDmcyAll(BatchMemberUploadRegistRequestModel in) {

		BatchMemberUploadErrorRequestModel errIn = new BatchMemberUploadErrorRequestModel();
		errIn.setYr(in.getYr());
		errIn.setClcoId(in.getClcoId());
		errIn.setRegDvVal(in.getRegDvVal());
		errIn.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());
		errIn.setState(6);

		in.setMngrId(errIn.getMngrId());
		in.setCuTgtrUpdYn(true);
		in.setVcnTgtrUpdYn(true);
		in.setFmlyInitYn(false);
		in.setFmlyUpdYn(true);
		in.setSpcuMttr1UpdYn(true);
		in.setSpcuMttr2UpdYn(true);

		List<BatchMemberUploadCustomerModel> list = getAllErrorList(errIn);

		in.setList(list);

//		in.getList().forEach(mem-> {
//
//			MemberModel vo = new MemberModel();
//			vo.setUid(mem.getUid());
//			repository.DmcyRlsPrcs(vo);
//		});

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpBackup(in);

		// 업로드 상태를 4로 변경하여 처리한다.
		in.setUpldStVal(4);
		repository.updateClcoAempBlkRegTmpUpldStVal3(in);

		repository.DmcyBlkRlsPrcs(in);

		regist(in, false);

		repository.DmcyBlkRstPrcs(in);

		Map<String, Object> params = UstraMapUtils.getMap(
				"clcoId", in.getClcoId(),
				"yr", in.getYr(),
				"managerId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
				"regDvVal", in.getRegDvVal());

		registRepository.updateClcoAempBlkRegTmpRegist(params);

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpRestore(in);

//		in.getList().forEach(mem-> {
//
//			MemberModel vo = new MemberModel();
//			vo.setUid(mem.getUid());
//			repository.DmcyMnlPrcs(vo);
//		});
	}

	@Transactional
	public void registDmcy(BatchMemberUploadRegistRequestModel in) {

		BatchMemberUploadErrorRequestModel errIn = new BatchMemberUploadErrorRequestModel();
		errIn.setYr(in.getYr());
		errIn.setClcoId(in.getClcoId());
		errIn.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());
		errIn.setState(6);

		in.setMngrId(errIn.getMngrId());
		in.setCuTgtrUpdYn(true);
		in.setVcnTgtrUpdYn(true);
		in.setFmlyInitYn(false);
		in.setFmlyUpdYn(true);
		in.setSpcuMttr1UpdYn(true);
		in.setSpcuMttr2UpdYn(true);

		List<BatchMemberUploadCustomerModel> list = getAllErrorList(errIn);

		in.getList().forEach(mem->{
			BatchMemberUploadCustomerModel found = list.stream().filter(itm->itm.getAempRegSeq().equals(mem.getAempRegSeq())).findFirst().orElse(null);
			if( found != null )
				mem.setUid(found.getUid());
			else mem.setUid(null);
		});
		in.setList(in.getList().stream().filter(mem->mem.getUid() != null).collect(Collectors.toList()));

//		in.getList().forEach(mem-> {
//
//			MemberModel vo = new MemberModel();
//			vo.setUid(mem.getUid());
//			repository.DmcyRlsPrcs(vo);
//		});

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpBackup(in);

		// 업로드 상태를 4로 변경하여 처리한다.
		in.setUpldStVal(4);
		repository.updateClcoAempBlkRegTmpUpldStVal3(in);

		repository.DmcyBlkRlsPrcs(in);

		regist(in, false);

		repository.DmcyBlkRstPrcs(in);

		Map<String, Object> params = UstraMapUtils.getMap(
			"clcoId", in.getClcoId(),
			"yr", in.getYr(),
			"managerId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
			"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
			"regDvVal", in.getRegDvVal());

		registRepository.updateClcoAempBlkRegTmpRegist(params);

		// 1과4는 잠시 다른 값으로 변경해 두고 완료 후 복구 한다.
		repository.updateClcoAempBlkRegTmpRestore(in);

//		in.getList().forEach(mem-> {
//
//			MemberModel vo = new MemberModel();
//			vo.setUid(mem.getUid());
//		});
	}

	/**
	 *
	 * 처리내용 : 선택 년도 모든 고객 다운로드 (for Test)
	 *
	 * @param in
	 * @return
	 */
	public List<BatchCustomerExcelModel> getTestCustomerList(CustomerExcelDownModel in) {

		in.setMngrId("" + NcuAuthenticationUtils.getCurrentUser().getMngrId());
		return repository.selectCustomerTmpTestExcelList(in);
	}

	public List<BatchCustomerExcelModel> selectCustomerTmpExcelList(CustomerExcelDownModel in) {
		// TODO Auto-generated method stub
		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());
		in.setMngrId(String.valueOf(managerDtl.getMngrId()));
		return errorExcelMsg(repository.selectCustomerTmpExcelList(in));
	}
/*

	public Map<String, Object> getBatchCustomerList(CustomerExcelDownModel vo) {
		Map<String, Object> result = new HashMap<>();
		List<BatchCustomerExcelModel> dupList = new ArrayList<BatchCustomerExcelModel>();
		List<BatchCustomerExcelModel> missingList = new ArrayList<BatchCustomerExcelModel>();
		List<BatchCustomerExcelModel> etcList = new ArrayList<BatchCustomerExcelModel>();
		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());

		vo.setMngrId(String.valueOf(managerDtl.getMngrId()));
		// T_CLCO_AEMP_BLK_REG_TMP
		vo.setResultFlag("dup");
		dupList = repository.getClcoAempBlkRegTmp(vo);
		vo.setResultFlag("missing");
		missingList = repository.getClcoAempBlkRegTmp(vo);
		vo.setResultFlag("etc");
		etcList = repository.getClcoAempBlkRegTmp(vo);

		result.put("dupCnt", dupList.size());
		result.put("missingCnt", missingList.size());
		result.put("etcCnt", etcList.size());

		result.put("dupList", dupList);
		result.put("missingList", missingList);
		result.put("etcList", etcList);

		return result;
	}
*/

	/**
	 *
	 * 처리내용 : 예약 정보 체크
	 *
	 * @param in
	 * @return
	 */

	public BatchMemberUploadReserveInfoModel checkReserve(BatchMemberUploadRegistRequestModel in) {

		BatchMemberUploadReserveInfoModel ret = new BatchMemberUploadReserveInfoModel();
		ret.setCuResvCnt(0);
		ret.setSpcuResvCnt(0);
		ret.setVcnResvCnt(0);
		return ret;
	}

	public List<BatchCustomerExcelModel> getCustomerListForDownload(List<BatchMemberUploadCustomerModel> in) {

		if( CollectionUtils.isEmpty(in) )
			return Arrays.asList(new BatchCustomerExcelModel());
		return errorExcelMsg(repository.selectClcoAempBlkRegTmpExcelList(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
			"list", in)));
	}

	public List<CommonParametersModel> getClcoList(CommonParametersModel model) {

		NcuAdminUser user = NcuAuthenticationUtils.getCurrentUser();
		if( "01".equals(user.getAuthType()) ||
			"02".equals(user.getAuthType()) ||
			"03".equals(user.getAuthType()) )
			model.setClcoId(user.getClcoId());
		List<CommonParametersModel> result = repository.getClcoList(model);
		result.stream()
				.forEach( v -> {
					if( "1".equals(v.getClcoSvcTyCd()) ) {
						v.setClcoNm(v.getClcoNm() + " (Biz)");
					} else if( "5".equals(v.getClcoSvcTyCd()) ) {
						v.setClcoNm(v.getClcoNm() + " (bizCenter)");
					} else if( "6".equals(v.getClcoSvcTyCd()) ) {
						v.setClcoNm(v.getClcoNm() + " (bizLite)");
					}
				});
		return result;
	}

	public BatchMemberUploadResultModel getCurrentReg(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(NcuAuthenticationUtils.getCurrentUser().getMngrId());
		return repository.selectClcoAempBlkRegTmpCurrentReg(in);
	}

	public List<BatchCustomerExcelModel> selectDuplicatedCustomer(CustomerExcelDownModel in) {

		in.setMngrId(String.valueOf(NcuAuthenticationUtils.getCurrentUser().getMngrId()));
		return errorExcelMsg(repository.selectClcoAempBlkRegTmpDuplicatedExcel(in));
	}

	public List<BatchCustomerExcelModel> selectDuplicatedCustomerList(List<BatchMemberUploadCustomerModel> in) {
		return errorExcelMsg(repository.selectClcoAempBlkRegTmpDuplicatedExcelList(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", NcuAuthenticationUtils.getCurrentUser().getMngrId(),
			"list", in)));
	}
}
