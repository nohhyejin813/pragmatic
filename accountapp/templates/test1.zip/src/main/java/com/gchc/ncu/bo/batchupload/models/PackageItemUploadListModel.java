package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PackageItemUploadListModel extends NcuModel {

	int pkgItmLstUpldId;

	int pkgItmUpldBscId;

	int xclShtNo;

	int xclRowId;

	String itmCatNm;

	int itmCatId;

	String dtlCatItmNm;

	int dtlCatItmId;

	String examResvItmNm;

	String examNm;

	int pkgItmStVal;

	String pkgItmErrCont;
}
