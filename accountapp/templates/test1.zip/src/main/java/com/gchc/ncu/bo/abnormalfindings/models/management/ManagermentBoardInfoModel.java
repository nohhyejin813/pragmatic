package com.gchc.ncu.bo.abnormalfindings.models.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentBoardInfoModel extends UstraManagementBaseModel
{
	@ApiModelProperty(value="전체 개수")
	private Integer wholCnt;


	@ApiModelProperty(value="검진 완료 개수")
	private Integer cuCmplCnt;


	@ApiModelProperty(value="결과 등록")
	private Integer rsltRegCnt;




	@ApiModelProperty(value="유소견 동의 개수")
	private Integer abnfAgrCnt;



	@ApiModelProperty(value="개인정보 수집 동의 개수")
	private Integer innfAgrCnt;


	@ApiModelProperty(value="민감 정보 수집 동의 개수")
	private Integer sensInfGahrCnt;

	@ApiModelProperty(value="제3자정보 동의 개수")
	private Integer p3rdAgrCnt;





}
