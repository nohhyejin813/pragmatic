package com.gchc.ncu.bo.care.models;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DwCnntScwdDatBscModel extends UstraManagementBaseModel {

	private String cnntRegId;
	private Integer regSeq;
	private String cnntCatNm;
	private String cmsDvCd;
	private String cmsDtlCd;
	private String cmsPgmCd;
	private String cnntRegNm;
	private String cnntDesc;
	private String cnntN1stKeywVal;
	private String cnntN2ndKeywVal;
	private String cnntN3rdKeywVal;
	private String cnntN4thKeywVal;
	private String cnntN5thKeywVal;
	private String cnntN6thKeywVal;
	private Integer cnntLastVer;
	private String cnntFileNm;
	private String cnntStrgPath;
	private String sexCd;
	private Integer mnAg;
	private Integer mxAg;
	private String cnntRpsImgNm;
	private String cnntRpsImgPath;

}
