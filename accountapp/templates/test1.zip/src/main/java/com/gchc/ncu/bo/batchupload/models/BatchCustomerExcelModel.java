package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchCustomerExcelModel extends NcuModel {
	// 엑셀 다운로드 용
	private String aempNm;
	private String aempCuGrdNm;
	private String aempVcnGrdNm;
	private String aempId;
	private String excuYn;
	private String aempBrdt;
	private String encmDt;
	private String pkgNm;
	private String corpSpfnVal;
	private String nhicSuptTgtYn;
	private String spcuTgtYn;
	private String extrMttrNm1;
	private String extrMttrNm2;
	private String emlAdr;
	private String mblNo;
	private String spsrNm;
	private String spsrCuGrdNm;
	private String spsrVcnGrdNm;
	private String spsrBrdt;
	private String spsrCorpSpfn;
	private String spsrPkgNm;
	private String bsplNm;
	private String deptNm1;
	private String deptNm2;
	private String deptNm3;
	private String jbgdNm;
	private String wrplTlno;
	private String wrplZpcd;
	private String wrplBscAdr;
	private String wrplDtlAdr;
	private String hsTlno;
	private String hsZpcd;
	private String hsBscAdr;
	private String aempRegSeq;
	private String uid;
	private String hsDtlAdr;
	private String upldErrVal;

	private String oldAempNm;
	private String oldAempId;
	private String oldAempBrdt;
	private String oldAempSexCd;

	private String workDeptNm;	// 근무부서
	private String lineNm;		// 라인
	private String jobNm;		// 작업
	private String teamNm;		// 팀명

	private String custMemo;

}
