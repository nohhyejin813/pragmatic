package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;


@Getter
@Setter
@ToString
public class ManagermentYearVo extends GchcVo
{
	@ApiModelProperty(value="유저 UID", example = "6347")
	private Integer uid;

	private Integer tgtClcoId;
}
