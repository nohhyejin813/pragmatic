package com.gchc.ncu.bo.batchupload.enu;

import java.text.MessageFormat;

public enum BatchCenterVaccineUploadError {

	MISSING_INFORMATION(2, "{0}이(가) 누락되었습니다."),

	NO_DIGIT(2, "{0}이(가) 숫자가 아닙니다."),

	TOO_SMALL_PRICE(2, "금액이 1000 이하입니다.")

	;

	Integer errCd;
	String message;

	BatchCenterVaccineUploadError(Integer value, String message) {

		this.message = message;
		this.errCd = value;
	}

	public Integer getErrorCd() {

		return this.errCd;
	}

	public String getMessage(Object...args) {

		return MessageFormat.format(this.message, args);
	}
}
