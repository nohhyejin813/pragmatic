package com.gchc.ncu.bo.batchupload.comm;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @FileName : BatchUploadUtil.java
 * @date : 2021. 10. 15
 * @author : hykim
 * @프로그램 설명 : 일괄업로드 유틸리티
 * @변경이력 :
 */
@Component
public class BatchUploadUtil {

	/**
	 * 값이 Y,y,1이면 Integer 1 반환
	 * 값이 N,n,0,empty이면 Integer 0 반환
	 * @param param
	 * @return
	 */
	public Integer convertBooleanToInteger(String param) {
		if("1".equals(param) || "Y".equals(param) || "y".equals(param)) {
			return 1;
		} else if("0".equals(param) || "N".equals(param) || "n".equals(param) || param.isEmpty()) {
			return 0;
		}
		return 0;
	}

	/**
	 * 금액을 숫자로 변환
	 * @param param
	 * @return
	 * @throws ParseException
	 */
	public Integer convertCurrencyToInteger(String param) throws ParseException {
		if(param.isEmpty()) {
			return 0;
		}
		final NumberFormat format = NumberFormat.getNumberInstance(Locale.getDefault());
		if(format instanceof DecimalFormat) {
			((DecimalFormat) format).setParseBigDecimal(true);
		}
		BigDecimal resultValue = (BigDecimal) format.parse(param.replaceAll("[^\\d.,]", ""));
		return resultValue.intValue();
	}

	/**
	 * 생년월일의 다양한 형태를 YYYYMMDD, SEX_CD(0, 1)로 변경
	 * @param _birthDay (YYMMDD-X, YYYYMMDD-X 허용)
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> convertBirthDayValue(String _birthDay) throws Exception {
		// 예상되는 형태
		// YYYYMMDD				// length 8, - 미포함
		// YYYY-MM-DD			// length 10, - 포함
		// YY-MM-DD				// length 8, - 포함 (20세기, 21세기 출생 구분 불가능)
		// YYMMDD				// length 6, - 미포함 (20세기, 21세기 출생 구분 불가능)
		// YYMMDD-X (성별코드)	// length 8, - 포함
		Map<String, Object> result = new HashMap<>();
		String match	= "[^\uAC00-\uD7A3xfe0-9a-zA-Z\\s]";	// 한글, 숫자, 영문대소문자를 제외한 문자를 제거한다.
		String birthDay = _birthDay.replaceAll(match, "");
		String sexCd	= "";

		if(StringUtils.isEmpty(birthDay)) {
			result.put("code", "E");
			result.put("error", "입력된 값이 없습니다.");
		}
		if(!StringUtils.isNumeric(birthDay) || birthDay.length() != 7) {
			result.put("code", "E");
			result.put("error", "입력값이 잘못되었습니다. 생년월일 6자리 + 주민등록번호 앞 1자리를 입력해주세요.");
			return result;
		}

		if(birthDay.length() == 7) {
			char _sexCd = birthDay.charAt(birthDay.length() - 1);
			sexCd = String.valueOf(_sexCd);
			result.put("sexCd", sexCd);
			if("1".equals(sexCd) || "2".equals(sexCd) || "5".equals(sexCd) || "6".equals(sexCd)) {
				birthDay = "19" + birthDay.substring(0, 6);
			} else if("3".equals(sexCd) || "4".equals(sexCd) || "7".equals(sexCd) || "8".equals(sexCd)) {
				birthDay = "20" + birthDay.substring(0, 6);
			} else {
				result.put("code", "E");
				result.put("error", "입력값이 잘못되었습니다. 유효한 형식이 아닙니다.");
			}
			return result;
		}
		return result;
	}
}
