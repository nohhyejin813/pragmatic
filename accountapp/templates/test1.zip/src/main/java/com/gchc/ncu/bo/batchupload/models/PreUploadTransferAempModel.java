package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PreUploadTransferAempModel {

	private Integer errCol;
	private String error;
	private Object object;
	private BatchUploadTransferExcelModel parsed;
	private BatchUploadTransferFamilyExcelModel tnsfFamily;
	private BatchUploadMultiFamilyExcelModel mltiFamily;
	private Integer row;
	private String src;

	private String yr;
	private String clcoId;
}
