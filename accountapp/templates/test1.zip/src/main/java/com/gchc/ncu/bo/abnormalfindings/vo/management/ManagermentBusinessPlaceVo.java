package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;


@Getter
@Setter
@ToString
public class ManagermentBusinessPlaceVo extends GchcVo
{
	@ApiModelProperty(value="고객사 아이디", example = "1")
	private Integer clcoId;


	@ApiModelProperty(value="검색 연도", example = "2020")
	private String yr;
}
