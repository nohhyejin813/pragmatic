package com.gchc.ncu.bo.care.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gchc.ncu.bo.care.models.*;
import com.gchc.ncu.bo.wellness.talk.models.TalkSearchModel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.repository.LifeStyleRepository;
import com.gchc.ncu.bo.care.vo.LifeStyleVo;

@Service
@RequiredArgsConstructor
public class LifeStyleService {

	private final LifeStyleRepository lifeStyleRepository;

	public List<LifeHbtScdlBscModel> getScheduleList(LifeStyleVo criteria) {
		return lifeStyleRepository.selectScheduleList(criteria);
	}

	public LifeHbtScdlBscModel getSchedule(LifeHbtScdlBscModel criteria) {
		return lifeStyleRepository.selectScheduleDetail(criteria);
	}

	@Transactional
	public void setSchedule(LifeHbtScdlBscModel model) {
		lifeStyleRepository.saveSchedule(model);
	}

	@Transactional
	public void removeSchedule(List<LifeHbtScdlBscModel> list) {
		if (list != null) {
			for (LifeHbtScdlBscModel model : list) {
				lifeStyleRepository.deleteSchedule(model);
			}
		}
	}

	public List<LifeHbtCtraBscModel> getContractList(LifeStyleVo criteria) {
		return lifeStyleRepository.selectContractList(criteria);
	}

	public LifeHbtCtraBscModel getContract(LifeHbtCtraBscModel criteria) {
		return lifeStyleRepository.selectContractDetail(criteria);
	}


	@Transactional
	public void setContract(LifeHbtCtraBscModel model) {
		int checkConflictCnt = lifeStyleRepository.selectContractConflictCnt(model);

		if (checkConflictCnt > 0) {
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "계약기간이 중복된 계약이 있습니다.");
		}

		if (model.getLifeHbtCtraId() == null) {
			lifeStyleRepository.insertContract(model);
		} else {
			lifeStyleRepository.updateContract(model);
		}
	}

	@Transactional
	public void removeContract(List<LifeHbtCtraBscModel> list) {
		if (list != null) {
			for (LifeHbtCtraBscModel model : list) {
				lifeStyleRepository.deleteContract(model);
			}
		}
	}

	public List<LifeHbtCtraDtlModel> getContractHbtDtlList(LifeHbtCtraBscModel criteria) {
		return lifeStyleRepository.selectContractHbtDetailList(criteria);
	}

	public List<LifeStyleCdModel> getContractCommCdList() {
		return lifeStyleRepository.selectContractCommCdList();
	}

	public void setContractHbtDtlSave(List<LifeHbtCtraDtlModel> list) {

		lifeStyleRepository.deleteContractHbtDtl(list.get(0));

		if (list != null) {
			for (LifeHbtCtraDtlModel model : list) {
				lifeStyleRepository.insertContractHbtDtl(model);
			}
		}
	}

	public List<LifeHbtApplBscModel> getApplicationList(LifeStyleVo criteria) {
		List<LifeHbtApplBscModel> list = lifeStyleRepository.selectApplicationList(criteria);
		UstraMaskingUtils.maskTextFields(list);
		return list;
	}

	public List<LifeHbtApplScdlDtlModel> getApplicationDetailList(LifeStyleVo criteria) {
		return lifeStyleRepository.selectApplicationDetailList(criteria);
	}

	public List<DwCnntScwdDatBscModel> getProgramList() {
		return lifeStyleRepository.getProgramList();
	}

	public List<DwCnntScwdDatBscModel> getCategoryList(DwCnntScwdDatBscModel model) {
		return lifeStyleRepository.getCategoryList(model);
	}

	public List<DwCnntScwdDatBscModel> getContentList(DwCnntScwdDatBscModel model) {
		return lifeStyleRepository.getContentList(model);
	}

	public List<LifeHbtScdlBscModel> getScheduleYearList(LifeHbtScdlBscModel model) {
		return lifeStyleRepository.getScheduleYearList();
	}

	@Transactional
	public LifeHbtScdlBscModel saveScheduleCopy(LifeHbtScdlBscModel model) {
		int scheduleSize = lifeStyleRepository.getScheduleDataCheck(model);

		if( scheduleSize == 0 ){
			lifeStyleRepository.saveScheduleCopy(model);
		}

		model.setDuplicationYn(scheduleSize);

		return model;
	}

	public LifeHbtScdlBscModel getScheduleSaveYn(LifeHbtScdlBscModel model) {
		int scheduleSize = lifeStyleRepository.getScheduleSaveYn(model);
		model.setDuplicationYn(scheduleSize);
		return model;
	}
}
