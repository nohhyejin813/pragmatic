package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum TransferMultiColumn implements BatchUploadColumn {

	AEMP_NM("임직원이름", "AempNm"),

	AEMP_ID("임직원사번", "AempId"),

	FMLY_NM1("가족1이름", "FmlyNm1"),

	FMLY_BRDT1("가족1생년월일", "FmlyBrdt1"),

	FMLY_NM2("가족2이름", "FmlyNm2"),

	FMLY_BRDT2("가족2생년월일", "FmlyBrdt2"),

	FMLY_NM3("가족3이름", "FmlyNm3"),

	FMLY_BRDT3("가족3생년월일", "FmlyBrdt3"),

	FMLY_NM4("가족4이름", "FmlyNm4"),

	FMLY_BRDT4("가족4생년월일", "FmlyBrdt4"),

	FMLY_NM5("가족5이름", "FmlyNm5"),

	FMLY_BRDT5("가족5생년월일", "FmlyBrdt5"),

	FMLY_NM6("가족6이름", "FmlyNm6"),

	FMLY_BRDT6("가족6생년월일", "FmlyBrdt6"),

	FMLY_NM7("가족7이름", "FmlyNm7"),

	FMLY_BRDT7("가족7생년월일", "FmlyBrdt7"),

	FMLY_NM8("가족8이름", "FmlyNm8"),

	FMLY_BRDT8("가족8생년월일", "FmlyBrdt8"),

	FMLY_NM9("가족9이름", "FmlyNm9"),

	FMLY_BRDT9("가족9생년월일", "FmlyBrdt9"),

	FMLY_NM10("가족10이름", "FmlyNm10"),

	FMLY_BRDT10("가족10생년월일", "FmlyBrdt10")

	;

	private String title;

	private String field;

	TransferMultiColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
