package com.gchc.ncu.bo.batchupload.controller;

import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.service.BatchCampaignUploadService;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @FileName : BatchCampaignUploadController.java
 * @date : 2023. 02. 06
 * @author : hykim
 * @프로그램 설명 : 일괄업로드 Controller
 * @변경이력 :
 */
@RequiredArgsConstructor
@Api(tags = "일괄업로드 컨트롤러")
@RestController
@RequestMapping("/api/bo/batchupload/campaign")
public class BatchCampaignUploadController {

	@Autowired
	private FileOperationManager fileOperationManager;
	@Autowired
	private BatchCampaignUploadService service;
	@Autowired
	private BatchXlsHistProcess batchXlsHistProcess;

	/**
	 * 양식 다운로드
	 */
	@PostMapping("/sample-download-excel")
	@ApiOperation(value="부가정보 양식 다운로드", notes="부가정보 양식 다운로드")
	public ResponseEntity<?> downloadExcel(HttpServletRequest request, HttpServletResponse response) {
		return sampleConvertExcel(service.getSampleDownloadExcel(), request, response);
	}

	ResponseEntity<?> sampleConvertExcel(List<BatchCampaignExcelModel> model, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();

		for( int i = 0; i < model.size(); i++ ) {

			Map<String, Object> map = new TreeMap<>();

			// 리스트 셋팅
			BatchCampaignExcelModel exMap = model.get(i);

			map.put("col1", exMap.getClcoNm()); 		// 고객사
			map.put("col2", exMap.getAempNm()); 		// 이름
			map.put("col3", exMap.getAempId()); 		// 사번
			map.put("col4", exMap.getWorkDeptNm());	// 근무부서
			map.put("col5", exMap.getLineNm());		// 라인명
			map.put("col6", exMap.getJobNm());		// 작업명
			map.put("col7", exMap.getTeamNm());		// 캠페인팀

			list.add(map);
		}

		if( StringUtils.isNotEmpty(model.get(0).getAempNm()) ) {

			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "일괄업로드 > 고객 > 부가정보";
			String cont = "고객사, 이름, 사번, 근무부서, 라인, 작업, 캠페인팀";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사"	),
				new UstraExcelCellInfoModel("col2"	, "이름"		),
				new UstraExcelCellInfoModel("col3"	, "사번"		),
				new UstraExcelCellInfoModel("col4"	, "근무부서"	),
				new UstraExcelCellInfoModel("col5"   	, "라인"		),
				new UstraExcelCellInfoModel("col6"   	, "작업"		),
				new UstraExcelCellInfoModel("col7"   	, "캠페인팀"	)
			))
			.withSheetName("업로드정보");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "고객(일반)", request, response)
			.build());
	}

	/**
	 * 오류 다운로드
	 */
	@PostMapping("/error-download-excel")
	@ApiOperation(value="부가정보 오류 엑셀 다운로드", notes="부가정보 오류 엑셀 다운로드")
	public ResponseEntity<?> downloadExcelCustomer(@RequestBody List<BatchCampaignExcelModel> param, HttpServletRequest request, HttpServletResponse response) {
		return errorConvertExcel(param, request, response);
	}

	ResponseEntity<?> errorConvertExcel(List<BatchCampaignExcelModel> errorList, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();

		for( int i = 0; i < errorList.size(); i++ ) {

			Map<String, Object> map = new TreeMap<>();

			// 리스트 셋팅
			BatchCampaignExcelModel exMap = errorList.get(i);

			map.put("col1", exMap.getClcoNm()); 		// 고객사
			map.put("col2", exMap.getAempNm()); 		// 이름
			map.put("col3", exMap.getAempId()); 		// 사번
			map.put("col4", exMap.getWorkDeptNm());	// 근무부서
			map.put("col5", exMap.getLineNm());		// 라인명
			map.put("col6", exMap.getJobNm());		// 작업명
			map.put("col7", exMap.getTeamNm());		// 캠페인팀
			map.put("col8", exMap.getErrMsg());		// 오류내용

			list.add(map);
		}

		if( StringUtils.isNotEmpty(errorList.get(0).getAempNm()) ) {
			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "일괄업로드 > 고객 > 부가정보";
			String cont = "고객사, 이름, 사번, 근무부서, 라인, 작업, 캠페인팀, 오류내용";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;

		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사"	),
				new UstraExcelCellInfoModel("col2"	, "이름"		),
				new UstraExcelCellInfoModel("col3"	, "사번"		),
				new UstraExcelCellInfoModel("col4"	, "근무부서"	),
				new UstraExcelCellInfoModel("col5"   	, "라인"		),
				new UstraExcelCellInfoModel("col6"   	, "작업"		),
				new UstraExcelCellInfoModel("col7"   	, "캠페인팀"	),
				new UstraExcelCellInfoModel("col8"   	, "오류내용"	)

			))
			.withSheetName("오류내용");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "오류내용", request, response)
			.build());
	}
}
