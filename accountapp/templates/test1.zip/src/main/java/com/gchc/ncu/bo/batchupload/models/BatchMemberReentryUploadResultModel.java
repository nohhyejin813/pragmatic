package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchMemberReentryUploadResultModel {

	Integer totalCnt;

	Integer normalCnt;

	Integer errorCnt;

	Integer missedCnt;

	Integer invalidCnt;

	Integer duplicatedCnt;

	Integer etcCnt;
}
