package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
@ToString
public class BatchVaccineUserModel extends NcuModel {
	private String uid;
	private String nm;
	private String brdt;
	private String sexCd;
	private String vcnTgtrId;
	private String cuTgtId;
	private String clcoId;
	private String excelClcoNm;
	private String clcoNm;
	private String clcoYn;
	private String cuiId;
	private String excelCuiNm;
	private String cuiNm;
	private String cuiYn;
	private String vcnResvStCd;
	private String vcnResvId;
	private String vcnNm;
}
