package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.PoisTyBscModel;
import com.gchc.ncu.bo.care.vo.AddictionTypeVo;

@Mapper
public interface AddictionTypeRepository {

	List<PoisTyBscModel> selectAddictionTypeList(AddictionTypeVo criteria);
	PoisTyBscModel selectAddictionTypeDetail(PoisTyBscModel model);
	void insertAddictionType(PoisTyBscModel model);
	void updateAddictionType(PoisTyBscModel model);
	void deleteAddictionType(PoisTyBscModel model);
	List<Integer> selectUsedAddictionTypeCount(PoisTyBscModel model);

}
