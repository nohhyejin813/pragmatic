package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.ncu.bo.care.models.PoisHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.PoisHstkBscModel;
import com.gchc.ncu.bo.care.repository.AddictionHstkRepository;
import com.gchc.ncu.bo.care.vo.AddictionHstkVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AddictionHstkService {

	private final AddictionHstkRepository addictionHstkRepository;

	public List<PoisHstkBscModel> getAddictionHstkList(AddictionHstkVo criteria) {
		return addictionHstkRepository.selectAddictionHstkList(criteria);
	}

	public PoisHstkBscModel getAddictionHstkDetail(PoisHstkBscModel criteria) {
		return addictionHstkRepository.selectAddictionHstkDetail(criteria);
	}

	@Transactional
	public void saveAddictionHstk(PoisHstkBscModel model) {
		if (StringUtils.isEmpty(model.getHstkId())) {
			addictionHstkRepository.insertAddictionHstk(model);

			if (model.getAnswExpoTyCd().equals("30")) {
				PoisHstkAnswDtlModel answOModel = new PoisHstkAnswDtlModel();
				answOModel.setHstkId(model.getHstkId());
				answOModel.setAnswNo(1);
				answOModel.setAnswCont("네");
				answOModel.setAnswScr(1);

				saveAddictionHstkAnswer(answOModel);

				PoisHstkAnswDtlModel answXModel = new PoisHstkAnswDtlModel();
				answXModel.setHstkId(model.getHstkId());
				answXModel.setAnswNo(2);
				answXModel.setAnswCont("아니오");
				answXModel.setAnswScr(0);

				saveAddictionHstkAnswer(answXModel);
			}
		} else {
			addictionHstkRepository.updateAddictionHstk(model);
		}
	}

	@Transactional
	public void deleteAddictionHstk(List<PoisHstkBscModel> list) {
		if (list != null) {
			for (PoisHstkBscModel model : list) {
				deleteAddictionHstkAnswerByHstkId(model.getHstkId());
				addictionHstkRepository.deleteAddictionHstk(model);
			}
		}
	}

	public List<PoisHstkAnswDtlModel> getAddictionHstkAnswerList(PoisHstkBscModel criteria) {
		return addictionHstkRepository.selectAddictionHstkAnswerList(criteria);
	}

	@Transactional
	public void saveAddictionHstkAnswerList(int hstkId, List<PoisHstkAnswDtlModel> list) {
		deleteAddictionHstkAnswerByHstkId(hstkId);

		if (list != null && list.size() > 0) {
			for (PoisHstkAnswDtlModel model : list) {
				saveAddictionHstkAnswer(model);
			}
		}
	}

	protected void saveAddictionHstkAnswer(PoisHstkAnswDtlModel model) {
		addictionHstkRepository.saveAddictionHstkAnswer(model);
	}

	protected void deleteAddictionHstkAnswerByHstkId(int AddictionHstkId) {
		addictionHstkRepository.deleteAddictionHstkAnswerByHstkId(AddictionHstkId);
	}

}
