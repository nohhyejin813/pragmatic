package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;

@Getter
@Setter
@ToString
public class ManagermentMngCounselHistoryVo extends GchcVo
{
	@ApiModelProperty(value="유저 ID", example="230787")
	private Integer uid;

}
