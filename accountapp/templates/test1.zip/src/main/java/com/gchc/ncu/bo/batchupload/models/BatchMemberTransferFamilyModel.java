package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
public class BatchMemberTransferFamilyModel extends NcuModel {

	Integer cuTgtId;

	String nm;

	String brdt;

	String sexCd;

	Integer mbrGrdId;

	String suptTgtrDvCd;
}
