package com.gchc.ncu.bo.challenge.reward.enu;

import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import lombok.Getter;

@Getter
public enum RewardColumn implements BatchUploadColumn {

	JOB_NM("사번"		, "EmpNo"		),
	TEAM_NM("보상내용"	, "CmpnCont"	);

	String title;	// 제목
	String field;	// 필드명

	RewardColumn(String title, String field) {
		this.title = title;
		this.field = field;
	}
}
