package com.gchc.ncu.bo.abnormalfindings.models;

import com.gchc.common.model.GchcPageableVo;
import com.gchc.ncu.bo.abnormalfindings.vo.target.AbnfTargetVo;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 검진결과:유소견관리(암) Model
 *
 * @author 2021.11.22
 */



@Data
@Builder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class Disease1Model extends GchcPageableVo
{
	@ApiModelProperty(value="rowNum")
	private Integer rowNum;


	public Integer totalItemCount;
/*
	@ApiModelProperty(value="생성일From")
	private String frstRegDtmFrom;

	@ApiModelProperty(value="생성일To")
	private String frstRegDtmTo;

	@ApiModelProperty(value="검진일From")
	private String cuDtmFrom;

	@ApiModelProperty(value="검진일To")
	private String cuDtmTo;
*/

	@ApiModelProperty(value=" 날짜 검색 구분('검진일', '등록일')")
	private String dayTy;

	@ApiModelProperty(value="검색 시작 날짜")
	private String dayFrom;

	@ApiModelProperty(value="검색 종료 날짜")
	private String dayTo;


	@ApiModelProperty(value="검진일")
	private String cuDtm;

	@ApiModelProperty(value="UID")
	private Integer uid;

	@ApiModelProperty(value="회원 명")
	@Masked(MaskingType.NAME)
	private String nm;

	@ApiModelProperty(value="생년월일(YYYY-MM-DD)")
	private String brdt;

	@ApiModelProperty(value="고객사 이름")
	private String clcoNm;

	@ApiModelProperty(value="고객사 ID")
	private Integer clcoId;

	@ApiModelProperty(value="고객사 ID")
	private Integer[] clcoIds;

	@ApiModelProperty(value="사업장ID")
	private Integer bsplId;

	@ApiModelProperty(value="사업장 명 ")
	private String bsplNm;

	@ApiModelProperty(value="사번")
	@Masked(MaskingType.ID)
	private String empno;

	/** 검진결과 코드(공통코드 없음)
	 *  정상 (4),건강주의군 (0),건강주의군L (1),대사증후군 (2),대사증후군L (3)
	 */
	@ApiModelProperty(value="검진결과 코드(공통코드 없음) - 정상 (4),건강주의군 (0),건강주의군L (1),대사증후군 (2),대사증후군L (3)")
	private Integer cuRsltCd;

	@ApiModelProperty(value="검진결과(AS-IS:운영군)")
	private String cuRsltNm;

	@ApiModelProperty(value="검색단어")
	private String srchTxt;

	@ApiModelProperty(value="검색구분")
	private String srchTyp;

//	@ApiModelProperty(value="CALL상태")
//	private boolean callYn;

//	@ApiModelProperty(value="상담결과")
//	private String cnsRslt;

	@ApiModelProperty(value="유소견 색상")
	private String tpy;

	@ApiModelProperty(value="갯수")
	private Integer totalCount;

	@ApiModelProperty(value="성별")
	private String sexCd;

	@ApiModelProperty(value="ID")
	private String id;

	@ApiModelProperty(value="등록일")
	private String regDtm;

	@ApiModelProperty(value="B형간염보균")
	private String hepCarB;

	@ApiModelProperty(value="위암")
	private String stmCan;

	@ApiModelProperty(value="대장암")
	private String colCan;

	@ApiModelProperty(value="폐암")
	private String lunCan;

	@ApiModelProperty(value="간암")
	private String livCan;

	@ApiModelProperty(value="담낭암")
	private String galCan;

	@ApiModelProperty(value="췌장암")
	private String panCan;

	@ApiModelProperty(value="신장암")
	private String kidCan;

	@ApiModelProperty(value="갑상선암")
	private String thyCan;

	@ApiModelProperty(value="전립선암")
	private String proCan;

	@ApiModelProperty(value="유방암")
	private String breCan;

	@ApiModelProperty(value="다운로드 메모")
	private String dwldMemo;

	@ApiModelProperty(value="다운로드 사유코드")
	private String dwldRsnCd;

	@ApiModelProperty(value="다운로드 접근경로")
	private String dwldPageUrl;

	/*
	@ApiModelProperty(value="콜완료여부")
	private String calCplStu;

	@ApiModelProperty(value="콜완료여부내용")
	private String calCplStuTxt;

	@ApiModelProperty(value="콜결과상태")
	private String calResStu;
*/
}


