package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum VaccineExaminationUploadState {

    ALL("tot"),

    SUCCESS("normal"),

    ERROR("error"),

    ETC("")

    ;

    private final String value;

    VaccineExaminationUploadState(String value) {
        this.value = value;
    }
}
