package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.CstmCuBscItmBscModel;
import com.gchc.ncu.bo.care.models.SsngCsttBscModel;
import com.gchc.ncu.bo.care.models.SsngCsttCuItmDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttUseDescDtlModel;
import com.gchc.ncu.bo.care.vo.CsttMngVo;

@Mapper
public interface CsttMngRepository {

	SsngCsttBscModel selectCsttMngBase(CsttMngVo criteria);
	List<SsngCsttDtlModel> selectCsttMngDtl(CsttMngVo criteria);
	List<SsngCsttCuItmDtlModel> selectCsttMngCuItemDtl(CsttMngVo criteria);
	void updateCsttBase(SsngCsttBscModel model);
	void insertCsttDtl(SsngCsttDtlModel model);
	void updateCsttDtl(SsngCsttDtlModel model);
	void deleteCsttDtl(SsngCsttDtlModel model);
	void insertCsttCuItm(SsngCsttCuItmDtlModel model);
	void updateCsttCuItm(SsngCsttCuItmDtlModel model);
	void deleteCuItm(SsngCsttCuItmDtlModel model);
	List<SsngCsttUseDescDtlModel> selectUseDescDtl(CsttMngVo criteria);
	void updateUseDescDtl(SsngCsttUseDescDtlModel model);
	void insertUseDescDtl(SsngCsttUseDescDtlModel model);
	void deleteUseDescDtl(SsngCsttUseDescDtlModel model);
	List<CstmCuBscItmBscModel> selectCuCdList();

}
