package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DailyWalkGoalVo extends UstraManagementBaseModel {

	private Integer diseaseId;
	private String genderCd;
	private String seasonCd;

}
