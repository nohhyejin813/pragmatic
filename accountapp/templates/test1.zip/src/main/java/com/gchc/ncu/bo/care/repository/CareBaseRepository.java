package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.CareDssCdModel;
import com.gchc.ncu.bo.care.models.LifeStyleCdModel;

@Mapper
public interface CareBaseRepository {

	List<CareDssCdModel> selectCareDiseaseCodeList();
	void updateCareDiseaseCode(CareDssCdModel model);

	List<LifeStyleCdModel> selectLifeStyleCodeList();
	void updateLifeStyleCode(LifeStyleCdModel model);

}
