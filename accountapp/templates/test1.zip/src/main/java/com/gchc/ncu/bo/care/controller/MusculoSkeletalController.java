package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.SrvyBscModel;
import com.gchc.ncu.bo.care.models.SrvyQstHisModel;
import com.gchc.ncu.bo.care.models.SrvyQstThmAreaDtlModel;
import com.gchc.ncu.bo.care.service.MusculoSkeletalService;
import com.gchc.ncu.bo.care.vo.MusculoSkeletalVo;

@RestController
@RequestMapping("/api/bo/care/musc/")
@RequiredArgsConstructor
public class MusculoSkeletalController {

	private final MusculoSkeletalService musculoSkeletalService;


	@GetMapping("/srvy-list")
	public List<SrvyBscModel> getSrvyList() {
		return musculoSkeletalService.getSrvyList();
	}

	@GetMapping("/thmAreaitem-list")
	public List<SrvyQstThmAreaDtlModel> getThmAreaitemList(@ModelAttribute MusculoSkeletalVo criteria) {
		return musculoSkeletalService.getThmAreaitemList(criteria);
	}

	@GetMapping("/qutitem-list")
	public List<SrvyQstThmAreaDtlModel> getQutitemList(@ModelAttribute MusculoSkeletalVo criteria) {
		return musculoSkeletalService.getQutitemList(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> saveSrvyQstHis(@RequestBody List<SrvyQstHisModel> list) {
		musculoSkeletalService.saveSrvyQstHis(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}


	@GetMapping("/chronic-srvy-list")
	public List<SrvyBscModel> getChronicSrvyList() {
		return musculoSkeletalService.getChronicSrvyList();
	}

	@GetMapping("/chronic-qutitem-list")
	public List<SrvyQstThmAreaDtlModel> getChronicQutitemList(@ModelAttribute MusculoSkeletalVo criteria) {
		return musculoSkeletalService.getChronicQutitemList(criteria);
	}

	@PostMapping("/chronic-save")
	public RestResult<?> saveChronicSrvyQstHis(@RequestBody List<SrvyQstHisModel> list) {
		musculoSkeletalService.saveChronicSrvyQstHis(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
