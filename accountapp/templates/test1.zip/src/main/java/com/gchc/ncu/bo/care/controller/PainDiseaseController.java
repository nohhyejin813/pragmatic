package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.NrsnDssAgDtlModel;
import com.gchc.ncu.bo.care.models.NrsnDssBscModel;
import com.gchc.ncu.bo.care.models.NrsnDssExamRltnModel;
import com.gchc.ncu.bo.care.models.NrsnDssMjrDssRltnModel;
import com.gchc.ncu.bo.care.service.PainDiseaseService;
import com.gchc.ncu.bo.care.vo.PainDiseaseVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/pain/disease")
@RequiredArgsConstructor
public class PainDiseaseController {

	private final PainDiseaseService painDiseaseService;

	@GetMapping("/list")
	public List<NrsnDssBscModel> list(@ModelAttribute PainDiseaseVo criteria) {
		return painDiseaseService.getPainDiseaseList(criteria);
	}

	@GetMapping("/detail")
	public NrsnDssBscModel detail(@ModelAttribute NrsnDssBscModel criteria) {
		return painDiseaseService.getPainDiseaseDetail(criteria);
	}

	@GetMapping("/list/age")
	public List<NrsnDssAgDtlModel> detailAge(@ModelAttribute NrsnDssAgDtlModel criteria) {
		return painDiseaseService.getPainDiseaseAgeDetail(criteria);
	}

	@GetMapping("/list/dept")
	public List<NrsnDssExamRltnModel> detailDept(@ModelAttribute NrsnDssExamRltnModel criteria) {
		return painDiseaseService.getPainDiseaseDeptDetail(criteria);
	}

	@GetMapping("/list/mjr")
	public List<NrsnDssMjrDssRltnModel> detailMjr(@ModelAttribute NrsnDssMjrDssRltnModel criteria) {
		return painDiseaseService.getPainDiseaseMjrDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody NrsnDssBscModel model) {
		painDiseaseService.savePainDisease(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/save/{nrsnDssId}/age")
	public RestResult<?> saveAge(@PathVariable(name = "nrsnDssId", required = true) int nrsnDssId, @RequestBody List<NrsnDssAgDtlModel> list) {
		painDiseaseService.savePainDiseaseAge(nrsnDssId, list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/save/{nrsnDssId}/dept")
	public RestResult<?> saveDept(@PathVariable(name = "nrsnDssId", required = true) int nrsnDssId, @RequestBody List<NrsnDssExamRltnModel> list) {
		painDiseaseService.savePainDiseaseDept(nrsnDssId, list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/save/{nrsnDssId}/mjr")
	public RestResult<?> saveMjr(@PathVariable(name = "nrsnDssId", required = true) int nrsnDssId, @RequestBody List<NrsnDssMjrDssRltnModel> list) {
		painDiseaseService.savePainDiseaseMjr(nrsnDssId, list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<NrsnDssBscModel> list) {
		painDiseaseService.deletePainDisease(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
