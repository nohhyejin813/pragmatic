package com.gchc.ncu.bo.batchupload.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BatchReflectionUtils {

    public String getStringValue(Object obj, String mthdNm) {

        try {

            return obj.getClass().getMethod(mthdNm).invoke(obj).toString();
        }
        catch( Exception e ) {

            return null;
        }
    }
}
