package com.gchc.ncu.bo.care.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
public class KeywordVo extends UstraManagementBaseModel {

	private String careMenuDvCd;
	private String cnntAreaCd;
	private String linkKvl;

}
 