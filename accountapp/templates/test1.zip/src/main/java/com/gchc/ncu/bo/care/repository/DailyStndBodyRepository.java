package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.StndBodyBscModel;
import com.gchc.ncu.bo.care.vo.DailyStndBodyVo;

@Mapper
public interface DailyStndBodyRepository {

	List<StndBodyBscModel> selectDailyStndBodyList(DailyStndBodyVo criteria);
	void saveDailyStndBody(StndBodyBscModel model);

}
