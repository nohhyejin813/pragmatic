package com.gchc.ncu.bo.batchupload.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.file.model.FileConvertInput;
import com.gsitm.ustra.java.data.file.processor.convert.LocalExcelFileToDataConverter;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import com.gsitm.ustra.java.data.poi.convert.DefaultDataFormatter;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.batchupload.models.BatchMemberReentryUploadResultModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberReentryUploadValidateRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadCustomerReentryModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadReentryDownloadRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadReentryErrorRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadResultRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadReentryExcelModel;
import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.batchupload.service.BatchMemberReentryUploadService;

@RestController
@RequestMapping("/api/bo/batchupload/reentry")
public class BatchMemberReentryUploadController {

	@Autowired private BatchMemberReentryUploadService service;

	@Autowired private FileOperationManager fileOperationManager;

	@Autowired private BatchXlsHistProcess batchXlsHistProcess;

	@RequestMapping("/validate")
	public void validate(@RequestBody BatchMemberReentryUploadValidateRequestModel in) {

		// Excel convert
		FileConvertInput<LocalExcelFileToDataConverter.Option, List<RowInfo>> converter =
			LocalExcelFileToDataConverter.builder(in.getFileGrpId(), true, BatchUploadReentryExcelModel.class)
				.metaDataId(FileConvertInput.FileMetaId.builder().fileId(in.getFileId()).fileNos(Arrays.asList(in.getFileNo())).build())
				.option(option->option.setDataFormatter(new DefaultDataFormatter()))
				.build();
		List<RowInfo> converted = fileOperationManager.convert(converter);

		service.uploadMemberReentry(converted, in.getClcoId(), in.getYr());
	}

	@RequestMapping("/result")
	public BatchMemberReentryUploadResultModel result(@RequestBody BatchMemberUploadResultRequestModel in) {

		return service.getResult(in);
	}

	@RequestMapping("/remove")
	public void remove(@RequestBody List<BatchMemberUploadCustomerReentryModel> in) {

		service.remove(in);
	}

	@RequestMapping("/remove-all")
	public void removeAll(@RequestBody BatchMemberUploadReentryErrorRequestModel in) {

		service.removeAll(in);
	}

	@RequestMapping("/init")
	public void init(@RequestBody BatchMemberUploadResultRequestModel in) {

		service.init(in);
	}

	@RequestMapping("/regist")
	public void regist(@RequestBody BatchMemberUploadResultRequestModel in) {

		service.regist(in);
	}

	@RequestMapping("/error-list")
	public RestResult<List<BatchMemberUploadCustomerReentryModel>> errorList(@RequestBody BatchMemberUploadReentryErrorRequestModel in) {

		return GchcRestResult.of(service.getErrorList(in));
	}

	@RequestMapping("/download-excel")
	public ResponseEntity<?> downloadExcelReentry(@RequestBody BatchMemberUploadReentryDownloadRequestModel in, HttpServletRequest request, HttpServletResponse response) {

		if( "9".equals(in.getResultFlag()) )
			return convertExcel(service.getTestReentryCustomerList(in), request, response);
		return convertExcel(service.selectReentryCustomerTmpExcelList(in), request, response);
	}

	@RequestMapping("/download-excel-list")
	public ResponseEntity<?> downloadExcelReentry(@RequestBody List<BatchMemberUploadCustomerReentryModel> in, HttpServletRequest request, HttpServletResponse response) {

		return convertExcel(service.selectReentryCustomerTmpExcelList(in), request, response);
	}

	ResponseEntity<?> convertExcel(List<BatchUploadReentryExcelModel> targets, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		for(int i=0;i<targets.size();i++) {
			Map<String, Object> map = new TreeMap<>();
			BatchUploadReentryExcelModel exMap = targets.get(i); // 리스트 셋팅

			map.put("col1", exMap.getAempNm()); // 이름
			map.put("col2", exMap.getAempBrdt()); // 생년월일
			map.put("col3", exMap.getExistAempId()); // 기존사번
			map.put("col4", exMap.getNewAempId()); // 신규사번
			map.put("col5", exMap.getPkgNm()); // 검진패키지 pkgNm
			map.put("col6", exMap.getCorpSpfnVal()); // 지원금 corpSpfnVal
			map.put("col7", exMap.getAempReenRegSeq()); // MemberID
			map.put("col8", exMap.getUpldErrVal());

			list.add(map);
		}

		if( list.size() > 0 && ObjectUtils.isNotEmpty(list.get(0).get("col1")) ) {

			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "고객-재입사";
			String cont = "임직원이름, 임직원생년월일, 기존사번, 신규사번, 패키지명, 회사지원금, MemberID, 오류내용";
			customerReentryXlsHist(tagretUrl, list.size(), pageNm, cont);
			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col3").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "임직원이름"),
				new UstraExcelCellInfoModel("col2"	, "임직원생년월일"),
				new UstraExcelCellInfoModel("col3"	, "기존사번"),
				new UstraExcelCellInfoModel("col4"	, "신규사번"),
				new UstraExcelCellInfoModel("col5"	, "패키지명"),
				new UstraExcelCellInfoModel("col6"	, "회사지원금"),
				new UstraExcelCellInfoModel("col7"	, "MemberID"),
				new UstraExcelCellInfoModel("col8"	, "오류내용")
			))
			.withCellGenerator(new BatchUploadCellGenerator(Arrays.asList(
				"임직원이름",
				"기존사번",
				"신규사번",
				"패키지명",
				"회사지원금"
			)))
			.withSheetName("고객(재입사)");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "고객(재입사)", request, response)
			.build());
	}

	private void customerReentryXlsHist(String url, int listSize, String pageNm, String cont) {
		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		histModel.setDwldPageUrl(url);
		histModel.setInnfVwCnt(listSize);
		histModel.setDwldPageNm(pageNm);
		if(cont.length() > 200) cont = cont.substring(0, 200);
		histModel.setDwldCont(cont);
		batchXlsHistProcess.insertHistXlsDownload(histModel);
	}
}
