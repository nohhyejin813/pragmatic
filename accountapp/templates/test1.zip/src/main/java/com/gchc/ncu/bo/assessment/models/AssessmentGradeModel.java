package com.gchc.ncu.bo.assessment.models;

import java.util.Date;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentGradeModel extends UstraManagementBaseModel {
	/* T_CUI_SCR_GRD_BSC [헬스케어_검진기관점수등급기본] */

	private String		yr;			// 년도
	private int			cuiScrGrdId;// 검진기관점수등급아이디
	private String		cuiGrdCd;	// 검진기관등급코드
	private int			topScr;		// 최고점수
	private int			lwstScr;	// 최하점수
	private boolean		delYn;		// 삭제여부
	private String		frstRegrId;	// 최초등록자아이디
}
