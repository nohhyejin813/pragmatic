package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

import java.text.MessageFormat;

@Getter
public enum CapaErrorCode {

    NORMAL("정상"),

    PAST("{0} 예약일이 불가능한 일정입니다."),

    HOLIDAY("{0} 예약일이 휴일&대체공휴일 입니다."),

    BASIC("{0} 예약일이 일일캐파 마감입니다."),

    ITEM("{0} 예약일이 {1} 마감입니다."),

    BOTH("{0} 예약일이 일일캐파 및 {1} 마감입니다.")
    ;

    String message;

    String itmNm;

    CapaErrorCode(String message) {
        this.message = message;
    }

    public void setItemNm(String itmNm) {

        this.itmNm = itmNm;
    }

    public String getMessage(String tgtr) {

        return MessageFormat.format(this.message, tgtr, this.itmNm);
    }
}
