package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;

import com.gchc.ncu.bo.care.models.DssHzrdCausGuidBscModel;
import com.gchc.ncu.bo.care.models.DssHzrdRecsDtlModel;
import com.gchc.ncu.bo.care.models.DssHzrdRecsModel;
import com.gchc.ncu.bo.care.models.MbrHthAgRecsModel;
import com.gchc.ncu.bo.care.repository.HealthAgeRepository;
import com.gchc.ncu.bo.care.vo.HealthAgeVo;

@Service
@RequiredArgsConstructor
public class HealthAgeService {

	private final HealthAgeRepository repository;

	public List<MbrHthAgRecsModel> getHealthAgeHisList(HealthAgeVo in, boolean masking) {
		List<MbrHthAgRecsModel> list = repository.selectHealthAgeHisList(in);

		if (masking) {
			UstraMaskingUtils.maskTextFields(list);
		}

		return list;
	}

	public List<DssHzrdRecsModel> getDiseaseRiskList(HealthAgeVo in, boolean masking) {
		List<DssHzrdRecsModel> list = repository.selectDiseaseRiskList(in);

		if (masking) {
			UstraMaskingUtils.maskTextFields(list);
		}

		return list;
	}

	public List<DssHzrdRecsDtlModel> getDiseaseRiskDtl(HealthAgeVo in) {
		return repository.selectDiseaseRiskDtl(in);
	}

	public List<DssHzrdCausGuidBscModel> getBaseInfoList() {
		return repository.selectBaseInfoList();
	}

	@Transactional
	public int updateBaseInfo(List<DssHzrdCausGuidBscModel> list) {
		int result = 0;
		DssHzrdCausGuidBscModel updateTemp = null;

		if (list != null) {
			for (DssHzrdCausGuidBscModel model : list) {
				updateTemp = new DssHzrdCausGuidBscModel();

				updateTemp.setDssHzrdCausCd(model.getDssHzrdCausCd());

				for (int i=1; i<4; i++) {
					String cont = "";

					if (i == 1) {
						cont = model.getDwLower();
					} else if (i == 2) {
						cont = model.getDwWarning();
					} else {
						cont = model.getDwHigher();
					}

					updateTemp.setDssHzrdCausCont(cont);
					updateTemp.setDssHzrdCausBscVal(i);

					if(cont != "" ) result = repository.updateBaseInfo(updateTemp);
				}

			}
		}

		return result;
	}

}
