package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MusculoSkeletalStatsVo extends UstraManagementBaseModel {

	private String year;
	private Integer clcoId;
	private Integer bsplId;
	private String joinCd;

	private String searchItemType;
	private String searchType;

}
