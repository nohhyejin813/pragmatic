package com.gchc.ncu.bo.batchupload.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.batchupload.models.BatchCenterVaccineUploadModel;
import com.gchc.ncu.bo.batchupload.models.CenterVaccineUploadRequestModel;
import com.gchc.ncu.bo.batchupload.models.CenterVaccineUploadResultModel;
import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.batchupload.service.BatchCenterUploadService;

@RestController
@RequestMapping("/api/bo/batchupload/center")
public class BatchCenterUploadController {

	@Autowired private BatchCenterUploadService service;

	@Autowired private FileOperationManager fileOperationManager;

	@Autowired private BatchXlsHistProcess batchXlsHistProcess;

	@PostMapping("/validate")
	void validate(@RequestBody CenterVaccineUploadRequestModel in) {

		service.validateCenterVaccine(in);
	}

	@PostMapping("/result")
	CenterVaccineUploadResultModel getResult(@RequestBody CenterVaccineUploadRequestModel in) {

		return service.getResult(in);
	}

	@PostMapping("/error-list")
	RestResult<List<BatchCenterVaccineUploadModel>> getErrorList(@RequestBody CenterVaccineUploadRequestModel in) {

		return GchcRestResult.of(service.getErrorList(in));
	}

	@PostMapping("/download-excel-list")
	ResponseEntity<?> downloadExcelList(@RequestBody List<BatchCenterVaccineUploadModel> in, HttpServletRequest request, HttpServletResponse response) {

		return convertExcel(service.getErrorList(in), request, response);
	}

	@PostMapping("/download-excel")
	ResponseEntity<?> downloadExcel(@RequestBody CenterVaccineUploadRequestModel in, HttpServletRequest request, HttpServletResponse response) {

		return convertExcel(service.getErrorListForExcel(in), request, response);
	}

	@PostMapping("/download-excel-test")
	ResponseEntity<?> downloadExcelTest(@RequestBody CenterVaccineUploadRequestModel in, HttpServletRequest request, HttpServletResponse response) {

		return convertExcel(service.getDownloadListForTest(in), request, response);
	}

	@PostMapping("/init")
	void init(@RequestBody CenterVaccineUploadRequestModel in) {

		service.init(in);
	}

	@PostMapping("/regist")
	void regist(@RequestBody CenterVaccineUploadRequestModel in) {

		service.regist(in);
	}

	@PostMapping("/remove")
	void remove(@RequestBody List<BatchCenterVaccineUploadModel> in) {

		service.remove(in);
	}

	@PostMapping("/remove-all")
	void removeAll(@RequestBody CenterVaccineUploadRequestModel in) {

		service.removeAll(in);
	}

	private ResponseEntity<?> convertExcel(List<BatchCenterVaccineUploadModel> targets, HttpServletRequest request,
		HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		for(int i=0;i<targets.size();i++) {
			Map<String, Object> map = new TreeMap<>();
			BatchCenterVaccineUploadModel exMap = targets.get(i); // 리스트 셋팅

			map.put("col1", exMap.getCuiNm());
			map.put("col2", exMap.getClcoNm());
			map.put("col3", exMap.getBsplNm());
			map.put("col4", exMap.getVcnNm());
			map.put("col5", exMap.getVcnAmt());
			map.put("col6", exMap.getVcnDcAmt());
			map.put("col7", exMap.getEtcMsgCont());
			map.put("col8", exMap.getCuiBlkVcnId());

			list.add(map);
		}

		String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
		String pageNm = "백신-검진기관 백신Lib";
		String cont = "검진센터명, 고객사명, 사업장명, 백신명, 백신 소비자가, 백신 할인가, 예약고객용 알림내용, VcnLibID";

		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		histModel.setDwldPageUrl(tagretUrl);
		histModel.setInnfVwCnt(list.size());
		histModel.setDwldPageNm(pageNm);
		histModel.setDwldCont(cont);
		batchXlsHistProcess.insertHistXlsDownload(histModel);


		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "검진센터명"),
				new UstraExcelCellInfoModel("col2"	, "고객사명"),
				new UstraExcelCellInfoModel("col3"	, "사업장명"),
				new UstraExcelCellInfoModel("col4"	, "백신명"),
				new UstraExcelCellInfoModel("col5"	, "백신 소비자가"),
				new UstraExcelCellInfoModel("col6"	, "백신 할인가"),
				new UstraExcelCellInfoModel("col7"	, "예약고객용 알림내용"),
				new UstraExcelCellInfoModel("col8"	, "VcnLibID")
			))
			.withCellGenerator(new BatchUploadCellGenerator(Arrays.asList(
					"검진센터명",
					"백신명",
					"백신 소비자가"
				)))
			.withSheetName("백신LIB등록");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "백신LIB등록", request, response)
			.build());
	}

}
