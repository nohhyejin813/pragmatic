package com.gchc.ncu.bo.assessment.service;

import java.util.List;

import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gsitm.ustra.java.core.cache.UstraCacheManagerSupport;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.gchc.ncu.bo.assessment.models.AssessmentModel;
import com.gchc.ncu.bo.assessment.models.SatisfactionDegreeModel;
import com.gchc.ncu.bo.assessment.repository.SatisfactionDegreeRepository;
import com.gchc.ncu.bo.comm.prototype.models.PrototypeModel;
import com.gchc.ncu.bo.comm.prototype.models.PrototypeModel.Criteria;
import com.gchc.ncu.bo.comm.util.GchcGridUtil;

import com.gsitm.ustra.java.data.domains.DefaultPaginationRequest;
import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.mybatis.proxy.MapperManager;
import com.gsitm.ustra.java.management.repositories.UstraBatchRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 프로토타입 Service
 *
 * @author gs_hykim@gchealthcare.com
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class SatisfactionDegreeService {

	@Autowired
	private SatisfactionDegreeRepository repository;

	public int getSatisfactionLastYear(){
		return repository.getSatisfactionLastYear();
	}

	public int[] getSatisfactionYears() {
		return repository.getSatisfactionYears();
	}

	public List<SatisfactionDegreeModel> getSatisfactionDegreeClcoList(int srchYr) {
		return repository.getSatisfactionDegreeClcoList(srchYr);
	}

	public List<SatisfactionDegreeModel> getSatisfactionDegreeCuiList(SatisfactionDegreeModel in) {
		return repository.getSatisfactionDegreeCuiList(in);
	}

	public List<SatisfactionDegreeModel> getSatisfactionDegreeList(SatisfactionDegreeModel in) {
		in.setOrderName(GchcGridUtil.getCamalToLarge(in.getOrderName()));
		PaginationRequest pr = in.toPaginationRequest();
		return repository.getSatisfactionDegreeList(in,pr);
	}

	public SatisfactionDegreeModel getSatisfactionDegree(SatisfactionDegreeModel in) {
		return repository.getSatisfactionDegree(in);
	}

	public List<SatisfactionDegreeModel> getSatisfactionDegreeCommentList(SatisfactionDegreeModel in) {
		return repository.getSatisfactionDegreeCommentList(in);
	}

	/**
	 * 만족도결과 엑셀처리 서비스(전체고객사)
	 * @param model 만족도결과 관련 모델
	 * @return 엑셀 workbook
	 */
	public Workbook getSatisfactionDegreeCommentAllExcel(SatisfactionDegreeModel model){
		List<SatisfactionDegreeModel> list = repository.getSatisfactionDegreeCommentAllList(model);

		if (ObjectUtils.isEmpty(list)) {
			return null;
		}

		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet();
		int firstHeaderIdx = 0;
		XSSFRow headerRowFirst = sheet.createRow(firstHeaderIdx);
		final int MARGIN_ROW_WITH_HEADER = 4;
		final int MARGIN_CELL = 0;

		XSSFCellStyle headerCellStyle = this.createHeaderCellStyle(wb);

		// 헤더
		createCell(wb, headerRowFirst, MARGIN_CELL +  0, "No"      , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  1, "검진기관명", headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  2, "고객사명" , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  3, "친절도"   , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  4, "신뢰도"   , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  5, "시설"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  6, "검사항목"  , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  7, "재방문의사", headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  8, "의견"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  9, "성명"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL + 10, "사번"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL + 11, "등록일"   , headerCellStyle);

		XSSFCellStyle cellStyle = wb.createCellStyle();
		cellStyle = list.size() > 4900 ? null : cellStyle;
		int dataRowIndex = headerRowFirst.getRowNum() + 1;
		/* 65000개 넘어갈수 없음 */
		for(int i = 0; i < list.size() /* && i < 4900 */; i++) {
			XSSFRow dataRow = sheet.createRow(dataRowIndex);
			SatisfactionDegreeModel sfd = list.get(i);
			createCell(wb, dataRow, MARGIN_CELL +  0, sfd.getRowNum        (), cellStyle); // No
			createCell(wb, dataRow, MARGIN_CELL +  1, sfd.getCuiNm         (), cellStyle); // 검진기관명
			createCell(wb, dataRow, MARGIN_CELL +  2, sfd.getClcoNm        (), cellStyle); // 고객사명
			createCell(wb, dataRow, MARGIN_CELL +  3, sfd.getKndnStdgScr   (), cellStyle); // 친절도
			createCell(wb, dataRow, MARGIN_CELL +  4, sfd.getTrsStdgScr    (), cellStyle); // 신뢰도
			createCell(wb, dataRow, MARGIN_CELL +  5, sfd.getFcltStdgScr   (), cellStyle); // 시설
			createCell(wb, dataRow, MARGIN_CELL +  6, sfd.getExamItmStdgScr(), cellStyle); // 검사항목
			createCell(wb, dataRow, MARGIN_CELL +  7, sfd.getRcmnYn        (), cellStyle); // 재방문의사
			createCell(wb, dataRow, MARGIN_CELL +  8, sfd.getOpinCont      (), cellStyle); // 의견
			createCell(wb, dataRow, MARGIN_CELL +  9, sfd.getRealNm        (), cellStyle); // 성명
			createCell(wb, dataRow, MARGIN_CELL + 10, sfd.getEmpno         (), cellStyle); // 사번
			createCell(wb, dataRow, MARGIN_CELL + 11, sfd.getFrstRegDtm    (), cellStyle); // 등록일

			dataRowIndex++;
		}

		return wb;
//
//		return null;
	}

	/**
	 * 만족도결과 엑셀처리 서비스
	 * @param model 만족도결과 관련 모델
	 * @return 엑셀 workbook
	 */
	public Workbook getSatisfactionDegreeCommentExcel(SatisfactionDegreeModel model){
		List<SatisfactionDegreeModel> list = repository.getSatisfactionDegreeCommentList(model);

		if (ObjectUtils.isEmpty(list)) {
			return null;
		}

		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet();
		int firstHeaderIdx = 0;
		XSSFRow headerRowFirst = sheet.createRow(firstHeaderIdx);
		final int MARGIN_ROW_WITH_HEADER = 4;
		final int MARGIN_CELL = 0;

		XSSFCellStyle headerCellStyle = this.createHeaderCellStyle(wb);

		// 헤더
		createCell(wb, headerRowFirst, MARGIN_CELL +  0, "No"      , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  1, "검진기관명", headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  2, "고객사명" , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  3, "친절도"   , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  4, "신뢰도"   , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  5, "시설"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  6, "검사항목"  , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  7, "재방문의사", headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  8, "의견"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL +  9, "성명"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL + 10, "사번"     , headerCellStyle);
		createCell(wb, headerRowFirst, MARGIN_CELL + 11, "등록일"   , headerCellStyle);

		XSSFCellStyle cellStyle = wb.createCellStyle();
		cellStyle = list.size() > 4900 ? null : cellStyle;
		int dataRowIndex = headerRowFirst.getRowNum() + 1;
		/* 65000개 넘어갈수 없음 */
		for(int i = 0; i < list.size() /* && i < 4900 */; i++) {
			XSSFRow dataRow = sheet.createRow(dataRowIndex);
			SatisfactionDegreeModel sfd = list.get(i);
			createCell(wb, dataRow, MARGIN_CELL +  0, sfd.getRowNum        (), cellStyle); // No
			createCell(wb, dataRow, MARGIN_CELL +  1, sfd.getCuiNm         (), cellStyle); // 검진기관명
			createCell(wb, dataRow, MARGIN_CELL +  2, sfd.getClcoNm        (), cellStyle); // 고객사명
			createCell(wb, dataRow, MARGIN_CELL +  3, sfd.getKndnStdgScr   (), cellStyle); // 친절도
			createCell(wb, dataRow, MARGIN_CELL +  4, sfd.getTrsStdgScr    (), cellStyle); // 신뢰도
			createCell(wb, dataRow, MARGIN_CELL +  5, sfd.getFcltStdgScr   (), cellStyle); // 시설
			createCell(wb, dataRow, MARGIN_CELL +  6, sfd.getExamItmStdgScr(), cellStyle); // 검사항목
			createCell(wb, dataRow, MARGIN_CELL +  7, sfd.getRcmnYn        (), cellStyle); // 재방문의사
			createCell(wb, dataRow, MARGIN_CELL +  8, sfd.getOpinCont      (), cellStyle); // 의견
			createCell(wb, dataRow, MARGIN_CELL +  9, sfd.getRealNm        (), cellStyle); // 성명
			createCell(wb, dataRow, MARGIN_CELL + 10, sfd.getEmpno         (), cellStyle); // 사번
			createCell(wb, dataRow, MARGIN_CELL + 11, sfd.getFrstRegDtm    (), cellStyle); // 등록일

			dataRowIndex++;
		}

		return wb;
//
//		return null;
	}


	private XSSFColor getXSSFColorObj(String rgbCode) {
		if (!StringUtils.hasText(rgbCode)) {
			LOGGER.error("엑셀용 색상 객체 생성에 실패했습니다.");
			rgbCode = "FFFFFF";
		}

		byte[] rgbByte = null;
		try {
			rgbByte = Hex.decodeHex(rgbCode);
		} catch (DecoderException e) {
			LOGGER.error("엑셀용 색상 객체 설정 중 코드값 오류로 생성에 실패했습니다.");
			return null;
		} catch (Exception ex) {
			LOGGER.error("엑셀용 색상 객체 설정 중 알 수 없는 에러가 발생했습니다.\n%s", ex.getMessage());
			return null;
		}

		return new XSSFColor(rgbByte, null);
	}

	private XSSFCellStyle createHeaderCellStyle(XSSFWorkbook wb) {
		XSSFCellStyle customDataCellStyle = null;
		customDataCellStyle = (XSSFCellStyle) wb.createCellStyle();
		customDataCellStyle.setWrapText(true);
		this.setCommonCellStyle(wb, customDataCellStyle);
		XSSFColor totalColor = this.getXSSFColorObj("F7F7F7");
		XSSFColor headerBorderColor = this.getXSSFColorObj("707070");

		customDataCellStyle.setFillForegroundColor(totalColor);
		customDataCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		customDataCellStyle.setBorderRight(BorderStyle.THIN);
		customDataCellStyle.setBorderLeft(BorderStyle.THIN);
		customDataCellStyle.setBorderTop(BorderStyle.MEDIUM);
		customDataCellStyle.setBorderBottom(BorderStyle.MEDIUM);

		customDataCellStyle.setTopBorderColor(headerBorderColor);
		customDataCellStyle.setBottomBorderColor(headerBorderColor);

		return customDataCellStyle;
	}

	/**
	 * 공통 CellStyle
	 * @param wb
	 * @param cellStyle
	 */
	private void setCommonCellStyle(XSSFWorkbook wb, CellStyle cellStyle) {
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

		cellStyle.setBorderRight(BorderStyle.THIN);
		cellStyle.setBorderLeft(BorderStyle.THIN);
		cellStyle.setBorderTop(BorderStyle.THIN);
		cellStyle.setBorderBottom(BorderStyle.THIN);

		DataFormat format = wb.createDataFormat();
		cellStyle.setDataFormat(format.getFormat("#,###.##"));
	}

	/**
	 * Cell 등록
	 * @param row
	 * @param colIndex
	 * @param cellValue
	 */
	private void createCell(XSSFWorkbook wb, XSSFRow row, int colIndex, Object cellValue,
							XSSFCellStyle customCellStyle) {
		XSSFCell cell = row.createCell(colIndex);
		XSSFCellStyle cellStyle = null;

		if (customCellStyle != null) {
			cellStyle = customCellStyle;
		}

		if( cellValue instanceof String){
			cell.setCellValue((String)cellValue);
		}
		else
		if( cellValue instanceof Integer){
			cell.setCellValue((Integer)cellValue);
		}
		else
		if( cellValue instanceof Long){
			cell.setCellValue((Long)cellValue);
		}
		else
		if( cellValue instanceof Double){
			cell.setCellValue((Double)cellValue);
		}
		else
		{
			cell.setCellValue(cellValue.toString());
		}

		cell.setCellStyle(cellStyle);
	}

	public int deleteComment(SatisfactionDegreeModel in) {
		return repository.deleteComment(in);
	}
}
