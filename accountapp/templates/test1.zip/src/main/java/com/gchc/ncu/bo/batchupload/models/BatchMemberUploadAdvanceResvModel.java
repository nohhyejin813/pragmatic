package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * @FileName : BatchMemberUploadAdvanceResvModel.java
 * @date : 2022. 06. 10
 * @author : 이광희
 * @프로그램 설명 : 선예약 일괄업로드 Service
 * @변경이력 :
 */

@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
public class BatchMemberUploadAdvanceResvModel extends NcuModel {

	@ApiModelProperty(value="고객사아이디 NN")
	private Integer clcoId;
	@ApiModelProperty(value="년도 NN")
	private Integer yr;


	/*임직원-필수정보*/
	@ApiModelProperty(value="고객사코드")
	private String clcoCode;
	@ApiModelProperty(value="[중복체크] 임직원이름")
	private String aempNm;
	private String corpSpfnVal;
	@ApiModelProperty(value="임직원 검진등급명")
	private String aempCuGrdNm;
	private String aempVcnGrdNm;
	@ApiModelProperty(value="임직원 검진등급 ID")
	private Integer aempCuGrdId;
	private Integer aempVcnGrdId;
	@ApiModelProperty(value="[중복체크] 임직원생년월일")
	private String aempBrdt;
	@ApiModelProperty(value="임직원성별코드")
	private String aempSexCd;
	@ApiModelProperty(value="[중복체크] 임직원핸드폰번호")
	private String mblNo;


	/*임직원-선예약정보*/
	@ApiModelProperty(value="검진기관명")
	private String cuiNm;
	private Integer cuiId;
	@ApiModelProperty(value="패키지명")
	private String pkgNm;
	@ApiModelProperty(value="예약신청일1차")
	private String tn1ResvApplDt;
	@ApiModelProperty(value="예약신청시간1차")
	private String tn1ResvTmcRngVal;
	@ApiModelProperty(value="예약신청일2차")
	private String tn2ResvApplDt;
	@ApiModelProperty(value="예약신청시간2차")
	private String tn2ResvTmcRngVal;
	@ApiModelProperty(value="패키지항목명")
	private String pkgTyNm;
	private Integer pkgTyId;


	/*임직원-부가정보*/
	@ApiModelProperty(value="임직원이메일주소")
	private String emlAdr;
	@ApiModelProperty(value="임원여부(Y/N)")
	private Integer excuYn;
	@ApiModelProperty(value="건강보험공단지원대상여부(Y/N)")
	private Integer nhicSuptTgtYn;
	@ApiModelProperty(value="특수검진대상여부(Y/N)")
	private Integer spcuTgtYn;
	@ApiModelProperty(value="특수물질(1차)")
	private String extrMttrNm1;
	@ApiModelProperty(value="특수물질(2차)")
	private String extrMttrNm2;
	@ApiModelProperty(value="부서명 기본값 '미등록'")
	private String deptNm1;
	private String deptNm2;
	private String deptNm3;
	@ApiModelProperty(value="직급명 기본값 '미등록'")
	private String jbgdNm;
	@ApiModelProperty(value="사번")
	private String aempId;
	@ApiModelProperty(value="직장전화")
	private String wrplTlno;
	@ApiModelProperty(value="직장우편번호")
	private String wrplZpcd;
	@ApiModelProperty(value="직장기본주소")
	private String wrplBscAdr;
	@ApiModelProperty(value="직장상세주소")
	private String wrplDtlAdr;
	@ApiModelProperty(value="자택전화번호")
	private String hsTlno;
	@ApiModelProperty(value="자택우편번호")
	private String hsZpcd;
	@ApiModelProperty(value="자택기본주소")
	private String hsBscAdr;
	@ApiModelProperty(value="자택상세주소")
	private String hsDtlAdr;
	@ApiModelProperty(value="입사일")
	private String encmDt;
	@ApiModelProperty(value="임직원비고")
	private String aempCmt;


	/*가족-기본정보*/
	@ApiModelProperty(value="가족이름")
	private String spsrNm;
	@ApiModelProperty(value="가족검진등급")
	private String spsrCuGrdNm;
	@ApiModelProperty(value="가족등급 ID")
	private Integer spsrCuGrdId;
	@ApiModelProperty(value="가족백신등급")
	private String spsrVcnGrdNm;
	private Integer spsrVcnGrdId;
	@ApiModelProperty(value="가족생년월일")
	private String spsrBrdt;
	@ApiModelProperty(value="가족성별코드")
	private String spsrSexCd;
	@ApiModelProperty(value="가족회사지원금")
	private String spsrCorpSpfn;
	@ApiModelProperty(value="가족연락처")
	private String spsrNo;
	@ApiModelProperty(value="가족비고")
	private String spsrCmt;


	/*가족-선예약정보*/
	@ApiModelProperty(value="가족검진기관명")
	private String spsrCuiNm;
	private Integer spsrCuiId;
	@ApiModelProperty(value="가족패키지명")
	private String spsrPkgNm;
	@ApiModelProperty(value="가족예약신청일1차")
	private String tn1SpsrResvApplDt;
	@ApiModelProperty(value="가족예약신청시간1차")
	private String tn1SpsrResvTmcRngVal;
	@ApiModelProperty(value="가족예약신청일2차")
	private String tn2SpsrResvApplDt;
	@ApiModelProperty(value="가족예약신청시간2차")
	private String tn2SpsrResvTmcRngVal;
	@ApiModelProperty(value="가족패키지항목명")
	private String spsrPkgTyNm;
	private Integer spsrPkgTyId;

	@ApiModelProperty(value="사업장명")
	private String bsplNm;
	@ApiModelProperty(value="사업장 ID")
	private Integer bsplId;
	@ApiModelProperty(value="임직원등록일련번호 NN")
	private Integer aempRegSeq;
	@ApiModelProperty(value="업로드상태값 기본값 0")
	private Integer upldStVal;
	@ApiModelProperty(value="업로드오류값")
	private String upldErrVal;
	@ApiModelProperty(value="관리자 ID NN")
	private Integer mngrId;

	// rollback으로 인한 주석처리
	private String athoKvl;


	/*임직원-기등록정보*/
	@ApiModelProperty(value="연관임직원 이름")
	private String oldAempNm;
	@ApiModelProperty(value="연관임직원 사번")
	private String oldAempId;
	@ApiModelProperty(value="연관임직원 생년월일")
	private String oldAempBrdt;
	@ApiModelProperty(value="연관임직원 성별코드")
	private String oldAempSexCd;

	private Integer regTyVal;

	List<BatchUploadAdvanceResvSelectItemModel> slctItmList;
	List<BatchUploadAdvanceResvSelectItemModel> spsrSlctItmList;

	List<String> slctItmHdrList;
}
