package com.gchc.ncu.bo.batchupload.enu;

public enum PackageItemStatus {

	NORMAL(""),

	INVALID_RULE("구분자는 0~2개 존재해야 합니다."),

	INVALID_FORMAT_1_1("첫 번째 항목은 기본/선택검사 정보만 가능"),

	INVALID_FORMAT_1_2("첫 번째 항목은 기본/선택검사 정보만 가능"),

	INVALID_FORMAT_2_2("구분자가 1개면 두번째 항목은 성별이나 금액만 가능"),

	INVALID_FORMAT_1_3("첫 번째 항목은 기본/선택검사 정보만 가능"),

	INVALID_FORMAT_2_3("구분자가 2개면 두번째 항목은 성별만 가능"),

	INVALID_FORMAT_3_3("구분자가 2개면 세번째 항목은 금액만 가능"),

	;

	String cont;

	PackageItemStatus(String cont) {

		this.cont = cont;
	}

	public String getCont() {

		return this.cont;
	}
}
