package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.ncu.bo.care.models.ActPgmBscModel;
import com.gchc.ncu.bo.care.models.ActPgmDtlModel;
import com.gchc.ncu.bo.care.repository.ActivityProgramRepository;
import com.gchc.ncu.bo.care.vo.ActivityProgramVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ActivityProgramService {

	private final ActivityProgramRepository programRepository;

	public List<ActPgmBscModel> getProgramList(ActivityProgramVo criteria) {
		return programRepository.selectProgramList(criteria);
	}

	public ActPgmBscModel getProgramDetail(ActPgmBscModel criteria) {
		return programRepository.selectProgramDetail(criteria);
	}

	@Transactional
	public void saveProgram(ActPgmBscModel model) {
		if (StringUtils.isEmpty(model.getActPgmId())) {
			programRepository.insertProgram(model);
		} else {
			programRepository.updateProgram(model);
		}
	}

	@Transactional
	public void deleteProgram(List<ActPgmBscModel> list) {
		if (list != null) {
			for (ActPgmBscModel model : list) {
				programRepository.deleteProgramMissionByActPgmId(model.getActPgmId());
				programRepository.deleteProgram(model);
			}
		}
	}

	public List<ActPgmDtlModel> getProgramMissionList(ActivityProgramVo criteria) {
		return programRepository.selectProgramMissionList(criteria);
	}

	public ActPgmDtlModel getProgramMissionDetail(ActPgmDtlModel criteria) {
		return programRepository.selectProgramMissionDetail(criteria);
	}

	@Transactional
	public void saveProgramMission(ActPgmDtlModel model) {
		if (StringUtils.isEmpty(getProgramMissionDetail(model))) {
			programRepository.insertProgramMission(model);
		} else {
			programRepository.updateProgramMission(model);
		}
	}

	@Transactional
	public void deleteProgramMission(List<ActPgmDtlModel> list) {
		if (list != null) {
			for (ActPgmDtlModel model : list) {
				programRepository.deleteProgramMission(model);
			}
		}
	}

}
