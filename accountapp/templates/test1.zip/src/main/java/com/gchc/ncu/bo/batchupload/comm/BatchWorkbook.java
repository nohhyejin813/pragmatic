package com.gchc.ncu.bo.batchupload.comm;

import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.util.XMLHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.model.SharedStrings;
import org.apache.poi.xssf.model.Styles;
import org.apache.poi.xssf.model.StylesTable;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class BatchWorkbook {

	OPCPackage opc;
	XSSFReader reader;

	Map<String, InputStream> sheetInputStreams;

	public BatchWorkbook(InputStream is) {

		loadSheetInfo(is);
	}

	public boolean isLoaded() {

		return opc != null && reader != null && ObjectUtils.isNotEmpty(sheetInputStreams);
	}

	public boolean loadSheetInfo(InputStream is) {

		try {

			opc = OPCPackage.open(is);
			reader = new XSSFReader(opc);

			sheetInputStreams = new HashMap<>();

			XSSFReader.SheetIterator sheetIterator = (XSSFReader.SheetIterator)reader.getSheetsData();
			while( sheetIterator.hasNext() ) {

				InputStream data = sheetIterator.next();
				sheetInputStreams.put(sheetIterator.getSheetName(), data);
			}
		}
		// SPARROW 1490491 IMPROPER_CHECK_FOR_UNUSUAL_OR_EXCEPTIONAL_CONDITION
		catch (OpenXML4JException | IOException e ) {

			LOGGER.error(ExceptionUtils.getStackTrace(e));
			return false;
		}

		return true;
	}

	public int getSheetCount() {

		if( !isLoaded() || ObjectUtils.isEmpty(sheetInputStreams) )
			return 0;

		return sheetInputStreams.size();
	}

	public List<String> getSheetNames() {

		if( !isLoaded() )
			return null;
		return sheetInputStreams.keySet().stream().collect(Collectors.toList());
	}

	public String removeSheet(String sheetName) {

		if( !isLoaded() )
			return "";

		if( sheetInputStreams.containsKey(sheetName) ) {
			sheetInputStreams.remove(sheetName);
			return sheetName;
		}

		return "";
	}

	public List<RowInfo> readSheet(String sheetName) {

		if( !isLoaded() )
			return null;

		try {

			StylesTable styles = reader.getStylesTable();
			ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(opc);
			InputSource source = new InputSource(sheetInputStreams.get(sheetName));

			BatchExcelParser parser = new BatchExcelParser();
			ContentHandler handler = createReadHandler(styles, strings, parser, false, null);

			XMLReader xml = XMLHelper.newXMLReader();
			xml.setContentHandler(handler);
			xml.parse(source);

			return parser.getRows();
		}
		// SPARROW 1490493 IMPROPER_CHECK_FOR_UNUSUAL_OR_EXCEPTIONAL_CONDITION
		catch(InvalidFormatException | SAXException | ParserConfigurationException | IOException e ) {

			LOGGER.error(ExceptionUtils.getStackTrace(e));
			return null;
		}
	}

	private static ContentHandler createReadHandler(Styles styles,
        SharedStrings strings,
        SheetContentsHandler sheetContentsHandler,
        boolean formulasNotResults,
        DataFormatter dataFormatter) {

		if (dataFormatter == null) {
			dataFormatter = new DataFormatter();
		}

		ContentHandler handler = new XSSFSheetXMLHandler(styles, strings, sheetContentsHandler, dataFormatter, formulasNotResults);

		return handler;
	}
}
