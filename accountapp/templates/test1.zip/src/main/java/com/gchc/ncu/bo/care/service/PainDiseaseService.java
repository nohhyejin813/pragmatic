package com.gchc.ncu.bo.care.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.NrsnDssAgDtlModel;
import com.gchc.ncu.bo.care.models.NrsnDssBscModel;
import com.gchc.ncu.bo.care.models.NrsnDssExamRltnModel;
import com.gchc.ncu.bo.care.models.NrsnDssMjrDssRltnModel;
import com.gchc.ncu.bo.care.repository.PainDiseaseEpidemicRepository;
import com.gchc.ncu.bo.care.repository.PainDiseaseRepository;
import com.gchc.ncu.bo.care.vo.PainDiseaseVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PainDiseaseService {

	private final PainDiseaseRepository painDiseaseRepository;
	private final PainDiseaseEpidemicRepository painDiseaseEpidemicRepository;

	public List<NrsnDssBscModel> getPainDiseaseList(PainDiseaseVo criteria) {
		return painDiseaseRepository.selectPainDiseaseList(criteria);
	}

	public NrsnDssBscModel getPainDiseaseDetail(NrsnDssBscModel criteria) {
		return painDiseaseRepository.selectPainDiseaseDetail(criteria);
	}

	@Transactional
	public void savePainDisease(@Valid NrsnDssBscModel model) {
		if (StringUtils.isEmpty(model.getNrsnDssId())) {
			painDiseaseRepository.insertPainDisease(model);
		} else {
			painDiseaseRepository.updatePainDisease(model);
		}
	}

	@Transactional
	public void deletePainDisease(List<NrsnDssBscModel> list) {
		if (list != null) {
			for (NrsnDssBscModel model : list) {
				if (painDiseaseRepository.selectUsedPainDiseaseCount(model) > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "이미 사용 중인 항목입니다.[" + model.getExpoDssNm() + "]");
				}

				int nrsnDssId = model.getNrsnDssId();

				deletePainDiseaseAge(nrsnDssId);
				deletePainDiseaseDept(nrsnDssId);
				deletePainDiseaseMjr(nrsnDssId);
				painDiseaseEpidemicRepository.deletePainDiseaseEpidemicMonth(nrsnDssId);

				painDiseaseRepository.deletePainDisease(nrsnDssId);
			}
		}
	}

	public List<NrsnDssAgDtlModel> getPainDiseaseAgeDetail(NrsnDssAgDtlModel criteria) {
		return painDiseaseRepository.selectPainDiseaseAgeList(criteria);
	}

	@Transactional
	public void savePainDiseaseAge(int nrsnDssId, @Valid List<NrsnDssAgDtlModel> list) {
		deletePainDiseaseAge(nrsnDssId);

		if (list != null) {
			for (NrsnDssAgDtlModel model : list) {
				painDiseaseRepository.insertPainDiseaseAge(model);
			}
		}
	}

	protected void deletePainDiseaseAge(int nrsnDssId) {
		painDiseaseRepository.deletePainDiseaseAge(nrsnDssId);
	}


	public List<NrsnDssExamRltnModel> getPainDiseaseDeptDetail(NrsnDssExamRltnModel criteria) {
		return painDiseaseRepository.selectPainDiseaseDeptList(criteria);
	}

	@Transactional
	public void savePainDiseaseDept(int nrsnDssId, @Valid List<NrsnDssExamRltnModel> list) {
		deletePainDiseaseDept(nrsnDssId);

		if (list != null) {
			for (NrsnDssExamRltnModel model : list) {
				painDiseaseRepository.insertPainDiseaseDept(model);
			}
		}
	}

	protected void deletePainDiseaseDept(int nrsnDssId) {
		painDiseaseRepository.deletePainDiseaseDept(nrsnDssId);
	}

	public List<NrsnDssMjrDssRltnModel> getPainDiseaseMjrDetail(NrsnDssMjrDssRltnModel criteria) {
		return painDiseaseRepository.selectPainDiseaseMjrList(criteria);
	}

	@Transactional
	public void savePainDiseaseMjr(int nrsnDssId, @Valid List<NrsnDssMjrDssRltnModel> list) {
		deletePainDiseaseMjr(nrsnDssId);

		if (list != null) {
			for (NrsnDssMjrDssRltnModel model : list) {
				painDiseaseRepository.insertPainDiseaseMjr(model);
			}
		}
	}

	protected void deletePainDiseaseMjr(int nrsnDssId) {
		painDiseaseRepository.deletePainDiseaseMjr(nrsnDssId);
	}

}
