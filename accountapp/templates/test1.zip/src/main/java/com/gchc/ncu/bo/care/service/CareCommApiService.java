package com.gchc.ncu.bo.care.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.gchc.common.constant.Channel;
import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.message.model.MessageUnion;
import com.gchc.common.rest.client.RestClientTemplate;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gsitm.ustra.java.core.utils.ApplicationContextProvider;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;
import com.gsitm.ustra.java.mvc.utils.UstraWebUtils;
import com.gsitm.ustra.java.security.authentication.UstraAuthenticationManager;

@Service
public class CareCommApiService extends RestClientTemplate {

	@Value("${gchc.api.common}")
    private String commonEndpoint;

	protected Map<String, Object> getParams() {
		UstraAuthenticationManager manager = ApplicationContextProvider.getBeanSafety(UstraAuthenticationManager.class);

		Map<String, Object> params = new HashMap<>();

		params.put("procUId", manager.getAuthentication().getName());
		params.put("procUType", "1");

		return params;
	}

	private RestResult<Integer> callApiMessageAutoInsert(MessageUnion messageUnion) {
		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Integer>>() {})
				.appendHeader("channel-code", Channel.API_GIA_CHANNEL)
				.parameter(messageUnion)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/message/message-insert-auto-send").build().toUri())
				.method(HttpMethod.POST)
				.bodyRequest(true)
				.build());
	}

	public boolean sendMessage(MessageUnion msgUnion, String messageType, String title, String content, String reservedTime,  String... mobileNos) {
		String sUid = GchcJwtUtil.getUserId();

		msgUnion.setSndUid(0);
		msgUnion.setSysDvCd("UAS");
		msgUnion.setSndDvCd(messageType);
		msgUnion.setAutoSndYn(1);

		if (reservedTime != null) {
			msgUnion.setResvStCd(1);
			msgUnion.setResvDtm(reservedTime);
		} else {
			msgUnion.setResvStCd(0);
		}

		msgUnion.setNtfcStupDvCd("05");
		msgUnion.setSndGrpDvCd(1030);

		msgUnion.setTmplId(0);

		if (msgUnion.getMsgCatGrpCd() == null) {
			msgUnion.setMsgCatGrpCd("7");
		}

		if (msgUnion.getMsgCatDtlCd() == null) {
			msgUnion.setMsgCatDtlCd("0701");
		}

		msgUnion.setTitl(title);
		msgUnion.setCont(content);

		msgUnion.setSndId(0);
		msgUnion.setSndIpAdr(UstraWebUtils.getClientIp());
		msgUnion.setFrstRegrTyCd("0");
		msgUnion.setFrstRegrId(sUid);

		ArrayList<String> rcvUserList = new ArrayList<>();

		for (String mobileNo : mobileNos) {
			rcvUserList.add(mobileNo);
		}

		msgUnion.setRcvUserList(rcvUserList);

		RestResult<Integer> rsMsg = callApiMessageAutoInsert(msgUnion);

		if (rsMsg == null || rsMsg.getHasError()) {
			return false;
		}

		int rsMsgId = rsMsg.getBody();

		return rsMsgId > 0;
	}

	public void sendSMS(String title, String content, String linkUrl, String reservedTime, String msgCatGrpCd, String msgCatDtlCd, String... receiverInfo) {
		MessageUnion msgUnion = new MessageUnion();

		msgUnion.setSndKdCd(1);
		msgUnion.setRcvrTyCd(0);
		msgUnion.setLmsRcvYn(1);

		msgUnion.setMsgCatGrpCd(msgCatGrpCd);
		msgUnion.setMsgCatDtlCd(msgCatDtlCd);

		sendMessage(msgUnion, "5", title, content, reservedTime, receiverInfo);
	}

	public void sendSMS(String uid, String mblNo, String title, String content, String linkUrl, String msgCatGrpCd, String msgCatDtlCd, String reservedTime) {
		sendSMS(title, content, linkUrl, reservedTime, msgCatGrpCd, msgCatDtlCd, new String[] {mblNo + "#" + uid});
	}

	public void sendEmail(String title, String content, String linkUrl, String reservedTime, String msgCatGrpCd, String msgCatDtlCd, String... receiverInfo) {
		MessageUnion msgUnion = new MessageUnion();

		msgUnion.setSndKdCd(0);
		msgUnion.setSndEmlAdr("noreply@gchealthcare.com");

		msgUnion.setMsgCatGrpCd(msgCatGrpCd);
		msgUnion.setMsgCatDtlCd(msgCatDtlCd);

		sendMessage(msgUnion, "2", title, content, reservedTime, receiverInfo);
	}

	public void sendEmail(String uid, String emlAdr, String mblNo, String title, String content, String linkUrl, String msgCatGrpCd, String msgCatDtlCd, String reservedTime) {
		sendEmail(title, content, linkUrl, reservedTime, msgCatGrpCd, msgCatDtlCd, new String[] {emlAdr + "#" + uid});
	}

	public void sendAppPush(String title, String content, String linkUrl, String reservedTime, String msgCatGrpCd, String msgCatDtlCd, String... receiverInfo) {
		MessageUnion msgUnion = new MessageUnion();

//		msgUnion.setPshSndTyCd("");
//		msgUnion.setLinkKvl("");
		msgUnion.setLinkUrl(linkUrl);
		msgUnion.setRcvrTyCd(0);
		msgUnion.setPshLinkId("1");
		msgUnion.setSndKdCd(2);
		msgUnion.setSndPushSndTy("target");
		msgUnion.setMblPltfDvCd("I");

		msgUnion.setMsgCatGrpCd(msgCatGrpCd);
		msgUnion.setMsgCatDtlCd(msgCatDtlCd);

		sendMessage(msgUnion, "4", title, content, reservedTime, receiverInfo);
	}

	public void sendAppPush(String uid, String mblNo, String title, String content, String linkUrl, String msgCatGrpCd, String msgCatDtlCd, String reservedTime) {
		sendAppPush(title, content, linkUrl, reservedTime, msgCatGrpCd, msgCatDtlCd, new String[] { mblNo + "#" + uid});
	}

	public RestResult<Map<String, Integer>> sendLifeStyleAppl(int contractId) {
		Map<String, Object> params = getParams();

		params.put("contractId", contractId);

		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Integer>>>() {})
			.appendHeader("channel-code", Channel.API_BO_CHANNEL)
			.parameter(params)
			.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/message/lifeStyle/appl").build().toUri())
			.method(HttpMethod.POST)
			.bodyRequest(true)
			.build());
	}

	public RestResult<Map<String, Integer>> sendLifeStyleGuide() {
		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Integer>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/message/lifeStyle/guide").build().toUri())
				.method(HttpMethod.POST)
				.bodyRequest(true)
				.parameter(getParams())
				.build());
	}

	public RestResult<Map<String, Integer>> sendCounselGuide(int contractId) {
		Map<String, Object> params = getParams();

		params.put("contractId", contractId);

		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Integer>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.parameter(params)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/message/counsel/guide").build().toUri())
				.method(HttpMethod.POST)
				.bodyRequest(true)
				.build());
	}

	public RestResult<Map<String, Integer>> batchCareCampaign(int campaignId) {
		Map<String, Object> params = getParams();

		params.put("campaignId", campaignId);

		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Integer>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.parameter(params)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/campaign/batch").build().toUri())
				.method(HttpMethod.POST)
				.bodyRequest(true)
				.build());
	}

	public RestResult<Map<String, Integer>> batchCareCampaignAutoExtension() {
		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Integer>>>() {})
			.appendHeader("channel-code", Channel.API_BO_CHANNEL)
			.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/campaign/batch-auto-extension").build().toUri())
			.method(HttpMethod.POST)
			.bodyRequest(true)
			.build());
	}

	public RestResult<Map<String, Integer>> batchCareCampaignSendMsg() {
		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Integer>>>() {})
			.appendHeader("channel-code", Channel.API_BO_CHANNEL)
			.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/campaign/batch-sned-msg").build().toUri())
			.method(HttpMethod.POST)
			.bodyRequest(true)
			.build());
	}

	public RestResult<Map<String, Object>> getChronicWeekInfo(String startDate, String endDate) {
		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Object>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/chronic/program/info/week?s=" + startDate + "&e=" + endDate).build().toUri())
				.method(HttpMethod.GET)
				.build());
	}

	public RestResult<Map<String, Object>> getChronicStepInfo(int sonoId, String tDate) {
		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Object>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/chronic/program/info/step?id=" + sonoId + "&dt=" + tDate).build().toUri())
				.method(HttpMethod.GET)
				.build());
	}

	public RestResult<Map<String, Object>> batchChronicMissionMessage() {
		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Object>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/chronic/batch/mission-message").build().toUri())
				.method(HttpMethod.POST)
				.build());
	}

	public Map<String, Object> setAssessment() {
		RestResult<Map<String, Object>> restResult = this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Object>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/musc/assessment").build().toUri())
				.parameter(getParams())
				.method(HttpMethod.POST)
				.bodyRequest(true)
				.build());

		return restResult.getBody();
	}

	public void sendChronicProgramMessage(Object pgmApplId, Object svcId, Object msgSndTyCd, List<String> uidList, Object resvTime) {
		RestResult<Map<String, Object>> restResult = this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Object>>>() {})
				.appendHeader("channel-code", Channel.API_BO_CHANNEL)
				.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/chronic/program/message?pgmApplId=" + pgmApplId + "&svcId=" + svcId + "&msgSndTyCd=" + msgSndTyCd + "&uid=" + String.join(",", uidList) + (resvTime == null ? "" : ("&resvDtm=" + resvTime))).build().toUri())
				.method(HttpMethod.GET)
				.build());

		Map<String, Object> resultMap = restResult.getBody();

		if (resultMap == null || String.valueOf(resultMap.get("ERROR")).equals("Y")) {
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, String.valueOf(resultMap.get("MESSAGE")));
		}
	}

	/**
	 * 미션미수행 대상자 메시지발송 - 미션독려 NEW
	 * @param
	 * @return
	 */
	public void sendAppPushMsn(String title, String content, String linkUrl, String linkKvl, String reservedTime, String msgCatGrpCd, String msgCatDtlCd, String... receiverInfo) {
		MessageUnion msgUnion = new MessageUnion();

//		msgUnion.setPshSndTyCd("");
		msgUnion.setLinkKvl(linkKvl);
		msgUnion.setLinkUrl(linkUrl);
		msgUnion.setRcvrTyCd(0);
		msgUnion.setPshLinkId("1");
		msgUnion.setSndKdCd(2);
		msgUnion.setSndPushSndTy("target");
		msgUnion.setMblPltfDvCd("I");

		msgUnion.setMsgCatGrpCd(msgCatGrpCd);
		msgUnion.setMsgCatDtlCd(msgCatDtlCd);

		sendMessageMsn(msgUnion, "4", title, content, reservedTime, receiverInfo);
	}

	public boolean sendMessageMsn(MessageUnion msgUnion, String messageType, String title, String content, String reservedTime,  String... mobileNos) {
		String sUid = GchcJwtUtil.getUserId();

		msgUnion.setSndUid(0);
		msgUnion.setSysDvCd("UAS");
		msgUnion.setSndDvCd(messageType);
		msgUnion.setAutoSndYn(1);

		if (reservedTime != null) {
			msgUnion.setResvStCd(1);
			msgUnion.setResvDtm(reservedTime);
		} else {
			msgUnion.setResvStCd(0);
		}

		msgUnion.setNtfcStupDvCd("05");
		msgUnion.setSndGrpDvCd(1030);

		msgUnion.setTmplId(0);

		msgUnion.setSndMblNo("0234494805");

		if (msgUnion.getMsgCatGrpCd() == null) {
			msgUnion.setMsgCatGrpCd("7");
		}

		if (msgUnion.getMsgCatDtlCd() == null) {
			msgUnion.setMsgCatDtlCd("0701");
		}

		msgUnion.setTitl(title);
		msgUnion.setCont(content);

		msgUnion.setSndId(0);
		msgUnion.setSndIpAdr(UstraWebUtils.getClientIp());
		msgUnion.setFrstRegrTyCd("0");
		msgUnion.setFrstRegrId(sUid);

		ArrayList<String> rcvUserList = new ArrayList<>();

		for (String mobileNo : mobileNos) {
			rcvUserList.add(mobileNo);
		}

		msgUnion.setRcvUserList(rcvUserList);

		RestResult<Integer> rsMsg = callApiMessageAutoInsert(msgUnion);

		if (rsMsg == null || rsMsg.getHasError()) {
			return false;
		}

		int rsMsgId = rsMsg.getBody();

		return rsMsgId > 0;
	}

	public RestResult<Map<String, Integer>> sendAuthPush(int postId, String pushType) {
		Map<String, Object> params = getParams();

		params.put("postId"		, postId	);
		params.put("pushType"	, pushType	);

		return this.call(RestTemplateExchangeOption.jsonFormUrlEncoded(new TypeReference<RestResult<Map<String, Integer>>>() {})
			.appendHeader("channel-code", Channel.API_BO_CHANNEL)
			.parameter(params)
			.uri(UriComponentsBuilder.fromHttpUrl(commonEndpoint + "/api/common/care/message/auth/push").build().toUri())
			.method(HttpMethod.POST)
			.bodyRequest(true)
			.build());
	}

}
