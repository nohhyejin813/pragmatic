package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.NrsnClsfSxRltnModel;
import com.gchc.ncu.bo.care.models.NrsnDssSxRltnModel;
import com.gchc.ncu.bo.care.models.NrsnSxBscModel;
import com.gchc.ncu.bo.care.vo.PainSymptomVo;

@Mapper
public interface PainSymptomRepository {

	List<NrsnSxBscModel> selectSymptomList(PainSymptomVo criteria);
	NrsnSxBscModel selectSymptomDetail(NrsnSxBscModel criteria);
	void insertSymptom(NrsnSxBscModel model);
	void updateSymptom(NrsnSxBscModel model);
	void deleteSymptom(NrsnSxBscModel model);

	List<NrsnClsfSxRltnModel> selectSymptomPartList(NrsnSxBscModel criteria);
	void insertSymptomPart(NrsnClsfSxRltnModel model);
	void deleteSymptomPart(int nrsnSxId);

	List<NrsnDssSxRltnModel> selectSymptomDiseaseList(NrsnSxBscModel criteria);
	void insertSymptomDisease(NrsnDssSxRltnModel model);
	void deleteSymptomDisease(int nrsnSxId);

}
