package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.NtrtMsnBscModel;
import com.gchc.ncu.bo.care.repository.NutritionMissionRepository;
import com.gchc.ncu.bo.care.vo.NutritionMissionVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class NutritionMissionService {

	private final NutritionMissionRepository missionRepository;

	public List<NtrtMsnBscModel> getNutritionMissionList(NutritionMissionVo criteria) {
		return missionRepository.selectNutritionMissionList(criteria);
	}

	public NtrtMsnBscModel getNutritionMissionDetail(NtrtMsnBscModel criteria) {
		return missionRepository.selectNutritionMissionDetail(criteria);
	}

	@Transactional
	public void saveNutritionMissionBase(NtrtMsnBscModel model) {
		if (StringUtils.isEmpty(model.getNtrtMsnId())) {
			missionRepository.insertNutritionMissionBase(model);
		} else {
			missionRepository.updateNutritionMissionBase(model);
		}
	}

	@Transactional
	public void deleteNutritionMissionBase(List<NtrtMsnBscModel> list) {
		if (list != null) {
			for (NtrtMsnBscModel model : list) {
				if (missionRepository.selectUsedNutritionMissionCount(model) > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "이미 사용 중인 미션입니다.[" + model.getNtrtMsnNm() + "]");
				}

				missionRepository.deleteNutritionMissionBase(model);
			}
		}
	}

}
