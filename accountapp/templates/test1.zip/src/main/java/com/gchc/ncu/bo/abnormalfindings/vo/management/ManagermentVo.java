package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.gchc.common.model.GchcPageableVo;



@Data
@Builder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentVo extends GchcPageableVo
{

	@ApiModelProperty(value="연도", example = "2019")
	private String yr;

	@ApiModelProperty(value="유소견 매니저(회원여부 파단. 현재X)", example = "1")
	private Integer isUbcareManager;


	@ApiModelProperty(value="관리자 아이디", example="-1")
	private Integer mngrId;



	@ApiModelProperty(value="검진 시작 일자", example = "2019-01-01") //CHECKUP_FROM_DATE
	private String cuFromDt;

	@ApiModelProperty(value="검진 종료 일자", example = "2019-12-31") //CHECKUP_TO_DATE
	private String cuToDt;


	@ApiModelProperty(value="상담 시작 일자") //CONSULT_TO_DATE
	private String cnslFromDt;


	@ApiModelProperty(value="상담 종료 일자") //CHECKUP_FROM_DATE
	private String cnslToDt;

	@ApiModelProperty(value="고객사 아이디", example = "1")
	private Integer clcoId;




	@ApiModelProperty(value="사업장 아이디", example="200")
	private Integer bsplId;

	@ApiModelProperty(value="부서 아이디", example = "7")
	private Integer deptId;



	@ApiModelProperty(value="구분값", example = "1")
	private Integer ty; //GUNBUN

	@ApiModelProperty(value="검색어", example = "")
	private String search; //검색어


	@ApiModelProperty(value="", example="1")
	private Integer status;

	@ApiModelProperty(value="다운로드 메모")
	private String dwldMemo;

	@ApiModelProperty(value="다운로드 사유코드")
	private String dwldRsnCd;

	@ApiModelProperty(value="다운로드 접근경로")
	private String dwldPageUrl;




}
