package com.gchc.ncu.bo.abnormalfindings.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBoardInfoModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBusinessPlaceModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentCorporationNameModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentCounselModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentDepartmentNameModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentEnterPriseStatisticssModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentMngCounselHistoryModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentModel;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentYearModel;
import com.gchc.ncu.bo.abnormalfindings.service.ManagermentService;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBoardInfoVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBrainDiseaselevelVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentBusinessPlaceVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentCorporationNameVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentCounselVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentDepartmentNameVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentDeptNmVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentEnterpriseStatisticssVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentMngCounselHistoryVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentVo;
import com.gchc.ncu.bo.abnormalfindings.vo.management.ManagermentYearVo;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;



/**
 * 유소견 Controller
 * @FileName : AbnormalFindingsController.java
 * @date : 2021. 7. 30
 * @author : gs_shbaek@gchealthcare.com
 * @프로그램 설명 :
 * @변경이력 :
 */
@Api(tags="유소견 관리 - AbnormalFindingsController", description="AbnormalFindingsController")
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/abnormalFindings")
public class ManagermentController {

	private final ManagermentService managermentService;

	@Autowired
	private FileOperationManager fileOperationManager;


	@ApiOperation(value="기준연도 목록 조회", notes = "유소견의 기준연도 목록을 조회 한다.")
	@GetMapping("/check-up-year")
	public List<ManagermentYearModel> getCheckUpYear(@ModelAttribute @Valid ManagermentYearVo abnormalFindingsYearVO)
	{
		return managermentService.getCheckUpYear(abnormalFindingsYearVO);
	}

	//@RequestParam("uid") Integer uid



	@ApiOperation(value="회사 네임 목록 조회", notes = "회사 네임 목록을 조회 한다.")
	@GetMapping("/coporation-name")
	public List<ManagermentCorporationNameModel> getCoporationNameList(@ModelAttribute @Valid ManagermentCorporationNameVo abnormalFindingsCorporationNameVo)
	{
		abnormalFindingsCorporationNameVo.setNMenuAbnfManage(abnormalFindingsCorporationNameVo.getIsMenuAbnfManage() == true ? 1 : 0);

		return managermentService.getCoporationNameList(abnormalFindingsCorporationNameVo);
	}




	@ApiOperation(value="사업장 목록 조회", notes = "사업장 목록을 조회 한다.")
	@GetMapping("/business-place")
	public List<ManagermentBusinessPlaceModel> getBusinessPlaceList(@ModelAttribute @Valid ManagermentBusinessPlaceVo abnormalFindingsBusinessPlaceVo)
	{
		return managermentService.getBusinessPlaceList(abnormalFindingsBusinessPlaceVo);
	}




	@ApiOperation(value="부서명 목록 조회", notes = "부서명 목록을 조회 한다.")
	@GetMapping("/department-name")
	public List<ManagermentDepartmentNameModel> getDepartmentNameList(@ModelAttribute @Valid ManagermentDepartmentNameVo abnormalFindingsDepartmentNameVo)
	{
		return managermentService.getDepartmentNameList(abnormalFindingsDepartmentNameVo);
	}



	@ApiOperation(value="뇌질한 위험도 조회", notes = "뇌질한 위험 상태를 조회 한다.")
	@GetMapping("/brain-diseaselevel")
	public List<String> getBrainDiseaseLevel(@ModelAttribute @Valid ManagermentBrainDiseaselevelVo abnormalFindingsBrainDiseaselevelVo)
	{
		return managermentService.getBrainDiseaseLevel(abnormalFindingsBrainDiseaselevelVo);
	}


	@ApiOperation(value="유소견 보드 조회", notes = "유소견 보드 정보를 조회 한다.")
	@GetMapping("/board-count")
	public ManagermentBoardInfoModel getBoardInfo(@ModelAttribute @Valid ManagermentBoardInfoVo abnormalFindingsBoardInfoVo)
	{
		ManagermentBoardInfoModel obj =  managermentService.getBoardInfo(abnormalFindingsBoardInfoVo);
		return obj;
	}




	@ApiOperation(value="유소견 목록 조회", notes = "유소견 목록을 조회 한다.")
	@GetMapping("/abnormal-finding-list")
	public List<ManagermentModel> getAbnormalFindingsList(@ModelAttribute @Valid ManagermentVo abnormalFindingsVo)
	{
		return managermentService.getAbnormalFindingsList(abnormalFindingsVo);
	}



	@ApiOperation(value="유소견 목록 엑셀 다운로드", notes = "유소견 목록 엑셀 다운로드 한다.")
	@PostMapping("/abnormal-finding-list/excel")
	public ResponseEntity<?> getAbnormalFindingsListExcelDownload(@RequestBody ManagermentVo abnormalFindingsVo,
			HttpServletRequest request, HttpServletResponse response)  {

		List<ManagermentModel> list =  managermentService.getAbnormalFindingsListExcel(abnormalFindingsVo);
		List<Map<String, Object>> cmmTargetList = new ArrayList<Map<String,Object>>();

		// 공통백신결과 List MAP 처리
		for(int i=0; i<list.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			ManagermentModel cmmMap = list.get(i);

			map.put("col1"	, cmmMap.getRowNum());				//No
			map.put("col2"	, cmmMap.getGradeNm());				//등급
			map.put("col3"	, cmmMap.getNm());					//이름
			map.put("col4"	, cmmMap.getUid());					//사번
			map.put("col5"	, cmmMap.getBirthDay());			//생일
			map.put("col6"	, cmmMap.getCenter());				//검진센터
			map.put("col7"	, cmmMap.getCuDtm());				//검진일
			map.put("col8"	, cmmMap.getIsResultAgree());		//결과동의서
			map.put("col9"	, cmmMap.getThirdpartyAgree());		//제3자정보 동의
			map.put("col10"	, cmmMap.getYusogyeonAgree());		//유소견 동의
			map.put("col11"	, cmmMap.getPersoninfoAgree());		//뇌심혈관위험도
			map.put("col12"	, cmmMap.getJobStress());			//직무스트레스
			map.put("col13"	, cmmMap.getLmbGrd());				//허리 둘레
			map.put("col14"	, cmmMap.getSbp());					//SBP
			map.put("col15"	, cmmMap.getDbp());					//DBP
			map.put("col16"	, cmmMap.getBst());					//BST
			map.put("col17"	, cmmMap.getSgot());				//SGOT
			map.put("col18"	, cmmMap.getSgpt());				//SGPT
			map.put("col19"	, cmmMap.getGtp());					//yGTP
			map.put("col20"	, cmmMap.getTcClst());				//TC
			map.put("col21"	, cmmMap.getTgntft());				//TG
			map.put("col22"	, cmmMap.getLdlClst());				//LDL
			map.put("col23"	, cmmMap.getHdlClst());				//HDL
			map.put("col24"	, cmmMap.getHbHemo());				//Hb
			map.put("col25"	, cmmMap.getUrineProtein());		//요단백
			map.put("col26"	, cmmMap.getCreatinine());			//Crea
			map.put("col27"	, cmmMap.getGfrRate());				//GFR
			map.put("col28"	, cmmMap.getThorXrayFrnt());		//흉부Xray정면
			map.put("col29"	, cmmMap.getThorXrayLat());			//흉부Xray측면
			map.put("col30"	, cmmMap.getCnsl());				//상담
			cmmTargetList.add(map);
		}

		// ===============================================================
		UstraExcelModel excelModel;

		// [[ 1번 SHEET ]] ########################################################################
		excelModel = UstraExcelModel.of(
			cmmTargetList,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "No"),
				new UstraExcelCellInfoModel("col2"	, "등급"),
				new UstraExcelCellInfoModel("col3"	, "이름"),
				new UstraExcelCellInfoModel("col4"	, "사번"),
				new UstraExcelCellInfoModel("col5"	, "생년월일"),
				new UstraExcelCellInfoModel("col6"	, "검진센터"),
				new UstraExcelCellInfoModel("col7"	, "검진일"),
				new UstraExcelCellInfoModel("col8"	, "결과동의"),
				new UstraExcelCellInfoModel("col9"	, "제3자정보동의"),
				new UstraExcelCellInfoModel("col10"	, "유소견동의"),
				new UstraExcelCellInfoModel("col11"	, "뇌심혈관위험도"),
				new UstraExcelCellInfoModel("col12"	, "직무스트레스"),
				new UstraExcelCellInfoModel("col13"	, "허리둘레"),
				new UstraExcelCellInfoModel("col14"	, "SBP"),
				new UstraExcelCellInfoModel("col15"	, "DBP"),
				new UstraExcelCellInfoModel("col16"	, "BST"),
				new UstraExcelCellInfoModel("col17"	, "SGOT"),
				new UstraExcelCellInfoModel("col18"	, "SGPT"),
				new UstraExcelCellInfoModel("col19"	, "yGTP"),
				new UstraExcelCellInfoModel("col20"	, "TC"),
				new UstraExcelCellInfoModel("col21"	, "TG"),
				new UstraExcelCellInfoModel("col22"	, "LDL"),
				new UstraExcelCellInfoModel("col23"	, "HDL"),
				new UstraExcelCellInfoModel("col24"	, "Hb"),
				new UstraExcelCellInfoModel("col25"	, "요단백"),
				new UstraExcelCellInfoModel("col26"	, "Crea"),
				new UstraExcelCellInfoModel("col27"	, "GRF"),
				new UstraExcelCellInfoModel("col28"	, "흉부Xray정면"),
				new UstraExcelCellInfoModel("col29"	, "흉부Xray측명"),
				new UstraExcelCellInfoModel("col30"	, "상담")
				))
			.withCellGenerator(new BatchUploadCellGenerator())
			.withSheetName("유소견_현황_리스트")	;	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
						.entityBuilder(Arrays.asList(excelModel), "유소견_현황_리스트", request, response)
						.build());
	}




/*
	@ApiOperation(value="유소견 목록 조회", notes = "유소견 목록을 조회 한다.")
	@GetMapping("/abnormal-finding-list")
	public RestResult<List< AbnormalFindingsModel>> getAbnormalFindingsList(@ModelAttribute @Valid AbnormalFindingsVo abnormalFindingsVo)
	{
		List<AbnormalFindingsModel> list =  abnormalFindingsService.getAbnormalFindingsList(abnormalFindingsVo);
		return GchcRestResult.of(list);
	}
*/


	@ApiOperation(value="기업 통계 목록 조회", notes = "기업 통계의 내역을 조회한다.")
	@GetMapping("/enterprise-statisticss")
	public List<ManagermentEnterPriseStatisticssModel> getEnterpriseStatisticssList(@ModelAttribute @Valid ManagermentEnterpriseStatisticssVo abnormalFindingsEnterPriseStatisicsVo)
	{
		return managermentService.getEnterpriseStatisticssList(abnormalFindingsEnterPriseStatisicsVo);
	}


	@ApiOperation(value="기업 통계 목록 조회", notes = "기업 통계의 내역을 조회한다.")
	@GetMapping("/enterprise-statisticss-list")
	public List<ManagermentEnterPriseStatisticssModel> getEnterpriseStatisticssAllList(@ModelAttribute @Valid ManagermentEnterpriseStatisticssVo abnormalFindingsEnterPriseStatisicsVo)
	{
		return managermentService.getEnterpriseStatisticssAllList(abnormalFindingsEnterPriseStatisicsVo);
	}





	@ApiOperation(value="유소견 상담관리 목록 조회", notes = "유소견 상담관리 목록을 조회 한다.")
	@GetMapping("/counsel-list")
	public List<ManagermentCounselModel> getCounselList(@ModelAttribute @Valid ManagermentCounselVo abnormalFindingsCounselVo)
	{
		return managermentService.getCounselList(abnormalFindingsCounselVo);
	}




	@ApiOperation(value="유소견 목록 엑셀 다운로드", notes = "유소견 목록 엑셀 다운로드 한다.")
	@PostMapping("/counsel-list/excel")
	public ResponseEntity<?> getCounselListExcelDownload(@RequestBody ManagermentCounselVo abnormalFindingsCounselVo,
			HttpServletRequest request, HttpServletResponse response)
	{
		List<ManagermentCounselModel> list =  managermentService.getCounselListExcel(abnormalFindingsCounselVo);
		List<Map<String, Object>> cmmTargetList = new ArrayList<Map<String,Object>>();

		// 공통백신결과 List MAP 처리
		for(int i=0; i<list.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			ManagermentCounselModel cmmMap = list.get(i);

			map.put("col1"	, cmmMap.getRowNum());				//No
			map.put("col2"	, cmmMap.getNm());					//이름
			map.put("col3"	, cmmMap.getBsplNm());				//사업장
			map.put("col4"	, cmmMap.getDeptNm());				//부서
			map.put("col5"	, cmmMap.getUid());					//사번
			map.put("col6"	, cmmMap.getCnslTy());				//상담유형
			map.put("col7"	, cmmMap.getCnslCta());				//상담분류
			map.put("col8"	, cmmMap.getCnslTitl());			//상담제목
			map.put("col9"	, cmmMap.getMsrCont());				//상담측정
			map.put("col10"	, cmmMap.getAbnfCnslMemo());		//상담냉용
			map.put("col11"	, cmmMap.getCnslDtm());				//상담시간

			cmmTargetList.add(map);
		}

		// ===============================================================
		UstraExcelModel excelModel;

		// [[ 1번 SHEET ]] ########################################################################
		excelModel = UstraExcelModel.of(
			cmmTargetList,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "No"),
				new UstraExcelCellInfoModel("col2"	, "이름"),
				new UstraExcelCellInfoModel("col3"	, "사업장"),
				new UstraExcelCellInfoModel("col4"	, "부서"),
				new UstraExcelCellInfoModel("col5"	, "사번"),
				new UstraExcelCellInfoModel("col6"	, "상담유형"),
				new UstraExcelCellInfoModel("col7"	, "상담분류"),
				new UstraExcelCellInfoModel("col8"	, "상담제목"),
				new UstraExcelCellInfoModel("col9"	, "상담측정"),
				new UstraExcelCellInfoModel("col10"	, "상담내용"),
				new UstraExcelCellInfoModel("col11"	, "상담시간")
				))
			.withCellGenerator(new BatchUploadCellGenerator())
			.withSheetName("유소견_상담관리")	;	// 시트명


		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
						.entityBuilder(Arrays.asList(excelModel), "유소견_상담관리_리스트", request, response)
						.build());
	}




	@ApiOperation(value="유소견관리 상담내역(과거 상담) 조회", notes = "유소견관리 상담내역(과거 상담) 조회 한다.")
	@GetMapping("/mng-counsel-history")
	public List<ManagermentMngCounselHistoryModel> getMngCounselHistory(@ModelAttribute @Valid ManagermentMngCounselHistoryVo abnormalFindingsMngCounselHistoryVo)
	{
		return managermentService.getMngCounselHistory(abnormalFindingsMngCounselHistoryVo);
	}



	@ApiOperation(value="유소견관리 상담내역 등록", notes = "유소견관리 상담내역을 등록 한다.")
	@PostMapping("/mng-counsel")
	public Integer insertMngCounselHistory(@RequestBody ManagermentMngCounselHistoryModel abnormalFindingsMngCounselHistoryModel)
	{
		String strHm = String.format("%s:%s", abnormalFindingsMngCounselHistoryModel.getCnslHour(), abnormalFindingsMngCounselHistoryModel.getCnslMinute());
		abnormalFindingsMngCounselHistoryModel.setCnslHm(strHm);
		return managermentService.insertMngCounselHistory(abnormalFindingsMngCounselHistoryModel);
	}





	@ApiOperation(value="유소견관리 상담내역 수정", notes = "유소견관리 상담내역을 수정 한다.")
	@PutMapping("/mng-counsel/{abnfCnslId}")
	public Integer updateMngCounselHistory(@PathVariable Integer abnfCnslId, @RequestBody ManagermentMngCounselHistoryModel abnormalFindingsMngCounselHistoryModel)
	{
		String strHm = String.format("%s:%s", abnormalFindingsMngCounselHistoryModel.getCnslHour(), abnormalFindingsMngCounselHistoryModel.getCnslMinute());
		abnormalFindingsMngCounselHistoryModel.setCnslHm(strHm);
		abnormalFindingsMngCounselHistoryModel.setAbnfCnslId(abnfCnslId);
		return managermentService.updateMngCounselHistory(abnormalFindingsMngCounselHistoryModel);
	}




	@ApiOperation(value="유소견관리 상담내역 삭제", notes = "유소견관리 상담내역을 삭제 한다.")
	@DeleteMapping("/mng-counsel")
	public Integer deleteMngCounselHistory(@RequestBody ManagermentMngCounselHistoryModel abnormalFindingsMngCounselHistoryModel)
	{
		return managermentService.deleteMngCounselHistory(abnormalFindingsMngCounselHistoryModel);
	}


	@ApiOperation(value="부셔명 조회", notes = "부서명을 가져온다")
	@GetMapping("/dept-nm")
	public String getDeptNm(@ModelAttribute @Valid ManagermentDeptNmVo abnormalFindingsDeptNmVo)
	{
		return managermentService.getDeptNm(abnormalFindingsDeptNmVo);
	}

}
