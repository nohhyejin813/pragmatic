package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.DssHzrdCausGuidBscModel;
import com.gchc.ncu.bo.care.models.DssHzrdRecsDtlModel;
import com.gchc.ncu.bo.care.models.DssHzrdRecsModel;
import com.gchc.ncu.bo.care.models.MbrHthAgRecsModel;
import com.gchc.ncu.bo.care.service.HealthAgeService;
import com.gchc.ncu.bo.care.vo.HealthAgeVo;

@RestController
@RequestMapping("/api/bo/care/health-age")
@RequiredArgsConstructor
public class HealthAgeController {

	private final HealthAgeService service;

	@GetMapping("/health-age-his-list")
	public List<MbrHthAgRecsModel> getHealthAgeHisList(@ModelAttribute HealthAgeVo in ) {
		return service.getHealthAgeHisList(in,true);
	}

	@GetMapping("/disease-risk-list")
	public List<DssHzrdRecsModel> getDiseaseRiskList(@ModelAttribute HealthAgeVo in ) {
		return service.getDiseaseRiskList(in,true);
	}

	@GetMapping("/disease-risk-dtl")
	public List<DssHzrdRecsDtlModel> getDiseaseRiskDtl(@ModelAttribute HealthAgeVo in ) {
		return service.getDiseaseRiskDtl(in);
	}

	@GetMapping("/disease-risk-base")
	public List<DssHzrdCausGuidBscModel> getBaseInfoList() {
		return service.getBaseInfoList();
	}

	@PostMapping("/saveBaseInfo")
	public RestResult<?> saveBaseInfo(@RequestBody List<DssHzrdCausGuidBscModel> list) {
		int result = service.updateBaseInfo(list);

		return GchcRestResult.of(result, GchcResponseCode.SUCCESS);
	}


}
