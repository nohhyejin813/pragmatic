package com.gchc.ncu.bo.admin.repository;

import java.util.List;

import com.gchc.ncu.bo.admin.models.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gchc.ncu.bo.member.models.ClientModel;


/**
 * 프로토타입 Repository
 *
 * @author gs_hskim@gchealthcare.com
 */
@Mapper
public interface AdminRepository {

	List<AdminModel> 			getHowcareMainGraphData();
	List<AdminModel> 			getMainInstGraphData(Integer cuiId);
	List<AdminModel> 			getCheckupinstGraphData(Integer clcoId);
	ClientModel 				getEasyClient(ClientModel model);
	AdminProgressModel 			getAdminProgressFlag(Integer clcoId);
	AdminOpenPopupModel 		getOpenPopupData(Integer clcoId);
	String 						getBsplNm(Integer clcoId);
	List<ClientMiniModel> 		getAddBspl(Integer clcoId);
	String 						atchFileId(Integer clcoId);
	int 						modClcoOpenFlag(Integer clcoId);
	List<ClientMiniModel> 		getClientList(Integer yr);
	List<ClientMiniModel> 		getOpenClientNoticeData(@Param("cuiId")Integer cuiId, @Param("yr") Integer yr);

	AdminOpenMailModel 			getOpenMailFowardInfo(Integer clcoId);
	List<AdminOpenMailTargetModel> getOpenMailTarget(Integer clcoID);
	List<AdminOpenMailTargetModel> getBizCenterOpenMailTarget(Integer clcoID);

	int insClcoAthoStlTrscHis(ClcoAthoStlTrscHisModel clcoAthoStlTrscHisModel);

	int updateClcoCtraStlHis(ClcoAthoStlTrscHisModel clcoAthoStlTrscHisModel);

	List<AdminClcoCtraModel> selectClcoCtraHis(ClientPaymentModel clientPaymentModel);

	void updateClcoCtraHisResvSrtDt(AdminClcoCtraModel updAdminClcoCtraModel);

	void updateClcoBsplHisResvSrtDt(AdminClcoCtraModel updAdminClcoCtraModel);
}
