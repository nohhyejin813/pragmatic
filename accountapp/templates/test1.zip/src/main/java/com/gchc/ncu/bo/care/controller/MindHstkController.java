package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.MidFeelBscModel;
import com.gchc.ncu.bo.care.service.MindHstkService;
import com.gchc.ncu.bo.care.vo.MindHstkVo;

@RestController
@RequestMapping("/api/bo/care/mind/hstk")
@RequiredArgsConstructor
public class MindHstkController {

	private final MindHstkService MindService;

	@GetMapping("/searchBsc")
	public List<MidFeelBscModel> searchBsc(@ModelAttribute MindHstkVo criteria) {
		return MindService.getMidFeelBsc(criteria);
	}

	@GetMapping("/searchEmoDtl")
	public MidFeelBscModel searchEmoDtl(@ModelAttribute MindHstkVo criteria) {
		return MindService.getMidFeelDtl(criteria);
	}

	@PostMapping("/saveBsc")
	public RestResult<?> updateCsttMateBsc(@RequestBody @Valid MidFeelBscModel model) {
		MindService.saveBsc(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/deleteBsc")
	public RestResult<?> deleteBsc(@RequestBody List<MidFeelBscModel> list ) {
		MindService.deleteBsc(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
