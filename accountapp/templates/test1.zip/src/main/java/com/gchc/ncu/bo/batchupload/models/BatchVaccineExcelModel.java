package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchVaccineExcelModel extends NcuModel {
	// T_BLK_VCN_HVEX_HIS	헬스케어_일괄백신수검내역
	private String excelFileName; // 다운로드 엑셀 파일명
	private int yr;	// 기준년도

	private Integer row;
	private int vcnId;			// VCN_ID 백신아이디
	private String cuiNm;		// CUI_NM 검진기관명
	private String cuiId;		// CUI_ID 검진기관아이디
	private String clcoNm;		// CLCO_NM 고객사명
	private String clcoId;		// CLCO_ID 고객사아이디
	//private String yr;			// YR 기준년도
	private String custNm;		// CUST_NM 고객명
	private String brdt; 		// 생년월일
	private String sexCd;		// 성별
	private String aempId;		// AEMP_ID 임직원아이디
	private String fmlyNm;		// FMLY_NM 가족이름
	private String vcnInctNm;	// VCN_INCT_NM 백신접종명
	private String vcnInctDt;	// VCN_INCT_DT 백신접종일자
	private String vcnInctCuiYn;// VCN_INCT_CUI_YN 백신접종검진기관여부
	private String uid;			// UID 회원아이디
	private String upldStVal;	// UPLD_ST_VAL 업로드상태값
	private String upldErrVal;	// UPLD_ERR_VAL 업로드오류값
	private String useYn;		// USE_YN 사용여부
	private String upldyn;		// UPLD_YN 업로드여부
	private String mngrKdCd;	// MNGR_KD_CD 관리자종류코드
	private String mngrId;		// MNGR_ID 관리자아이디
	private String selfYn;		// SELF_YN 본인여부
	private String delYn;		// DEL_YN 삭제여부
	private String delMngrId;	// DEL_MNGR_ID 삭제관리자아이디
	private String delDtm;		// DEL_DTM 삭제일시

	private String getType;		// 검색조건
	//private String frstRegDtm	// FRST_REG_DTM 최초등록일시
	//private String frstRegrTyCd	// FRST_REGR_TY_CD 최초등록자유형코드
	//private String frstRegrId	// FRST_REGR_ID 최초등록자아이디
	//private String lastUpdDtm	// LAST_UPD_DTM 최종수정일시
	//private String lastUpdrTyCd	// LAST_UPDR_TY_CD 최종수정자유형코드
	//private String lastUpdrId	// LAST_UPDR_ID 최종수정자아이디

	// 오류
	private List<String> error;
	private Integer errorCnt;
}
