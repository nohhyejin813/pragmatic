package com.gchc.ncu.bo.abnormalfindings.models;

import com.gchc.common.model.GchcPageableVo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@Builder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class HthSvcModel extends GchcPageableVo
{
	@ApiModelProperty(value="변경일")
	private String changDay;

	@ApiModelProperty(value="변경전_운영군1차")
	private Integer tmpSvcgCdS1;

	@ApiModelProperty(value="변경전_운영군1차")
	private String tmpSvcgCdS1Nm;

	@ApiModelProperty(value="변경전_운영군2차")
	private Integer tmpSvcgCdS2;

	@ApiModelProperty(value="변경전_운영군2차")
	private String tmpSvcgCdS2Nm;


	@ApiModelProperty(value="변경된_운영군1차")
	private Integer tmpSvcgCdE1;

	@ApiModelProperty(value="변경된_운영군1차")
	private String tmpSvcgCdE1Nm;

	@ApiModelProperty(value="변경된_운영군2차")
	private Integer tmpSvcgCdE2;

	@ApiModelProperty(value="변경된_운영군2차")
	private String tmpSvcgCdE2Nm;


	@ApiModelProperty(value="회원 UID")
	private Integer uid;



	@ApiModelProperty(value="회원서비스ID")
	private Integer mbrSvcId;

	@ApiModelProperty(value="진행회차")
	private Integer pgrsTms;

	@ApiModelProperty(value="서비스군")
	private Integer svcgCd;

	@ApiModelProperty(value="임시서비스군")
	private Integer tmpSvcgCd;

	@ApiModelProperty(value="임시서비스군상세")
	private Integer tmpSvcgDtlCd;

	@ApiModelProperty(value=" 임시서비스군차수")
	private String tmpSvcgOnoVal;


	@ApiModelProperty(value="고객진행상태")
	private Integer custPgrsStCd;

	@ApiModelProperty(value="고객진행상태(변경후상태)")
	private Integer custPgrsStCdE;


	@ApiModelProperty(value="변경코드")
	private Integer chgCd;

	@ApiModelProperty(value="변경 내역")
	private String chgCont;


	@ApiModelProperty(value="변경자 UID")
	private Integer wUid;

	@ApiModelProperty(value="고객사")
	private String clcoNm;

}
