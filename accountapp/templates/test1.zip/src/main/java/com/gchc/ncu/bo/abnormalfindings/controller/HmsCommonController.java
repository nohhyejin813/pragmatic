package com.gchc.ncu.bo.abnormalfindings.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.ncu.bo.abnormalfindings.service.HmsCommonService;
import com.gchc.ncu.bo.checkupinst.models.CodeModel;

import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 약관 관리 Controller
 *
 * @author 2021.08.12 목 /Yi Geon-Jin
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/abnormalFindings")
@Api(tags="유소견 관리 - 검진결과:유소견관리(신)")
public class HmsCommonController {

    private final HmsCommonService commonService;

	/**
	 * 고객사 리스트 조회
	 */
	@GetMapping("/common/clco")
	public List<CodeModel> getClcoList() {
		return commonService.getClcoList();
	}

	/**
	 * 근무지역 리스트 조회
	 */
	@GetMapping("/common/workrgn")
	public List<CodeModel> getWorkRgnList(@RequestParam Integer clcoId) {
		return commonService.getWorkRgnList(clcoId);
	}

	/**
	 * 사업장 리스트 조회
	 */
	@GetMapping("/common/workplace")
	public List<CodeModel> getWorkPlaceList(@RequestParam Integer clcoId) {
		return commonService.getWorkPlaceList(clcoId);
	}


}
