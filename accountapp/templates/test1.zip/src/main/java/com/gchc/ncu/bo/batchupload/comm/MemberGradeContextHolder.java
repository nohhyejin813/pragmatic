package com.gchc.ncu.bo.batchupload.comm;

import java.util.List;

import com.microsoft.sqlserver.jdbc.StringUtils;

import com.gchc.ncu.bo.batchupload.models.SupportGradeModel;

public class MemberGradeContextHolder {

	private static final ThreadLocal<List<SupportGradeModel>> contextHolder = new ThreadLocal<List<SupportGradeModel>>();

	public static List<SupportGradeModel> get() {

		return contextHolder.get();
	}

	public static SupportGradeModel get(int id) {

		return get().stream().filter(g->g.getMbrGrdId() == id).findFirst().orElse(null);
	}

	public static void set(List<SupportGradeModel> data) {

		contextHolder.set(data);
	}

	public static void clear() {

		if( get() != null )
			contextHolder.remove();
	}

	public static String getDefault(boolean isSelf, boolean isCheckup) {

		return get().stream()
			.filter(g->g.getCorpSuptYn() == 0)
			//.filter(g->g.getClcoId() == null)
			.filter(g->{
				if( isSelf )
					return g.getSelfYn() == 1;
				if( isCheckup )
					return g.getSelfYn() == 0 && g.getGrdNm().equals("기타(미지원)");
				return g.getSelfYn() == 0 && g.getGrdNm().equals("백신-가족(미지원)");
			})
			.filter(g->{

				if( isCheckup )
					return StringUtils.isEmpty(g.getSuptTgtDvCd()) || "20".equals(g.getSuptTgtDvCd());
				return "10".equals(g.getSuptTgtDvCd());
			})
			.findFirst().map(SupportGradeModel::getGrdNm).orElse(null);
	}
}
