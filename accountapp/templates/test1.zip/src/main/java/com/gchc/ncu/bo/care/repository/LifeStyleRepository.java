package com.gchc.ncu.bo.care.repository;

import java.util.List;

import com.gchc.ncu.bo.care.models.*;
import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.vo.LifeStyleVo;

@Mapper
public interface LifeStyleRepository {

	List<LifeHbtScdlBscModel> selectScheduleList(LifeStyleVo criteria);
	LifeHbtScdlBscModel selectScheduleDetail(LifeHbtScdlBscModel criteria);
	void saveSchedule(LifeHbtScdlBscModel model);
	void deleteSchedule(LifeHbtScdlBscModel model);

	List<LifeHbtCtraBscModel> selectContractList(LifeStyleVo criteria);
	LifeHbtCtraBscModel selectContractDetail(LifeHbtCtraBscModel criteria);
	int selectContractConflictCnt(LifeHbtCtraBscModel model);
	int insertContract(LifeHbtCtraBscModel model);
	void updateContract(LifeHbtCtraBscModel model);
	void deleteContract(LifeHbtCtraBscModel model);

	List<LifeHbtCtraDtlModel> selectContractHbtDetailList(LifeHbtCtraBscModel criteria);
	List<LifeStyleCdModel> selectContractCommCdList();
	void insertContractHbtDtl(LifeHbtCtraDtlModel criteria);
	void deleteContractHbtDtl(LifeHbtCtraDtlModel criteria);

	List<LifeHbtApplBscModel> selectApplicationList(LifeStyleVo criteria);
	List<LifeHbtApplScdlDtlModel> selectApplicationDetailList(LifeStyleVo criteria);

	List<DwCnntScwdDatBscModel> getProgramList();

	List<DwCnntScwdDatBscModel> getCategoryList(DwCnntScwdDatBscModel model);

	List<DwCnntScwdDatBscModel> getContentList(DwCnntScwdDatBscModel model);

	List<LifeHbtScdlBscModel> getScheduleYearList();

	int getScheduleDataCheck(LifeHbtScdlBscModel model);

	void saveScheduleCopy(LifeHbtScdlBscModel model);

	int getScheduleSaveYn(LifeHbtScdlBscModel model);

}
