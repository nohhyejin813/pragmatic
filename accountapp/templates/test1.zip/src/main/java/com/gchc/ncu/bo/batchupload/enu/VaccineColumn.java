package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum VaccineColumn implements BatchUploadColumn {

	CLCO_NM("고객사명", "ClcoNm"),

	CUI_NM("검진센터명", "CuiNm"),

	CUST_NM("이름", "CustNm"),

	BRDT("주민번호", "Brdt"),

	VCN_INCT_NM("접종백신", "VcnInctNm"),

	VCN_INCT_DT("접종일자", "VcnInctDt"),

	MEMBER_ID("MemberId", "Uid")

	;
	String title;

	String field;

	VaccineColumn(String title, String field) {
		this.title = title;
		this.field = field;
	}
}
