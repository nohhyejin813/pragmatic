package com.gchc.ncu.bo.abnormalfindings.models.management;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;


@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
public class ManagermentCorporationNameModel extends UstraManagementBaseModel
{
	private Integer clcoId;
	private String clcoNm;
}
