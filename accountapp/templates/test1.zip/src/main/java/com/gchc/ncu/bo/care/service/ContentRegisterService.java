package com.gchc.ncu.bo.care.service;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.CnntAbvBscModel;
import com.gchc.ncu.bo.care.models.MsgRcvrBscModel;
import com.gchc.ncu.bo.care.repository.ContentRegisterRepository;
import com.gchc.ncu.bo.care.vo.ContentRegisterVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ContentRegisterService {

	private final ContentRegisterRepository contentRegisterRepository;

	public List<CnntAbvBscModel> getRegisterList(ContentRegisterVo criteria) {
		return contentRegisterRepository.selectRegisterList(criteria);
	}

	public CnntAbvBscModel getDetail(ContentRegisterVo criteria) {
		return contentRegisterRepository.selectDetail(criteria);
	}

	@Transactional
	public void updateDetail(ContentRegisterVo criteria) {
		contentRegisterRepository.updateDetail(criteria);
	}

	public List<MsgRcvrBscModel> getManager() {
		return contentRegisterRepository.selectManager();
	}

	@Transactional
	public void saveManager(Map<String, List<MsgRcvrBscModel>> map) {
		List<MsgRcvrBscModel> removeList = map.get("remove");

		if (removeList != null) {
			for (MsgRcvrBscModel model : removeList) {
				if (model.getRegSeq() == null) {
					continue;
				}

				contentRegisterRepository.deleteManager(model);
			}
		}

		List<MsgRcvrBscModel> saveList = map.get("save");

		if (saveList != null) {
			for (@Valid MsgRcvrBscModel model : saveList) {
				contentRegisterRepository.saveManager(model);
			}
		}
	}

}
