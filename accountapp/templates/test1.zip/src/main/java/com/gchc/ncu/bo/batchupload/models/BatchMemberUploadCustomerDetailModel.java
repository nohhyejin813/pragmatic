package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
public class BatchMemberUploadCustomerDetailModel extends NcuModel {

	private Integer clcoId;

	private Integer yr;

	private Integer cuTgtId;

	private Integer aempDtlRegSeq;

	private String aempNm;

	private String aempGrdNm;

	private String aempId;

	private Integer tnsfYn;

	private String spfnTnsfGrpNm;

	private Integer spfnTnsfGrpId;

	private Integer spltYn;

	private Integer mltiYn;

	private Integer slctSpfnUseYn;

	private String slctSpfnSuptSlctGrpNm;

	private Integer slctSpfnSuptSlctGrpId;

	private String pkgNm;

	private Integer corpSpfn;

	private Integer mltiSlctTgtrCnt;

	private String fmlyGrdNm;

	private Integer fmlyGrdId;

	private String fmlyNm1;

	private String fmlyBrdt1;

	private String fmlySexCd1;

	private String fmlyNm2;

	private String fmlyBrdt2;

	private String fmlySexCd2;

	private String fmlyNm3;

	private String fmlyBrdt3;

	private String fmlySexCd3;

	private String fmlyNm4;

	private String fmlyBrdt4;

	private String fmlySexCd4;

	private String fmlyNm5;

	private String fmlyBrdt5;

	private String fmlySexCd5;

	private String fmlyNm6;

	private String fmlyBrdt6;

	private String fmlySexCd6;

	private String fmlyNm7;

	private String fmlyBrdt7;

	private String fmlySexCd7;

	private String fmlyNm8;

	private String fmlyBrdt8;

	private String fmlySexCd8;

	private String fmlyNm9;

	private String fmlyBrdt9;

	private String fmlySexCd9;

	private String fmlyNm10;

	private String fmlyBrdt10;

	private String fmlySexCd10;

	private Integer upldYn;

	private Integer mngrId;

	private Integer useYn;

	private Integer delYn;

	private Integer upldStVal;

	private String upldErrVal;

	private String tnsfTgtFmlyNm1;

	private String tnsfTgtFmlyBrdt1;

	private String tnsfTgtFmlySexCd1;

	private String tnsfTgtFmlyNm2;

	private String tnsfTgtFmlyBrdt2;

	private String tnsfTgtFmlySexCd2;

	private String tnsfTgtFmlyNm3;

	private String tnsfTgtFmlyBrdt3;

	private String tnsfTgtFmlySexCd3;

	private String tnsfTgtFmlyNm4;

	private String tnsfTgtFmlyBrdt4;

	private String tnsfTgtFmlySexCd4;

	private String tnsfTgtFmlyNm5;

	private String tnsfTgtFmlyBrdt5;

	private String tnsfTgtFmlySexCd5;

	private String tnsfTgtFmlyNm6;

	private String tnsfTgtFmlyBrdt6;

	private String tnsfTgtFmlySexCd6;

	private String tnsfTgtFmlyNm7;

	private String tnsfTgtFmlyBrdt7;

	private String tnsfTgtFmlySexCd7;

	private String tnsfTgtFmlyNm8;

	private String tnsfTgtFmlyBrdt8;

	private String tnsfTgtFmlySexCd8;

	private String tnsfTgtFmlyNm9;

	private String tnsfTgtFmlyBrdt9;

	private String tnsfTgtFmlySexCd9;

	private String tnsfTgtFmlyNm10;

	private String tnsfTgtFmlyBrdt10;

	private String tnsfTgtFmlySexCd10;

	private Integer tnsfFmlyCnt;

	private Integer mltiFmlyCnt;
}
