package com.gchc.ncu.bo.abnormalfindings.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.gchc.ncu.bo.abnormalfindings.models.AbnfCodeModel;
import com.gchc.ncu.bo.abnormalfindings.models.AbnfMemberModel;
import com.gchc.ncu.bo.abnormalfindings.models.HthSvcModel;
import com.gchc.ncu.bo.abnormalfindings.models.MemberCodeModel;
import com.gchc.ncu.bo.abnormalfindings.models.MemberInfoModel;
import com.gchc.ncu.bo.abnormalfindings.repository.AbnfMemberRepository;
import com.gchc.ncu.bo.abnormalfindings.vo.AbnfMemberVo;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogService;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.service.CommonService;
import com.gchc.ncu.bo.comm.util.GchcGridUtil;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;

import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 유소견 운영군 리스트 Service
 *
 * @author gs_shbaek@gchealthcare.com
 */

@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class AbnfMemberService
{
	@Autowired
	private AbnfMemberRepository memberRepository;

	@Autowired
	private CommonService commonService;

	@Autowired
	private XlsDownloadRecordService xlsDownloadRecordService;

	@Autowired
	private UsrInnfActiLogService usrInnfActiLogService;


    public List<AbnfMemberModel> getMemberList(AbnfMemberVo abnfMemberVo) {
    	abnfMemberVo.setOrderName(GchcGridUtil.getCamalToLarge(abnfMemberVo.getOrderName()));
		PaginationRequest pr = abnfMemberVo.toPaginationRequest();
		List<AbnfMemberModel> list =  memberRepository.getMemberList(abnfMemberVo, pr);
		UstraMaskingUtils.maskTextFields(list);


		if(list.size() > 1 ) {
			UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
			usrInfomodel.setActiLogDvCd("40");	//로깅 유형
			usrInfomodel.setMenuNm("유소견 관리 > 운영군리스트 ");	//메뉴명
			usrInfomodel.setPfrmNm("운영군 리스트 목록 조회");	//실행명
			usrInfomodel.setPfrmCont(list.get(0).getClcoNm()+" 고객사 "+"운영군 리스트 목록 조회");	//실행 내용
			usrInfomodel.setInnfVwCnt(list.get(0).totalItemCount.intValue());
			if(list.size() == 1) {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid().toString());	//고객명
			}else {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid() + "등 " + list.size() +"건");	//고객명
			}
			usrInnfActiLogService.insert(usrInfomodel);
		}

		return list;
    }

    public List<AbnfMemberModel> getMemberListExcelDownload(AbnfMemberVo abnfMemberVo) {
    	List<AbnfMemberModel>  dataList =  memberRepository.getMemberListExcelDownload(abnfMemberVo);

		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm("유소견관리 > 운영군리스트 > 엑셀다운로드");
		record.setDwldPageUrl(abnfMemberVo.getDwldPageUrl());
		record.setDwldCont("사번, 퇴사여부, 고객명, 성별나이, 고객사, 근무지1, 군별정보, 분류, 평가완료, 진행상태, 최근검진일, 결과보고서히스토리, 뇌/심위험도 ");

		record.setDwldMemo(abnfMemberVo.getDwldMemo()); // 메모
		record.setDwldRsnCd(abnfMemberVo.getDwldRsnCd()); // 다운로드 사유 코드
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(dataList.size() ); //개인정보 Download 건수.
		record.setCustNm("UID : " + dataList.get(0).getUid() + "등 " + dataList.size() + "건");
		xlsDownloadRecordService.insert(record);

		return dataList;
    }



    public MemberCodeModel getSearchList() {

    	MemberCodeModel memberCodeModel = new MemberCodeModel();
    	memberCodeModel.setTmpSvcgCdList( memberRepository.getTmpSvcgCdList());
    	memberCodeModel.setSvcgDtlCdList( memberRepository.getSvcgDtlCdList());
    	memberCodeModel.setPgrsStCdList( memberRepository.getPgrsStCdList());

		return memberCodeModel;
    }

    public MemberInfoModel getMemberInfo(Integer uid) {
    	MemberInfoModel memberInfo = new MemberInfoModel();
    	memberInfo = memberRepository.getMemberInfo(uid);
    	UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
		usrInfomodel.setActiLogDvCd("40");	//로깅 유형
		usrInfomodel.setMenuNm("유소견 관리 > 운영군리스트 > 조회목록 고객명 선택 시 > 고객정보(P)");	//메뉴명
		usrInfomodel.setPfrmNm("운영군 리스트 고객정보 상세조회");	//실행명
		usrInfomodel.setPfrmCont(memberInfo.getBsplNm()+" 고객사 "+"운영군 리스트 고객정보 상세조회");	//실행 내용
		usrInfomodel.setCustNm("UID : " + uid.toString());
		usrInnfActiLogService.insert(usrInfomodel);

    	return memberInfo;
    }

    public List<HthSvcModel> getHthSvcHistList(HthSvcModel hthSvcModel) {
//    	UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
//		usrInfomodel.setActiLogDvCd("40");	//로깅 유형
//		usrInfomodel.setMenuNm("유소견 관리 > 운영군리스트 > 조회목록 군별정보 선택 시 > 군별정보(P)");	//메뉴명
//		usrInfomodel.setPfrmNm("운영군 리스트 군별정보 ");	//실행명
//		usrInfomodel.setPfrmCont("운영군 리스트 군별정보 ");	//실행 내용
//		usrInnfActiLogService.insert(usrInfomodel);

    	return memberRepository.getHthSvcHistList(hthSvcModel);
    }

    public List<AbnfCodeModel> getSvcgDtlCdList() {
//    	UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
//		usrInfomodel.setActiLogDvCd("40");	//로깅 유형
//		usrInfomodel.setMenuNm("유소견 관리 > 운영군리스트 > 조회목록 군별정보 선택 시 > 군별정보(P)");	//메뉴명
//		usrInfomodel.setPfrmNm("운영군 리스트 군별정보 상세조회");	//실행명
//		usrInfomodel.setPfrmCont("운영군 리스트 군별정보 상세조회");	//실행 내용
//		usrInnfActiLogService.insert(usrInfomodel);

    	return memberRepository.getSvcgDtlCdList();
    }

    public List<AbnfCodeModel> getSvcgCdList() {
    	return memberRepository.getSvcgCdList();
    }

    public List<AbnfCodeModel> getCustPgrStCdList() {
//    	UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
//		usrInfomodel.setActiLogDvCd("40");	//로깅 유형
//		usrInfomodel.setMenuNm("유소견 관리 > 운영군리스트 > 조회목록 진행상태 선택 시 > 진행상태변경(P)");	//메뉴명
//		usrInfomodel.setPfrmNm("운영군 리스트 진행상태 상세조회");	//실행명
//		usrInfomodel.setPfrmCont("운영군 리스트 진행상태 상세조회");	//실행 내용
//		usrInnfActiLogService.insert(usrInfomodel);
    	return memberRepository.getCustPgrStCdList();
    }







    public Integer updateHthSvcHistList(HthSvcModel hthSvcModel) {
    	HthSvcModel tHthSvcModel = memberRepository.getHthSvcInfo(hthSvcModel);

    	if(tHthSvcModel.getTmpSvcgCd() != hthSvcModel.getTmpSvcgCd())
    		tHthSvcModel.setCustPgrsStCd(10); //고객 진행 상태
    	else
    		tHthSvcModel.setCustPgrsStCd(hthSvcModel.getCustPgrsStCd());

    	Integer bTmpSvcgCdE1 = tHthSvcModel.getTmpSvcgCdE1();
    	Integer bTmpSvcgCdE2 = tHthSvcModel.getTmpSvcgCdE2();



    	tHthSvcModel.setTmpSvcgCdE1(hthSvcModel.getTmpSvcgCdE1());
    	tHthSvcModel.setTmpSvcgCdE2(hthSvcModel.getTmpSvcgCdE2());
    	tHthSvcModel.setChgCd(hthSvcModel.getChgCd());
    	tHthSvcModel.setChgCont(hthSvcModel.getChgCont());
    	tHthSvcModel.setUid(hthSvcModel.getUid());


		String strUserId = GchcJwtUtil.getUserId();
		if(strUserId != null)
		{
			NcuUserDetail userDetail = commonService.getUserDetail(strUserId);
			if(userDetail != null) {
				Integer uid = userDetail.getUid();
				//기존 DB에 0만 존재함
				tHthSvcModel.setWUid(0);
			}
		}

    	Integer nResult = memberRepository.updateHthSvc(tHthSvcModel);

    	tHthSvcModel.setTmpSvcgCdS1(bTmpSvcgCdE1);
    	tHthSvcModel.setTmpSvcgCdS2(bTmpSvcgCdE2);


    	nResult = memberRepository.insertHthSvcHst(tHthSvcModel);


    	UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
		usrInfomodel.setActiLogDvCd("60");	//로깅 유형

		usrInfomodel.setMenuNm("유소견 관리 > 운영군리스트 > 조회목록 군별정보 선택 시 > 군별정보(P)");	//메뉴명
		usrInfomodel.setPfrmNm("운영군 리스트 군별정보 수정");	//실행명
		usrInfomodel.setCustNm("UID : " + hthSvcModel.getUid());	//고객명
		usrInfomodel.setPfrmCont(hthSvcModel.getClcoNm()+" 고객사 "+"운영군 리스트 군별정보 수정");	//실행 내용
		usrInnfActiLogService.insert(usrInfomodel);


    	return nResult;
    }



    /**
     * 고객 상태 변경
     * @param hthSvcModel
     * @return
     */
    public Integer updateClcoStHst(HthSvcModel hthSvcModel) {
    	HthSvcModel tHthSvcModel = memberRepository.getHthSvcInfo(hthSvcModel);

    	Integer custPgrStCd = tHthSvcModel.getCustPgrsStCd();


    	tHthSvcModel.setChgCd(hthSvcModel.getChgCd());
    	tHthSvcModel.setChgCont(hthSvcModel.getChgCont());
    	tHthSvcModel.setUid(hthSvcModel.getUid());

    	tHthSvcModel.setTmpSvcgCdE1(null);
    	tHthSvcModel.setTmpSvcgCdE2(null);


    	//변경 상태 적용
		tHthSvcModel.setCustPgrsStCd(hthSvcModel.getCustPgrsStCd());

		String strUserId = GchcJwtUtil.getUserId();
		if(strUserId != null)
		{
			NcuUserDetail userDetail = commonService.getUserDetail(strUserId);
			if(userDetail != null) {
				Integer uid = userDetail.getUid();
				tHthSvcModel.setWUid(uid);
			}
		}

    	UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
		usrInfomodel.setActiLogDvCd("60");	//로깅 유형

		usrInfomodel.setMenuNm("유소견 관리 > 운영군리스트 > 조회목록 진행상태 선택 시 > 진행상태(P)");	//메뉴명
		usrInfomodel.setPfrmNm("운영군 리스트 진행상태 수정");	//실행명
		usrInfomodel.setCustNm(hthSvcModel.getUid() +  "(UID)");	//고객명
		usrInfomodel.setPfrmCont("운영군 리스트 진행상태 수정");	//실행 내용
		usrInnfActiLogService.insert(usrInfomodel);

    	Integer nResult = memberRepository.updateHthSvc(tHthSvcModel);


    	tHthSvcModel.setCustPgrsStCd(custPgrStCd);
		tHthSvcModel.setCustPgrsStCdE(hthSvcModel.getCustPgrsStCd());


    	nResult = memberRepository.insertClcoStHst(tHthSvcModel);




    	return nResult;
    }


}
