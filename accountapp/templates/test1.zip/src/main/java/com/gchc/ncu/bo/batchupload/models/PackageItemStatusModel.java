package com.gchc.ncu.bo.batchupload.models;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.batchupload.enu.PackageItemStatus;

@Getter
@Setter
@Builder
public class PackageItemStatusModel {

	PackageItemStatus itemStatus;

	String itmTyCd;

	String sexCd;

	int chexStupCnt;

	int itmPrc;

	public static PackageItemStatusModel ofError(PackageItemStatus itemStatus) {

		return PackageItemStatusModel.builder()
			.itemStatus(itemStatus)
			.build();
	}

	public static PackageItemStatusModel ofNormal(String type, String sex, int prc) {

		return PackageItemStatusModel.builder()
			.itemStatus(PackageItemStatus.NORMAL)
			.itmTyCd(type)
			.sexCd(sex)
			.itmPrc(prc)
			.build();
	}
}
