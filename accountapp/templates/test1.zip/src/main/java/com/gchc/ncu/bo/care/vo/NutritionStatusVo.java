package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class NutritionStatusVo extends UstraManagementBaseModel {

	private String ntrtIngrdId;
	private String ntrtIngrdNm;
	private String ntrtItrstCd;
	private Integer ntrtIndcId;
	private String sexCd;

}
