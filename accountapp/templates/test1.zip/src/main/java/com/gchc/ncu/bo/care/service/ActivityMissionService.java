package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.repository.ActivityMissionRepository;
import com.gchc.ncu.bo.care.vo.ActivityMissionVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ActivityMissionService {

	private final ActivityMissionRepository missionRepository;

	public List<ActMsnBscModel> getActivityMissionList(ActivityMissionVo criteria) {
		return missionRepository.selectActivityMissionList(criteria);
	}

	public ActMsnBscModel getActivityMissionDetail(ActMsnBscModel criteria) {
		return missionRepository.selectActivityMissionDetail(criteria);
	}

	@Transactional
	public void saveActivityMissionBase(ActMsnBscModel model) {
		if (StringUtils.isEmpty(model.getActMsnId())) {
			missionRepository.insertActivityMissionBase(model);
		} else {
			missionRepository.updateActivityMissionBase(model);
		}
	}

	@Transactional
	public void deleteActivityMissionBase(List<ActMsnBscModel> list) {
		if (list != null) {
			for (ActMsnBscModel model : list) {
				List<Integer> usedCountList = missionRepository.selectUsedActivityMissionCount(model);

				for (int usedCount : usedCountList) {
					if (usedCount > 0) {
						throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "이미 사용 중인 미션입니다.[" + model.getActMsnNm() + "]");
					}
				}

				missionRepository.deleteActivityMissionBase(model);
			}
		}
	}

}
