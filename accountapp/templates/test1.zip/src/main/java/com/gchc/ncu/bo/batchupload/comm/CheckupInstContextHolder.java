package com.gchc.ncu.bo.batchupload.comm;

import com.gchc.ncu.bo.batchupload.models.BatchCheckupInstModel;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;

import java.util.List;

public class CheckupInstContextHolder {

    private static final ThreadLocal<List<BatchCheckupInstModel>> contextHolder = new ThreadLocal<List<BatchCheckupInstModel>>();

    public static List<BatchCheckupInstModel> get() {

        return contextHolder.get();
    }

    public static BatchCheckupInstModel get(String cuiNm) {

        return get().stream().filter(c->c.getCuiNm().equals(cuiNm)).findFirst().orElse(null);
    }

    public static void set(List<BatchCheckupInstModel> data) {

        contextHolder.set(data);
    }

    static String _cd(String src) {
        return src.length() == 3 ? "0" + src : src;
    }

	public static boolean checkTmcRngCd(String cuiNm, String tmcRngCd) {

		if( get(cuiNm).getResvTmcStupYn() == 1 ) {

			return _cd(tmcRngCd).compareTo(_cd(get(cuiNm).getCuiTskSrtTmcRngCd())) >= 0 && _cd(tmcRngCd).compareTo(_cd(get(cuiNm).getCuiTskEndTmcRngCd())) <= 0;
		}
		else {

			return BatchUploadUtils.strIn(tmcRngCd, "12", "1224");
		}
	}

    public static void clear() {

        if (get() != null)
            contextHolder.remove();
    }
}
