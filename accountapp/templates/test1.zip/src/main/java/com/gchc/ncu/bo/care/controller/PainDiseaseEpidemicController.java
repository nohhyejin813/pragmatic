package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.NrsnDssEpidDtlModel;
import com.gchc.ncu.bo.care.service.PainDiseaseEpidemicService;
import com.gchc.ncu.bo.care.vo.PainDiseaseEpidemicVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/pain/disease/epidemic")
@RequiredArgsConstructor
public class PainDiseaseEpidemicController {

	private final PainDiseaseEpidemicService painDiseaseEpidemicService;

	@GetMapping("/list")
	public List<NrsnDssEpidDtlModel> epidemicList(@ModelAttribute PainDiseaseEpidemicVo criteria) {
		return painDiseaseEpidemicService.getPainDiseaseEpidemicList(criteria);
	}

	@GetMapping("/month/list")
	public List<NrsnDssEpidDtlModel> epidemicMonthList(@ModelAttribute NrsnDssEpidDtlModel criteria) {
		return painDiseaseEpidemicService.getPainDiseaseEpidemicMonthList(criteria);
	}

	@PostMapping("/month/save/{nrsnDssId}")
	public RestResult<?> saveEpidemicMonth(@PathVariable(name = "nrsnDssId", required = true) int nrsnDssId, @RequestBody List<NrsnDssEpidDtlModel> list) {
		painDiseaseEpidemicService.savePainDiseaseEpidemicMonth(nrsnDssId, list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
