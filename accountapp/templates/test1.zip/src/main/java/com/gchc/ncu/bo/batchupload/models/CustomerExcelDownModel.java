package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Getter
@Setter
public class CustomerExcelDownModel extends UstraManagementBaseModel {
	private String yr;

	private String clcoId;

	private String mngrId;

	private String regDvVal;

	private String fileGrpId;

	private String fileId;

	private int fileNo;

	private String resultFlag;	// 엑셀 업로드결과 구분 (0:전체, 1:성공, 2:에러)

	private Integer state;

	private String excelFileName;

}
