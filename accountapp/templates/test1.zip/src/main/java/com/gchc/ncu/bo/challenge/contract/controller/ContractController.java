package com.gchc.ncu.bo.challenge.contract.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.CmpgBscModel;
import com.gchc.ncu.bo.care.models.CmpgCtraBscModel;
import com.gchc.ncu.bo.care.vo.CareCampaignVo;
import com.gchc.ncu.bo.challenge.contract.models.ChalCmpgCtraBscModel;
import com.gchc.ncu.bo.challenge.contract.models.ChalCmpgBscModel;
import com.gchc.ncu.bo.challenge.contract.vo.ContractVo;
import com.gchc.ncu.bo.challenge.contract.service.ContractService;
import com.gchc.ncu.bo.chronic.progress.models.SvcMsnModel;
import com.gchc.ncu.bo.chronic.progress.models.SvcMsnSearchModel;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;
import org.springframework.web.bind.annotation.*;

//import com.gchc.ncu.bo.care.models.CmpgCtraBscModel;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/challenge/contract")

public class ContractController {

    private final ContractService contractService;

    /*
    * 챌린지 계약
    * */
    @GetMapping("/management/list")
    public List<ChalCmpgCtraBscModel> getContractList(@ModelAttribute ContractVo vo) {
        return contractService.getContractList(vo);
    }

    @GetMapping("/management/detail")
    public ChalCmpgCtraBscModel getContractDetail(@ModelAttribute ContractVo vo) {
        return contractService.getContractDetail(vo);
    }

    // 만족도 설문 리스트
    @GetMapping("/survey/list")
    public List<Map<String, Object>> getSurveyList(@ModelAttribute HashMap<String, Object> model) {
        return contractService.getSurveyList(model);
    }

    @PostMapping("/management/save")
    public RestResult<?> setChallengeContract(@RequestBody ChalCmpgCtraBscModel model) {
        contractService.setChallengeContract(model);
        return GchcRestResult.of(GchcResponseCode.SUCCESS);
    }

    @GetMapping("/management/delete-check")
    public List<ChalCmpgBscModel> getContractCheck(@ModelAttribute ChalCmpgBscModel model) {
        model.setCmpgCtraIdList(model.getCmpgCtraIds().split(","));
        return contractService.getContractCheck(model);
    }

    @DeleteMapping("/management/remove")
    public RestResult<?> removeChallengeContract(@RequestBody List<ChalCmpgCtraBscModel> models) {
        contractService.removeChallengeContract(models);
        return GchcRestResult.of(GchcResponseCode.SUCCESS);
    }

    /*
    * 챌린지 차수
    * */
    @GetMapping("/term/list")
    public List<ChalCmpgBscModel> getContractTermList(@ModelAttribute ContractVo vo) {
        return contractService.getContractTermList(vo);
    }

    @GetMapping("/term/detail")
    public ChalCmpgBscModel getContractTermDetail(@ModelAttribute ContractVo vo) {
        return contractService.getContractTermDetail(vo);
    }

    @PostMapping("/term/save")
    public RestResult<?> setContractTerm(@RequestBody ChalCmpgBscModel model) {
        contractService.setContractTerm(model);
        return GchcRestResult.of(GchcResponseCode.SUCCESS);
    }

    @GetMapping("/term/delete-check")
    public List<ChalCmpgBscModel> getContractTermCheck(@ModelAttribute ChalCmpgBscModel model) {
        model.setCmpgIdList(model.getCmpgIds().split(","));
        return contractService.getContractTermCheck(model);
    }

    @DeleteMapping("/term/remove")
    public RestResult<?> removeContractTerm(@RequestBody List<ChalCmpgBscModel> models) {
        contractService.removeContractTerm(models);
        return GchcRestResult.of(GchcResponseCode.SUCCESS);
    }


}
