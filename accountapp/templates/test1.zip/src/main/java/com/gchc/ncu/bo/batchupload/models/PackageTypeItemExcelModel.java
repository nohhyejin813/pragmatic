package com.gchc.ncu.bo.batchupload.models;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;

@Getter
@Setter
@Builder
public class PackageTypeItemExcelModel {

	@UstraExcelCellInfo(col = 0, header = "카테고리")
	String catNm;

	@UstraExcelCellInfo(col = 0, header = "검진세부항목")
	String subCatNm;

	@UstraExcelCellInfo(col = 0, header = "검사명")
	String examItmNm;

	@UstraExcelCellInfo(col = 0, header = "패키지명-패키지유형명-금액")
	String pkgType;

	@UstraExcelCellInfo(col = 0, header = "비고")
	String etc;
}
