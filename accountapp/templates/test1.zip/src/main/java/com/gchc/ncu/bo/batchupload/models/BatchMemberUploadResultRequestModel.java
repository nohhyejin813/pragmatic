package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.gchc.common.model.GchcPageableVo;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BatchMemberUploadResultRequestModel extends GchcPageableVo {

	Integer clcoId;

	Integer yr;

	Integer mngrId;

	String regDvVal;

	Integer stVal;
}
