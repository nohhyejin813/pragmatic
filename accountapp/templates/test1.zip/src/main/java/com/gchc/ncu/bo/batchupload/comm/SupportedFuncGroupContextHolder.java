package com.gchc.ncu.bo.batchupload.comm;

import java.util.ArrayList;
import java.util.List;

import com.gchc.ncu.bo.batchupload.enu.SpfnGrpType;
import com.gchc.ncu.bo.batchupload.models.SpfnGrpInfModel;

public class SupportedFuncGroupContextHolder {

	private static final ThreadLocal<List<SpfnGrpInfModel>> contextHolder = new ThreadLocal<List<SpfnGrpInfModel>>();

	public static List<SpfnGrpInfModel> get() {

		return contextHolder.get();
	}

	public static SpfnGrpInfModel get(SpfnGrpType type, String name) {

		return get().stream()
			.filter(i->i.getType().equals(type))
			.filter(i->i.getGrpNm().equals(name))
			.findFirst().orElse(null);
	}

	public static boolean isEmpty(SpfnGrpType type) {

		return get().stream()
			.filter(i->i.getType().equals(type))
			.count() == 0;
	}

	public static void set(List<SpfnGrpInfModel> data) {

		contextHolder.set(data);
	}

	public static void add(SpfnGrpType type, List<SpfnGrpInfModel> data) {

		List<SpfnGrpInfModel> list = get();
		if( list == null )
			list = new ArrayList<>();
		data.forEach(d->d.setType(type));
		list.addAll(data);
		set(list);
	}

	public static void clear() {

		if( get() != null )
			contextHolder.remove();
	}
}
