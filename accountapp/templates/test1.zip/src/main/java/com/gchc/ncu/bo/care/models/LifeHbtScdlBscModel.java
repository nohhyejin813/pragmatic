package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class LifeHbtScdlBscModel extends UstraManagementBaseModel {

	private String lifeHbtCd;
	private String lifeHbtNm;
	private String aplcYr;
	private Integer crteWkOno;
	private String titl;
	private String linkUrl;

	private int duplicationYn;		// 중복여부
	private String copyYr;			// 복사년도
	private String cnntRegId;		// 콘텐츠등록아이디
	private String cnntCatNm;		// 콘텐츠카테고리명
	private String cnntRegNm;		// 콘텐츠등록명

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

	private List<Map<String, Object>> scheduleYearList;	// 생활습관일정년도목록



}
