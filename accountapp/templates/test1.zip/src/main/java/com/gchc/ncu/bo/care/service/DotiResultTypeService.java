package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.DotiTyCdModel;
import com.gchc.ncu.bo.care.repository.DotiResultTypeRepository;
import com.gchc.ncu.bo.care.vo.DotiResultTypeVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DotiResultTypeService {

	private final DotiResultTypeRepository dotiResultTypeRepository;

	public List<DotiTyCdModel> getDotiResultTypeList(DotiResultTypeVo criteria) {
		return dotiResultTypeRepository.selectDotiResultTypeList(criteria);
	}

	public DotiTyCdModel getDotiResultTypeDetail(DotiTyCdModel criteria) {
		return dotiResultTypeRepository.selectDotiResultTypeDetail(criteria);
	}

	public void saveDotiResultType(DotiTyCdModel model) {
		dotiResultTypeRepository.saveDotiResultType(model);
	}

	@Transactional
	public void deleteDotiResultType(List<DotiTyCdModel> list) {
		if (list != null) {
			for (DotiTyCdModel model : list) {
				dotiResultTypeRepository.deleteDotiResultType(model);
			}
		}
	}

}
