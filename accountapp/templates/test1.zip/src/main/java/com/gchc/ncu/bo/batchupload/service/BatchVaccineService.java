package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.VaccineColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.BatchUploadExcelVaccineModel;
import com.gchc.ncu.bo.batchupload.models.BatchVaccineExcelModel;
import com.gchc.ncu.bo.batchupload.models.BatchVaccineTempModel;
import com.gchc.ncu.bo.batchupload.models.BatchVaccineUserModel;
import com.gchc.ncu.bo.batchupload.repository.BatchExaminationUploadRepository;
import com.gchc.ncu.bo.batchupload.repository.BatchVaccineRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.repository.CommonRepository;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BatchVaccineService {

	@Autowired
	BatchVaccineRepository vaccineRepo;

	@Autowired
	BatchExaminationUploadRepository examRepo;

	@Autowired
	private CommonRepository commRepo;

	private boolean contains(Collection<Object> values, String title) {

		return values.stream().filter(v->v.toString().replace(" ", "").equals(title)).count() > 0;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> setCheckupVaccineData(List<RowInfo> converted, Integer yr) {

		Map<String, Object> result = new HashMap<>();
		BatchVaccineExcelModel vaccine = new BatchVaccineExcelModel();
		BatchUploadExcelVaccineModel upload = new BatchUploadExcelVaccineModel();
		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());
		BatchVaccineUserModel user = new BatchVaccineUserModel();
		List<BatchVaccineTempModel> temp = new ArrayList<BatchVaccineTempModel>();
		// 리턴할 목록
		List<BatchVaccineExcelModel> totalList = new ArrayList<BatchVaccineExcelModel>();
		List<BatchVaccineExcelModel> missingList = new ArrayList<BatchVaccineExcelModel>();
		List<BatchVaccineExcelModel> nonMatchList = new ArrayList<BatchVaccineExcelModel>();
		List<BatchVaccineExcelModel> etcList = new ArrayList<BatchVaccineExcelModel>();

		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();

		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();
		if( BatchUploadColumn.stream(VaccineColumn.class).anyMatch(c->!contains(headerRow.values(), c.getTitle())) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur();

		List<BatchUploadExcelVaccineModel> in = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyMap((Map<String, Object>)r.getObject()))
			.map(r->{

				BatchUploadExcelVaccineModel v = BatchUploadUtils.map((Map<String, Object>)r.getObject(),
					headerRow,
					BatchUploadColumn.table(VaccineColumn.class), BatchUploadExcelVaccineModel.class);
				v.setYr(yr);
				return v;
			})
			.collect(Collectors.toList());

		for(int i=0;i<in.size();i++) {
			vaccine = new BatchVaccineExcelModel();
			upload = new BatchUploadExcelVaccineModel();
			user = new BatchVaccineUserModel();
			upload = in.get(i);
			String upldStVal = "0"; // 업로드상태값 필수값 초기 미진행 상태 세팅
			String upldErrVal = ""; // 업로드 오류정보
			Integer clcoId = 0;
			Integer cuiId = 0;
			// 내용누락 여부 체크 하여 상태값 2 : 내용누락 체크하기.
			// 대전제 엑셀 상에 들어오는 모든 데이터는 필수값이다.
			// 현재 BRDT 와 SEX_CD 없음. 2022-02-03 기준
			/*
			백신 일괄업로드 상태 코드 정리
			0 : 미진행
			1 : 정상
			2 : 내용누락
			3 : 데이터불일치(정보)
			4 : 기타(형식, 오류...등) 중복 or 2 and 3일 경우 */
			if("".equals(upload.getClcoNm())) {
				upldErrVal += "| 고객사 정보가 누락되었습니다.";
				upldStVal = "2";
			}
			if("".equals(upload.getCuiNm())) {
				upldErrVal += "| 검진센터 정보가 누락되었습니다.";
				upldStVal = "2";
			}
			if("".equals(upload.getCustNm())) {
				upldErrVal += "| 접종자 명 정보가 누락되었습니다.";
				upldStVal = "2";
			}
			if("".equals(upload.getBrdt())) {
				upldErrVal += "| 접종자 주민번호 정보가 누락되었습니다.";
				upldStVal = "2";
			}
			if("".equals(upload.getVcnInctNm())) {
				upldErrVal += "| 접종백신 정보가 누락되었습니다.";
				upldStVal = "2";
			}
			if("".equals(upload.getVcnInctDt())) {
				upldErrVal += "| 접종일자가 누락되었습니다.";
				upldStVal = "2";
			}

//			if(8 == upload.getBrdt().length()) {
//				brdtArr = upload.getBrdt().split("-");
//				brdt = brdtArr[0].substring(0,2)+"-"+brdtArr[0].substring(2,4)+"-"+brdtArr[0].substring(4); // ex 2021-10-21
//				if("1".equals(brdtArr[1])) {
//					sexCd = "1";
//					brdt = "19"+brdt;
//				}else if("2".equals(brdtArr[1])) {
//					sexCd = "2";
//					brdt = "19"+brdt;
//				}else if("3".equals(brdtArr[1])) {
//					sexCd = "1";
//					brdt = "20"+brdt;
//				}else if("4".equals(brdtArr[1])) {
//					sexCd = "2";
//					brdt = "20"+brdt;
//				}else if("5".equals(brdtArr[1])) { //혹시나 하는 외국인
//					sexCd = "1";
//					brdt = "19"+brdt;
//				}else if("6".equals(brdtArr[1])) { //혹시나 하는 외국인
//					sexCd = "2";
//					brdt = "19"+brdt;
//				}
//			} else {
//				upldErrVal += "| 주민번호 양식이 잘못 되었습니다.";
//				upldStVal = "3"; //데이터 불일치.
//			}
//			// 2번이면 데이터가 조회 될 수 가 없음. 그냥 Insert 처리.
//			// 기본 정보 가져오기
//			vaccine.setBrdt(brdt);
//			vaccine.setSexCd(sexCd);

			String brdt = BatchUploadUtils.formattedBrdt(upload.getBrdt());
			if( StringUtils.isNotEmpty(brdt) && brdt.length() > 10 ) {
				vaccine.setBrdt(brdt.substring(0, 10));
				vaccine.setSexCd(brdt.substring(10, 11));
			}

			clcoId = examRepo.getMatchClcoId(upload.getClcoNm());
			if( clcoId == null ) {
				upldErrVal += "| 고객사 정보가 존재 하지 않습니다.";
				upldStVal = "3"; //데이터 불일치.
			}
			cuiId = examRepo.getMatchCuiId(upload.getCuiNm());
			if( cuiId == null ) {
				upldErrVal += "| 검진기관 정보가 존재 하지 않습니다.";
				upldStVal = "3"; //데이터 불일치.
			}

			vaccine.setYr(yr);
			vaccine.setClcoNm(BatchUploadUtils.autoFixRvs(upload.getClcoNm()));
			vaccine.setClcoId(clcoId != null ? String.valueOf(clcoId) : null);
			vaccine.setCuiNm(upload.getCuiNm());
			vaccine.setCuiId(cuiId != null ? String.valueOf(cuiId) : null);
			vaccine.setCustNm(upload.getCustNm());
			vaccine.setVcnInctNm(upload.getVcnInctNm());
			vaccine.setVcnInctDt(upload.getVcnInctDt());
			vaccine.setMngrId(String.valueOf(managerDtl.getMngrId()));
			vaccine.setMngrKdCd(managerDtl.getUseDvCd()); // 사용자 종류코드
			vaccine.setFrstRegrId(String.valueOf(managerDtl.getMngrId()));
			vaccine.setFrstRegrTyCd(managerDtl.getFrstRegrTyCd());
			vaccine.setLastUpdrId(String.valueOf(managerDtl.getMngrId()));
			vaccine.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());

			user = vaccineRepo.getVaccineUserMatch(vaccine);

			if(null != user) {

				if(null != user.getUid()) {
					vaccine.setUid(user.getUid());
				}

				if(!user.getVcnNm().equals(upload.getVcnInctNm())) { // 입력받은 백신 정보 체크
					if("0".equals(upldStVal)) { // 앞서 오류가 존재하지 않은 경우
						upldErrVal += "| 접종백신 정보가 일치 하지 않습니다.";
						upldStVal = "3"; //데이터 불일치.
					} else {
						upldErrVal += "| 접종백신 정보가 일치 하지 않습니다.";
						upldStVal = "4"; //데이터 불일치.
					}
				}
				// 고객사 ID, 검진센터 ID 가져오기
				vaccine.setClcoId(user.getClcoId());
				vaccine.setCuiId(user.getCuiId());
			} else {
				if("0".equals(upldStVal)) { // 앞서 오류가 존재하지 않은 경우
					upldErrVal += "| 예약정보가 존재 하지 않습니다.";
					upldStVal = "3"; //데이터 불일치.
				}
			}

			if("0".equals(upldStVal)) {
				upldStVal = "1";
			}
			vaccine.setUpldErrVal(upldErrVal);
			vaccine.setUpldStVal(upldStVal);

			// 인서트 처리함.
			vaccineRepo.insertVaccineBlkHvexHis(vaccine);

			// vaccine.setClcoNm(in.get(i).get);
		}
		// 인서트 이 후 RESV 테이블 업데이트 처리.
		// 중복 여부 체크 하기
		temp = vaccineRepo.getBatchVaccineHisList(vaccine);

		for (int i=0;i<temp.size();i++) {
			vaccine = new BatchVaccineExcelModel();

			vaccine.setMngrId(String.valueOf(managerDtl.getMngrId()));
			vaccine.setLastUpdrId(String.valueOf(managerDtl.getMngrId()));
			vaccine.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());
			vaccine.setYr(yr);
			vaccine.setVcnId(temp.get(i).getVcnId());

			if(2 == temp.get(i).getExcelSameRnk()) {
				String tempTxt = temp.get(i).getUpldErrVal();
				//if (!"| 엑셀에 중복이 존재합니다".contains(tempTxt)) {
				tempTxt = temp.get(i).getUpldErrVal() + "| 엑셀에 중복이 존재합니다";
				//}
				vaccine.setUpldErrVal(tempTxt);
				vaccine.setUpldStVal("4");
				vaccineRepo.updateExcelVaccineDupData(vaccine);
			}
			vaccineRepo.updateExcelVaccineDupNmCheck(vaccine);
		}


		// 예약 테이블 업데이트
		vaccine = new BatchVaccineExcelModel();

		vaccine.setMngrId(String.valueOf(managerDtl.getMngrId()));
		vaccine.setLastUpdrId(String.valueOf(managerDtl.getMngrId()));
		vaccine.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());
		vaccine.setYr(yr);

		// 이거 주석 풀어서 테스트 진행하면 됨.
		vaccineRepo.updateBlkHvexHis(vaccine);

		// 처리 후 결과 가져오기
		vaccine.setGetType("tot");
		int totalCnt = vaccineRepo.getVaccineBlkHvexHisCnt(vaccine);
		totalList = vaccineRepo.getVaccineBlkHvexHis(vaccine);
		vaccine.setGetType("miss");
		missingList = vaccineRepo.getVaccineBlkHvexHis(vaccine);
		vaccine.setGetType("non");
		nonMatchList = vaccineRepo.getVaccineBlkHvexHis(vaccine);
		vaccine.setGetType("etc");
		etcList = vaccineRepo.getVaccineBlkHvexHis(vaccine);

		result.put("totalList", totalList);
		result.put("missingList", missingList);
		result.put("nonMatchList", nonMatchList);
		result.put("etcList", etcList);

		// Cnt 가져오기
		vaccine.setGetType("normal");
		int normalCnt = vaccineRepo.getVaccineBlkHvexHisCnt(vaccine);
		vaccine.setGetType("error");
		int errorCnt = vaccineRepo.getVaccineBlkHvexHisCnt(vaccine);

		result.put("totalCnt", totalCnt);
		result.put("normalCnt", normalCnt);
		result.put("errorCnt", errorCnt);

		result.put("success", "good");
		return result;
	}

	public Map<String, Object> deleteSelectCheckup(List<BatchVaccineExcelModel> in) {
		Map<String, Object> result = new HashMap<>();
		BatchVaccineExcelModel vaccine = new BatchVaccineExcelModel();

		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());

		for(int i=0;i<in.size();i++) {
			vaccine = new BatchVaccineExcelModel();
			vaccine.setVcnId(in.get(i).getVcnId());
			vaccine.setMngrId(String.valueOf(managerDtl.getMngrId())); // 관리자 아이디
			vaccine.setLastUpdrTyCd(managerDtl.getLastUpdrTyCd());

			vaccineRepo.deleteSelectVaccine(vaccine);
		}
		result.put("success", "good");
		return result;
	}

	public Map<String, Object> getBatchVaccineList(BatchVaccineExcelModel vo) {
		Map<String, Object> result = new HashMap<>();

		List<BatchVaccineExcelModel> totalList = new ArrayList<BatchVaccineExcelModel>();
		List<BatchVaccineExcelModel> missingList = new ArrayList<BatchVaccineExcelModel>();
		List<BatchVaccineExcelModel> nonMatchList = new ArrayList<BatchVaccineExcelModel>();
		List<BatchVaccineExcelModel> etcList = new ArrayList<BatchVaccineExcelModel>();

		NcuUserDetail managerDtl = commRepo.getUserDetail(GchcJwtUtil.getUserId());
		vo.setMngrId(String.valueOf(managerDtl.getMngrId())); // 관리자 아이디
		vo.setGetType("tot");
		int totalCnt = vaccineRepo.getVaccineBlkHvexHisCnt(vo);
		totalList = vaccineRepo.getVaccineBlkHvexHis(vo);
		vo.setGetType("miss");
		missingList = vaccineRepo.getVaccineBlkHvexHis(vo);
		vo.setGetType("non");
		nonMatchList = vaccineRepo.getVaccineBlkHvexHis(vo);
		vo.setGetType("etc");
		etcList = vaccineRepo.getVaccineBlkHvexHis(vo);

		result.put("totalList", totalList);
		result.put("missingList", missingList);
		result.put("nonMatchList", nonMatchList);
		result.put("etcList", etcList);

		// Cnt 가져오기
		vo.setGetType("normal");
		int normalCnt = vaccineRepo.getVaccineBlkHvexHisCnt(vo);
		vo.setGetType("error");
		int errorCnt = vaccineRepo.getVaccineBlkHvexHisCnt(vo);

		result.put("totalCnt", totalCnt);
		result.put("normalCnt", normalCnt);
		result.put("errorCnt", errorCnt);
		return result;
	}

	public List<BatchVaccineExcelModel> getVaccineExcelList(BatchVaccineExcelModel src) {
		return vaccineRepo.getVaccineExcelList(src);
	}
}
