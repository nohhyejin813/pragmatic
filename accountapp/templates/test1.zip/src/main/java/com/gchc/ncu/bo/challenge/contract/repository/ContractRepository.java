package com.gchc.ncu.bo.challenge.contract.repository;

import com.gchc.ncu.bo.care.models.CmpgBscModel;
import com.gchc.ncu.bo.care.models.CmpgCtraBscModel;
import com.gchc.ncu.bo.care.vo.CareCampaignVo;
import com.gchc.ncu.bo.challenge.contract.models.*;
import com.gchc.ncu.bo.challenge.contract.vo.ContractVo;
import com.gchc.ncu.bo.challenge.theme.models.ThmBscModel;
import com.gchc.ncu.bo.chronic.progress.models.SvcMsnModel;
import com.gchc.ncu.bo.chronic.progress.models.SvcMsnSearchModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface ContractRepository {

	/*
	 * 챌린지 계약
	 * */
	List<ChalCmpgCtraBscModel> selectContractList(ContractVo vo);

	ChalCmpgCtraBscModel selectContractDetail(ContractVo vo);
	List<Map<String, Object>> selectSurveyList(Map<String, Object> model);

	int selectChallengeClientCount(ChalCmpgCtraBscModel model);
	int selectChallengeWorkplaceCount(ChalCmpgCtraBscModel model);
	void insertChallengeContract(ChalCmpgCtraBscModel model);
	void updateChallengeContract(ChalCmpgCtraBscModel model);

	int selectUsedChallengeContractCount(int cmpgCtraId);
	void deleteChallengeRewardByCmpgId(int cmpgId);
	void deleteChallengeNotificationByCmpgId(int cmpgCtraId);

	List<ChalCmpgBscModel> selectContractCheck(ChalCmpgBscModel model);
	void deleteChallengeContract(int cmpgCtraId);




	/*
	 * 챌린지 차수
	 * */

	List<ChalCmpgBscModel> selectContractTermList(ContractVo vo);
	ChalCmpgBscModel selectContractTermDetail(ContractVo vo);
	int selectUsedChallengeMemberCount(int cmpgId);
	int selectOverlappedDateCount(ChalCmpgBscModel model);
	void insertContractTerm(ChalCmpgBscModel model);
	void updateContractTerm(ChalCmpgBscModel model);

	List<ChalCmpgBscModel> selectContractTermCheck(ChalCmpgBscModel model);
	void deleteContractTerm(int cmpgId);






}
