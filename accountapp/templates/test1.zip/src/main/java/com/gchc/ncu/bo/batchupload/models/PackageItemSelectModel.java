package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class PackageItemSelectModel extends UstraManagementBaseModel {


	// 메인 데이터 -----------------------------------------------------------
	private int pkgId;			// 패키지 아이디
	private String pkgNm;		// 패키지 명
	private String yr;			// 연도
	private int clcoId;			// 고객사 아이디
	private String sbmtSrtDtm;	// 시작일자
	private String sbmtEndDtm;	// 종료일자
	private int cuiCnt;			// 검진기관 수


	// 상세 데이터 -----------------------------------------------------------
	private int cuiId;			// 검진기관 아이디
	private String cuiNm;		// 검진기관 명
	private int useYn;			// 사용여부
	private int prc;			// 금액
	private int pkgTyId;		// 패키지 타입 아이디
	private String pkgTyNm;		// 패키지 타입명
	private String pkgTyNknm;
}
