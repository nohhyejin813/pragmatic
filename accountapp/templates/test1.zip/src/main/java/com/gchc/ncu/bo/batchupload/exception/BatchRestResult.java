package com.gchc.ncu.bo.batchupload.exception;

import java.util.Map;

import com.gsitm.ustra.java.core.exception.ResponseCode;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.comm.code.NcuResponseCode;

public class BatchRestResult {

	static public RestResult<Map<String, String>> of(ResponseCode code) {

		return GchcRestResult.of(UstraMapUtils.getMap(
			"code", code.getCode(),
			"message", code.getMessage()), GchcResponseCode.SUCCESS);
	}

	static public RestResult<Map<String, String>> of(String code, String message) {

		return GchcRestResult.of(UstraMapUtils.getMap(
			"code", code,
			"message", message), GchcResponseCode.SUCCESS);
	}

	public static Object of(NcuResponseCode code, Map<String, Object> result) {

		return GchcRestResult.of(UstraMapUtils.getMap(
			"code", code.getCode(),
			"message", code.getMessage(),
			"result", result));
	}
}
