package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum PackageTypeAddColumn implements BatchUploadColumn {

	CAT_NM("카테고리", "ItmCatNm"),

	SUB_CAT_NM("검진세부항목", "DtlCatItmNm"),

	EXAM_NM("검사명", "ExamNm"),

	ITM_PRC("추가검사선택시비용", "ItmPrc"),

	ETC("비고", "Etc")

	;

	String title;

	String field;

	PackageTypeAddColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
