package com.gchc.ncu.bo.admin.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ClientPaymentModel {
	private int 	clcoId;
	private int 	clcoCtraId;
	private String 	clcoNm;
	private String 	yr;

	private String 	goodsName;
	private String 	amt;
	private String 	mid;
	private String 	ediDate;
	private String 	moid;
	private String 	signData;
	private String 	buyerName;
	private String 	buyerTel;
	private String 	payMethod;
	private String 	buyerEmail;
	private String 	currencyCode;
	private String 	transType;
	private String 	charSet;
	private String 	verifySType;
	private String 	encGoodsName;
	private String 	encBuyerName;
	private String 	npDirectYn;
	private String 	npDirectLayer;
	private String 	jsVer;
	private String 	npSvcType;
	private String 	deployedVer;
	private String 	deployedDate;
	private String 	deployedFileName;
	private String 	encVbankAccountName;
	private String 	authResultCode;
	private String 	authResultMsg;
	private String 	authToken;
	private String 	txTid;
	private String 	nextAppURL;
	private String 	netCancelURL;
	private String 	signature;
	private String 	cancelAmt;
	private String  logoImage;
	private String  netCancel;
	private String  tranReqData;
	private String  tranResData;
	private String  ctraSrtDt;
	private String  ctraEndDt;
	private String  cuImplSrtDt;	// 검진시작일자
	private String  cuImplEndDt;	// 검진종료일자
	private String  stlTyCd;
}
