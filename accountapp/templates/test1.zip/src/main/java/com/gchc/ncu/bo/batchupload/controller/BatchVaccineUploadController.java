package com.gchc.ncu.bo.batchupload.controller;

import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.batchupload.enu.VaccineExaminationUploadState;
import com.gchc.ncu.bo.batchupload.models.BatchVaccineExcelModel;
import com.gchc.ncu.bo.batchupload.models.ExaminationExcelDownModel;
import com.gchc.ncu.bo.batchupload.models.XlsDownloadHistModel;
import com.gchc.ncu.bo.batchupload.service.BatchVaccineService;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.service.CommonService;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@RequiredArgsConstructor
@Api(tags = "백신 수검 일괄업로드 컨트롤러")
@RestController
@RequestMapping("/api/bo/batchupload")
public class BatchVaccineUploadController {

	@Autowired private FileOperationManager fileOperationManager;

	@Autowired private CommonService commonService;

	private final BatchVaccineService vaccineService;

	@Autowired private BatchXlsHistProcess batchXlsHistProcess;

//	@SuppressWarnings("null")
//	@PostMapping("/vaccine/checkup")
//	@ApiOperation(value="수검(수검완료) 일괄업로드 유효성 체크", notes="수검(수검완료) 일괄업로드 유효성을 체크한다.")
//	public Map<String, Object> validateExcelCheckupExamination(@RequestBody List<PreUploadVaccineModel> in) {
//		Map<String, Object> result = new HashMap<>();
//
//		//result = examinationService.setCheckupExaminationData(in);
//		result = vaccineService.setCheckupVaccineData(in);
//		//result.put("success", "good");
//		return result;
//	}

	@SuppressWarnings("null")
	@PostMapping("/vaccine/deleteSelectCheckup")
	@ApiOperation(value="수검완료 목록 삭제", notes="수검완료 목록 삭제한다.")
	public Map<String, Object> deleteSelectCheckup(@RequestBody List<BatchVaccineExcelModel> in) {
		Map<String, Object> result = new HashMap<>();

		result = vaccineService.deleteSelectCheckup(in);
		return result;
	}

	@SuppressWarnings("null")
	@PostMapping("/vaccine/getBatchVaccineList")
	@ApiOperation(value="수검완료 목록 조회", notes="수검완료 목록 조회한다.")
	public Map<String, Object> getBatchVaccineList(@RequestBody BatchVaccineExcelModel vo) {
		Map<String, Object> result = new HashMap<>();
		result = vaccineService.getBatchVaccineList(vo);
		return result;
	}

	@PostMapping("/vaccine/selected_download_excel")
	public ResponseEntity<?> selectedDownloadExcelExamination(@RequestBody List<BatchVaccineExcelModel> in, HttpServletRequest request, HttpServletResponse response) {
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		String datStCd = "";

		// System.out.println("############# excelList.size = "+examinationList.size());
		String brdtArr[];
		String bryr = "";
		String brdt = "";
		String sexCd = "";

		// 2. 공통백신결과 List MAP 처리
		for(int i=0; i<in.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			BatchVaccineExcelModel exMap = in.get(i);				// 수검완료 체크 리스트
			if(!ObjectUtils.isEmpty(exMap.getBrdt())) {
				sexCd = exMap.getSexCd();
				brdtArr = exMap.getBrdt().split("-");
				bryr = brdtArr[0].substring(0,2); // ex 1981-12-13 -> 19  출생년도 앞자리 두개 추출
				brdt = brdtArr[0].substring(2) + brdtArr[1] + brdtArr[2]; // 엑셀 업로드 양식 811213 형태로 변경
				if("1".equals(sexCd)) {
					if("19".equals(bryr)) {
						brdt = brdt + "-1";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-3";
					}
				} else {
					if("19".equals(bryr)) {
						brdt = brdt + "-2";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-4";
					}
				}
			}
			System.out.println(brdt);
			map.put("col1"	, exMap.getClcoNm());		// 고객사명
			map.put("col2"	, exMap.getCuiNm());		// 검진센터명
			map.put("col3"	, exMap.getCustNm());		// 이름
			map.put("col4"	, brdt);					// 생일
			map.put("col5"	, exMap.getVcnInctNm());	// 접종백신
			map.put("col6"	, exMap.getVcnInctDt());	// 접종일자
			map.put("col7"	, exMap.getUid());			// MemberId

			list.add(map);
		}
		System.out.println("#### list = "+list.toString());

		String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
		String pageNm = "백신-수검완료";
		String cont = "고객사명, 검진센터명, 이름, 주민번호, 접종백신, 접종일자, MemberId";

		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		histModel.setDwldPageUrl(tagretUrl);
		histModel.setInnfVwCnt(list.size());
		histModel.setDwldPageNm(pageNm);
		histModel.setDwldCont(cont);
		histModel.setDwldCustNm(list.get(0).get("col3").toString());
		batchXlsHistProcess.insertHistXlsDownload(histModel);

		// 3. 헤더 값   매핑
		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사명"),
				new UstraExcelCellInfoModel("col2"	, "검진센터명"),
				new UstraExcelCellInfoModel("col3"	, "이름"),
				new UstraExcelCellInfoModel("col4"	, "주민번호"),
				new UstraExcelCellInfoModel("col5"	, "접종백신"),
				new UstraExcelCellInfoModel("col6"	, "접종일자"),
				new UstraExcelCellInfoModel("col7"	, "MemberId")
			))
//		.withCellGenerator(new com.gsitm.ustra.java.data.poi.generator.ColoredHeaderUstraExcelCellGenerator())	// 색칠
//		.withAdditionalData("data", commVcnList)
//		.withTitle("공통백신정보")		// 제목
		.withCellGenerator(new BatchUploadCellGenerator(getSpecialCellList()))
		.withSheetName("백신수검");	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel), "백신수검완료", request, response)
				.build());
	}

	@PostMapping("/vaccine/download_excel")
	public ResponseEntity<?> excelDownload(@RequestBody ExaminationExcelDownModel in, HttpServletRequest request, HttpServletResponse response) {
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		//ExaminationSrcModel src = new ExaminationSrcModel();
		BatchVaccineExcelModel src = new BatchVaccineExcelModel();
		// 1. 결과 목록호출 resultFlag (0:전체, 1:성공, 2:에러)
		NcuUserDetail managerDtl = commonService.getUserDetail(GchcJwtUtil.getUserId());
		System.out.println("##### getResultFlag() = "+in.getResultFlag());

		// SPARROW 1490518,1490519,1490520 FORBIDEN_ASSIGN_LITERAL
		VaccineExaminationUploadState datStCd = VaccineExaminationUploadState.ETC;
		if("0".equals(in.getResultFlag())) { // 전체
			datStCd = VaccineExaminationUploadState.ALL;
		} else if("1".equals(in.getResultFlag())) { // 성공
			datStCd = VaccineExaminationUploadState.SUCCESS;
		} else { // 에러 목록만.
			datStCd = VaccineExaminationUploadState.ERROR;
		}
		src.setMngrId(String.valueOf(managerDtl.getMngrId()));
		src.setGetType(datStCd.getValue());
		src.setYr(Integer.parseInt(in.getYr()));

		//List<PackageUploadExcelModel> pkgList = examinationService.getPackageExcelList(in);
		List<BatchVaccineExcelModel> vaccineList = vaccineService.getVaccineExcelList(src);
		System.out.println("############# excelList.size = "+vaccineList.size());
		String brdtArr[];
		String bryr = "";
		String brdt = "";
		String sexCd = "";

		// 2. 공통백신결과 List MAP 처리
		for(int i=0; i<vaccineList.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			BatchVaccineExcelModel exMap = vaccineList.get(i);				// 패키지 조회결과 리스트
			if(!ObjectUtils.isEmpty(exMap.getBrdt())) {
				sexCd = exMap.getSexCd();
				brdtArr = exMap.getBrdt().split("-");
				bryr = brdtArr[0].substring(0,2); // ex 1981-12-13 -> 19  출생년도 앞자리 두개 추출
				brdt = brdtArr[0].substring(2) + brdtArr[1] + brdtArr[2]; // 엑셀 업로드 양식 811213 형태로 변경
				if("1".equals(sexCd)) {
					if("19".equals(bryr)) {
						brdt = brdt + "-1";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-3";
					}
				} else {
					if("19".equals(bryr)) {
						brdt = brdt + "-2";
					} else if("20".equals(bryr)) {
						brdt = brdt + "-4";
					}
				}
			}

			System.out.println(brdt);
			map.put("col1"	, exMap.getClcoNm());		// 고객사명
			map.put("col2"	, exMap.getCuiNm());		// 검진센터명
			map.put("col3"	, exMap.getCustNm());		// 이름
			map.put("col4"	, brdt);					// 생일
			map.put("col5"	, exMap.getVcnInctNm());	// 접종백신
			map.put("col6"	, exMap.getVcnInctDt());	// 접종일자
			map.put("col7"	, exMap.getUid());			// MemberId

			list.add(map);
		}
		System.out.println("#### list = "+list.toString());

		String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
		String pageNm = "백신-수검완료";
		String cont = "고객사명, 검진센터명, 이름, 주민번호, 접종백신, 접종일자, MemberId";

		XlsDownloadHistModel histModel = new XlsDownloadHistModel();
		histModel.setDwldPageUrl(tagretUrl);
		histModel.setInnfVwCnt(list.size());
		histModel.setDwldPageNm(pageNm);
		histModel.setDwldCont(cont);
		histModel.setDwldCustNm(list.get(0).get("col3").toString());
		batchXlsHistProcess.insertHistXlsDownload(histModel);

		// 3. 헤더 값   매핑
		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사명"),
				new UstraExcelCellInfoModel("col2"	, "검진센터명"),
				new UstraExcelCellInfoModel("col3"	, "이름"),
				new UstraExcelCellInfoModel("col4"	, "주민번호"),
				new UstraExcelCellInfoModel("col5"	, "접종백신"),
				new UstraExcelCellInfoModel("col6"	, "접종일자"),
				new UstraExcelCellInfoModel("col7"	, "MemberId")
			))
//		.withCellGenerator(new com.gsitm.ustra.java.data.poi.generator.ColoredHeaderUstraExcelCellGenerator())	// 색칠
//		.withAdditionalData("data", commVcnList)
//		.withTitle("공통백신정보")		// 제목
		.withCellGenerator(new BatchUploadCellGenerator(getSpecialCellList()))
		.withSheetName("백신수검완료");	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel), "백신수검완료", request, response)
				.build());
	}

	@PostMapping("/vaccine/vaccine_template_download")
	public ResponseEntity<?> excelTemplateDownload(@RequestBody ExaminationExcelDownModel in, HttpServletRequest request, HttpServletResponse response) {
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		//ExaminationSrcModel src = new ExaminationSrcModel();
		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사명"),
				new UstraExcelCellInfoModel("col2"	, "검진센터명"),
				new UstraExcelCellInfoModel("col3"	, "이름"),
				new UstraExcelCellInfoModel("col4"	, "주민번호"),
				new UstraExcelCellInfoModel("col5"	, "접종백신"),
				new UstraExcelCellInfoModel("col6"	, "접종일자"),
				new UstraExcelCellInfoModel("col7"	, "MemberId")
		))
		.withCellGenerator(new BatchUploadCellGenerator(getSpecialCellList()))
		.withSheetName("백신수검완료");	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
				.entityBuilder(Arrays.asList(excelModel), "일괄업로드백신수검등록_V3_2", request, response)
				.build());
	}

	private List<String> getSpecialCellList() {
		return Arrays.asList(
				"고객사명",
				"검진센터명",
				"이름",
				"주민번호",
				"접종백신",
				"접종일자"
			);
	}
}
