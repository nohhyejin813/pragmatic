package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PainDiseaseVo extends UstraManagementBaseModel {

	private String diseaseNm;
	private String ageGroupCd;
	private String sexCd;
	private String adltChldDssDvCd;
	private String epidDvCd;
	private String useYn;


}
