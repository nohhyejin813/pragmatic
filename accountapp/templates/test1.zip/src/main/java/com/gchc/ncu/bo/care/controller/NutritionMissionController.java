package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.NtrtMsnBscModel;
import com.gchc.ncu.bo.care.service.NutritionMissionService;
import com.gchc.ncu.bo.care.vo.NutritionMissionVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/nutrition/mission")
@RequiredArgsConstructor
public class NutritionMissionController {

	private final NutritionMissionService missionService;

	@GetMapping("/list")
	public List<NtrtMsnBscModel> list(@ModelAttribute NutritionMissionVo criteria) {
		return missionService.getNutritionMissionList(criteria);
	}

	@GetMapping("/detail")
	public NtrtMsnBscModel detail(@ModelAttribute NtrtMsnBscModel criteria) {
		return missionService.getNutritionMissionDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid NtrtMsnBscModel model) {
		missionService.saveNutritionMissionBase(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<NtrtMsnBscModel> list) {
		missionService.deleteNutritionMissionBase(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
