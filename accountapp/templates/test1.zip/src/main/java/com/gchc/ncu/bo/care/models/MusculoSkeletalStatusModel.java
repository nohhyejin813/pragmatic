package com.gchc.ncu.bo.care.models;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MusculoSkeletalStatusModel {

	private String muscEsnCd;
	private Integer joinCnt;
	private Integer totCnt;
	private Double joinRt;

}
