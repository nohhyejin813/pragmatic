package com.gchc.ncu.bo.assessment.vo;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.gchc.ncu.bo.assessment.models.AssessmentFileModel;
import com.gchc.ncu.bo.assessment.models.AssessmentTargetModel;
import com.gchc.ncu.bo.assessment.models.AssessmentQuestionModel;
import com.gchc.ncu.bo.assessment.models.AssessmentScoreModel;
import com.gchc.ncu.bo.assessment.models.AssessmentStatusModel;
import com.gsitm.ustra.java.mvc.rest.model.RestVo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@RequiredArgsConstructor
public class AssessmentQuestionTypeVo extends RestVo {

	private int								qstTyCd; //CUI_ASM_QST_ID
	private String							qstTyNm;

	private List<AssessmentQuestionVo> 		qstList;

	private boolean							hideYn;
	private boolean							delYn;
	private boolean							chkYn;

	private	boolean							inserted;
	private	boolean							updated;
	private	boolean							deleted;

	@java.beans.ConstructorProperties({"qstTyCd", "qstTyNm", "qstList"})
	public AssessmentQuestionTypeVo(int qstTyCd, String qstTyNm, List<AssessmentQuestionVo> qstList) {
		this.qstTyCd = qstTyCd;
		this.qstTyNm = qstTyNm;
		this.qstList = qstList;
	}

}