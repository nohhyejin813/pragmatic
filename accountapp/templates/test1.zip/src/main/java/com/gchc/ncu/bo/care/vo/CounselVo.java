package com.gchc.ncu.bo.care.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Map;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
public class CounselVo extends UstraManagementBaseModel {

	private String cnslTmcDvCd;
	private Integer clcoId;
	private String ctraSrtDt;
	private String ctraEndDt;
	private Integer midCnslCtraId;
	private String applSrtDt;
	private String applEndDt;
	private String mbrNm;
	private String midCnslStCd;
	private String answerSrtDt;
	private String answerEndDt;

	private Map<String, String> dwldInfo;

}
