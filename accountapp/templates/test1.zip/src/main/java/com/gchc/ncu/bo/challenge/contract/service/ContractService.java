package com.gchc.ncu.bo.challenge.contract.service;

//import com.gchc.ncu.bo.care.models.*;
import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.CmpgBscModel;
import com.gchc.ncu.bo.care.models.CmpgCtraBscModel;
import com.gchc.ncu.bo.care.vo.CareCampaignVo;
import com.gchc.ncu.bo.challenge.contract.models.*;
import com.gchc.ncu.bo.challenge.contract.repository.ContractRepository;

		import com.gchc.ncu.bo.challenge.contract.vo.ContractVo;
import com.gchc.ncu.bo.challenge.theme.models.ThmBscModel;
import com.gchc.ncu.bo.chronic.progress.models.SvcMsnModel;
import com.gchc.ncu.bo.chronic.progress.models.SvcMsnSearchModel;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ContractService {


	private final ContractRepository contractRepository;

	/*
	 * 챌린지 계약
	 * */
	public List<ChalCmpgCtraBscModel> getContractList(ContractVo vo) {
		if (vo.getCmpgCd() == null || vo.getCmpgCd().equals("")){
			vo.setCmpgCd("12");
		}
		return contractRepository.selectContractList(vo);
	}

	public ChalCmpgCtraBscModel getContractDetail(ContractVo vo) {
		if (vo.getCmpgCd() == null || vo.getCmpgCd().equals("")){
			vo.setCmpgCd("12");
		}
		return contractRepository.selectContractDetail(vo);
	}

	public List<Map<String, Object>> getSurveyList(Map<String, Object> model) {
		return contractRepository.selectSurveyList(model);
	}


	public void setChallengeContract(ChalCmpgCtraBscModel model) {
//		int checkClientCount = contractRepository.selectChallengeClientCount(model);
//
//		if (checkClientCount >= 1) {
//			String checkContractMessage = "이미 계약된 고객사 또는 사업장 입니다.";
//
//			if (model.getBsplId() == null) {
//				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, checkContractMessage);
//			}
//
//			int checkWorkplaceCount = contractRepository.selectChallengeWorkplaceCount(model);
//
//			if (checkWorkplaceCount >= 1) {
//				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, checkContractMessage);
//			}
//		}

		if (model.getCmpgCtraId() == null) {
			contractRepository.insertChallengeContract(model);
		} else {
			contractRepository.updateChallengeContract(model);
		}
	}

	public List<ChalCmpgBscModel> getContractCheck(ChalCmpgBscModel model) {
		return contractRepository.selectContractCheck(model);
	}

	@Transactional
	public void removeChallengeContract(List<ChalCmpgCtraBscModel> models) {
		for (ChalCmpgCtraBscModel model : models) {
			int usedCount = contractRepository.selectUsedChallengeContractCount(model.getCmpgCtraId());

			if (usedCount > 0) {
				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "회원 활동 이력이 존재하는 챌린지 차수입니다.");
			}

			ContractVo vo = new ContractVo();
			vo.setCmpgCtraId(model.getCmpgCtraId());

			List<ChalCmpgBscModel> getTermList = getContractTermList(vo);

			for (ChalCmpgBscModel termModel : getTermList) {
				contractRepository.deleteChallengeRewardByCmpgId(termModel.getCmpgId());
				contractRepository.deleteChallengeNotificationByCmpgId(termModel.getCmpgId());
				contractRepository.deleteContractTerm(termModel.getCmpgId());
			}

			contractRepository.deleteChallengeContract(model.getCmpgCtraId());
		}
	}


	/*
	 * 챌린지 차수
	 * */
	public List<ChalCmpgBscModel> getContractTermList(ContractVo vo) {
		return contractRepository.selectContractTermList(vo);
	}

	public ChalCmpgBscModel getContractTermDetail(ContractVo vo) {
		return contractRepository.selectContractTermDetail(vo);
	}


	@Transactional
	public void setContractTerm(ChalCmpgBscModel model) {
//			if (model.getRowStatus().equals("D")) {
//				int checkCount = contractRepository.selectUsedChallengeMemberCount(model.getCmpgId());
//
//				if (checkCount > 0) {
//					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "회원 활동 이력이 존재하는 캠페인입니다.");
//				}
//
//				contractRepository.deleteContractTerm(model.getCmpgId());
//			} else {

				// 챌린지 계약 종료일이 차수 종료일보다 커야함.(종료된 계약에 차수 등록이 되면 안됨)
				int checkCount = contractRepository.selectOverlappedDateCount(model);

				if (checkCount > 0 && model.getRowStatus().equals("C")) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "챌린지 차수 종료일이 챌린지 계약 종료일보다 큽니다. <br>챌린지 계약 진행기간을 확인해 주세요.");
				}

				if (model.getCmpgId() == null || model.getRowStatus().equals("C")) {
					contractRepository.insertContractTerm(model);
				} else {
					contractRepository.updateContractTerm(model);
				}
//			}
	}


	public List<ChalCmpgBscModel> getContractTermCheck(ChalCmpgBscModel model) {
		return contractRepository.selectContractTermCheck(model);
	}

	@Transactional
	public void removeContractTerm(List<ChalCmpgBscModel> models) {
		for (ChalCmpgBscModel model : models) {
			if (model.getRowStatus().equals("D")) {
				int checkCount = contractRepository.selectUsedChallengeMemberCount(model.getCmpgId());

				if (checkCount > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "회원 활동 이력이 존재하는 캠페인입니다.");
				}
				contractRepository.deleteContractTerm(model.getCmpgId());
			}
		}
	}






}
