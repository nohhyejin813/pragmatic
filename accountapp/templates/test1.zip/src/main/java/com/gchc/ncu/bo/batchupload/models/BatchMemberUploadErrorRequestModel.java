package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuPageableVo;

@Getter
@Setter
public class BatchMemberUploadErrorRequestModel extends NcuPageableVo {

	private Integer clcoId;

	private Integer yr;

	private Integer mngrId;

	private String regDvVal;

	private Integer state;
}
