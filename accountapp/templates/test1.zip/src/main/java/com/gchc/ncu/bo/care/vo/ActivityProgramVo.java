package com.gchc.ncu.bo.care.vo;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ActivityProgramVo extends UstraManagementBaseModel {

	private Integer diseaseId;
	private Integer programId;
	private String programNm;

}
