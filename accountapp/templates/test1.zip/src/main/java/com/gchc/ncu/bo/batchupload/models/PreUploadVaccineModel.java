package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class PreUploadVaccineModel {
	private Integer errCol;
	private String error;
	private BatchUploadExcelVaccineModel object;
	private Boolean parsed;
	private Integer row;
	private String src;

	private Integer yr;
}
