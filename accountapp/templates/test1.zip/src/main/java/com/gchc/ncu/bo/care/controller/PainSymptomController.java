package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.NrsnClsfSxRltnModel;
import com.gchc.ncu.bo.care.models.NrsnDssSxRltnModel;
import com.gchc.ncu.bo.care.models.NrsnSxBscModel;
import com.gchc.ncu.bo.care.service.PainSymptomService;
import com.gchc.ncu.bo.care.vo.PainSymptomVo;

@RestController
@RequestMapping("/api/bo/care/pain/symptom")
@RequiredArgsConstructor
public class PainSymptomController {

	private final PainSymptomService painSymptomService;

	@GetMapping("/list")
	public List<NrsnSxBscModel> list(@ModelAttribute PainSymptomVo criteria) {
		return painSymptomService.getSymptomList(criteria);
	}

	@GetMapping("/detail")
	public NrsnSxBscModel detail(@ModelAttribute NrsnSxBscModel criteria) {
		return painSymptomService.getSymptomDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody NrsnSxBscModel model) {
		painSymptomService.saveSymptom(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<NrsnSxBscModel> list) {
		painSymptomService.deleteSymptom(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/list/part")
	public List<NrsnClsfSxRltnModel> listPart(@ModelAttribute NrsnSxBscModel criteria) {
		return painSymptomService.getSymptomPartList(criteria);
	}

	@PostMapping("/save/{nrsnSxId}/part")
	public RestResult<?> savePart(@PathVariable(name = "nrsnSxId", required = true) int nrsnSxId, @RequestBody List<NrsnClsfSxRltnModel> list) {
		painSymptomService.saveSymptomPart(nrsnSxId, list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/list/disease")
	public List<NrsnDssSxRltnModel> listDisease(@ModelAttribute NrsnSxBscModel criteria) {
		return painSymptomService.getSymptomDiseaseList(criteria);
	}

	@PostMapping("/save/{nrsnSxId}/disease")
	public RestResult<?> saveDisease(@PathVariable(name = "nrsnSxId", required = true) int nrsnSxId, @RequestBody List<NrsnDssSxRltnModel> list) {
		painSymptomService.saveSymptomDisease(nrsnSxId, list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}



}
