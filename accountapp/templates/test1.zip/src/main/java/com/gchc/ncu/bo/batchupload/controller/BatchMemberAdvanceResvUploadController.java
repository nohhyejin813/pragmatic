package com.gchc.ncu.bo.batchupload.controller;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.batchupload.service.BatchMemberAdvanceResvUploadService;
import com.gchc.ncu.bo.comm.models.CommonParametersModel;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.file.model.FileConvertInput;
import com.gsitm.ustra.java.data.file.processor.convert.LocalExcelFileToDataConverter;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @FileName : BatchMemberAdvanceResvUploadController.java
 * @date : 2022. 06. 10
 * @author : 이광희
 * @프로그램 설명 : 선예약 일괄업로드 Controller
 * @변경이력 :
 */

@RequiredArgsConstructor
@Api(tags = "선예약 일괄업로드 컨트롤러")
@RestController
@RequestMapping("/api/bo/batchupload/advanceresv")
public class BatchMemberAdvanceResvUploadController {

	@Autowired
	private FileOperationManager fileOperationManager;

	@Autowired
	private BatchMemberAdvanceResvUploadService service;

	@Autowired private BatchXlsHistProcess batchXlsHistProcess;


	@PostMapping("/result")
	public BatchMemberAdvanceResvUploadResultModel result(@RequestBody BatchMemberUploadResultRequestModel in) {

		return service.getResult(in);
	}

	@GetMapping("/clco")
	public List<CommonParametersModel> getClcoList(@ModelAttribute CommonParametersModel model) {
		return service.getClcoList(model);
	}

	@PostMapping("/error-list")
	public RestResult<List<BatchMemberUploadAdvanceResvModel>> duplicatedErrorList(@RequestBody BatchMemberUploadErrorRequestModel in) {

		return GchcRestResult.of(service.getErrorList(in));
	}

	@PostMapping("/init")
	public void init(@RequestBody BatchMemberUploadInitRequestModel in) {

		service.init(in);
	}

	@PostMapping("/remove")
	public void remove(@RequestBody List<BatchMemberUploadAdvanceResvModel> in) {

		service.remove(in);
	}

	@PostMapping("remove-all")
	public void removeAll(@RequestBody CustomerExcelDownModel in) {

		service.removeAll(in);
	}

	@PostMapping("/check-reserve")
	public BatchMemberUploadReserveInfoModel checkReserve(@RequestBody BatchMemberUploadRegistRequestModel in) {

		return service.checkReserve(in);
	}

	@PostMapping("/regist")
	public void regist(@RequestBody BatchMemberUploadRegistRequestModel in) throws IOException {

		service.regist(in);
	}

	@PostMapping("/regist-uploaded-member")
	public void registUploadedMember(@RequestBody BatchMemberUploadRegistRequestModel in) throws IOException {

		service.registUploadedMember(in);
	}

	@SuppressWarnings("null")
	@PostMapping("/validate")
	@ApiOperation(value="고객(일반) 일괄업로드 유효성 체크", notes="고객(일반) 일괄업로드 유효성을 체크한다.")
	public BatchMemberAdvanceResvUploadResultModel validateExcelResultCustomer(@RequestBody BatchMemberUploadValidateRequestModel in) {

		// Excel convert
		FileConvertInput<LocalExcelFileToDataConverter.Option, List<RowInfo>> converter =
			LocalExcelFileToDataConverter.builder(in.getFileGrpId(), true, BatchUploadAdvanceResvExcelModel.class)
				.metaDataId(FileConvertInput.FileMetaId.builder().fileId(in.getFileId()).fileNos(Arrays.asList(in.getFileNo())).build())
				.build();
		List<RowInfo> converted = fileOperationManager.convert(converter);

		final int clcoId = in.getClcoId();
		final int yr = in.getYr();

		return service.uploadMember(converted, clcoId, yr, 1, 1, 0);
	}

	@PostMapping("/download-duplicated-customer")
	public ResponseEntity<?> downloadDuplicatedCustomer(@RequestBody CustomerExcelDownModel in, HttpServletRequest request, HttpServletResponse response) throws Exception {

		return convertDuplicatedExcel(service.selectDuplicatedCustomer(in), request, response);
	}

	@PostMapping("/download-duplicated-list")
	public ResponseEntity<?> downloadDuplicated(@RequestBody List<BatchMemberUploadAdvanceResvModel> in, HttpServletRequest request, HttpServletResponse response) {

		return convertDuplicatedExcel(service.selectDuplicatedCustomerList(in), request, response);
	}

	ResponseEntity<?> convertDuplicatedExcel(List<BatchAdvanceResvExcelModel> customerList, HttpServletRequest request, HttpServletResponse response) {

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		for(int i=0;i<customerList.size();i++) {

			Map<String, Object> map = new TreeMap<>();
			BatchAdvanceResvExcelModel exMap = customerList.get(i); // 리스트 셋팅

			map.put("col1", exMap.getClcoCode()); 			// 고객사코드
			map.put("col2", exMap.getAempNm()); 			// 임직원이름
			map.put("col3", exMap.getCorpSpfnVal()); 			// 임직원회사지원금
			map.put("col4", exMap.getTn1ResvApplDt()); 		// 검진예약일자
			map.put("col5", exMap.getAempCuGrdNm()); 		// 임직원등급
			map.put("col6", exMap.getAempBrdt()); 			// 임직원생년월일
			map.put("col7", exMap.getMblNo()); 				// 임직원핸드폰번호
			map.put("col8", exMap.getEmlAdr()); 			// 임직원이메일
			map.put("col9", exMap.getExcuYn()); 			// 임원여부
			map.put("col10", exMap.getNhicSuptTgtYn()); 	// 공단지원여부 nhicSuptTgtYn
			map.put("col11", exMap.getSpcuTgtYn()); 		// 특수검진여부 spcuTgtYn
			map.put("col12", exMap.getExtrMttrNm1()); 		// 특수물질(1차) extrMttrNm1
			map.put("col13", exMap.getExtrMttrNm2()); 		// 특수물질(2차) extrMttrNm2
			map.put("col14", exMap.getDeptNm1()); 			// 부서 deptNm
			map.put("col15", exMap.getJbgdNm()); 			// 직급 jbgdNm
			map.put("col16", exMap.getAempId()); 			// 사번
			map.put("col17", exMap.getWrplTlno()); 			// 직장 전화 wrplTlno
			map.put("col18", exMap.getEncmDt()); 			// 입사일
			map.put("col20", exMap.getSpsrNm()); 			// 가족이름 spsrNm
			map.put("col21", exMap.getSpsrCuGrdNm()); 		// 가족검진등급 spsrCuGrdNm
			map.put("col22", exMap.getSpsrBrdt()); 			// 가족생년월일 spsrBrdt
			map.put("col23", exMap.getSpsrCorpSpfn()); 		// 가족지원금 spsrCorpSpfn
			map.put("col24", exMap.getSpsrNo()); 			// 가족연락처 spsrNo
			map.put("col25", exMap.getSpsrCmt()); 			// 가족비고
			map.put("col26", exMap.getBsplNm()); 			// 사업장 bsplNm

			map.put("col27", exMap.getOldAempNm());
			map.put("col28", exMap.getOldAempId());
			map.put("col29", exMap.getOldAempBrdt());
			map.put("col30", exMap.getOldAempSexCd());

			list.add(map);
		}

		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "고객사코드"),
				new UstraExcelCellInfoModel("col2"	, "임직원이름"),
				new UstraExcelCellInfoModel("col3"	, "임직원회사지원금"),
				new UstraExcelCellInfoModel("col4"	, "검진예약일자"),
				new UstraExcelCellInfoModel("col5"	, "임직원등급"),
				new UstraExcelCellInfoModel("col6"	, "임직원생년월일"),
				new UstraExcelCellInfoModel("col7"	, "임직원핸드폰번호"),
				new UstraExcelCellInfoModel("col8"	, "임직원이메일"),
				new UstraExcelCellInfoModel("col9"	, "임원여부(Y/N)"),
				new UstraExcelCellInfoModel("col10"	, "건강보험공단지원대상여부(Y/N)"),
				new UstraExcelCellInfoModel("col11"	, "특수검진대상여부(Y/N)"),
				new UstraExcelCellInfoModel("col12"	, "특수물질(1차)"),
				new UstraExcelCellInfoModel("col13"	, "특수물질(2차)"),
				new UstraExcelCellInfoModel("col14"	, "부서"),
				new UstraExcelCellInfoModel("col15"	, "직급"),
				new UstraExcelCellInfoModel("col16"	, "사번"),
				new UstraExcelCellInfoModel("col17"	, "직장전화"),
				new UstraExcelCellInfoModel("col18"	, "입사일"),
				new UstraExcelCellInfoModel("col19"	, "임직원비고"),
				new UstraExcelCellInfoModel("col20"	, "가족이름"),
				new UstraExcelCellInfoModel("col21"	, "가족등급"),
				new UstraExcelCellInfoModel("col22"	, "가족생년월일"),
				new UstraExcelCellInfoModel("col23"	, "가족회사지원금"),
				new UstraExcelCellInfoModel("col24"	, "가족연락처"),
				new UstraExcelCellInfoModel("col25"	, "가족비고"),
				new UstraExcelCellInfoModel("col26"	, "사업장명")
			))
			.withCellGenerator(new BatchUploadCellGenerator())
			.withSheetName("고객(일반)");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "고객(일반)", request, response)
			.build());
	}

	/**
	 * 리스트 엑셀 다운로드
	 * @param in
	 * @throws Exception
	 */
	@PostMapping("/download-excel-customer")
	@ApiOperation(value="고객(일반) 엑셀 다운로드", notes="고객(일반) 엑셀 다운로드")
	public ResponseEntity<?> downloadExcelCustomer(@RequestBody CustomerExcelDownModel in, HttpServletRequest request, HttpServletResponse response) throws Exception {

		if( "9".equals(in.getResultFlag())) {
			in.setResultFlag("test");
		} else if ("99".equals(in.getResultFlag())) {
			in.setResultFlag("total");
		} else if ("1".equals(in.getResultFlag())) {
			in.setResultFlag("new");
		} else if ("4".equals(in.getResultFlag())) {
			in.setResultFlag("normal");
		} else if( "1000".equals(in.getResultFlag())) {
			in.setResultFlag("req");
		}

		List<BatchAdvanceResvExcelModel> customerList = new ArrayList<>();

		if( "test".equals(in.getResultFlag()) )
			customerList = service.getTestCustomerList(in);
		else
			customerList = service.selectCustomerTmpExcelList(in);

		return convertExcel(customerList, request, response);
	}

	@PostMapping("/download-excel-list")
	public ResponseEntity<?> downloadExcel(@RequestBody List<BatchMemberUploadAdvanceResvModel> in, HttpServletRequest request, HttpServletResponse response) {

		return convertExcel(service.getCustomerListForDownload(in), request, response);
	}

	String cd2nm(String src) {

		return String.valueOf((char)((int)src.charAt(0) - '3' + 'A'));
	}

	List<UstraExcelCellInfoModel> applSlctItm(List<UstraExcelCellInfoModel> src, List<String> slctItmKdCds, List<String> spsrSlctItmKdCds) {

		src = new ArrayList<>(src);

		int index = src.indexOf(CollectionUtils.find(src, i->((UstraExcelCellInfoModel)i).getName().equals("col41")));
		src.addAll(index, IntStream.range(0, slctItmKdCds.size())
			.mapToObj(idx->new UstraExcelCellInfoModel("col" + (idx + 100), "선택검사" + cd2nm(slctItmKdCds.get(idx))))
			.collect(Collectors.toList()));

		index = src.indexOf(CollectionUtils.find(src, i->((UstraExcelCellInfoModel)i).getName().equals("col46")));
		src.addAll(index, IntStream.range(0,  spsrSlctItmKdCds.size())
			.mapToObj(idx->new UstraExcelCellInfoModel("col" + (idx + 200), "가족선택검사" + cd2nm(spsrSlctItmKdCds.get(idx))))
			.collect(Collectors.toList()));

		return src;
	}

	ResponseEntity<?> convertExcel(List<BatchAdvanceResvExcelModel> customerList, HttpServletRequest request, HttpServletResponse response) {

		List<String> slctItmKdCds = customerList.stream()
		.flatMap(c->Optional.ofNullable(c.getSlctItmList()).map(List::stream).orElse(null))
		.map(c->c.getExamKdCd())
		.filter(cd->!"1".equals(cd))
		.distinct()
		.collect(Collectors.toList());

		if( CollectionUtils.isEmpty(slctItmKdCds) ) {

			slctItmKdCds.add("3");
			slctItmKdCds.add("4");
		}

		List<String> spsrSlctItmKdCds = customerList.stream()
			.flatMap(c->Optional.ofNullable(c.getSpsrSlctItmList()).map(List::stream).orElse(null))
			.map(c->c.getExamKdCd())
			.filter(cd->!"1".equals(cd))
			.distinct()
			.collect(Collectors.toList());

		if( CollectionUtils.isEmpty(spsrSlctItmKdCds) ) {

			spsrSlctItmKdCds.add("3");
			spsrSlctItmKdCds.add("4");
		}

		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>(); // 엑셀 다운로드용.
		for(int i=0;i<customerList.size();i++) {

			Map<String, Object> map = new TreeMap<>();
			BatchAdvanceResvExcelModel exMap = customerList.get(i); // 리스트 셋팅

			map.put("col1", exMap.getAempNm()); // 이름
			map.put("col2", exMap.getAempCuGrdNm()); // 등급
			map.put("col4", exMap.getAempId()); // 사번
			map.put("col5", exMap.getExcuYn()); // 임원여부
			map.put("col6", exMap.getAempBrdt()); // 생년월일
			map.put("col7", exMap.getEncmDt()); // 입사일
			map.put("col8", exMap.getPkgNm());
			map.put("col9", exMap.getCorpSpfnVal());
			map.put("col10", exMap.getNhicSuptTgtYn()); // 공단지원여부 nhicSuptTgtYn
			map.put("col11", exMap.getSpcuTgtYn()); // 특수검진여부 spcuTgtYn
			map.put("col12", exMap.getExtrMttrNm1()); // 특수물질(1차) extrMttrNm1
			map.put("col13", exMap.getExtrMttrNm2()); // 특수물질(2차) extrMttrNm2
			map.put("col14", exMap.getEmlAdr()); // 이메일 emlAdr
			map.put("col15", exMap.getMblNo()); // 핸드폰 mblNo
			map.put("col16", exMap.getSpsrNm()); // 배우자명 spsrNm
			map.put("col17", exMap.getSpsrCuGrdNm()); // 가족검진등급 spsrCuGrdNm
			map.put("col18", exMap.getSpsrVcnGrdNm()); // 가족백신등급 spsrCuGrdNm
			map.put("col19", exMap.getSpsrBrdt()); // 배우자생년월일 spsrBrdt
			map.put("col20", exMap.getSpsrCorpSpfn()); // 배우자지원금 spsrCorpSpfn
			map.put("col21", exMap.getSpsrPkgNm());
			map.put("col22", exMap.getBsplNm()); // 사업장 bsplNm
			map.put("col23", exMap.getDeptNm1()); // 부서 deptNm1
			map.put("col24", exMap.getDeptNm2()); // 부서 deptNm2
			map.put("col25", exMap.getDeptNm3()); // 부서 deptNm3
			map.put("col26", exMap.getJbgdNm()); // 직급 jbgdNm
			map.put("col27", exMap.getWrplTlno()); // 직장 전화 wrplTlno
			map.put("col28", exMap.getWrplZpcd()); // 직장 전화 wrplTlno
			map.put("col29", exMap.getWrplBscAdr()); // 직장 전화 wrplTlno
			map.put("col30", exMap.getWrplDtlAdr()); // 직장 전화 wrplTlno
			map.put("col31", exMap.getHsTlno()); // 직장 전화 wrplTlno
			map.put("col32", exMap.getHsZpcd()); // 직장 전화 wrplTlno
			map.put("col33", exMap.getHsBscAdr()); // 직장 전화 wrplTlno
			map.put("col34", exMap.getHsDtlAdr()); // 직장 전화 wrplTlno
			map.put("col35", exMap.getAempRegSeq()); // MemberID
			map.put("col36", exMap.getUpldErrVal());
			map.put("col37", exMap.getCuiNm());
			map.put("col38", exMap.getTn1ResvApplDt());
			map.put("col39", exMap.getTn1ResvTmcRngVal());
			map.put("col40", exMap.getPkgTyNm());
			map.put("col41", exMap.getSlctItmString("1"));
			map.put("col42", exMap.getSpsrCuiNm());
			map.put("col43", exMap.getTn1SpsrResvApplDt());
			map.put("col44", exMap.getTn1SpsrResvTmcRngVal());
			map.put("col45", exMap.getSpsrPkgTyNm());
			map.put("col46", exMap.getSpsrSlctItmString("1"));

			for( int j=0; j<slctItmKdCds.size(); j++ )
				map.put("col" + (j + 100), exMap.getSlctItmString(slctItmKdCds.get(j)));

			for( int j=0; j<spsrSlctItmKdCds.size(); j++ )
				map.put("col" + (j + 200), exMap.getSpsrSlctItmString(spsrSlctItmKdCds.get(j)));

			list.add(map);
		}

		if( StringUtils.isNotEmpty(customerList.get(0).getAempNm()) ) {

			String tagretUrl = request.getRequestURL().toString().split("\\?")[0];
			String pageNm = "고객-일반";
			String cont = "이름, 등급, 백신등급, 사번, 임원여부, 생년월일, 입사일, 검진패키지, 지원금, 공단지원여부, 특수검진여부, 특수물질(1차), 특수물질(2차), 이메일, 핸드폰, 배우자명, 배우자검진등급, 배우자백신등급, 배우자생년월일, 배우자지원금, 배우자검진패키지, 사업장, 부서1, 부서2, 부서3, 직급, 직장 전화, 직장 우편번호, 직장 기본 주소, 직장 상세 주소, 집 전화, 집 우편번호, 집 기본 주소, 집 상세 주소, MemberId, 오류내용";

			XlsDownloadHistModel histModel = new XlsDownloadHistModel();
			histModel.setDwldPageUrl(tagretUrl);
			histModel.setInnfVwCnt(list.size());
			histModel.setDwldPageNm(pageNm);
			histModel.setDwldCont(cont);
			histModel.setDwldCustNm(list.get(0).get("col1").toString());
			batchXlsHistProcess.insertHistXlsDownload(histModel);
		}

		UstraExcelModel excelModel;
		excelModel = UstraExcelModel.of(
			list,
			applSlctItm(Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "이름"),
				new UstraExcelCellInfoModel("col2"	, "등급"),
				new UstraExcelCellInfoModel("col3"	, "백신등급"),
				new UstraExcelCellInfoModel("col4"	, "사번"),
				new UstraExcelCellInfoModel("col5"	, "임원여부"),
				new UstraExcelCellInfoModel("col6"	, "생년월일"),
				new UstraExcelCellInfoModel("col7"	, "입사일"),
				new UstraExcelCellInfoModel("col37"	, "검진기관명"),
				new UstraExcelCellInfoModel("col38"	, "예약신청일"),
				new UstraExcelCellInfoModel("col39"	, "예약신청시간"),
				new UstraExcelCellInfoModel("col8"	, "패키지명"),
				new UstraExcelCellInfoModel("col40"	, "패키지유형명"),
				new UstraExcelCellInfoModel("col41"	, "추가검사"),
				new UstraExcelCellInfoModel("col9"	, "지원금"),
				new UstraExcelCellInfoModel("col10"	, "공단지원여부"),
				new UstraExcelCellInfoModel("col11"	, "특수검진여부"),
				new UstraExcelCellInfoModel("col12"	, "특수물질(1차)"),
				new UstraExcelCellInfoModel("col13"	, "특수물질(2차)"),
				new UstraExcelCellInfoModel("col14"	, "이메일"),
				new UstraExcelCellInfoModel("col15"	, "핸드폰"),
				new UstraExcelCellInfoModel("col16"	, "가족명"),
				new UstraExcelCellInfoModel("col17"	, "가족검진등급"),
				new UstraExcelCellInfoModel("col18"	, "가족백신등급"),
				new UstraExcelCellInfoModel("col19"	, "가족생년월일"),
				new UstraExcelCellInfoModel("col20"	, "가족지원금"),
				new UstraExcelCellInfoModel("col42"	, "가족검진기관명"),
				new UstraExcelCellInfoModel("col43"	, "가족예약신청일"),
				new UstraExcelCellInfoModel("col44"	, "가족예약신청시간"),
				new UstraExcelCellInfoModel("col21"	, "가족패키지명"),
				new UstraExcelCellInfoModel("col45"	, "가족패키지유형명"),
				new UstraExcelCellInfoModel("col46"	, "가족추가검사"),
				new UstraExcelCellInfoModel("col22"	, "사업장"),
				new UstraExcelCellInfoModel("col23"	, "부서1"),
				new UstraExcelCellInfoModel("col24"	, "부서2"),
				new UstraExcelCellInfoModel("col25"	, "부서3"),
				new UstraExcelCellInfoModel("col26"	, "직급"),
				new UstraExcelCellInfoModel("col27"	, "직장 전화"),
				new UstraExcelCellInfoModel("col28"	, "직장 우편번호"),
				new UstraExcelCellInfoModel("col29"	, "직장 기본 주소"),
				new UstraExcelCellInfoModel("col30"	, "직장 상세 주소"),
				new UstraExcelCellInfoModel("col31"	, "집 전화"),
				new UstraExcelCellInfoModel("col32"	, "집 우편번호"),
				new UstraExcelCellInfoModel("col33"	, "집 기본 주소"),
				new UstraExcelCellInfoModel("col34"	, "집 상세 주소"),
				new UstraExcelCellInfoModel("col35"	, "MemberId"),
				new UstraExcelCellInfoModel("col36" , "오류내용")
			), slctItmKdCds, spsrSlctItmKdCds))
			.withCellGenerator(new BatchUploadCellGenerator())
			.withSheetName("고객(일반)");	// 시트명
		return fileOperationManager
			.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(excelModel), "고객(일반)", request, response)
			.build());
	}

}
