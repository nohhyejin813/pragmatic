package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
public class BatchResignationUploadResultModel extends NcuModel {

	private Integer totalCount;		// 전체건수

	private Integer normalCount;	// 수정건수

	private Integer errorCount;		// 오류건수

	private String success;			// 성공코드

	private List<Map<String, Object>> normalList;	// 정상목록

	private List<Map<String, Object>> errorList;	// 오류목록

}
