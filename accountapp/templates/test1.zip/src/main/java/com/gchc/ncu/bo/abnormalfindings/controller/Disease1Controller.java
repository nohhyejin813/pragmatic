package com.gchc.ncu.bo.abnormalfindings.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.abnormalfindings.models.AbnfMemberModel;
import com.gchc.ncu.bo.abnormalfindings.models.Disease1Model;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBusinessPlaceModel;
import com.gchc.ncu.bo.abnormalfindings.service.Disease1Service;
import com.gchc.ncu.bo.abnormalfindings.vo.AbnfMemberVo;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.checkupinst.util.CheckupInstUtil;
import com.gchc.ncu.bo.comm.service.ApiInterfaceService;

import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 검진결과:유소견관리(암)
 *
 * @author 2021.11.29
 */
@Api(tags="유소견관리 - 검진결과:유소견관리(암) - Disease1Controller", description="Disease1Controller")
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/abnormalFindings")
public class Disease1Controller {
	@Qualifier("checkupinstUtil")
	@Autowired
	CheckupInstUtil util;

	@Autowired
	private ApiInterfaceService apiInterfaceService;

	@Autowired
	private FileOperationManager fileOperationManager;


    private final Disease1Service service;


    //AS_IS 프로시저(HMS_SMS발송_사업장_회사지원금_선택)
    //1. AMemberBiz.SmsCheckup_Workplace_Supportfund_List(1, DateTime.Now.Year, int.Parse(lboxCompany.SelectedValue), -1);
    //2. public DataSet SmsCheckup_Workplace_Supportfund_List(int type, int year, int comid, int workplaceid)
    //3. return SqlHelper.ExecuteDataset(dbConn, CommandType.StoredProcedure, "HMS_SMS발송_사업장_회사지원금_선택", param);

    @ApiOperation(value="HMS_유소견(암) 사업장 목록조회", notes = "HMS_유소견(암) 사업장 목록조회한다.")
    @GetMapping("/workplacelist")
    public List<ManagermentBusinessPlaceModel> getWorkPlaceList(@ModelAttribute @Valid Disease1Model model) {
    	return service.getWorkPlaceList(model);
    }


    /**
     * 유소견관리(암)  - 목록조회
     */
    @ApiOperation(value="유소견관리(암) 그리드 조회", notes = "유소견관리(암) 그리드 목록을 조회한다.")
    @GetMapping("/disease1")
    public RestResult<List<Disease1Model>> getDisease1List(@ModelAttribute @Valid Disease1Model model) {
    	List<Disease1Model> resultList = service.getDisease1List(model);
		return GchcRestResult.of(resultList);
    }



    @ApiOperation(value="유소견관리(암) 엑셀 목록 조회", notes = "유소견관리(암) 엑셀 목록을 조회한다.")
	@PostMapping("/disease1/excel")
	public ResponseEntity<?> getDisease1ListExcelDownload(@RequestBody Disease1Model model, HttpServletRequest request, HttpServletResponse response)  {

		List<Disease1Model> targetList = service.getDisease1ListExcel(model);
//		List<Map<String, Object>> cmmTargetList = new ArrayList<Map<String,Object>>();

		List<Map<String, Object>> cmmTargetList = targetList.stream()
			.map(target->{
				Map<String, Object> result = new HashMap<>();
				UstraMapUtils.putMap(result,
					"col1", target.getNm(),
					"col2", target.getSexCd(),
					"col3", target.getBrdt(),
					"col4", target.getClcoNm(),
					"col5", target.getEmpno());
				UstraMapUtils.putMap(result,
					"col6", target.getCuDtm(),
					"col7", target.getRegDtm(),
					"col8", target.getHepCarB(),
					"col9", target.getStmCan(),
					"col10", target.getColCan());
				UstraMapUtils.putMap(result,
					"col11", target.getLunCan(),
					"col12", target.getLivCan(),
					"col13", target.getGalCan(),
					"col14", target.getPanCan(),
					"col15", target.getKidCan());
				UstraMapUtils.putMap(result,
					"col16", target.getThyCan(),
					"col17", target.getProCan(),
					"col18", target.getBreCan());

				return result;
			})
			.collect(Collectors.toList());
		return fileOperationManager.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(UstraExcelModel.of(
				cmmTargetList,
				Arrays.asList(
					new UstraExcelCellInfoModel("col1"	, "고객명"),
					new UstraExcelCellInfoModel("col2"	, "성별"),
					new UstraExcelCellInfoModel("col3"	, "생일"),
					new UstraExcelCellInfoModel("col4"	, "고객사명"),
					new UstraExcelCellInfoModel("col5"	, "사번"),
					new UstraExcelCellInfoModel("col6"	, "검진일"),
					new UstraExcelCellInfoModel("col7"	, "등록일"),
					new UstraExcelCellInfoModel("col8"	, "B형간염보균"),
					new UstraExcelCellInfoModel("col9"	, "위암"),
					new UstraExcelCellInfoModel("col10"	, "대장암"),
					new UstraExcelCellInfoModel("col11"	, "폐암"),
					new UstraExcelCellInfoModel("col12"	, "간암"),
					new UstraExcelCellInfoModel("col13"	, "담남암"),
					new UstraExcelCellInfoModel("col14"	, "췌장암"),
					new UstraExcelCellInfoModel("col15"	, "신장암"),
					new UstraExcelCellInfoModel("col16"	, "간상선암"),
					new UstraExcelCellInfoModel("col17"	, "전립선암"),
					new UstraExcelCellInfoModel("col18"	, "유방암"))
					)
					.withCellGenerator(new BatchUploadCellGenerator())
					), "유소견관리(암)", request, response)
				.build());

	}

}
