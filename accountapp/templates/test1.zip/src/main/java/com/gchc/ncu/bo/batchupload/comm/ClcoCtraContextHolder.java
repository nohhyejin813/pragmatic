package com.gchc.ncu.bo.batchupload.comm;

import com.gchc.ncu.bo.batchupload.models.ClcoCtraTnsfInfoModel;

public class ClcoCtraContextHolder {

	private static final ThreadLocal<ClcoCtraTnsfInfoModel> contextHolder = new ThreadLocal<ClcoCtraTnsfInfoModel>();

	public static ClcoCtraTnsfInfoModel get() {

		return contextHolder.get();
	}

	public static void set(ClcoCtraTnsfInfoModel data) {

		contextHolder.set(data);
	}

	public static void clear() {

		if( get() != null )
			contextHolder.remove();
	}
}
