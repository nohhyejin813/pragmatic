package com.gchc.ncu.bo.batchupload.service;

import com.gchc.ncu.bo.batchupload.comm.SearchMapContextHolder;
import com.gchc.ncu.bo.batchupload.enu.BatchCenterVaccineUploadError;
import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.CenterVaccineColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.BatchCenterVaccineUploadModel;
import com.gchc.ncu.bo.batchupload.models.CenterVaccineUploadRequestModel;
import com.gchc.ncu.bo.batchupload.models.CenterVaccineUploadResultModel;
import com.gchc.ncu.bo.batchupload.repository.BatchCenterUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.config.GchcDataBatchExecutor;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.file.model.FileConvertInput;
import com.gsitm.ustra.java.data.file.processor.convert.LocalExcelFileToDataConverter;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class BatchCenterUploadService {

	@Autowired private BatchCenterUploadRepository repository;

	@Autowired private FileOperationManager fileOperationManager;

	@Autowired private GchcDataBatchExecutor batchExecutor;

	void checkCenterVaccineError(BatchCenterVaccineUploadModel src, boolean result, BatchCenterVaccineUploadError error, Object...args) {

		if( !result ) {

			src.setUpldStVal(error.getErrorCd());
			src.setUpldErrVal(src.getUpldErrVal().concat(("|") + error.getMessage(args)));
		}
	}

	BatchCenterVaccineUploadModel validate(BatchCenterVaccineUploadModel src) {

		src.setUpldStVal(1);
		src.setUpldErrVal("");

		checkCenterVaccineError(src, StringUtils.isNotEmpty(src.getCuiNm()), BatchCenterVaccineUploadError.MISSING_INFORMATION, "검진센터명");
		checkCenterVaccineError(src, StringUtils.isEmpty(src.getClcoNm()) ||
			StringUtils.isNotEmpty(src.getBsplNm()), BatchCenterVaccineUploadError.MISSING_INFORMATION, "사업장명");
		checkCenterVaccineError(src, StringUtils.isNotEmpty(src.getVcnNm()), BatchCenterVaccineUploadError.MISSING_INFORMATION, "백신명");
		checkCenterVaccineError(src, ObjectUtils.isNotEmpty(src.getVcnAmt()), BatchCenterVaccineUploadError.MISSING_INFORMATION, "백신 소비자가");
		return src;
	}

	private boolean contains(Collection<Object> list, String src) {

		return list.stream().filter(itm->itm.toString().replace(" ", "").equals(src)).count() > 0;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void validateCenterVaccine(CenterVaccineUploadRequestModel in) {

		// Excel convert
		FileConvertInput<LocalExcelFileToDataConverter.Option, List<RowInfo>> converter =
			LocalExcelFileToDataConverter.builder(in.getFileGrpId(), true, Map.class)
			.metaDataId(FileConvertInput.FileMetaId.builder().fileId(in.getFileId()).fileNos(Arrays.asList(in.getFileNo())).build())
			.build();
		List<RowInfo> converted = fileOperationManager.convert(converter);

		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();
		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

//		if( BatchUploadColumn.stream(CenterVaccineColumn.class).anyMatch(c->!contains(headerRow.values(), c.getTitle())) )
//			BatchResponseCode.INVALID_SHEET_TITLE.occur();
		String missed = BatchUploadColumn.stream(CenterVaccineColumn.class)
				.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
				.findFirst()
				.map(BatchUploadColumn::getTitle)
				.orElse(null);
		if( StringUtils.isNotEmpty(missed) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

		final int yr = in.getYr();
		final int mngrId = BatchUploadUtils.getCurrentMngrId();

		List<BatchCenterVaccineUploadModel> vcnList = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyMap((Map<String, Object>)r.getObject()))
			.map(r->{

				BatchCenterVaccineUploadModel v = BatchUploadUtils.map((Map<String, Object>)r.getObject(),
					headerRow,
					BatchUploadColumn.table(CenterVaccineColumn.class), BatchCenterVaccineUploadModel.class);
				v.setYr(yr);
				v.setMngrId(mngrId);
				return v;
			})
			.collect(Collectors.toList());

		// 검색조건 설정
		SearchMapContextHolder.set(UstraMapUtils.getMap(
			"yr", yr,
			"mngrId", mngrId));

		repository.updateCuiBlkVcnHisUploadYn(SearchMapContextHolder.get());

		// 신규 등록 대상 추출
		List<BatchCenterVaccineUploadModel> forInsert = vcnList.stream()
			.filter(p->ObjectUtils.isEmpty(p.getCuiBlkVcnId()))
			.map(p->validate(p))
			.collect(Collectors.toList());

		// 업데이트 대상 추출
		List<BatchCenterVaccineUploadModel> forUpdate = new ArrayList<>();
		List<BatchCenterVaccineUploadModel> checkUpdate = vcnList.stream()
			.filter(p->ObjectUtils.isNotEmpty(p.getCuiBlkVcnId()))
			.collect(Collectors.toList());
		if( CollectionUtils.isNotEmpty(checkUpdate) ) {

			List<BatchCenterVaccineUploadModel> checked = repository.selectPkgUpldBscForUpdate(UstraMapUtils.getMap(
				"yr", yr,
				"mngrId", mngrId,
				"list", checkUpdate));
			forUpdate = checkUpdate.stream()
				.filter(p->checked.stream().anyMatch(ch->p.getCuiBlkVcnId().equals(ch.getCuiBlkVcnId())))
				.map(p->validate(p))
				.collect(Collectors.toList());

			forInsert.addAll(checkUpdate.stream()
				.filter(p->checked.stream().noneMatch(ch->p.getCuiBlkVcnId().equals(ch.getCuiBlkVcnId())))
				.map(p->validate(p))
				.collect(Collectors.toList()));
		}

		// 신규 등록
		batchExecutor.batchUpdate(
			"INSERT INTO T_CUI_BLK_VCN_HIS (\r\n" +
			"     YR\r\n" +
			"	, CUI_NM\r\n" +
			"	, CUI_ID\r\n" +
			"	, CLCO_NM\r\n" +
			"	, CLCO_ID\r\n" +
			"	, BSPL_NM\r\n" +
			"	, BSPL_ID\r\n" +
			"	, VCN_NM\r\n" +
			"	, VCN_ID\r\n" +
			"	, VCN_AMT\r\n" +
			"	, VCN_DC_AMT\r\n" +
			"	, ETC_MSG_CONT\r\n" +
			"	, UPLD_ST_VAL\r\n" +
			"	, UPLD_ERR_VAL\r\n" +
			"	, USE_YN\r\n" +
			"	, DEL_YN\r\n" +
			"	, UPLD_YN\r\n" +
			"	, MNGR_ID\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			")\r\n" +
			"VALUES (\r\n" +
			"     #{yr}\r\n" +
			"	, #{cuiNm}\r\n" +
			"	, #{cuiId}\r\n" +
			"	, #{clcoNm}\r\n" +
			"	, #{clcoId}\r\n" +
			"	, #{bsplNm}\r\n" +
			"	, #{bsplId}\r\n" +
			"	, #{vcnNm}\r\n" +
			"   , #{vcnId}\r\n" +
			"	, #{vcnAmt}\r\n" +
			"	, #{vcnDcAmt}\r\n" +
			"	, #{etcMsgCont}\r\n" +
			"	, #{upldStVal}\r\n" +
			"	, #{upldErrVal}\r\n" +
			"	, 1\r\n" +
			"	, 0\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			")", forInsert);

		// 업데이트
		batchExecutor.batchUpdate(
			"UPDATE T_CUI_BLK_VCN_HIS\r\n" +
			"SET   CUI_NM = #{cuiNm}\r\n" +
			"	, CUI_ID = #{cuiId}\r\n" +
			"	, CLCO_NM = #{clcoNm}\r\n" +
			"	, CLCO_ID = #{clcoId}\r\n" +
			"	, BSPL_NM = #{bsplNm}\r\n" +
			"	, BSPL_ID = #{bsplId}\r\n" +
			"	, VCN_NM = #{vcnNm}\r\n" +
			"	, VCN_AMT = #{vcnAmt}\r\n" +
			"	, VCN_DC_AMT = #{vcnDcAmt}\r\n" +
			"	, ETC_MSG_CONT = #{etcMsgCont}\r\n" +
			"	, UPLD_ST_VAL = #{upldStVal}\r\n" +
			"	, UPLD_ERR_VAL = #{upldErrVal}\r\n" +
			"	, USE_YN = 1\r\n" +
			"	, DEL_YN = 0\r\n" +
			"	, UPLD_YN = 1\r\n" +
			"	, MNGR_ID = #{mngrId}\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPDR_ID = #{mngrId}\r\n" +
			"WHERE 1=1\r\n" +
			"	AND CUI_BLK_VCN_ID = #{cuiBlkVcnId}", forUpdate);

		// 중복 체크
		repository.updateCuiBlkVcnHisValidate(SearchMapContextHolder.get());

		// 검진기관 및 사업장 매핑
		repository.updateCuiBlkVcnHisIds(SearchMapContextHolder.get());

		// 매핑 여부 체크
		repository.updateCuiBlkVcnHisValidate2(SearchMapContextHolder.get());

		// 이미 등록된 백신Lib 체크
		repository.updateCuiBlkVcnHisValidate3(SearchMapContextHolder.get());
	}

	public CenterVaccineUploadResultModel getResult(CenterVaccineUploadRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		CenterVaccineUploadResultModel result = repository.getCuiBlkVcnHisResult(in);
		result.setErrorCnt(result.getMissedCnt() + result.getInvalidCnt() + result.getDuplicatedCnt() + result.getEtcCnt());
		return result;
	}

	public List<BatchCenterVaccineUploadModel> getErrorList(CenterVaccineUploadRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		List<BatchCenterVaccineUploadModel> list = repository.getCuiBlkVcnHis(in, in.toPaginationRequest());
		return errorMsg(list);
	}

	List<BatchCenterVaccineUploadModel> errorMsg(List<BatchCenterVaccineUploadModel> errList) {

		return errList.stream()
			.map(e->{
				String errMsg = e.getUpldErrVal();
				if( StringUtils.isEmpty(errMsg) )
					return e;
				errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
				e.setUpldErrVal(errMsg.replace("|", "\r\n"));
				return e;
			})
			.collect(Collectors.toList());
	}

	public List<BatchCenterVaccineUploadModel> getDownloadListForTest(CenterVaccineUploadRequestModel in) {

		return repository.selectCuiBlkVcnHisTest(in);
	}

	@Transactional
	public void init(CenterVaccineUploadRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		repository.updateCuiBlkVcnHisInit(in);
	}

	public List<BatchCenterVaccineUploadModel> getErrorListForExcel(CenterVaccineUploadRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		List<BatchCenterVaccineUploadModel> list = repository.getCuiBlkVcnHisForExcel(in);
		return list;
	}

	@Transactional
	public void remove(List<BatchCenterVaccineUploadModel> in) {

		repository.updateCuiBlkVcnHisRemove(UstraMapUtils.getMap(
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in));
	}

	@Transactional
	public void removeAll(CenterVaccineUploadRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		repository.updateCuiBlkVcnHisRemoveAll(in);
	}

	@Transactional
	public void regist(CenterVaccineUploadRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());

		repository.insertCuiVcnDtl(in);

		repository.updateCuiBlkVcnHisRegist(in);
	}

	public List<BatchCenterVaccineUploadModel> getErrorList(List<BatchCenterVaccineUploadModel> in) {

		if( CollectionUtils.isEmpty(in) )
			return Arrays.asList(new BatchCenterVaccineUploadModel());

		return repository.getCuiBlkVcnHisForExcelList(UstraMapUtils.getMap(
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in));
	}
}
