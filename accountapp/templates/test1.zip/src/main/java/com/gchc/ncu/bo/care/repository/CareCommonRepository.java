package com.gchc.ncu.bo.care.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.gsitm.ustra.java.management.models.UstraFileModel;

import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.models.ActPgmBscModel;
import com.gchc.ncu.bo.care.models.CareCodeModel;
import com.gchc.ncu.bo.care.models.CareDssCdModel;
import com.gchc.ncu.bo.care.models.DssLibBscModel;
import com.gchc.ncu.bo.care.models.DwCnntScwdDatBscModel;
import com.gchc.ncu.bo.care.models.HospMdspDeptDtlModel;
import com.gchc.ncu.bo.care.models.NtrtMsnBscModel;
import com.gchc.ncu.bo.care.models.NtrtPgmBscModel;
import com.gchc.ncu.bo.care.models.PoisTyBscModel;

@Mapper
public interface CareCommonRepository {

	List<CareCodeModel> getCodeList();
	List<CareDssCdModel> selectDiseaseList(CareDssCdModel model);
	List<ActMsnBscModel> selectActivityMissionList();
	List<ActPgmBscModel> selectActivityProgramList();
	List<NtrtMsnBscModel> selectNutritionMissionList();
	List<NtrtPgmBscModel> selectNutritionProgramList();
	List<PoisTyBscModel> selectAddictionTypeList();
	List<HospMdspDeptDtlModel> selectMdspDeptList();
	List<DssLibBscModel> selectDiseaseLibList(DssLibBscModel model);
	List<DwCnntScwdDatBscModel> selectContentCategory();
	List<DwCnntScwdDatBscModel> selectContentList(DwCnntScwdDatBscModel model);
	List<Map<String, Object>> selectTermsList(Map<String, Object> model);
	List<Map<String, Object>> selectSurveyList(Map<String, Object> model);
	List<Map<String, Object>> selectClientList(Map<String, Object> model);

	List<UstraFileModel> selectUploadedFile(UstraFileModel model);
	void insertUploadedFile(Map<String, Object> params);
	void updateUploadedFile(UstraFileModel ustraFileMode);
	void deleteUploadedFile(Map<String, Object> params);
	void insertUploadedFileNoSQ(UstraFileModel ustraFileMode);

}
