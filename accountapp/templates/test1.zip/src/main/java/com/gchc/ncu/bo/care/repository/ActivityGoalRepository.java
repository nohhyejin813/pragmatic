package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.DssActMsnRltnModel;
import com.gchc.ncu.bo.care.vo.ActivityGoalVo;

@Mapper
public interface ActivityGoalRepository {

	List<DssActMsnRltnModel> selectActivityGoalList(ActivityGoalVo criteria);
	void insertActivityGoal(DssActMsnRltnModel model);
	void deleteActivityGoalByCond(DssActMsnRltnModel model);

}
