package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchExminationTempModel {
	private int excelSameRnk;
	private int sameMemberRnk;
	private int blkUpldExamId;
	private int cuTgtrId;
	private int resvId;
	private String selfYn;
	private String corpSuptYn;
	private int cuiId;
	private int uid;
	private String pkgNm;
}
