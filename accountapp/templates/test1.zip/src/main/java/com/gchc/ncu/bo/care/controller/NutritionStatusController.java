package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.NtrtIndcBscModel;
import com.gchc.ncu.bo.care.models.NtrtIndcDtlModel;
import com.gchc.ncu.bo.care.models.NtrtIngrdBscModel;
import com.gchc.ncu.bo.care.models.NtrtItrstIngrdDtlModel;
import com.gchc.ncu.bo.care.models.NutritionCdModel;
import com.gchc.ncu.bo.care.service.NutritionStatusService;
import com.gchc.ncu.bo.care.vo.NutritionStatusVo;

@RestController
@RequestMapping("/api/bo/care/nutrition/status")
@RequiredArgsConstructor
public class NutritionStatusController {

	private final NutritionStatusService nutritionStatusService;

	@GetMapping("/list")
	public List<NtrtIngrdBscModel> list(@ModelAttribute NutritionStatusVo in) {
		return nutritionStatusService.getNutritionStatusList(in);
	}

	@GetMapping("/getDetail")
	public NtrtIngrdBscModel getNutritionStatus(@ModelAttribute NutritionStatusVo in) {
		return nutritionStatusService.getNutritionStatus(in);
	}

	@PostMapping("/saveNutrition")
	public RestResult<?> saveNutritionBsc(@RequestBody NtrtIngrdBscModel model) {
		nutritionStatusService.saveNutritionBsc(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<NtrtIngrdBscModel> list) {
		nutritionStatusService.deleteNutritionBsc(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	// 영양코드관리
	@GetMapping("/baseCdList")
	public List<NutritionCdModel> baseCdList() {
		return nutritionStatusService.getNutritionInterestList();
	}

	@PostMapping("/updateCode")
	public RestResult<?> updateNutritionCode(@RequestBody NutritionCdModel model) {
		nutritionStatusService.updateNutritionCode(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}


	// 영양관심사
	@GetMapping("/listNtrtItrst")
	public List<NtrtItrstIngrdDtlModel> getNtrtItrstIngrdList(@ModelAttribute NutritionStatusVo in) {
		return nutritionStatusService.getNtrtItrstIngrdList(in);
	}

	@GetMapping("/detailNtrtItrst")
	public NtrtItrstIngrdDtlModel getNtrtItrstDetail(@ModelAttribute NtrtItrstIngrdDtlModel in) {
		return nutritionStatusService.getNtrtItrstDetail(in);
	}

	@PostMapping("/saveNutritionItrst")
	public RestResult<?> saveNutritionItrst(@RequestBody NtrtItrstIngrdDtlModel model) {
		nutritionStatusService.saveNutritionItrst(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/deleteNtrtItrst")
	public RestResult<?> deleteNtrtItrst(@RequestBody List<NtrtItrstIngrdDtlModel> list) {
		nutritionStatusService.deleteNtrtItrst(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}


	// 영양지표
	@GetMapping("/indcList")
	public List<NtrtIndcBscModel> getNtrtIndcList(@ModelAttribute NutritionStatusVo in) {
		return nutritionStatusService.getNtrtIndcList(in);
	}

	@GetMapping("/indcDtlList")
	public List<NtrtIndcDtlModel> getNtrtIndcDtlList(@ModelAttribute NutritionStatusVo in) {
		return nutritionStatusService.getNtrtIndcDtlList(in);
	}

	@GetMapping("/indcDetail")
	public NtrtIndcBscModel getNtrtIndcDetail(@ModelAttribute NutritionStatusVo in) {
		return nutritionStatusService.getNtrtIndcDetail(in);
	}

	@PostMapping("/saveNtrtIndcBsc")
	public RestResult<?> saveNtrtIndcBsc(@RequestBody NtrtIndcBscModel model) {
		int result = nutritionStatusService.saveNtrtIndcBsc(model);
		return GchcRestResult.of(result, GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/deleteNtrtIndcBsc")
	public RestResult<?> deleteNtrtIndcBsc(@RequestBody List<NtrtIndcBscModel> list) {
		nutritionStatusService.deleteNtrtIndcBsc(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@PostMapping("/saveNtrtIndcDtl")
	public RestResult<?> saveNtrtIndcDtl(@RequestBody List<NtrtIndcDtlModel> list) {
		nutritionStatusService.saveNtrtIndcDtl(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
