package com.gchc.ncu.bo.abnormalfindings.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.abnormalfindings.models.AbnfCodeModel;
import com.gchc.ncu.bo.abnormalfindings.models.AbnfMemberModel;
import com.gchc.ncu.bo.abnormalfindings.models.HthSvcModel;
import com.gchc.ncu.bo.abnormalfindings.models.MemberCodeModel;
import com.gchc.ncu.bo.abnormalfindings.models.MemberInfoModel;
import com.gchc.ncu.bo.abnormalfindings.service.AbnfMemberService;
import com.gchc.ncu.bo.abnormalfindings.vo.AbnfMemberVo;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.checkupinst.util.CheckupInstUtil;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;



/**
 * 유소견 Controller
 * @FileName : AbnormalFindingsController.java
 * @date : 2021. 7. 30
 * @author : gs_shbaek@gchealthcare.com
 * @프로그램 설명 :
 * @변경이력 :
 */
@Api(tags="유소견 관리 - AbnormalFindingsController", description="AbnormalFindingsController")
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/abnormalFindings")
public class AbnfMemberController {

	@Qualifier("checkupinstUtil")
	@Autowired
	CheckupInstUtil util;


	private final AbnfMemberService memberService;

	@Autowired
	private FileOperationManager fileOperationManager;



	@ApiOperation(value="운영군리스트 목록 조회", notes = "운영군리스트 조회을 조회 한다.")
	@GetMapping("/member-list")
	public RestResult<List<AbnfMemberModel>> getMemberList(@ModelAttribute AbnfMemberVo abnfMemberVo)
	{
	//	abnfMemberVo.setOrderName(GchcGridUtil.getCamalToLarge(abnfMemberVo.getOrderName()));
		List<AbnfMemberModel> resultList = memberService.getMemberList(abnfMemberVo);
		return GchcRestResult.of(resultList);
	}






	@ApiOperation(value = "운영군리스트 엑셀 다운로드", notes = "운영군리스트조회엑셀 다운로드")
	@PostMapping("/member-list/excel")
	public ResponseEntity<?> getTargetListExcelDownload(@RequestBody AbnfMemberVo abnfMemberVo, HttpServletRequest request, HttpServletResponse response)  {

		List<AbnfMemberModel> targetList = memberService.getMemberListExcelDownload(abnfMemberVo);

		//List<Map<String, Object>> cmmTargetList = new ArrayList<Map<String,Object>>();

		// 공통백신결과 List MAP 처리

		List<Map<String, Object>> list = targetList.stream()
				.map(target->{
					Map<String, Object> result = new HashMap<>();
					UstraMapUtils.putMap(result,
						"col1", target.getEmpno(),
						"col2", target.getExitGrade(),
						"col3", target.getNm(),
						"col4", target.getSex() + "/" + target.getAge(),
						"col5", target.getClcoNm());
					UstraMapUtils.putMap(result,
						"col6", target.getWorkRgnNm1(),
						"col7", target.getTmpSvcgCdNm(),
						"col8", target.getTmpSvcgDtlCdNm(),
						"col9", target.getAsmStNm(),
						"col10", target.getCustPgrsStCdNm());
					UstraMapUtils.putMap(result,
						"col11", target.getCuDt(),
						"col12", "",
						"col13", target.getRgrp());

					return result;
				})
				.collect(Collectors.toList());

		// ===============================================================
		UstraExcelModel excelModel;

		// [[ 1번 SHEET ]] ########################################################################
		excelModel = UstraExcelModel.of(
				list,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "사번"),
				new UstraExcelCellInfoModel("col2"	, "퇴사여부"),
				new UstraExcelCellInfoModel("col3"	, "고객명"),
				new UstraExcelCellInfoModel("col4"	, "성별나이"),
				new UstraExcelCellInfoModel("col5"	, "고객사"),
				new UstraExcelCellInfoModel("col6"	, "근무지1"),
				new UstraExcelCellInfoModel("col7"	, "군별정보"),
				new UstraExcelCellInfoModel("col8"	, "분류"),
				new UstraExcelCellInfoModel("col9"	, "평가완료"),
				new UstraExcelCellInfoModel("col10"	, "진행상태"),
				new UstraExcelCellInfoModel("col11"	, "최근검진일"),
				new UstraExcelCellInfoModel("col12"	, "결과보고서"),
				new UstraExcelCellInfoModel("col13"	, "뇌/심위험도")
			))
		.withCellGenerator(new BatchUploadCellGenerator())
		.withSheetName("유소견 운영군_리스트")	;	// 시트명
		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
						.entityBuilder(Arrays.asList(excelModel), "유소견_운영군_리스트", request, response)
						.build());

	}



	@ApiOperation(value="대상자 목록 검색 조건 조회", notes = "대상자 목록 검색조건을 조회 한다.")
	@GetMapping("/search-list")
	public MemberCodeModel getSearchList()
	{
		return memberService.getSearchList();
	}


	@ApiOperation(value="운영군리스트 회원 정보", notes = "운영군리스트 회원 정보 조회을 조회 한다.")
	@GetMapping("/member-info")
	public MemberInfoModel getMemberInfo(@RequestParam Integer uid)
	{
		return memberService.getMemberInfo(uid);
	}


	@ApiOperation(value="군별 변경 내역", notes = "군별 변경 내역 조회을 조회 한다.")
	@GetMapping("/hthsvchist")
	public List<HthSvcModel> getHthSvcHistList(@ModelAttribute HthSvcModel hthSvcModel)
	{
		return memberService.getHthSvcHistList(hthSvcModel);
	}

	@ApiOperation(value="군별 변경", notes = "군별 변경")
	@PostMapping("/hthsvchist")
	public Integer updateHthSvcHistList(@RequestBody HthSvcModel hthSvcModel)
	{
		return memberService.updateHthSvcHistList(hthSvcModel);
	}

	@ApiOperation(value="군별 코드 목록", notes = "군별 코드 목록")
	@GetMapping("/svcgCdDtl")
	public List<AbnfCodeModel> getSvcgDtlCdList()
	{
		return memberService.getSvcgDtlCdList();
	}


	@ApiOperation(value="군별 코드 목록", notes = "군별 코드 목록")
	@GetMapping("/svcgCd")
	public List<AbnfCodeModel> getSvcgCdList()
	{
		return memberService.getSvcgCdList();
	}



	@ApiOperation(value="변경 사유 코드 목록")
	@GetMapping("/custPgrStCd")
	public List<AbnfCodeModel> getCustPgrStCdList()
	{
		return memberService.getCustPgrStCdList();
	}

	@ApiOperation(value="고객 상태 변경", notes = "고객 상태 변경")
	@PostMapping("/clcoStList")
	public Integer updateClcoStHst(@RequestBody HthSvcModel hthSvcModel)
	{
		return memberService.updateClcoStHst(hthSvcModel);
	}



//	SELECT DTL_CD, CD_NM FROM USTRA_CMM_CD  WHERE UPR_GRP_CD = 'SVCG_CD' AND GRP_CD = 701





}
