package com.gchc.ncu.bo.care.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.SkinAgBscModel;
import com.gchc.ncu.bo.care.models.SkinAgCnntDtlModel;
import com.gchc.ncu.bo.care.models.SkinAgRsltBscModel;
import com.gchc.ncu.bo.care.service.SkinAgeService;
import com.gchc.ncu.bo.care.vo.SkinAgeSearchVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/skin-age")
@RequiredArgsConstructor
public class SkinAgeController {

	private final SkinAgeService skinAgeService;

	@GetMapping("/base/list")
	public List<SkinAgBscModel> getSkinAgeBaseList(@ModelAttribute SkinAgeSearchVo vo) {
		return skinAgeService.getSkinAgeBaseList(vo);
	}

	@GetMapping("/content/list")
	public List<SkinAgCnntDtlModel> getSkinAgeContentList(@ModelAttribute SkinAgeSearchVo vo) {
		return skinAgeService.getSkinAgeContentList(vo);
	}

	@GetMapping("/base/item")
	public SkinAgBscModel getSkinAgeBaseItem(@ModelAttribute SkinAgeSearchVo vo) {
		return skinAgeService.getSkinAgeBaseItem(vo);
	}

	@GetMapping("/content/item")
	public SkinAgCnntDtlModel getSkinAgeContentItem(@ModelAttribute SkinAgeSearchVo vo) {
		return skinAgeService.getSkinAgeContentItem(vo);
	}

	@SuppressWarnings("rawtypes")
	@PostMapping("/base/item")
	public RestResult<GchcRestResult> setSkinAgeBaseItem(@RequestBody SkinAgBscModel model) {
		skinAgeService.setSkinAgeBaseItem(model);

		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@SuppressWarnings("rawtypes")
	@PostMapping("/content/item")
	public RestResult<GchcRestResult> setSkinAgeContentItem(@RequestBody SkinAgCnntDtlModel model) {
		skinAgeService.setSkinAgeContentItem(model);

		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@SuppressWarnings("rawtypes")
	@DeleteMapping("/base/item")
	public RestResult<GchcRestResult> removeSkinAgeBaseItem(@RequestBody List<SkinAgBscModel> models) {
		skinAgeService.removeSkinAgeBaseList(models);

		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@SuppressWarnings("rawtypes")
	@DeleteMapping("/content/item")
	public RestResult<GchcRestResult> removeSkinAgeContentItem(@RequestBody List<SkinAgCnntDtlModel> models) {
		skinAgeService.removeSkinAgeContentList(models);

		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@GetMapping("/result/list")
	public List<SkinAgRsltBscModel> getSkinAgeResultBaseList(@ModelAttribute SkinAgeSearchVo vo) {
		return skinAgeService.getSkinAgeResultBaseList(vo);
	}

	@GetMapping("/result/item")
	public SkinAgRsltBscModel getSkinAgeResultBaseItem(@ModelAttribute SkinAgeSearchVo vo) {
		return skinAgeService.getSkinAgeResultBaseItem(vo);
	}

	@SuppressWarnings("rawtypes")
	@PostMapping("/result/item")
	public RestResult<GchcRestResult> setSkinAgeResultBaseItem(@RequestBody SkinAgRsltBscModel model) {
		skinAgeService.setSkinAgeResultBaseItem(model);

		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@SuppressWarnings("rawtypes")
	@DeleteMapping("/result/item")
	public RestResult<GchcRestResult> removeSkinAgeResultBaseItem(@RequestBody List<SkinAgRsltBscModel> models) {
		skinAgeService.removeSkinAgeResultBaseList(models);

		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
