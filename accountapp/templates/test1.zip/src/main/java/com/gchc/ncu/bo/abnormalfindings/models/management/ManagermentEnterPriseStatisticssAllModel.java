package com.gchc.ncu.bo.abnormalfindings.models.management;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;



@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentEnterPriseStatisticssAllModel extends UstraManagementBaseModel
{
	@ApiModelProperty(value="년도")
	private String yr;

	@ApiModelProperty(value="전체")
	private Integer totalCnt1;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt1;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt1;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt1;




	@ApiModelProperty(value="전체")
	private Integer totalCnt2;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt2;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt2;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt2;



	@ApiModelProperty(value="전체")
	private Integer totalCnt3;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt3;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt3;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt3;


	@ApiModelProperty(value="전체")
	private Integer totalCnt4;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt4;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt4;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt4;


	@ApiModelProperty(value="전체")
	private Integer totalCnt5;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt5;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt5;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt5;


	@ApiModelProperty(value="전체")
	private Integer totalCnt6;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt6;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt6;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt6;


	@ApiModelProperty(value="전체")
	private Integer totalCnt7;

	@ApiModelProperty(value="정상A")
	private Integer normalCnt7;

	@ApiModelProperty(value="정상B(경계)")
	private Integer warningCnt7;

	@ApiModelProperty(value="질환의심")
	private Integer careCnt7;
}
