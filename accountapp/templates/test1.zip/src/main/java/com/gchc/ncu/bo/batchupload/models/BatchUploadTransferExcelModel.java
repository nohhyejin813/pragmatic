package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Getter
@Setter
public class BatchUploadTransferExcelModel extends UstraManagementBaseModel {

	private Integer clcoId;

	private Integer yr;

	@UstraExcelCellInfo(col = 0, header = "임직원이름", required = false)
	private String aempNm;

	@UstraExcelCellInfo(col = 1, header = "임직원등급", required = false)
	private String aempGrdNm;

	@UstraExcelCellInfo(col = 2, header = "사번", required = false)
	private String aempId;

	@UstraExcelCellInfo(col = 3, header = "양도 여부", required = false)
	private String tnsfYn;

	@UstraExcelCellInfo(col = 4, header = "양도 그룹명", required = false)
	private String spfnTnsfGrpNm;

	@UstraExcelCellInfo(col = 5, header = "선택 여부", required = false)
	private String slctSpfnUseYn;

	@UstraExcelCellInfo(col = 6, header = "선택 그룹명", required = false)
	private String slctSpfnSuptSlctGrpNm;

	@UstraExcelCellInfo(col = 7, header = "다중 여부", required = false)
	private String mltiYn;

	@UstraExcelCellInfo(col = 8, header = "패키지명", required = false)
	private String pkgNm;

	@UstraExcelCellInfo(col = 9, header = "회사 지원금", required = false)
	private String corpSpfn;

	@UstraExcelCellInfo(col = 10, header = "지원자수", required = false)
	private String mltiSlctTgtrCnt;

	@UstraExcelCellInfo(col = 11, header = "가족등급명", required = false)
	private String fmlyGrdNm;

	@UstraExcelCellInfo(col = 12, header = "MemberID", required = false)
	private String aempDtlRegSeq;
}

