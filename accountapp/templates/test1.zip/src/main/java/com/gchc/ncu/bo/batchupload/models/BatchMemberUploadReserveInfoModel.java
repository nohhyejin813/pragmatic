package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchMemberUploadReserveInfoModel {

	Integer cuResvCnt;

	Integer spcuResvCnt;

	Integer vcnResvCnt;
}
