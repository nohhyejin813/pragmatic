package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MidCnslCtraBscModel extends UstraManagementBaseModel {

	private Integer midCnslCtraId;
	private Integer clcoId;
	private String clcoNm;
	private String ctraSrtDt;
	private String ctraEndDt;
	private String titl;
	private String applMsg;
	private Integer useYn;
	private Integer psycCnslSvcYn;
	private Integer hrgSvcYn;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
