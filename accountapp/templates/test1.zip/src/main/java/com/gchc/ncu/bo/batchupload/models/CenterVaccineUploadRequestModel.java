package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuPageableVo;

@Getter
@Setter
public class CenterVaccineUploadRequestModel extends NcuPageableVo {

	private Integer yr;

	private Integer mngrId;

	private String fileGrpId;

	private String fileId;

	private Integer fileNo;

	private Integer state;
}
