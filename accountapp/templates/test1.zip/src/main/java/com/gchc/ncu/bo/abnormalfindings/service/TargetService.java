package com.gchc.ncu.bo.abnormalfindings.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.gchc.ncu.bo.abnormalfindings.models.target.AbnfTargetModel;
import com.gchc.ncu.bo.abnormalfindings.repository.TargetRepository;
import com.gchc.ncu.bo.abnormalfindings.vo.target.AbnfTargetVo;
import com.gchc.ncu.bo.checkupinst.models.CodeModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogService;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;
import com.gchc.ncu.bo.comm.util.GchcGridUtil;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 유소견 Service
 *
 * @author gs_shbaek@gchealthcare.com
 */

@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class TargetService
{
	@Autowired
	private TargetRepository targetRepository;

	@Autowired
	private UsrInnfActiLogService usrInnfActiLogService;

	@Autowired
	private XlsDownloadRecordService xlsDownloadRecordService;

	public List<CodeModel> getClcoList() {
		return targetRepository.getClcoList();
	}


	public List<AbnfTargetModel> getTargetList(AbnfTargetVo targetVo) {

		if(targetVo.getDayTo() == null || targetVo.getDayTo().equals("")) {
			targetVo.setDayTo("2099-12-31");
		}

		if(targetVo.getDayTy()  == null)
			targetVo.setDayTy("검진일");

		targetVo.setOrderName(GchcGridUtil.getCamalToLarge(targetVo.getOrderName()));
		PaginationRequest pr = targetVo.toPaginationRequest();

		List<AbnfTargetModel> dataList =  targetRepository.getTargetList(targetVo, pr);
		if(dataList != null && dataList.size() > 0) {
			UstraMaskingUtils.maskTextFields(dataList);
		}


		if(dataList != null && dataList.size() > 1) {
			UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
			usrInfomodel.setActiLogDvCd("40");	//로깅 유형

			usrInfomodel.setMenuNm("유소견관리 > 유소견관리대상자리스트");	//메뉴명
			usrInfomodel.setPfrmNm("유소견관리대상자리스트 조회");	//실행명
			usrInfomodel.setPfrmCont(dataList.get(0).getClcoNm() + "고객사 유소견관리대상자리스트 조회");	//실행 내용
			usrInfomodel.setInnfVwCnt(dataList.get(0).totalItemCount.intValue());	//조회 건수
			if(dataList.size() == 1) {
				usrInfomodel.setCustNm(dataList.get(0).getUid() + "등 " + dataList.size() +"건");	//고객명
			}else {
				usrInfomodel.setCustNm("UID : " + dataList.get(0).getUid() + "등 " + dataList.size() +"건");	//고객명
			}
			usrInnfActiLogService.insert(usrInfomodel);
		}

		return dataList;
	}



	public List<AbnfTargetModel> getTargetListExcelDownload(AbnfTargetVo targetVo) {
		if(targetVo.getDayTo() == null || targetVo.getDayTo().equals("")) {
			targetVo.setDayTo("2099-12-31");
		}

		if(targetVo.getDayTy() == null)
			targetVo.setDayTy("검진일");

		targetVo.setOrderName(GchcGridUtil.getCamalToLarge(targetVo.getOrderName()));
		List<AbnfTargetModel> dataList =  targetRepository.getTargetListExcelDownload(targetVo);
//		if(dataList != null && dataList.size() > 0) {
//			UstraMaskingUtils.maskTextFields(dataList);
//		}

		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm("유소견관리 > 검진결과: 유소견관리대상자리스트 > 엑셀다운로드");
		record.setDwldPageUrl(targetVo.getDwldPageUrl());
		record.setDwldCont("이름, 고객사, 사번, 검진결과 생성일, 검진일, 최근 등록일, 심뇌 위험군, 대사군, 암 예방군");
		record.setDwldMemo(targetVo.getDwldMemo()); // 메모
		record.setDwldRsnCd(targetVo.getDwldRsnCd()); // 다운로드 사유 코드
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(dataList.size() ); //개인정보 Download 건수.
		record.setCustNm("UID : " + dataList.get(0).getUid() + "등  " + dataList.size() + "건"+"(고객사 : "+dataList.get(0).getClcoNm()+")");
		xlsDownloadRecordService.insert(record);

		return dataList;
	}

	@ApiOperation(value="암 예방군 변경", notes = "")
	public Integer updateNpcPvntGrpNm(AbnfTargetVo targetVo)
	{
		UsrInnfActiLogModel model = new UsrInnfActiLogModel();
		for(int i : targetVo.getAbnfMngIds() ) {
			model.setActiLogDvCd("60");	//로깅 유형
			model.setMenuNm("(내부관리자)유소견관리 > 유소견관리대상자리스트 > 암예방군변경(B)");	//메뉴명
			model.setPfrmNm("암예방군 변경");	//실행명
			model.setCustNm("유소견관리아이디 : " + Integer.toString(i));	//고객명
			model.setPfrmCont("암예방군 변경 입니다.");	//실행 내용
			usrInnfActiLogService.insert(model);
		}

		return targetRepository.updateNpcPvntGrpNm(targetVo);
	}





}
