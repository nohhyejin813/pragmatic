package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
public class BatchUploadAdvanceResvSelectItemModel extends NcuModel {

	Integer clcoId;

	String yr;

	Integer aempRegSeq;

	Integer adreSlctItmSeq;

	String examItmNm;

	String examKdCd;

	String slctItmStVal;

	Integer pkgTyItmId;

	Integer itmId;

	Integer mngrId;

	Integer selfYn;
}
