package com.gchc.ncu.bo.abnormalfindings.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.checkupinst.models.CodeModel;
import com.gsitm.ustra.java.data.mybatis.executor.Many;

/**
 * 유소견 공통
 *
 * @author 2021.11.22
 */
@Mapper
public interface HmsCommonRepository {

	/** 복호화 Before */
	void exeKeyOpen();
	/** 복호화 After */
	void exeKeyClose();

	/** 고객사 */
	@Many List<CodeModel> getClcoList();
	/** 근무지역 */
	@Many List<CodeModel> getWorkRgnList(Integer clcoId);
	/** 사업장 */
	@Many List<CodeModel> getWorkPlaceList(Integer clcoId);

}
