package com.gchc.ncu.bo.challenge.reward.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import com.gsitm.ustra.java.data.poi.annotation.UstraExcelCellInfo;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
public class UploadRewardExcelModel extends NcuModel {

	// 다운로드 엑셀 파일명
	private String excelFileName;

	// 행
	private Integer row;

	@UstraExcelCellInfo(col = 0, header = "사번", required = false)
	private String empNo;
	@UstraExcelCellInfo(col = 1, header = "보상내용", required = false)
	private String cmpnCont;

	// 오류
	private List<String> error;
	// 오류건수
	private Integer errorCnt;

}
