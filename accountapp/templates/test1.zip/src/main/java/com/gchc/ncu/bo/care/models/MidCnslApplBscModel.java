package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gchc.common.util.GchcMaskType;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MidCnslApplBscModel extends UstraManagementBaseModel {

	private Integer midCnslApplId;
	private Integer midCnslCtraId;
	private Integer cnslNo;
	private Integer clcoId;
	private String clcoNm;
	@Masked(MaskingType.ID)
	private String uid;
	@Masked(MaskingType.NAME)
	private String mbrNm;
	@Masked(MaskingType.PHONE)
	private String rcvrMblNo;
	@Masked(GchcMaskType.DATE)
	private String brdt;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp applDtm;
	private String memo;
	private String cnslDt;
	private String cnslHm;
	private String cnslTmcDvCd;
	private Integer applPsblCnt;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp tn1TcallDtm;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp tn2TcallDtm;
	private String midCnslStCd;
	private String midCnslStNm;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
