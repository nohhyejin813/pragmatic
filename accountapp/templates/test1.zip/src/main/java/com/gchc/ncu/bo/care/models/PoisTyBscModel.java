package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PoisTyBscModel extends UstraManagementBaseModel {

	private Integer poisTyId;
	@NotNull(message = "중독유형명은 필수값입니다.")
	private String poisTyNm;
	private String qstThmCont;
	private String poisCatCd;
	private String hstkGuidCont;
	private Integer sortOrd;
	private String answExpoTyCd;
	private String hstkRsltTitl;
	private String hstkOrgnCont;
	private Integer poisTyIconFileId;
	private Integer poisRsltImgFileId;
	private String poisDiagMthCd;
	private Integer useYn;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
