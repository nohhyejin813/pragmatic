package com.gchc.ncu.bo.care.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.MidCnslApplBscModel;
import com.gchc.ncu.bo.care.models.MidCnslCtraBscModel;
import com.gchc.ncu.bo.care.models.MidCnslTmcBscModel;
import com.gchc.ncu.bo.care.repository.CounselRepository;
import com.gchc.ncu.bo.care.vo.CounselVo;
import com.gchc.ncu.bo.care.vo.ExcelDwldLogVo;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class CounselService {

	private final CareCommonService careCommonService;
	private final CounselRepository counselRepository;

	private SimpleDateFormat sdfDefault = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	private SimpleDateFormat sdfCounselTime = new SimpleDateFormat("yyyyMMddHHmm");
	private SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy-MM-dd");
	private SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm");

	public List<MidCnslTmcBscModel> getScheduleList(CounselVo criteria) {
		return counselRepository.selectScheduleList(criteria);
	}

	public MidCnslTmcBscModel getSchedule(MidCnslTmcBscModel criteria) {
		return counselRepository.selectScheduleDetail(criteria);
	}

	@Transactional
	public void setSchedule(MidCnslTmcBscModel model) {
		counselRepository.saveSchedule(model);
	}

	@Transactional
	public void removeSchedule(List<MidCnslTmcBscModel> list) {
		if (list != null) {
			for (MidCnslTmcBscModel model : list) {
				counselRepository.deleteSchedule(model);
			}
		}
	}

	public List<MidCnslCtraBscModel> getContractList(CounselVo criteria) {
		return counselRepository.selectContractList(criteria);
	}

	public MidCnslCtraBscModel getContract(MidCnslCtraBscModel criteria) {
		return counselRepository.selectContractDetail(criteria);
	}

	@Transactional
	public void setContract(MidCnslCtraBscModel model) {
		int checkConflictCnt = counselRepository.selectContractConflictCnt(model);

		if (checkConflictCnt > 0) {
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "계약기간이 중복된 계약이 있습니다.");
		}

		if (model.getMidCnslCtraId() == null) {
			counselRepository.insertContract(model);
		} else {
			counselRepository.updateContract(model);
		}
	}

	@Transactional
	public void removeContract(List<MidCnslCtraBscModel> list) {
		if (list != null) {
			for (MidCnslCtraBscModel model : list) {
				counselRepository.deleteContract(model);
			}
		}
	}

	public List<MidCnslApplBscModel> getApplicationList(CounselVo criteria, boolean masking) {
		List<MidCnslApplBscModel> list = counselRepository.selectApplicationList(criteria);

		if (masking) {
			UstraMaskingUtils.maskTextFields(list);
		}

//		list.forEach(item -> {
//			item.setUid(UstraMaskingUtils.maskText(MaskingType.ID, item.getUid()));
//			item.setMbrNm(UstraMaskingUtils.maskText(MaskingType.NAME, item.getMbrNm()));
//			item.setRcvrMblNo(UstraMaskingUtils.maskText(MaskingType.PHONE, item.getRcvrMblNo()));
//		});

		return list;
	}

	public UstraExcelModel downloadApplicationExcel(List<MidCnslApplBscModel> list) {
		List<UstraExcelCellInfoModel> commHeader =  Arrays.asList(
				new UstraExcelCellInfoModel("col1", "신청ID"),
				new UstraExcelCellInfoModel("col2", "상담희망일자"),
				new UstraExcelCellInfoModel("col3", "상담희망시간"),
				new UstraExcelCellInfoModel("col4", "고객사"),
				new UstraExcelCellInfoModel("col5", "회원ID"),
				new UstraExcelCellInfoModel("col6", "회원명"),
				new UstraExcelCellInfoModel("col7", "휴대폰번호"),
				new UstraExcelCellInfoModel("col8", "생년월일"),
				new UstraExcelCellInfoModel("col9", "진행상태"),
				new UstraExcelCellInfoModel("col10", "신청내용"),
				new UstraExcelCellInfoModel("col11", "신청일시")
			);

		List<Map<String, Object>> cmmList = new ArrayList<Map<String,Object>>();

		for(int i = 0; i < list.size(); i++) {
			MidCnslApplBscModel model = list.get(i);

			Map<String, Object> map = new TreeMap<>();
			map.put("col1", model.getMidCnslApplId());
			map.put("col4", model.getClcoNm());
			map.put("col5", model.getUid());
			map.put("col6", model.getMbrNm());
			map.put("col7", model.getRcvrMblNo());
			map.put("col8", model.getBrdt());
			map.put("col9", model.getMidCnslStNm());
			map.put("col10", model.getMemo());
			map.put("col11", sdfDefault.format(model.getApplDtm()));

			try {
				Date cnslTime = sdfCounselTime.parse(model.getCnslDt() + model.getCnslHm());

				map.put("col2", sdfYear.format(cnslTime));
				map.put("col3", sdfTime.format(cnslTime));
			} catch (ParseException e) {
				LOGGER.error(e.getMessage(), e);

				map.put("col2", model.getCnslDt());
				map.put("col3", model.getCnslHm());
			}

			cmmList.add(map);
		}

		UstraExcelModel excelModel = UstraExcelModel.of(cmmList, commHeader).withSheetName("마음상담_신청_현황_업로드용");

		return excelModel;
	}

	public UstraExcelModel downloadExcelDetail(CounselVo criteria, List<MidCnslApplBscModel> targetList) {
		Map<String, Object> paramsMap = new HashMap<>();
		paramsMap.put("targetClcoId", criteria.getClcoId());
		paramsMap.put("targetMemberIds", targetList);
		paramsMap.put("targetAnswerSrtDt", criteria.getAnswerSrtDt());
		paramsMap.put("targetAnswerEndDt", criteria.getAnswerEndDt());

		List<Map<String, Object>> list = counselRepository.selectApplicationExcelList(paramsMap);

		List<UstraExcelCellInfoModel> commHeader =  Arrays.asList(
			new UstraExcelCellInfoModel("col1", "회원ID"),
			new UstraExcelCellInfoModel("col2", "회원명"),
			new UstraExcelCellInfoModel("col3", "핸드폰번호"),
			new UstraExcelCellInfoModel("col4", "생년월일"),
			new UstraExcelCellInfoModel("col5", "전체등급"),
			new UstraExcelCellInfoModel("col6", "직무스트레스"),
			new UstraExcelCellInfoModel("col7", "근무환경"),
			new UstraExcelCellInfoModel("col8", "업무량"),
			new UstraExcelCellInfoModel("col9", "업무특성"),
			new UstraExcelCellInfoModel("col10", "대인관계"),
			new UstraExcelCellInfoModel("col11", "고용안정"),
			new UstraExcelCellInfoModel("col12", "조직체계"),
			new UstraExcelCellInfoModel("col13", "보상"),
			new UstraExcelCellInfoModel("col14", "조직문화"),
			new UstraExcelCellInfoModel("col15", "심리적증상"),
			new UstraExcelCellInfoModel("col16", "우울"),
			new UstraExcelCellInfoModel("col17", "불안"),
			new UstraExcelCellInfoModel("col18", "분노"),
			new UstraExcelCellInfoModel("col19", "공포"),
			new UstraExcelCellInfoModel("col20", "건강염려"),
			new UstraExcelCellInfoModel("col21", "강박"),
			new UstraExcelCellInfoModel("col22", "스트레스취약성"),
			new UstraExcelCellInfoModel("col23", "자살사고"),
			new UstraExcelCellInfoModel("col24", "수면문제"),
			new UstraExcelCellInfoModel("col25", "중독"),
			new UstraExcelCellInfoModel("col26", "외상경험")
		);

		List<Map<String, Object>> cmmList = new ArrayList<Map<String,Object>>();

		for(int i = 0; i < list.size(); i++) {
			Map<String, Object> model = list.get(i);

			Map<String, Object> map = new TreeMap<>();
			map.put("col1", model.get("UID"));
			map.put("col2", model.get("이름"));
			map.put("col3", model.get("핸드폰번호"));
			map.put("col4", model.get("생년월일"));
			map.put("col5", model.get("전체등급"));
			map.put("col6", model.get("직무스트레스"));
			map.put("col7", model.get("근무환경"));
			map.put("col8", model.get("업무량"));
			map.put("col9", model.get("업무특성"));
			map.put("col10", model.get("대인관계"));
			map.put("col11", model.get("고용안정"));
			map.put("col12", model.get("조직체계"));
			map.put("col13", model.get("보상"));
			map.put("col14", model.get("조직문화"));
			map.put("col15", model.get("심리적증상"));
			map.put("col16", model.get("우울"));
			map.put("col17", model.get("불안"));
			map.put("col18", model.get("분노"));
			map.put("col19", model.get("공포"));
			map.put("col20", model.get("건강염려"));
			map.put("col21", model.get("강박"));
			map.put("col22", model.get("스트레스취약성"));
			map.put("col23", model.get("자살사고"));
			map.put("col24", model.get("수면문제"));
			map.put("col25", model.get("중독"));
			map.put("col26", model.get("외상경험"));

			cmmList.add(map);
		}

		UstraExcelModel excelModel = UstraExcelModel.of(cmmList, commHeader).withSheetName("마음상담_신청자_상세");

		return excelModel;
	}

	public UstraExcelModel downloadHighRiskExcel(CounselVo criteria) {
		List<Map<String, Object>> list = counselRepository.selectHighRiskMemberInfoList(criteria);

		if (list == null || list.size() < 1) {
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "고위험군에 해당하는 사용자 정보가 없습니다.");
		}

		List<UstraExcelCellInfoModel> commHeader =  Arrays.asList(
			new UstraExcelCellInfoModel("col0", "설문완료일자"),
			new UstraExcelCellInfoModel("col1", "회원ID"),
			new UstraExcelCellInfoModel("col2", "회원명"),
			new UstraExcelCellInfoModel("col3", "핸드폰번호"),
			new UstraExcelCellInfoModel("col4", "생년월일"),
			new UstraExcelCellInfoModel("col5", "성별"),
			new UstraExcelCellInfoModel("col6", "사번"),
			new UstraExcelCellInfoModel("col7", "개인정보동의"),
			new UstraExcelCellInfoModel("col8", "개인정보동의일자"),
			new UstraExcelCellInfoModel("col9", "민감정보동의"),
			new UstraExcelCellInfoModel("col10", "민감정보동의일자"),
			new UstraExcelCellInfoModel("col11", "마음검진참여여부"),
			new UstraExcelCellInfoModel("col12", "마음검진참여일자"),
			new UstraExcelCellInfoModel("col13", "전체등급"),
			new UstraExcelCellInfoModel("col14", "직무스트레스"),
			new UstraExcelCellInfoModel("col15", "근무환경"),
			new UstraExcelCellInfoModel("col16", "업무량"),
			new UstraExcelCellInfoModel("col17", "업무특성"),
			new UstraExcelCellInfoModel("col18", "대인관계"),
			new UstraExcelCellInfoModel("col19", "고용안정"),
			new UstraExcelCellInfoModel("col20", "조직체계"),
			new UstraExcelCellInfoModel("col21", "보상"),
			new UstraExcelCellInfoModel("col22", "조직문화"),
			new UstraExcelCellInfoModel("col23", "심리적증상"),
			new UstraExcelCellInfoModel("col24", "우울"),
			new UstraExcelCellInfoModel("col25", "불안"),
			new UstraExcelCellInfoModel("col26", "분노"),
			new UstraExcelCellInfoModel("col27", "공포"),
			new UstraExcelCellInfoModel("col28", "건강염려"),
			new UstraExcelCellInfoModel("col29", "강박"),
			new UstraExcelCellInfoModel("col30", "스트레스취약성"),
			new UstraExcelCellInfoModel("col31", "자살사고"),
			new UstraExcelCellInfoModel("col32", "수면문제"),
			new UstraExcelCellInfoModel("col33", "중독"),
			new UstraExcelCellInfoModel("col34", "외상경험")
		);

		List<Map<String, Object>> cmmList = new ArrayList<Map<String,Object>>();

		for(int i = 0; i < list.size(); i++) {
			Map<String, Object> model = list.get(i);

			Map<String, Object> map = new TreeMap<>();
			map.put("col0", model.get("설문완료일"));
			map.put("col1", model.get("UID"));
			map.put("col2", model.get("이름"));
			map.put("col3", model.get("핸드폰번호"));
			map.put("col4", model.get("생년월일"));
			map.put("col5", model.get("성별"));
			map.put("col6", model.get("사번"));
			map.put("col7", model.get("개인정보동의"));
			map.put("col8", model.get("개인정보동의일자"));
			map.put("col9", model.get("민감정보동의"));
			map.put("col10", model.get("민감정보동의일자"));
			map.put("col11", model.get("마음검진참여여부"));
			map.put("col12", model.get("마음검진참여일자"));
			map.put("col13", model.get("전체등급"));
			map.put("col14", model.get("직무스트레스"));
			map.put("col15", model.get("근무환경"));
			map.put("col16", model.get("업무량"));
			map.put("col17", model.get("업무특성"));
			map.put("col18", model.get("대인관계"));
			map.put("col19", model.get("고용안정"));
			map.put("col20", model.get("조직체계"));
			map.put("col21", model.get("보상"));
			map.put("col22", model.get("조직문화"));
			map.put("col23", model.get("심리적증상"));
			map.put("col24", model.get("우울"));
			map.put("col25", model.get("불안"));
			map.put("col26", model.get("분노"));
			map.put("col27", model.get("공포"));
			map.put("col28", model.get("건강염려"));
			map.put("col29", model.get("강박"));
			map.put("col30", model.get("스트레스취약성"));
			map.put("col31", model.get("자살사고"));
			map.put("col32", model.get("수면문제"));
			map.put("col33", model.get("중독"));
			map.put("col34", model.get("외상경험"));

			cmmList.add(map);
		}

		UstraExcelModel excelModel = UstraExcelModel.of(cmmList, commHeader).withSheetName("마음상담_고위험군");

		Map<String, String> dwldInfoMap = criteria.getDwldInfo();

		dwldInfoMap.put("dwldCount", String.valueOf(list.size()));

		if (list.size() > 1) {
			dwldInfoMap.put("dwldAccess", list.get(0).get("이름") + "외 " + (list.size() - 1) + "명");
		} else {
			dwldInfoMap.put("dwldAccess", String.valueOf(list.get(0).get("이름")));
		}

		criteria.setDwldInfo(dwldInfoMap);

		ExcelDwldLogVo logVo = new ExcelDwldLogVo();
		logVo.setDwldInfo(criteria.getDwldInfo());

		careCommonService.setExcelDownloadLog(logVo);

		return excelModel;
	}

	@Transactional
	public void setApplicationStatus(List<MidCnslApplBscModel> list) {
		if (list != null) {
			for (MidCnslApplBscModel model : list) {
				counselRepository.updateMidCnslStatus(model);
			}
		}
	}

	public boolean checkApplicationConflict(MidCnslApplBscModel model) {
		Integer applPsblCnt = counselRepository.selectAvailApplCnt(model);
		Integer conflictCnt = counselRepository.selectConflictCounselByDate(model);

		if (conflictCnt != null && applPsblCnt != null && conflictCnt == applPsblCnt) {
			return true;
		}

		return false;
	}

	@Transactional
	public void setApplication(MidCnslApplBscModel model) {
		counselRepository.updateMidCnsl(model);
	}

	public List<String> getHolidayList() {
		return counselRepository.selectHolidayList();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void setHoliday(Map<String, Object> paramsMap) {

		if (paramsMap.get("remove") != null) {
			List<Map<String, Object>> removeList = (List<Map<String, Object>>) paramsMap.get("remove");

			for (Map<String, Object> deleteMap : removeList) {
				counselRepository.deleteHoliday(deleteMap);
			}
		}

		if (paramsMap.get("update") != null) {
			List<Map<String, Object>> saveList = (List<Map<String, Object>>) paramsMap.get("update");

			for (Map<String, Object> saveMap : saveList) {
				saveMap.put("usrId", GchcJwtUtil.getUserId());

				counselRepository.updateHoliday(saveMap);
			}
		}
	}

}
