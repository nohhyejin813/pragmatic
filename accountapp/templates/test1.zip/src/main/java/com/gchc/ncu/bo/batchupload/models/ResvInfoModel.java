package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResvInfoModel extends NcuModel {

    private String resvApplDt;

    private String resvTmcRngCd;

    private Integer itmId;
}
