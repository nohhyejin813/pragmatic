package com.gchc.ncu.bo.batchupload.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import com.gchc.ncu.bo.comm.models.NcuModel;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PackageItemUploadTitleModel extends NcuModel {

	int pkgItmTitlId;

	int pkgItmUpldBscId;

	String pkgItmShtDvCd;

	int xclComnId;

	String xclVal;

	String pkgNm;

	String pkgTyCont;

	String pkgItmAmtVal;

	int pkgTyId;

	int pkgExscYn;

	int chexYn;

	int pkgItmStVal;

	int cmplYn;

	int pkgTitlStVal;

	String pkgTitlErrCont;
}
