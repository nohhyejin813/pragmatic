package com.gchc.ncu.bo.batchupload.enu;

public enum PackageTypeStatus {

	NOT_REGISTERD("0"),

	SAVED("1"),

	REGISTERD("2"),

	REJECTED("3"),

	CONFIRMED("4")
	;

	String value;

	PackageTypeStatus(String value) {

		this.value = value;
	}

	public String getValue() {

		return value;
	}
}
