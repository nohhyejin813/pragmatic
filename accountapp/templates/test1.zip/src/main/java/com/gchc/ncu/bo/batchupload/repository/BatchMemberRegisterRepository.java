package com.gchc.ncu.bo.batchupload.repository;

import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

@Mapper
public interface BatchMemberRegisterRepository {

	// for merge
	void updateClcoAempBlkRegTmpId(Map<String, Object> params);

	void updateClcoAempBlkRegTmpId2(Map<String, Object> params);

	void insertMbrBsc(Map<String, Object> params);

	void insertMbrAddInfDtl(Map<String, Object> params);

	void updateMbrAddInfDtl(Map<String, Object> params);

	void insertMbrClcoRltn(Map<String, Object> params);

	void insertMbrClcoRltnChgRecs(Map<String, Object> params);

	void updateClcoAempBlkRegTmpUpdYn(Map<String, Object> params);

	void insertMbrChgRecsMbl(Map<String, Object> params);

	void insertMbrChgRecsEml(Map<String, Object> params);

	void insertMbrChgRecsNm(Map<String, Object> params);

	void insertMbrChgRecsBrdt(Map<String, Object> params);

	void insertMbrChgRecsSex(Map<String, Object> params);

	void updateClcoAempBlkRegTmpIdUpdYn(Map<String, Object> params);

	void insertMbrChgRecsId(Map<String, Object> params);

	void updateMbrBsc(Map<String, Object> params);

	void updateMbrClcoRltn(Map<String, Object> params);

	void insertMbrClcoRltnChgRecs2(Map<String, Object> params);

	void insertMbrHthSvcInfHis(Map<String, Object> params);

	void insertHthRistAsmCuRltn(Map<String, Object> params);

	void insertMbrBsplHis(Map<String, Object> params);

	void updateClcoAempBlkRegTmpTgtId(Map<String, Object> params);

	void insertCuTgtHis(Map<String, Object> params);

	void updateCuTgtHisExcuYn(Map<String, Object> params);

	void updateCuTgtHisMemo(Map<String, Object> params);

	void updateClcoAempBlkRegTmpTgtId2(Map<String, Object> params);

	void updateExtrHndlMttrResvTgtDelete(Map<String, Object> params);

	void insertExtrHndlMttrResvTgtRecs(Map<String, Object> params);

	void insertExtrHndlMttrResvTgt(Map<String, Object> params);

	void insertExtrHndlMttrResvTgt2(Map<String, Object> params);

	void insertExtrHndlMttrResvTgtRecs2(Map<String, Object> params);

	void updateClcoAempBlkRegTmpTgtrId(Map<String, Object> params);

	void insertCuTgtrHis(Map<String, Object> params);

	void insertCuTgtrRecs(Map<String, Object> params);

	void updateCuTgtrHis(Map<String, Object> params);

	void updateClcoAempBlkRegTmpVcnTgtrId(Map<String, Object> params);

	//void insertVcnTgtrBsc(Map<String, Object> params);

	void insertVcnTgtrChgRecs(Map<String, Object> params);

	void updateVcnTgtrBsc(Map<String, Object> params);

	void updateClcoAempBlkRegTmpSpsrTgtrId(Map<String, Object> params);

	void insertCuTgtrHisSpsr(Map<String, Object> params);

	void insertCuTgtrHisOther(Map<String, Object> params);

	void insertCuTgtrRecsSpsr(Map<String, Object> params);

	void updateCuTgtrHisSpsr(Map<String, Object> params);

	void updateClcoAempBlkRegTmpSpsrVcnTgtrId(Map<String, Object> params);

	void insertVcnTgtrChgRecsSpsr(Map<String, Object> params);

	void updateVcnTgtrBscSpsr(Map<String, Object> params);

	//void updateMbrClcoRltn2(Map<String, Object> params);

	//void insertMbrClcoRltnChgRecs3(Map<String, Object> params);

	//void updateMbrBsplHis(Map<String, Object> params);

	//void updateMbrAddInfDtl2(Map<String, Object> params);

	void updateClcoAempBlkRegTmpInfo(Map<String, Object> params);

	void updateClcoAempBlkRegTmpRegist(Map<String, Object> params);

	//void updateClcoAempBlkRegTmpUid(Map<String, Object> params);

	void updateClcoAempBlkRegTmpUpldSt(Map<String, Object> params);

	void updateClcoAempBlkRegTmpUpldSt2(Map<String, Object> params);

	void insertExtrHndlMttr(Map<String, Object> params);

	void deleteMbrBsplHis(Map<String, Object> params);

	void updateClcoAempBlkRegTmpUpldSt3(Map<String, Object> params);

	void insertMbrSpfnSyntInfBsc(Map<String, Object> params);

	void updateMbrSpfnSyntInfBsc(Map<String, Object> params);

	void insertMbrSpfnSyntInfBscSpsr(Map<String, Object> params);

	void updateMbrSpfnSyntInfBscSpsr(Map<String, Object> params);

	void updateExtrHndlMttrResvTgtDelete2(Map<String, Object> params);

	void deleteClcoAempBlkRegTmpSpsrTgtr(Map<String, Object> params);

	void insertCustInfEmpRecs(Map<String, Object> params);

	void insertCustInfEmpRecsForTgt(Map<String, Object> params);

	void insertCustInfEmpRecsFmlyInit(Map<String, Object> params);

	void updateClcoAempBlkRegTmpUpldStPrev(Map<String, Object> params);

	void insertCustInfEmpRecsForSpsr(Map<String, Object> params);

	void updateDmcyMbrBsc(Map<String, Object> params);

	void insertClcoWorkDept(Map<String, Object> params);

	void insertClcoLine(Map<String, Object> params);

	void insertClcoJob(Map<String, Object> params);

	void insertMbrMuscDeptHis(Map<String, Object> params);

	void updateMbrMuscDeptHis(Map<String, Object> params);

	void insertClcoTeam(Map<String, Object> params);

	void updateMbrClcoRltnTeamId(Map<String, Object> params);

}
