package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BatchResignationExcelModel extends NcuModel {
	/**
	 * 오류 엑셀다운로드
	 **/
	private String clcoNm;                // 고객사
	private String bsplNm;					// 사업장명
	private String mbrGrdNm;				// 등급명
	private String empNo;					// 사번
	private String tgtrNm;					// 검진대상자명
	private String tgtrbrdt;				// 검진대상자 생년월일
	private String aempNm;					// 임직원 이름
	private String aempBrdt;				// 임직원 생년월일
	private String corpSpfn;				// 회사 지원금
	private String pkgNm;					// 지원 패키지명(패키지 명)
	private String resvStCd;				// 예약상태
	private String cuiNm;					// 검진센터명
	private String pkgTyNm;					// 예약한 패키지명(패키지 타입명)
	private String cmplDtm;					// 검진 완료일
	private String resvFnlzDt;				// 예약 확정일
	private String tn1ResvApplDt;			// 1차 예약 신청일
	private String tn2ResvApplDt;			// 2차 예약 신청일
	private String frstResvDt;				// 예약 신청일
	private String firstaempNm;				// 직원명(최초)
	private boolean selfYn;					// 본인여부
	private String errMsg;					// 에러 메세지
}