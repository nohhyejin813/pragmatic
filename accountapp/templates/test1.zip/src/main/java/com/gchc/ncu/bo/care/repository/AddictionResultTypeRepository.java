package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.PoisRsltDtlModel;
import com.gchc.ncu.bo.care.vo.AddictionResultTypeVo;

@Mapper
public interface AddictionResultTypeRepository {

	List<PoisRsltDtlModel> selectAddictionResultTypeList(AddictionResultTypeVo criteria);
	PoisRsltDtlModel selectAddictionResultTypeDetail(PoisRsltDtlModel criteria);
	void saveAddictionResultType(PoisRsltDtlModel model);
	void deleteAddictionResultType(PoisRsltDtlModel model);

}
