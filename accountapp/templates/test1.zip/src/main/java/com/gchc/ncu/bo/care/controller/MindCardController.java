package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.MidCardBscModel;
import com.gchc.ncu.bo.care.service.MindCardService;
import com.gchc.ncu.bo.care.vo.MindCardVo;

@RestController
@RequestMapping("/api/bo/care/mind/card")
@RequiredArgsConstructor
public class MindCardController {

	private final MindCardService MindCardService;

	@GetMapping("/searchBsc")
	public List<MidCardBscModel> searchBsc(@ModelAttribute MindCardVo criteria) {
		return MindCardService.getMidCardBsc(criteria);
	}

	@GetMapping("/searchDtl")
	public MidCardBscModel searchDtl(@ModelAttribute MindCardVo criteria) {
		return MindCardService.getMidCardDtl(criteria);
	}

	@PostMapping("/saveBsc")
	public RestResult<?> updateCsttMateBsc(@RequestBody @Valid MidCardBscModel model) {
		MindCardService.saveBsc(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/deleteBsc")
	public RestResult<?> deleteBsc(@RequestBody List<MidCardBscModel> list ) {
		MindCardService.deleteBsc(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
