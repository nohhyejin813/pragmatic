package com.gchc.ncu.bo.abnormalfindings.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.abnormalfindings.models.target.AbnfTargetModel;
import com.gchc.ncu.bo.abnormalfindings.service.TargetService;
import com.gchc.ncu.bo.abnormalfindings.vo.target.AbnfTargetVo;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.checkupinst.models.CodeModel;
import com.gchc.ncu.bo.checkupinst.util.CheckupInstUtil;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;



/**
 * 유소견 Controller
 * @FileName : AbnormalFindingsController.java
 * @date : 2021. 7. 30
 * @author : gs_shbaek@gchealthcare.com
 * @프로그램 설명 :
 * @변경이력 :
 */
@Api(tags="유소견 관리 - AbnormalFindingsController", description="AbnormalFindingsController")
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/abnormalFindings")
public class TargetController {
	private final TargetService targetService;


	@Autowired
	private FileOperationManager fileOperationManager;





	@Qualifier("checkupinstUtil")
	@Autowired
	CheckupInstUtil util;



	@ApiOperation(value="고객사 목록 조회", notes = "고객사 목록 조회 한다.")
	@GetMapping("/clco-list")
	public List<CodeModel> getClcoList()
	{
		return targetService.getClcoList();
	}



	@ApiOperation(value="대상자 목록 조회", notes = "대상자 목록 조회을 조회 한다.")
	@GetMapping("/target-list")
	public RestResult<List<AbnfTargetModel>> getTargetList(@ModelAttribute AbnfTargetVo targetVo)
	{
    	List<AbnfTargetModel> resultList = targetService.getTargetList(targetVo);
		return GchcRestResult.of(resultList);
	}

	@ApiOperation(value = "대상자 목록 조회 엑셀 다운로드", notes = "대상자 목록 조회엑셀 다운로드")
	@PostMapping("/target-list/excel")
	public ResponseEntity<?> getTargetListExcelDownload(@RequestBody AbnfTargetVo targetVo, HttpServletRequest request, HttpServletResponse response)  {

		List<AbnfTargetModel> targetList = targetService.getTargetListExcelDownload(targetVo);
		List<Map<String, Object>> cmmTargetList = new ArrayList<Map<String,Object>>();

		// 공통백신결과 List MAP 처리
		for(int i=0; i<targetList.size(); i++) {
			Map<String, Object> map = new TreeMap<>();
			AbnfTargetModel cmmMap = targetList.get(i);	// 공통 백신리스트

			map.put("col1"	, cmmMap.getNm());						// 이름
			map.put("col2"	, cmmMap.getClcoNm());					// 고객사
			map.put("col3"	, cmmMap.getEmpNo());					// 사번
			map.put("col4"	, cmmMap.getCuRsltCrtDt());				// 검진결과 생성일
			map.put("col5"	, cmmMap.getCuDt());					// 검진일
			map.put("col6"	, cmmMap.getRcntRegDt());				// 최근 등록일
			map.put("col7"	, cmmMap.getBcsGrpNm());				// 심뇌 위험군
			map.put("col8"	, cmmMap.getMtsyGrpNm());				// 대사군
			map.put("col9"	, cmmMap.getCncrPvntGrpNm());			// 암 예방군

			cmmTargetList.add(map);
		}

		// ===============================================================
		UstraExcelModel excelModel;

		// [[ 1번 SHEET ]] ########################################################################
		excelModel = UstraExcelModel.of(
			cmmTargetList,
			Arrays.asList(
				new UstraExcelCellInfoModel("col1"	, "이름"),
				new UstraExcelCellInfoModel("col2"	, "고객사"),
				new UstraExcelCellInfoModel("col3"	, "사번"),
				new UstraExcelCellInfoModel("col4"	, "검진결과 생성일"),
				new UstraExcelCellInfoModel("col5"	, "검진일"),
				new UstraExcelCellInfoModel("col6"	, "최근 등록일"),
				new UstraExcelCellInfoModel("col7"	, "심뇌 위험군"),
				new UstraExcelCellInfoModel("col8"	, "대사군"),
				new UstraExcelCellInfoModel("col9"	, "암 예방군")
			))
		.withCellGenerator(new BatchUploadCellGenerator())
		.withSheetName("유소견_관리대상자리스트")	;	// 시트명

		return fileOperationManager
				.convert(DataToExcelWebResourceConverter
						.entityBuilder(Arrays.asList(excelModel), "유소견_관리대상자리스트.xls", request, response)
						.build());
	}


	@ApiOperation(value="대상자 목록 조회", notes = "대상자 목록 조회을 조회 한다.")
	@PostMapping("/npcpvntgrpnm")
	public Integer updateNpcPvntGrpNm(@RequestBody AbnfTargetVo targetVo)
	{
		return targetService.updateNpcPvntGrpNm(targetVo);
	}
}
