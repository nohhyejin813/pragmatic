package com.gchc.ncu.bo.abnormalfindings.vo.management;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.gchc.common.model.GchcVo;



@Getter
@Setter
@ToString
public class ManagermentDeptNmVo extends GchcVo
{
	@ApiModelProperty(value="고객사 ID", example="1")
	private Integer clcoId;

	@ApiModelProperty(value="부서명 ID", example="1")
	private String deptId;

}

