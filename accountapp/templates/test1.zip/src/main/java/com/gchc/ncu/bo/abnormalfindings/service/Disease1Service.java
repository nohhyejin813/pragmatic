package com.gchc.ncu.bo.abnormalfindings.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.gchc.ncu.bo.abnormalfindings.models.Disease1Model;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBusinessPlaceModel;
import com.gchc.ncu.bo.abnormalfindings.repository.Disease1Repository;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogService;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;
import com.gchc.ncu.bo.comm.util.GchcGridUtil;
import com.gsitm.ustra.java.core.utils.UstraMaskingUtils;
import com.gsitm.ustra.java.data.domains.PaginationList;
import com.gsitm.ustra.java.data.mybatis.pagination.domain.Paginator;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 검진결과:유소견관리(암)
 *
 * @author 2021.11.29
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class Disease1Service {

	@Autowired
	private Disease1Repository mapper;

	@Autowired
	private XlsDownloadRecordService xlsDownloadRecordService;

	@Autowired
	private UsrInnfActiLogService usrInnfActiLogService;


	public List<ManagermentBusinessPlaceModel> getWorkPlaceList(Disease1Model model) {
		return mapper.getWorkPlaceList(model);
	}


	/**
     * 유소견관리(암)  - 목록조회
     */
	public List<Disease1Model> getDisease1List(Disease1Model model) {
		List<Disease1Model> resultList = new ArrayList<Disease1Model>();
		model.setOrderName(GchcGridUtil.getCamalToLarge("ROW_NUM", model.getOrderName()));

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("model", model);
		paramMap.put("currentPage", model.getCurrentPage());
		paramMap.put("pageSize", model.getPageSize());
		paramMap.put("order", model.getOrderName());
		paramMap.put("orderDirection", model.getOrderDirection().toString());

		mapper.exeKeyOpen();
		List<Disease1Model> list = mapper.getDisease1List(paramMap);
		mapper.exeKeyClose();

		int count = list != null && list.size() > 0 ? list.get(0).getTotalItemCount() : 0;
		resultList = new PaginationList<Disease1Model>(list, new Paginator(model.getCurrentPage(), model.getPageSize(), count));

		if(list !=  null && list.size() > 1) {
			UsrInnfActiLogModel usrInfomodel = new UsrInnfActiLogModel();
			usrInfomodel.setActiLogDvCd("40");	//로깅 유형
			usrInfomodel.setMenuNm("유소견 관리 > 유소견관리(암) ");	//메뉴명
			usrInfomodel.setPfrmNm("유소견관리(암) 목록 ");	//실행명
			usrInfomodel.setPfrmCont(list.get(0).getClcoNm()+"고객사 유소견관리(암) 목록 조회");	//실행 내용
			usrInfomodel.setInnfVwCnt(list.get(0).totalItemCount.intValue());;	//조회 건수
			if(list.size() == 1) {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid().toString());	//고객명
			}else {
				usrInfomodel.setCustNm("UID : " + list.get(0).getUid() + "등 " + list.size() +"건");	//고객명
			}
			usrInnfActiLogService.insert(usrInfomodel);
		}

		if(resultList != null && resultList.size() > 0) {
			UstraMaskingUtils.maskTextFields(resultList);
		}

		return resultList;
	}


	public List<Disease1Model> getDisease1ListExcel(Disease1Model model) {

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("model", model);
		paramMap.put("currentPage", model.getCurrentPage());
		paramMap.put("pageSize", model.getPageSize());
		paramMap.put("order", model.getOrderName());
		paramMap.put("orderDirection", model.getOrderDirection().toString());

		mapper.exeKeyOpen();
		List<Disease1Model>  dataList =  mapper.getDisease1ListExcel(paramMap);
		mapper.exeKeyClose();

//		if(dataList != null && dataList.size() > 0) {
//			UstraMaskingUtils.maskTextFields(dataList);
//		}

		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm("유소견관리 > 검진결과:유소견관리(암) > 엑셀 다운로드");
		record.setDwldPageUrl(model.getDwldPageUrl());
		record.setDwldCont("고객명, 성별, 생일, 고객사명, 사번, 검진일, 등록일, B간염보균, 위함, 대장암, 폐암, 간암, 담남암, 췌장암, 신장암, 간상선암, 전립선암, 유방암");
		record.setDwldMemo(model.getDwldMemo()); // 메모
		record.setDwldRsnCd(model.getDwldRsnCd()); // 다운로드 사유 코드
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(dataList.size() ); //개인정보 Download 건수.
		record.setCustNm("UID : " + dataList.get(0).getUid() + "등  " + dataList.size() + "건"+"(고객사 : "+dataList.get(0).getClcoNm()+")");
		xlsDownloadRecordService.insert(record);


		return dataList;
	}

}
