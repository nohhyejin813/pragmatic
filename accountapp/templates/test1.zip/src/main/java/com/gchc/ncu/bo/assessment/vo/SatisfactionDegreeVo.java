package com.gchc.ncu.bo.assessment.vo;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.gchc.ncu.bo.assessment.models.SatisfactionDegreeModel;
import com.gsitm.ustra.java.mvc.rest.model.RestVo;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class SatisfactionDegreeVo extends RestVo {

	private int								yr;				//기준년도
	private int								cuiId;			//검진기관
	private int								clcoId;			//고객사

	@NotNull
	@Valid
	private SatisfactionDegreeModel 		info;			//고객만족도조사 상세

	private List<SatisfactionDegreeModel>	commentList;	//고객만족도조사 상세 > 코멘트 리스트

}