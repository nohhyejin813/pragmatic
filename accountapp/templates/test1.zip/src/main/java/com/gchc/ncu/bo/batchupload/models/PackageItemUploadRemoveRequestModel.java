package com.gchc.ncu.bo.batchupload.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PackageItemUploadRemoveRequestModel {

	Integer clcoId;

	Integer yr;

	Integer cuiId;

	Integer xclShtNo;

	Integer rowNum;

	String itmCatNm;

	String dtlCatItmNm;

	String examResvItmNm;
}
