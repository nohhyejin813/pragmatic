package com.gchc.ncu.bo.challenge.reward.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class RewardExcelModel extends NcuModel {
	/** 엑셀다운로드 **/
	private String empNo;		// 사번
}
