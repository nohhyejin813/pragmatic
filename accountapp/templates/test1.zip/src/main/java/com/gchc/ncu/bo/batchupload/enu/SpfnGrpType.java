package com.gchc.ncu.bo.batchupload.enu;

public enum SpfnGrpType {

	TRANSFER,

	SELECT
}
