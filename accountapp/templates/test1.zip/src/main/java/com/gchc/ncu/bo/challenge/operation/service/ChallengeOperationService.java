package com.gchc.ncu.bo.challenge.operation.service;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.care.models.*;
import com.gchc.ncu.bo.challenge.operation.models.CmpgCtraBsc2Model;
import com.gchc.ncu.bo.challenge.operation.repository.ChallengeOperationRepository;
import com.gchc.ncu.bo.care.service.CareCommApiService;
import com.gchc.ncu.bo.challenge.operation.vo.ChallengeOperationVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ChallengeOperationService {

	private final ChallengeOperationRepository challengeRepository;
	private final CareCommApiService careCommApiService;

	public CmpgCtraBsc2Model getCampaignContract(ChallengeOperationVo vo) {
		return challengeRepository.selectCampaignContract(vo);
	}

	@Transactional
	public void removeCampaignContract(List<CmpgCtraBsc2Model> models) {
		for (CmpgCtraBsc2Model model : models) {
			int usedCount = challengeRepository.selectUsedCampaignContractCount(model.getCmpgCtraId());

			if (usedCount > 0) {
				throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "회원 활동 이력이 존재하는 캠페인 계약입니다.");
			}

			ChallengeOperationVo vo = new ChallengeOperationVo();
			vo.setCmpgCtraId(model.getCmpgCtraId());

			List<CmpgBscModel> getTermList = getContractTermList(vo);

			for (CmpgBscModel termModel : getTermList) {
				challengeRepository.deleteCampaignRewardByCmpgId(termModel.getCmpgId());
				challengeRepository.deleteCampaignNotificationByCmpgId(termModel.getCmpgId());
				challengeRepository.deleteContractTerm(termModel.getCmpgId());
			}

			challengeRepository.deleteCampaignContract(model.getCmpgCtraId());
		}
	}

	public List<CmpgBscModel> getContractTermList(ChallengeOperationVo vo) {
		return challengeRepository.selectContractTermList(vo);
	}

	@Transactional
	public void setCampaignContractTerm(List<CmpgBscModel> models) {
		for (CmpgBscModel model : models) {
			if (model.getRowStatus().equals("D")) {
				int checkCount = challengeRepository.selectUsedCampaignMemberCount(model.getCmpgId());

				if (checkCount > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "회원 활동 이력이 존재하는 캠페인입니다.");
				}

				challengeRepository.deleteContractTerm(model.getCmpgId());
			} else {
				int checkCount = challengeRepository.selectOverlappedDateCount(model);

				if (checkCount > 0) {
					throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "캠페인 차수 목록을 재조회 후 중복된 진행기간을 확인해 주세요.");
				}

				if (model.getCmpgId() == null || model.getRowStatus().equals("C")) {
					challengeRepository.insertContractTerm(model);
				} else {
					challengeRepository.updateContractTerm(model);
				}
			}
		}
	}

	public List<CmpgNtfcDtlModel> getContractNoticeList(ChallengeOperationVo vo) {
		return challengeRepository.selectContractNoticeList(vo);
	}

	@Transactional
	public void setCampaignContractNotice(List<CmpgNtfcDtlModel> models) {
		for (CmpgNtfcDtlModel model : models) {
			if (model.getRowStatus().equals("D")) {
				challengeRepository.deleteContractNotice(model.getNtfcId());
			} else if (model.getCmpgId() == null || model.getRowStatus().equals("C")) {
				challengeRepository.insertContractNotice(model);
			} else {
				challengeRepository.updateContractNotice(model);
			}
		}
	}

	public List<CmpgCmpnDtlModel> getCampaignRewardList(ChallengeOperationVo vo) {
		return challengeRepository.selectCampaignRewardList(vo);
	}

	@Transactional
	public void setCampaignReward(List<CmpgCmpnDtlModel> models) {
		for (CmpgCmpnDtlModel model : models) {
			if (model.getRowStatus().equals("D")) {
				challengeRepository.deleteCampaignReward(model.getCmpgCmpnId());
			} else if (model.getCmpgCmpnId() == null || model.getRowStatus().equals("C")) {
				challengeRepository.insertCampaignReward(model);
			} else {
				challengeRepository.updateCampaignReward(model);
			}
		}
	}

	public List<MbrCmpgRecsModel> getCampaignRewardMemberList(ChallengeOperationVo vo) {
		List<MbrCmpgRecsModel> list = challengeRepository.selectCampaignRewardMemberList(vo);

//		UstraMaskingUtils.maskTextFields(list);

		return list;
	}

	@Transactional
	public void setCampaignRewardConfirm(ChallengeOperationVo vo) {
		CmpgCtraBsc2Model contractModel = getCampaignContract(vo);

		if (contractModel.getCmpnWayCd().equals("10")) {
			challengeRepository.updateCampaignRewardConfirmForRank(vo);
		} else if (contractModel.getCmpnWayCd().equals("20")) {
			List<CmpgCmpnDtlModel> getRewardList = getCampaignRewardList(vo);

			for (CmpgCmpnDtlModel model : getRewardList) {
				challengeRepository.updateCampaignRewardConfirmForDraw(model);
			}
		}

		challengeRepository.updateCampaignRewardAfterWork(vo);
	}

	@Transactional
	public void setCampaignRewardCancel(ChallengeOperationVo vo) {
		challengeRepository.updateCampaignRewardMemberCancel(vo);
		challengeRepository.updateCampaignRewardCancel(vo);
	}

	@Transactional
	public void setCampaignRewardPrize(List<MbrCmpgRecsModel> models) {
		for (MbrCmpgRecsModel model : models) {
			challengeRepository.updateCampaignRewardPrize(model);
		}
	}

	public List<CmpgBscModel> getOperManagementList(ChallengeOperationVo vo) {
		return challengeRepository.selectOperManagementList(vo);
	}

	public CmpgCtraBsc2Model getOperManagementDetail(ChallengeOperationVo vo) {
		return challengeRepository.selectOperManagementDetail(vo);
	}

	public List<MbrCmpgRecsModel> getOperManagementPeople(ChallengeOperationVo vo) {
		return challengeRepository.selectOperManagementPeople(vo);
	}

	public List<MbrCmpgRecsModel> getOperNoenterPeople(ChallengeOperationVo vo) {
		return challengeRepository.selectOperNoenterPeople(vo);
	}

	public List<MbrCmpgRecsModel> getOperPersonDetail(ChallengeOperationVo vo) {
		return challengeRepository.selectOperPersonDetail(vo);
	}

	public void getCampaignReset(ChallengeOperationVo vo) {
		careCommApiService.batchCareCampaign(vo.getCmpgId());
	}

	public List<CmpgNtfcBscModel> getCampaignNoticeList(ChallengeOperationVo vo) {
		return challengeRepository.selectCampaignNoticeList(vo);
	}

	public CmpgNtfcBscModel getCampaignNotice(ChallengeOperationVo vo) {
		return challengeRepository.selectCampaignNotice(vo);
	}

	public void setCampaignNotice(CmpgNtfcBscModel model) {
		if (model.getMsgId() == null) {
			challengeRepository.insertCampaignNotice(model);
		} else {
			challengeRepository.updateCampaignNotice(model);
		}
	}

	@Transactional
	public void removeCampaignNotice(List<CmpgNtfcBscModel> models) {
		for (CmpgNtfcBscModel model : models) {
			challengeRepository.deleteCampaignNotice(model.getMsgId());
		}
	}

	public List<CmpgTeamRecsModel> getOperationDetailTeam(ChallengeOperationVo vo) {
		return challengeRepository.selectOperationDetailTeam(vo);
	}

	public List<CmpgTeamRecsModel> getOperTeamPersonDetail(ChallengeOperationVo vo) {
		return challengeRepository.selectOperTeamPersonDetail(vo);
	}

	public void setTeamInfoUpdate(ChallengeOperationVo vo) {
		challengeRepository.updateCampaignTeamInfoUpdate(vo);
	}

	public CmpgBscModel getOperationTeamCount(ChallengeOperationVo vo) {
		return challengeRepository.selectOperationTeamCount(vo);
	}
}
