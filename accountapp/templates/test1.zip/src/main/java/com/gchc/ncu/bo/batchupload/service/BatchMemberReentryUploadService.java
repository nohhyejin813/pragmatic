package com.gchc.ncu.bo.batchupload.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.domains.PaginationRequest.OrderDirection;
import com.gsitm.ustra.java.data.poi.UstraExcelUtils.RowInfo;

import com.gchc.common.model.GchcPaginationRequest.GchcOrder;
import com.gchc.ncu.bo.batchupload.comm.PackageContextHolder;
import com.gchc.ncu.bo.batchupload.comm.SearchMapContextHolder;
import com.gchc.ncu.bo.batchupload.enu.BatchMemberUploadError;
import com.gchc.ncu.bo.batchupload.enu.BatchUploadColumn;
import com.gchc.ncu.bo.batchupload.enu.ReentryColumn;
import com.gchc.ncu.bo.batchupload.exception.BatchResponseCode;
import com.gchc.ncu.bo.batchupload.models.BatchMemberReentryUploadResultModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadCustomerReentryModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadReentryDownloadRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadReentryErrorRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchMemberUploadResultRequestModel;
import com.gchc.ncu.bo.batchupload.models.BatchUploadReentryExcelModel;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberReentryUploadRepository;
import com.gchc.ncu.bo.batchupload.repository.BatchMemberUploadRepository;
import com.gchc.ncu.bo.batchupload.utils.BatchUploadUtils;
import com.gchc.ncu.bo.config.GchcDataBatchExecutor;

@Service
public class BatchMemberReentryUploadService {

	@Autowired private BatchMemberUploadRepository memberUploadRepository;

	@Autowired private BatchMemberReentryUploadRepository repository;

	@Autowired private GchcDataBatchExecutor batchExecutor;

	boolean isEmptyRow(BatchUploadReentryExcelModel r) {

		return StringUtils.isEmpty(r.getAempNm()) &&
			StringUtils.isEmpty(r.getAempBrdt()) &&
			StringUtils.isEmpty(r.getExistAempId()) &&
			StringUtils.isEmpty(r.getNewAempId());
	}

	void checkReentryError(BatchMemberUploadCustomerReentryModel src, boolean result, BatchMemberUploadError error, Object...args) {

		if( !result ) {

			src.setUpldStVal(error.getErrorValue());
			src.setUpldErrVal(src.getUpldErrVal().concat(("|") + error.getMessage(args)));
		}
	}

	BatchUploadReentryExcelModel makeBrdt(BatchUploadReentryExcelModel src) {

		src.setAempBrdt(BatchUploadUtils.formattedBrdt(src.getAempBrdt()));
		return src;
	}

	BatchMemberUploadCustomerReentryModel validate(BatchMemberUploadCustomerReentryModel src) {

		// 패키지 조회
		if( PackageContextHolder.get() == null )
			PackageContextHolder.set(memberUploadRepository.getPackageList(SearchMapContextHolder.get()));

		// 오류 초기화
		src.setUpldStVal(1);
		src.setUpldErrVal("");

		// 생년월일, 성별 체크
		boolean validBrdt = BatchUploadUtils.checkBrdt(src.getAempBrdt());
		checkReentryError(src, validBrdt, BatchMemberUploadError.INVALID_INFORMATION, "생년월일");
		if( Optional.ofNullable(src.getAempBrdt()).map(String::length).orElse(0) > 10 ) {

			src.setAempSexCd(src.getAempBrdt().substring(10));
			src.setAempBrdt(src.getAempBrdt().substring(0, 10));
		}

		// 임직원 이름, 사번, 패키지명 체크
		checkReentryError(src, StringUtils.isNotEmpty(src.getAempNm()), BatchMemberUploadError.MISSING_INFORMATION, "이름");
		checkReentryError(src, StringUtils.isNotEmpty(src.getExistAempId()), BatchMemberUploadError.MISSING_INFORMATION, "기존 사번");
		checkReentryError(src, StringUtils.isNotEmpty(src.getNewAempId()), BatchMemberUploadError.MISSING_INFORMATION, "신규 사번");
		checkReentryError(src, StringUtils.isNotEmpty(src.getPkgNm()), BatchMemberUploadError.MISSING_INFORMATION, "패키지명");

		// 지원금 체크
		checkReentryError(src, BatchUploadUtils.numIn(src.getCorpSpfnVal(), 1000, Integer.MAX_VALUE),
			BatchMemberUploadError.INVALID_INFORMATION, "회사지원금");

		// 패키지 체크
		checkReentryError(src, StringUtils.isEmpty(src.getPkgNm()) ||
			!ObjectUtils.isEmpty(PackageContextHolder.get(src.getPkgNm())), BatchMemberUploadError.INVALID_AEMP_PACKAGE);

		return src;
	}

	private List<BatchUploadReentryExcelModel> errorExcelMsg(
		List<BatchUploadReentryExcelModel> errList) {

		return errList.stream()
			.map(e->{
				String errMsg = e.getUpldErrVal();
				if( StringUtils.isEmpty(errMsg) )
					return e;
				errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
				e.setUpldErrVal(errMsg.replace("|", "\r\n"));
				return e;
			})
			.collect(Collectors.toList());
	}

	List<BatchMemberUploadCustomerReentryModel> errorMsg(List<BatchMemberUploadCustomerReentryModel> errList) {

		return errList.stream()
			.map(e->{
				String errMsg = e.getUpldErrVal();
				if( StringUtils.isEmpty(errMsg) )
					return e;
				errMsg = errMsg.startsWith("|") ? errMsg.substring(1) : errMsg;
				e.setUpldErrVal(errMsg.replace("|", "\r\n"));
				return e;
			})
			.collect(Collectors.toList());
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void uploadMemberReentry(List<RowInfo> converted, Integer clcoId, Integer yr) {

		final int mngrId = BatchUploadUtils.getCurrentMngrId();

		// 헤더 체크
		if( CollectionUtils.isEmpty(converted) )
			BatchResponseCode.INVALID_SHEET.occur();
		Map<String, Object> headerRow = (Map<String, Object>)converted.get(0).getObject();

		String missed = BatchUploadColumn.stream(ReentryColumn.class)
			.filter(c->!BatchUploadUtils.hdrIn(c.getTitle(), headerRow.values()))
			.findFirst()
			.map(BatchUploadColumn::getTitle)
			.orElse(null);
		if( StringUtils.isNotEmpty(missed) )
			BatchResponseCode.INVALID_SHEET_TITLE.occur(missed);

		// 빈 ROW 삭제 및 값 설정
		List<BatchUploadReentryExcelModel> aempList = converted.subList(1, converted.size()).stream()
			.filter(r->!BatchUploadUtils.isEmptyRow(r.getObject()))
			.map(r->{

				BatchUploadReentryExcelModel o = BatchUploadUtils.map((Map<String, Object>)r.getObject(), headerRow,
					BatchUploadColumn.table(ReentryColumn.class), BatchUploadReentryExcelModel.class);
				o.setClcoId(clcoId);
				o.setYr(yr);
				return makeBrdt(o);
			})
			.filter(r->!isEmptyRow(r))
			.collect(Collectors.toList());

		// 검색조건 설정
		SearchMapContextHolder.set(UstraMapUtils.getMap(
			"clcoId", clcoId,
			"yr", yr,
			"mngrId", mngrId));

		// 업로드 초기화
		repository.updateClcoAempReenBlkRegTmpUploadYn(SearchMapContextHolder.get());

		// 신규 등록 대상 추출
		List<BatchMemberUploadCustomerReentryModel> forInsert = aempList.stream()
			.filter(c->StringUtils.isEmpty(c.getAempReenRegSeq()))
			.map(c->validate(BatchUploadUtils.map(c, BatchMemberUploadCustomerReentryModel.class)))
			.collect(Collectors.toList());

		// 업데이트 대상 추출
		List<BatchMemberUploadCustomerReentryModel> forUpdate = new ArrayList<>();
		List<BatchUploadReentryExcelModel> checkUpdate = aempList.stream()
			.filter(c->StringUtils.isNotEmpty(c.getAempReenRegSeq()))
			.collect(Collectors.toList());
		if( CollectionUtils.isNotEmpty(checkUpdate) ) {

			List<BatchMemberUploadCustomerReentryModel> checked = repository.getClcoAempReenBlkRegTmpForUpdate(UstraMapUtils.getMap(
				"clcoId", clcoId,
				"yr", yr,
				"mngrId", mngrId,
				"list", checkUpdate));
			forUpdate = checkUpdate.stream()
				.filter(c->checked.stream().anyMatch(ch->c.getAempReenRegSeq().equals("" + ch.getAempReenRegSeq())))
				.map(c->validate(BatchUploadUtils.map(c, BatchMemberUploadCustomerReentryModel.class)))
				.collect(Collectors.toList());

			forInsert.addAll(checkUpdate.stream()
				.filter(c->checked.stream().noneMatch(ch->c.getAempReenRegSeq().equals("" + ch.getAempReenRegSeq())))
				.map(c->validate(BatchUploadUtils.map(c, BatchMemberUploadCustomerReentryModel.class)))
				.collect(Collectors.toList()));
		}

		// 신규 등록
		int aempRegSeq = repository.getAempReenBlkRegTmpNextSeq(SearchMapContextHolder.get());
		for( int i=0; i<forInsert.size(); i++ ) {
			forInsert.get(i).setAempReenRegSeq(aempRegSeq++);
			forInsert.get(i).setMngrId(forInsert.get(i).getAdminUserMngrId());
		}

		batchExecutor.batchUpdate(
			"INSERT INTO MBR.T_CLCO_AEMP_REEN_BLK_REG_TMP (\r\n" +
			"	  CLCO_ID\r\n" +
			"	, YR\r\n" +
			"   , UID\r\n" +
			"	, AEMP_REEN_REG_SEQ\r\n" +
			"	, AEMP_NM\r\n" +
			"	, AEMP_BRDT\r\n" +
			"	, AEMP_SEX_CD\r\n" +
			"	, EXIST_AEMP_ID\r\n" +
			"	, NEW_AEMP_ID\r\n" +
			"	, PKG_NM\r\n" +
			"	, CORP_SPFN\r\n" +
			"	, UPLD_YN\r\n" +
			"	, MNGR_ID\r\n" +
			"	, UPLD_ST_VAL\r\n" +
			"	, UPLD_ERR_VAL\r\n" +
			"	, USE_YN\r\n" +
			"	, DEL_YN\r\n" +
			"	, FRST_REG_DTM\r\n" +
			"	, FRST_REGR_TY_CD\r\n" +
			"	, FRST_REGR_ID\r\n" +
			"	, LAST_UPD_DTM\r\n" +
			"	, LAST_UPDR_TY_CD\r\n" +
			"	, LAST_UPDR_ID\r\n" +
			")\r\n" +
			"VALUES (\r\n" +
			"	  #{clcoId}\r\n" +
			"	, #{yr}\r\n" +
			"   , 0\r\n" +
			"	, #{aempReenRegSeq}\r\n" +
			"	, #{aempNm}\r\n" +
			"	, #{aempBrdt}\r\n" +
			"	, #{aempSexCd}\r\n" +
			"	, #{existAempId}\r\n" +
			"	, #{newAempId}\r\n" +
			"	, #{pkgNm}\r\n" +
			"	, TRY_CONVERT(INT, #{corpSpfnVal})\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, #{upldStVal}\r\n" +
			"	, #{upldErrVal}\r\n" +
			"	, 1\r\n" +
			"	, 0\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			"	, GETDATE()\r\n" +
			"	, 1\r\n" +
			"	, #{mngrId}\r\n" +
			")", forInsert);

		// 업데이트
		forUpdate.forEach(r->r.setMngrId(r.getAdminUserMngrId()));
		batchExecutor.batchUpdate(
			"UPDATE MBR.T_CLCO_AEMP_REEN_BLK_REG_TMP\r\n" +
			"SET  CLCO_ID = #{clcoId}\r\n" +
			"	, YR = #{yr}\r\n" +
			"	, AEMP_REEN_REG_SEQ = #{aempReenRegSeq}\r\n" +
			"	, AEMP_NM = #{aempNm}\r\n" +
			"	, AEMP_BRDT = #{aempBrdt}\r\n" +
			"	, AEMP_SEX_CD = #{aempSexCd}\r\n" +
			"	, EXIST_AEMP_ID = #{existAempId}\r\n" +
			"	, NEW_AEMP_ID = #{newAempId}\r\n" +
			"	, PKG_NM = #{pkgNm}\r\n" +
			"	, CORP_SPFN = #{corpSpfnVal}\r\n" +
			"	, UPLD_YN = 1\r\n" +
			"	, MNGR_ID = #{mngrId}\r\n" +
			"	, DEL_YN = 0\r\n" +
			"	, UPLD_ST_VAL = #{upldStVal}\r\n" +
			"	, UPLD_ERR_VAL = #{upldErrVal}\r\n" +
			"	, LAST_UPD_DTM = GETDATE()\r\n" +
			"	, LAST_UPDR_TY_CD = 1\r\n" +
			"	, LAST_UPDR_ID = #{mngrId}\r\n" +
			"WHERE 1=1\r\n" +
			"	AND YR = #{yr}\r\n" +
			"	AND CLCO_ID = #{clcoId}\r\n" +
			"	AND AEMP_REEN_REG_SEQ = #{aempReenRegSeq}", forUpdate);

		// 고객사 내 중복 체크
		repository.updateClcoAempReenBlkRegTmpValidate(SearchMapContextHolder.get());

		// UID 설정
		repository.updateClcoAempReenBlkRegTmpUid(SearchMapContextHolder.get());

		// UID 가 없는 경우 오류 (퇴사 정보를 찾을 수 없습니다.)
		repository.updateClcoAempReenBlkRegTmpValidate2(SearchMapContextHolder.get());
	}

	public BatchMemberReentryUploadResultModel getResult(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		BatchMemberReentryUploadResultModel result = repository.getClcoAempReenBlkRegTmpResult(in);
		result.setErrorCnt(result.getMissedCnt() + result.getInvalidCnt() + result.getDuplicatedCnt() + result.getEtcCnt());
		return result;
	}

	@Transactional
	public void remove(List<BatchMemberUploadCustomerReentryModel> in) {

		repository.updateClcoAempReenBlkRegTmpRemove(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in));
	}

	@Transactional
	public void removeAll(BatchMemberUploadReentryErrorRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		repository.updateClcoAempReenBlkRegTmpRemoveAll(in);
	}

	@Transactional
	public void init(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		repository.updateClcoAempReenBlkRegTmpInit(in);
	}

	@Transactional
	public void regist(BatchMemberUploadResultRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());

		// 회원고객사관계 업데이트
		repository.updateMbrClcoRltnRestore(in);

		// 회원고객사관계 변경이력
		repository.insertMbrClcoRltnChgRecsRestore(in);

		// 회원사업장내역 업데이트
		repository.updateMbrBsplHisRestore(in);

		// 회원유형코드 업데이트
		repository.updateMbrBscMbrTyCd(in);

		// 회원 변경이력
		repository.insertMbrChgRecs(in);

		// 회원B2C고객사관계 업데이트
		repository.updateMbrClcoRltnQuit(in);

		// 회원B2C고객사관계 변경이력
		repository.insertMbrClcoRltnChgRecsQuit(in);

		// 회원B2C사업장이력 삭제
		repository.updateMbrBsplHisQuit(in);

		// 등록 완료 처리
		repository.updateClcoAempReenBlkRegTmpRegist(in);
	}

	public List<BatchMemberUploadCustomerReentryModel> getErrorList(BatchMemberUploadReentryErrorRequestModel in) {

		in.setMngrId(BatchUploadUtils.getCurrentMngrId());
		List<BatchMemberUploadCustomerReentryModel> list = repository.getClcoAempReenBlkRegTmp(in, in.toPaginationRequest(
			GchcOrder.of("AEMP_REEN_REG_SEQ", OrderDirection.ASC)));
		return errorMsg(list);
	}

	public List<BatchUploadReentryExcelModel> getTestReentryCustomerList(BatchMemberUploadReentryDownloadRequestModel in) {

		in.setMngrId("" + BatchUploadUtils.getCurrentMngrId());
		return repository.getClcoAempReenBlkRegTmpTestExcelList(in);
	}

	public List<BatchUploadReentryExcelModel> selectReentryCustomerTmpExcelList(
		BatchMemberUploadReentryDownloadRequestModel in) {
		in.setMngrId("" + BatchUploadUtils.getCurrentMngrId());
		return errorExcelMsg(repository.getClcoAempReenBlkRegTmpExcelList(in));
	}

	public List<BatchUploadReentryExcelModel> selectReentryCustomerTmpExcelList(
		List<BatchMemberUploadCustomerReentryModel> in) {

		if( CollectionUtils.isEmpty(in) )
			return Arrays.asList(new BatchUploadReentryExcelModel());

		return errorExcelMsg(repository.getClcoAempReenBlkRegTmpExcelList2(UstraMapUtils.getMap(
			"clcoId", in.get(0).getClcoId(),
			"yr", in.get(0).getYr(),
			"mngrId", BatchUploadUtils.getCurrentMngrId(),
			"list", in)));
	}
}
