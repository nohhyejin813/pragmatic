package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.MidCardBscModel;
import com.gchc.ncu.bo.care.vo.MindCardVo;

@Mapper
public interface MindCardRepository {

	List<MidCardBscModel> selectMindCardBsc(MindCardVo criteria);
	MidCardBscModel selectMindCardDtl(MindCardVo criteria);
	void insertMindCardBsc(MidCardBscModel model);
	void updateMindCardBsc(MidCardBscModel model);
	void deleteMindCardBsc(MidCardBscModel model);


}
