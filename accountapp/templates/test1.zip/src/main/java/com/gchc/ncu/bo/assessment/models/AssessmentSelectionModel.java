package com.gchc.ncu.bo.assessment.models;

import java.util.Date;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class AssessmentSelectionModel extends UstraManagementBaseModel {
	/*T_EASY_CUI_ASM_EXM_DTL [헬스케어_검진이지검진기관평가보기상세]*/

	private	int		cuiAsmQstId;		/*검진기관평가질문아이디*/
	private	int		cuiAsmExmId;		/*검진기관평가보기아이디*/
	private	boolean	sbjtYn;				/*여부*/
	private	String	exCont;				/*내용*/
	private	int		asmScr;				/*점수*/

	private	boolean	delYn;				/*삭제여부*/
	private	Date	frstRegDtm;			/*최초등록일시*/
	private	String	frstRegrTyCd;		/*최초등록자유형코드*/
	private	String	frstRegrId;			/*최초등록자아이디*/
	private	Date	lastUpdDtm;			/*최종수정일시*/
	private	String	lastUpdrTyCd;		/*최종수정자유형코드*/
	private	String	lastUpdrId;			/*최종수정자아이디*/



}
