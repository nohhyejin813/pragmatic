package com.gchc.ncu.bo.abnormalfindings.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gchc.ncu.bo.abnormalfindings.models.AbnfMemberModel;
import com.gchc.ncu.bo.abnormalfindings.models.Disease1Model;
import com.gchc.ncu.bo.abnormalfindings.models.management.ManagermentBusinessPlaceModel;
import com.gchc.ncu.bo.abnormalfindings.vo.AbnfMemberVo;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import com.gsitm.ustra.java.data.mybatis.executor.Many;

/**
 * 검진결과:유소견관리(암)
 *
 * @author 2021.11.29
 */
@Mapper
public interface Disease1Repository {

	/** 복호화 Before */
	void exeKeyOpen();

	/** 복호화 After */
	void exeKeyClose();


	List<ManagermentBusinessPlaceModel> getWorkPlaceList(Disease1Model model);


	/**
     * 유소견관리(암)  - 목록조회
     */

	@Many List<Disease1Model> getDisease1List(Map<String, Object> model);
	@Many List<Disease1Model> getDisease1ListExcel(Map<String, Object> model);


}
