package com.gchc.ncu.bo.challenge.auth.service;

import com.gchc.common.exception.GchcException;
import com.gchc.common.exception.GchcResponseCode;
import com.gchc.ncu.bo.challenge.auth.models.AuthBoardModel;
import com.gchc.ncu.bo.challenge.auth.models.AuthBoardSearchModel;
import com.gchc.ncu.bo.challenge.auth.repository.AuthBoardRepository;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogModel;
import com.gchc.ncu.bo.comm.log.UsrInnfActiLogService;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordModel;
import com.gchc.ncu.bo.comm.log.XlsDownloadRecordService;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.*;

/***
 * 인증챌린지 게시판관리
 * @FileName : ChronicStatusService.java
 * @date : 2023. 04. 28
 * @author : gcjclee2
 * @프로그램 설명 : 인증챌린지 게시판관리
 */
@Slf4j
@Service
@Validated
@RequiredArgsConstructor
@Transactional
public class AuthBoardService {

	private final XlsDownloadRecordService xlsDownloadRecordServicce;
	private final UsrInnfActiLogService usrInnfActiLogService;

	private final AuthBoardRepository repository;

	// 검색조건박스: 기준년도, 고객사명, 사업장명
	public AuthBoardModel getSearchReady(){
		return null;
	}

	public List<AuthBoardModel> getCategoryList(AuthBoardModel model){
		int categoryCount = repository.getCategoryCount(model);

		if( categoryCount == 0 ){
			model.setBsplId(-1);
		}

		return repository.getCategoryList(model);
	}

	public List<AuthBoardModel> getOnoList(AuthBoardModel model){

		int categoryCount = repository.getCategoryCount(model);

		if( categoryCount == 0 ){
			model.setBsplId(-1);
		}

		return repository.getOnoList(model);
	}

	// 인증목록
	public List<AuthBoardModel> getAuthBrdList(AuthBoardSearchModel model) {
		return repository.getAuthBrdList(model);
	}

	// 모아보기
	public List<AuthBoardModel> getAuthListPopup(AuthBoardSearchModel model) {
		return repository.getAuthListPopup(model);
	}

	// 모아보기
	public AuthBoardModel getAuthBrdDetail(AuthBoardSearchModel model) {
		return repository.getAuthBrdDetail(model);
	}

	public AuthBoardModel addAuthBrdReply(AuthBoardModel model) {
		repository.addAuthBrdReply(model);
		return model;
	}

	public List<AuthBoardModel> getAuthBrdReplyList(AuthBoardModel model) {
		return repository.getAuthBrdReplyList(model);
	}

	public AuthBoardModel deleteAuthBrdReply(AuthBoardModel model) {
		repository.deleteAuthBrdReply(model);
		return model;
	}

	public List<AuthBoardModel> getDclList(AuthBoardModel in) {
		return repository.getDclList(in);
	}


	@Transactional
	public Integer updateHiddenOne(AuthBoardModel model) {

		List<Integer> postIdList = new ArrayList<Integer>();

		postIdList.add(model.getPostId());

		Map<String, Object> paramMap = new HashMap<String, Object>();

		paramMap.put("postIdList", postIdList);
		paramMap.put("lastUpdrId", model.getLastUpdrId());

		return repository.updateHidden(paramMap);
	}

	@Transactional
	public Integer updateHidden(List<AuthBoardModel> list) {

		List<Integer> postIdList = new ArrayList<Integer>();

		for(AuthBoardModel v : list) {
			postIdList.add(Integer.valueOf(v.getPostId()));
		}

		// /care/chup-challenge/write?cmpgId=?&postId=?

//		<update id="updateCertiCount" parameterType="ChupChallengeVo">
//			UPDATE T_MBR_CMPG_ATHO_CHAL_HIS
//			   SET ATHO_CMPL_CNT =  (SELECT COUNT(1)
//									  FROM T_CMPG_WBOD_HIS
//									 WHERE UID = #{uid}
//									   AND CMPG_ID = #{cmpgId}
//									   AND ATHO_YN = 1
//									 )
//			     , ATHO_CMPL_RT =  (SELECT COUNT(1)
//									  FROM T_CMPG_WBOD_HIS
//									 WHERE UID = #{uid}
//									   AND CMPG_ID = #{cmpgId}
//									   AND ATHO_YN = 1
//									 ) /(
//	                                      SELECT GOAL_ATHO_CNT
//	                                        FROM T_CMPG_BSC
//	                                       WHERE CMPG_ID = #{cmpgId}
//	                                     ) * 100
//			 WHERE CMPG_ID = #{cmpgId}
//			   AND UID = #{uid}
//		</update>

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("postIdList", postIdList);
		paramMap.put("lastUpdrId", list.get(0).getLastUpdrId());

		return repository.updateHidden(paramMap);
	}

	@Transactional
	public Integer updateAuthorityOne(AuthBoardModel model) {

		List<Integer> postIdList = new ArrayList<Integer>();

		postIdList.add(model.getPostId());

		Map<String, Object> paramMap = new HashMap<String, Object>();

		paramMap.put("uid"		, model.getUid());
		paramMap.put("cmpgId"	, model.getCmpgId());
		paramMap.put("postIdList", postIdList);
		paramMap.put("lastUpdrId", model.getLastUpdrId());

		repository.updateAuthority(paramMap);

		return repository.updateCertiCount(paramMap);
	}

	@Transactional
	public Integer updateAuthority(List<AuthBoardModel> list) {

		List<Integer> postIdList = new ArrayList<Integer>();

		for(AuthBoardModel v : list) {
			postIdList.add(Integer.valueOf(v.getPostId()));
		}

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("postIdList", postIdList);
		paramMap.put("lastUpdrId", list.get(0).getLastUpdrId());

		return repository.updateAuthority(paramMap);
	}

	@Transactional
	public void updateAuthorityComplete(List<AuthBoardModel> list) {
		for( AuthBoardModel v : list ) {
			Map<String, Object> paramMap = new HashMap<String, Object>();

			paramMap.put("uid"		, v.getUid());
			paramMap.put("cmpgId"	, v.getCmpgId());
			paramMap.put("lastUpdrId", list.get(0).getLastUpdrId());

			repository.updateCertiCount(paramMap);
		}
	}

	@Transactional
	public Integer updateRepairOne(AuthBoardModel model) {

		List<Integer> postIdList = new ArrayList<Integer>();

		postIdList.add(model.getPostId());

		Map<String, Object> paramMap = new HashMap<String, Object>();

		paramMap.put("uid"		, model.getUid());
		paramMap.put("cmpgId"	, model.getCmpgId());
		paramMap.put("postIdList", postIdList);
		paramMap.put("lastUpdrId", model.getLastUpdrId());

		repository.updateRepair(paramMap);

		return repository.updateCertiCount(paramMap);
	}

	@Transactional
	public Integer updateRepair(List<AuthBoardModel> list) {

		List<Integer> postIdList = new ArrayList<Integer>();

		for(AuthBoardModel v : list) {
			postIdList.add(Integer.valueOf(v.getPostId()));
		}

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("postIdList", postIdList);
		paramMap.put("lastUpdrId", list.get(0).getLastUpdrId());

		return repository.updateRepair(paramMap);
	}

	public UstraExcelModel getExcelDownload(AuthBoardSearchModel model){
		//List<Map<String, Object>> list = repository.getExcelDownload(model);

		List<AuthBoardModel> list = repository.getAuthBrdList(model);

		if( list == null || list.size() < 1 ){
			throw new GchcException(GchcResponseCode.UNKNOWN_ERROR, "조회된 데이터가 없습니다.");
		}

		List<UstraExcelCellInfoModel> commHeader =  Arrays.asList(
				new UstraExcelCellInfoModel("col0", "카테고리"),
				new UstraExcelCellInfoModel("col1", "차수"),
				new UstraExcelCellInfoModel("col2", "해시태그"),
				new UstraExcelCellInfoModel("col3", "내용"),
				new UstraExcelCellInfoModel("col4", "인기순"),
				new UstraExcelCellInfoModel("col5", "조회수"),
				new UstraExcelCellInfoModel("col6", "응원해요"),
				new UstraExcelCellInfoModel("col7", "댓글"),
				new UstraExcelCellInfoModel("col8", "신고수"),
				new UstraExcelCellInfoModel("col9", "등록일시"),
				new UstraExcelCellInfoModel("col10", "작성자"),
				new UstraExcelCellInfoModel("col11", "숨김"),
				new UstraExcelCellInfoModel("col12", "인증상태")
		);

		List<Map<String, Object>> cmmList = new ArrayList<Map<String,Object>>();

		for(int i = 0; i < list.size(); i++) {
			Map<String, Object> map = new TreeMap<>();

			map.put("col0"	, list.get(i).getChalThmNm());
			map.put("col1"	, list.get(i).getOno());
			map.put("col2"	, list.get(i).getKeywNm());
			map.put("col3"	, list.get(i).getPostCont());
			map.put("col4"	, list.get(i).getTotCnt());
			map.put("col5"	, list.get(i).getVwCnt());
			map.put("col6"	, list.get(i).getGoodCnt());
			map.put("col7"	, list.get(i).getRplyCnt());
			map.put("col8"	, list.get(i).getDclCnt());
			map.put("col9"	, list.get(i).getRegDtm());
			map.put("col10"	, list.get(i).getNm());
			map.put("col11"	, list.get(i).getHdenYn());
			map.put("col12"	, list.get(i).getAthoYn());

			cmmList.add(map);
		}

		UstraExcelModel excelModel = UstraExcelModel.of(cmmList, commHeader).withSheetName("웰보드정보관리");

		Map<String, String> dwldInfoMap = model.getDwldInfo();

		dwldInfoMap.put("dwldCount", String.valueOf(list.size()));

		if (list.size() > 1) {
			dwldInfoMap.put("dwldAccess", list.get(0).getNm() + "외 " + (list.size() - 1) + "명");
		} else {
			dwldInfoMap.put("dwldAccess", String.valueOf(list.get(0).getNm()));
		}

		model.setDwldInfo(dwldInfoMap);

		setExcelDownloadLog(model);

		return excelModel;
	}

	@Transactional
	public void setExcelDownloadLog(AuthBoardSearchModel criteria) {
		UsrInnfActiLogModel innfActirecord = new UsrInnfActiLogModel();

		innfActirecord.setActiLogDvCd("40");
		innfActirecord.setPfrmNm(criteria.getDwldInfo().get("dwldPageNm") + " - 엑셀 다운로드");
		innfActirecord.setMenuNm(criteria.getDwldInfo().get("dwldPagePath"));
		innfActirecord.setPfrmCont(criteria.getDwldInfo().get("dwldPageNm") + " - 엑셀 다운로드");
		innfActirecord.setCustNm(criteria.getDwldInfo().get("dwldAccess"));

		usrInnfActiLogService.insert(innfActirecord);

		XlsDownloadRecordModel record = new XlsDownloadRecordModel();
		record.setDwldPageNm(criteria.getDwldInfo().get("dwldPageNm"));
		record.setDwldPageUrl(criteria.getDwldInfo().get("dwldPageUrl"));
		record.setDwldCont(criteria.getDwldInfo().get("dwldContents"));
		record.setDwldMemo(criteria.getDwldInfo().get("dwldMemo"));
		record.setInnfHndlPlcyAgrYn(false);
		record.setInnfVwCnt(Integer.parseInt(criteria.getDwldInfo().get("dwldCount")));
		record.setDwldRsnCd(criteria.getDwldInfo().get("dwldRsnCd"));
		record.setCustNm(criteria.getDwldInfo().get("dwldAccess"));
		record.setDwldActiCont(criteria.getDwldInfo().get("dwldPageNm") + " 엑셀 다운로드");

		xlsDownloadRecordServicce.insert(record);
	}

}
