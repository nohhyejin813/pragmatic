package com.gchc.ncu.bo.abnormalfindings.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.abnormalfindings.models.Disease2Model;
import com.gchc.ncu.bo.abnormalfindings.service.Disease2Service;
import com.gchc.ncu.bo.abnormalfindings.vo.Disease2Vo;
import com.gchc.ncu.bo.batchupload.comm.BatchUploadCellGenerator;
import com.gchc.ncu.bo.checkupinst.util.CheckupInstUtil;
import com.gchc.ncu.bo.comm.service.ApiInterfaceService;
import com.gsitm.ustra.java.core.utils.UstraMapUtils;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 유소견관리 > 검진결과:유소견관리(신)
 *
 * @since	2021.11.22
 * @author 	gs_tskwon@gchealthcare.com
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/abnormalFindings")
@Api(tags="유소견 관리 - 검진결과:유소견관리(신)")
public class Disease2Controller {
	@Qualifier("checkupinstUtil")
	@Autowired
	CheckupInstUtil util;

	@Autowired
	private ApiInterfaceService apiInterfaceService;

    private final Disease2Service disease2Service;

	@Autowired
	private FileOperationManager fileOperationManager;


    /**
     * 유소견관리(신)  - 목록조회
     */
    @PostMapping("/disease2")
    public RestResult<List<Disease2Model>> getDisease2List(@RequestBody @Valid Disease2Vo model) {
    	List<Disease2Model> resultList = disease2Service.getDisease2List(model);
		return GchcRestResult.of(resultList);

//		TODO: ApiInterface사용코드 (application.xml > gchc.api.common - IP값 변경해야 동작함.
//	    RestResult<List<Disease2Model>> resultList = apiInterfaceService.inquiryDisease2List(model);
//	    return resultList;
    }


    /**
     * 유소견관리(신)  - 엑셀 목록조회
     * @throws Exception
     */
	@PostMapping("/disease2/excel")
	ResponseEntity<?> convertExcel(@RequestBody @Valid Disease2Vo model,  HttpServletRequest request, HttpServletResponse response) {

		List<Disease2Model> resultList = disease2Service.getDisease2ListForExcel(model);

		List<Map<String, Object>> list = resultList.stream()
			.map(target->{
				Map<String, Object> result = new HashMap<>();
				UstraMapUtils.putMap(result,
					"col1", target.getRowNum(),
					"col2", target.getFrstRegDtm(),
					"col3", target.getNm(),
					"col4", target.getGender(),
					"col5", target.getBrdt());
				UstraMapUtils.putMap(result,
					"col6", target.getClcoNm(),
					"col7", target.getEmpno(),
					"col8", target.getCuDtm(),
					"col9", target.getRgrpClsfNm(),
					"col10", target.getCuRsltNm());
				UstraMapUtils.putMap(result,
					"col11", target.getSbp(),
					"col12", target.getDbp(),
					"col13", target.getBlsg(),
					"col14", target.getTc(),
					"col15", target.getHdl());

				UstraMapUtils.putMap(result,
					"col16", target.getLdl(),
					"col17", target.getTg(),
					"col18", target.getBmi(),
					"col19", target.getHeight(),
					"col20", target.getWeight());

				UstraMapUtils.putMap(result,
					"col21", target.getLmbc(),
					"col22", target.getAst(),
					"col23", target.getAlt(),
					"col24", target.getRgtp());

				return result;
			})
			.collect(Collectors.toList());
		return fileOperationManager.convert(DataToExcelWebResourceConverter
			.entityBuilder(Arrays.asList(UstraExcelModel.of(
				list,
				Arrays.asList(
					new UstraExcelCellInfoModel("col1"	, "No"),
					new UstraExcelCellInfoModel("col2"	, "생성일"),
					new UstraExcelCellInfoModel("col3"	, "고객명"),
					new UstraExcelCellInfoModel("col4"	, "성별"),
					new UstraExcelCellInfoModel("col5"	, "생일"),

					new UstraExcelCellInfoModel("col6"	, "고객사명"),
					new UstraExcelCellInfoModel("col7"	, "사번"),
					new UstraExcelCellInfoModel("col8"	, "검진일"),
					new UstraExcelCellInfoModel("col9"	, "뇌/심위험군"),
					new UstraExcelCellInfoModel("col10"	, "검진결과"),

					new UstraExcelCellInfoModel("col11"	, "SBP"),
					new UstraExcelCellInfoModel("col12"	, "DBP"),
					new UstraExcelCellInfoModel("col13"	, "혈당"),
					new UstraExcelCellInfoModel("col14"	, "TC"),
					new UstraExcelCellInfoModel("col15"	, "HDL"),

					new UstraExcelCellInfoModel("col16"	, "LDL"),
					new UstraExcelCellInfoModel("col17"	, "TG"),
					new UstraExcelCellInfoModel("col18"	, "BMI"),
					new UstraExcelCellInfoModel("col19"	, "신장"),
					new UstraExcelCellInfoModel("col20"	, "체중"),

					new UstraExcelCellInfoModel("col21"	, "허리둘레"),
					new UstraExcelCellInfoModel("col22"	, "AST"),
					new UstraExcelCellInfoModel("col23"	, "ALT"),
					new UstraExcelCellInfoModel("col24"	, "rGTP"))
					)
					.withCellGenerator(new BatchUploadCellGenerator())
					), "검진이지 공용 패키지", request, response)
				.build());
	}

}
