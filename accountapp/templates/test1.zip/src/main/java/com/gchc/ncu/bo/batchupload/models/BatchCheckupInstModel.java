package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchCheckupInstModel extends NcuModel {

    private Integer cuiId;

    private String cuiNm;

    private Integer resvTmcStupYn;

    private String cuiTskSrtTmcRngCd;

    private String cuiTskEndTmcRngCd;
}
