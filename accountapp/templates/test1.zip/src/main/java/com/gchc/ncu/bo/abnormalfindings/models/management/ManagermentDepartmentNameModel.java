package com.gchc.ncu.bo.abnormalfindings.models.management;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;


@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ManagermentDepartmentNameModel extends UstraManagementBaseModel
{
	private Integer deptId;
	private String deptNm;
}
