package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.vo.ActivityMissionVo;

@Mapper
public interface ActivityMissionRepository {

	List<ActMsnBscModel> selectActivityMissionList(ActivityMissionVo criteria);
	ActMsnBscModel selectActivityMissionDetail(ActMsnBscModel criteria);
	void insertActivityMissionBase(ActMsnBscModel model);
	void updateActivityMissionBase(ActMsnBscModel model);
	void deleteActivityMissionBase(ActMsnBscModel model);
	List<Integer> selectUsedActivityMissionCount(ActMsnBscModel model);

}
