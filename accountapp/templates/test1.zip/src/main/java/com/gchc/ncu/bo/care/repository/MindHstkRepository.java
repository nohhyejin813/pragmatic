package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.MidFeelBscModel;
import com.gchc.ncu.bo.care.vo.MindHstkVo;

@Mapper
public interface MindHstkRepository {

	List<MidFeelBscModel> selectMindBsc(MindHstkVo criteria);
	MidFeelBscModel selectMindDtl(MindHstkVo criteria);
	void insertMindHstkBsc(MidFeelBscModel model);
	void updateMindHstkBsc(MidFeelBscModel model);
	void deleteMindHstkBsc(MidFeelBscModel model);


}
