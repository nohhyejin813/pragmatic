package com.gchc.ncu.bo.care.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.MidCnslApplBscModel;
import com.gchc.ncu.bo.care.models.MidCnslCtraBscModel;
import com.gchc.ncu.bo.care.models.MidCnslTmcBscModel;
import com.gchc.ncu.bo.care.vo.CounselVo;

@Mapper
public interface CounselRepository {

	List<MidCnslTmcBscModel> selectScheduleList(CounselVo criteria);
	MidCnslTmcBscModel selectScheduleDetail(MidCnslTmcBscModel criteria);
	void saveSchedule(MidCnslTmcBscModel model);
	void deleteSchedule(MidCnslTmcBscModel model);

	List<MidCnslCtraBscModel> selectContractList(CounselVo criteria);
	MidCnslCtraBscModel selectContractDetail(MidCnslCtraBscModel criteria);
	int selectContractConflictCnt(MidCnslCtraBscModel model);
	int insertContract(MidCnslCtraBscModel model);
	void updateContract(MidCnslCtraBscModel model);
	void deleteContract(MidCnslCtraBscModel model);

	List<MidCnslApplBscModel> selectApplicationList(CounselVo criteria);
	Integer selectAvailApplCnt(MidCnslApplBscModel model);
	Integer selectConflictCounselByDate(MidCnslApplBscModel model);
	void updateMidCnslStatus(MidCnslApplBscModel model);
	void updateMidCnsl(MidCnslApplBscModel model);

	List<String> selectHolidayList();
	void updateHoliday(Map<String, Object> paramsMap);
	void deleteHoliday(Map<String, Object> paramsMap);

	List<Map<String, Object>> selectApplicationExcelList(Map<String, Object> paramsMap);
	List<Map<String, Object>> selectHighRiskMemberInfoList(CounselVo criteria);

}
