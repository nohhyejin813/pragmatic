package com.gchc.ncu.bo.batchupload.repository;

import com.gchc.ncu.bo.batchupload.models.*;
import com.gchc.ncu.bo.packages.models.ExamItemModel;
import com.gchc.ncu.bo.packages.models.PackageTypeModel;
import com.gsitm.ustra.java.data.domains.PaginationRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface BatchPackageUploadRepository {

	void updatePackageItemUploadBasicUseYn(Map<String, Object> map);

	void insertPackageItemUploadBasic(PackageItemUploadBasicModel in);

	void insertPackageItemTitle(List<PackageItemUploadTitleModel> titles);

	void insertPackageItemUploadListDetail(List<PackageItemUploadListModel> lists);

	void insertPackageItemUploadDetail(List<PackageItemUploadItemModel> items);

	void updatePackageUploadBasicUseYn(String userId);

	void insertPackageUploadBasic(BatchPackageUploadModel pkg);

	void updatePackageUploadBasicValidate2(Map<String, Object> map);

	void updatePackageUploadBasicValidate3(Map<String, Object> map);

	int selectPackageUploadBasic(PackageItemUploadBasicModel in);

	void insertCheckupInstAgencyRelation(PackageItemUploadBasicModel in);

	void insertPackageType(PackageItemUploadBasicModel in);

	List<PackageUploadResultModel> selectPackageUploadResult(PackageItemUploadBasicModel in);

	List<PackageUploadErrorModel> selectPackageUploadBasicError(PackageItemUploadBasicModel in);

	void validatePackageItemUploadTitle(PackageItemUploadBasicModel in);

	void updatePackageItemUploadBasicError(Map<String, Object> map);

	List<PackageTypeModel> selectPackageType(Map<String, Object> map);

	List<PackageTypeModel> selectPackageTypeForRegist(PackageItemUploadBasicModel in);

	void updatePackageItemUploadTitle(PackageItemUploadBasicModel in);

	void insertPackageTypeItem(PackageItemUploadBasicModel in);

	void insertPackageTypeItem2(PackageItemUploadBasicModel in);

	void insertPackageTypeSelectExamDetail(PackageItemUploadBasicModel in);

	void updatePackageItemUploadBasicComplete(PackageItemUploadBasicModel in);

	void updatePackageItemTitle(PackageItemUploadTitleModel title);

	void validatePackageItemUploadList(PackageItemUploadBasicModel in);

	List<PackageItemSelectModel> getPkgUploadList(PackageItemUploadBasicModel in);		// 패키지 메인조회

	List<PackageItemSelectModel> getPkgUploadDtlList(PackageItemUploadBasicModel in);	// 패키지 상세조회

	List<PackageItemUploadResultModel> selectPakcageItemUploadResult(PackageItemUploadBasicModel in);

	List<PackageItemUploadTitleModel> selectPackageItemUploadTitle(PackageItemUploadBasicModel in);

	List<PackageItemUploadListModel> selectPackageItemUploadList(PackageItemUploadBasicModel in);

	List<PackageItemUploadItemModel> selectPackageItemUploadDetail(PackageItemUploadBasicModel in);

	List<PackageTypeItemSelectModel> getPkgTypeUploadList(PackageItemUploadBasicModel in);    // 패키지-타입 메인 조회

	void updatePkgUpldBscUploadYn(Map<String, Object> map);

	List<BatchPackageUploadModel> getPkgUpldBscForUpdate(Map<String, Object> map);

	void updatePackageUploadBasicValidate1(Map<String, Object> map);

	List<ExamItemModel> getExamItemTemplateList(ExamItemModel in); // Template Excel List

	BatchPackageUploadResultModel getPkgUpldBscResult(BatchPackageUploadResultRequestModel in);

	List<BatchPackageUploadModel> getPkgUpldBscErrorList(@Param("model") BatchPackageUploadResultRequestModel in, PaginationRequest paginationRequest);

	void updatePkgUpldBscInit(BatchPackageUploadResultRequestModel in);

	void updatePkgUpldBscRegist(PackageItemUploadBasicModel in);

	List<PackageUploadExcelModel> selectPkgUpldBscExcel(Map<String, Object> map);

	List<PackageUploadExcelModel> selectPkgUpldBscExcelAll(PackageItemUploadBasicModel in);

	void updatePkgUpldBscDeleteAll(PackageItemUploadBasicModel in);

	void updatePkgUpldBscDelete(Map<String, Object> map);

	BatchPackageUploadResultModel selectPkgItmUpldBscResult(BatchPackageUploadResultRequestModel in);

	List<BatchPackageTypeUploadErrorModel> selectPkgItmUpldBscErrorList(BatchPackageUploadResultRequestModel in);

	void updatePkgItmLstUpldDtlRemove(Map<String, Object> map);

	void updatePkgItmLstUpldDtlRemoveAll(BatchPackageUploadResultRequestModel in);

	void updatePkgItmUpldDtlRemove(Map<String, Object> map);

	void updatePkgItmUpldDtlRemoveAll(BatchPackageUploadResultRequestModel in);

	void updatePkgItmTitlUpldDtlValidate(Map<String, Object> map);

	PackageItemUploadBasicModel getPkgItmUpldBsc(Map<String, Object> map);

	List<PackageItemUploadItemModel> getPkgItmUpldDtlError(Map<String, Object> map);

	List<PackageItemUploadTitleModel> getPkgItmTitlUpldDtl(Map<String, Object> map);

}
