package com.gchc.ncu.bo.batchupload.models;

import com.gchc.ncu.bo.comm.models.NcuModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ExaminationSrcModel extends NcuModel {
	// T_BLK_UPLD_EXAM_TMP
	private String clcoNm;
	private String cuiNm;

	private String exmrNm; // EXMR_NM 수검자이름
	private String brdt; // BRDT 생년월일
	private String sexCd; // 성별
	private String hvexCmplDt; // HVEX_CMPL_DT 수검완료일자
	private int corpSpfn; // CORP_SPFN 회사지원금
	private int addSpfn; // ADD_SPFN 추가지원금
	private String nhicSubtYn; // NHIC_SUBT_YN 건강보험공단차감여부
	private int nhicAmt; // NHIC_AMT 건강보험공단금액
	private int corpClmAmt; // CORP_CLM_AMT 회사청구금액
	private int uid; // CORP_CLM_AMT 회사청구금액
	private String blkUpldExamId; // BLK_UPLD_EXAM_ID 일괄업로드검사아이디
	private int cuiId; // CUI_ID 검진기관아이디
	private int clcoId; // CLCO_ID 고객사아이디
	private String yr; // YR
	private int cuTgtrId; // CU_TGTR_ID 검진대상자아이디
	private int resvId; // RESV_ID 예약아이디
	private String resvStCd; // RESV_ST_CD 예약상태코드
	private String selfYn; // SELF_YN 본인여부
	private String suptYn; // SUPT_YN 지원여부
	private String cuiYn; // CUI_YN 검진기관여부
	private String uid1; // UID1 회원아이디1
	private String datStCd; // DAT_ST_CD 데이터상태코드
	private String upldErrCausCont; // UPLD_ERR_CAUS_CONT 업로드오류원인내용
	private String useYn; // USE_YN 사용여부
	private String upldCmplYn; // UPLD_CMPL_YN 업로드완료여부
	private String usrKdCd; // USR_KD_CD 사용자종류코드
	private int mngrId; // MNGR_ID 관리자아이디
	private String delMngrId; // DEL_MNGR_ID 삭제관리자아이디
	private String delDtm; // DEL_DTM 삭제일시
	private String delYn; // DEL_YN 삭제여부
	// private String frstRegDtm; // FRST_REG_DTM
	// private String frstRegrTyCd; // FRST_REGR_TY_CD
	// private String frstRegrId; // FRST_REGR_ID
	// private String lastUpdDtm; // LAST_UPD_DTM
	// private String lastUpdrTyCd; // LAST_UPDR_TY_CD
	// private String lastUpdrId; // LAST_UPDR_ID
}
