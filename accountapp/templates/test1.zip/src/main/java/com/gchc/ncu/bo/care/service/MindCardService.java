package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.microsoft.sqlserver.jdbc.StringUtils;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.MidCardBscModel;
import com.gchc.ncu.bo.care.repository.MindCardRepository;
import com.gchc.ncu.bo.care.vo.MindCardVo;

@Service
@RequiredArgsConstructor
public class MindCardService {

	private final MindCardRepository mindCardRepository;

	public List<MidCardBscModel> getMidCardBsc(MindCardVo criteria) {
		return mindCardRepository.selectMindCardBsc(criteria);
	}

	public MidCardBscModel getMidCardDtl(MindCardVo criteria) {
		return mindCardRepository.selectMindCardDtl(criteria);
	}

	public void saveBsc(MidCardBscModel model) {
		if(StringUtils.isEmpty(model.getMidCardId())) {
			mindCardRepository.insertMindCardBsc(model);
		} else {
			mindCardRepository.updateMindCardBsc(model);
		}
	}

	public void deleteBsc(List<MidCardBscModel> list) {
		for(MidCardBscModel model : list) {
			mindCardRepository.deleteMindCardBsc(model);
		}
	}



}
