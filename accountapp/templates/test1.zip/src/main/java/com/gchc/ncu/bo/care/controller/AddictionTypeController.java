package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.PoisTyBscModel;
import com.gchc.ncu.bo.care.service.AddictionTypeService;
import com.gchc.ncu.bo.care.vo.AddictionTypeVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/bo/care/addiction/type")
@RequiredArgsConstructor
@Slf4j
public class AddictionTypeController {

	private final AddictionTypeService addictionTypeService;

	@GetMapping("/list")
	public List<PoisTyBscModel> list(@ModelAttribute AddictionTypeVo criteria) {
		LOGGER.debug("care > activity > mission > getList");

		return addictionTypeService.getAddictionTypeList(criteria);
	}

	@GetMapping("/detail")
	public PoisTyBscModel detail(@ModelAttribute PoisTyBscModel criteria) {
		LOGGER.debug("care > activity > mission > getDetail");

		return addictionTypeService.getAddictionTypeDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid PoisTyBscModel model) {
		addictionTypeService.saveAddictionType(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<PoisTyBscModel> list) {
		addictionTypeService.deleteAddictionType(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
