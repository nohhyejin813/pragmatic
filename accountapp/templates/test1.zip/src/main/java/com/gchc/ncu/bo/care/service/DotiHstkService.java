package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.gchc.ncu.bo.care.models.DotiHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.DotiHstkBscModel;
import com.gchc.ncu.bo.care.repository.DotiHstkRepository;
import com.gchc.ncu.bo.care.vo.DotiHstkVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DotiHstkService {

	private final DotiHstkRepository dotiHstkRepository;

	public List<DotiHstkBscModel> getDotiHstkList(DotiHstkVo criteria) {
		return dotiHstkRepository.selectDotiHstkList(criteria);
	}

	public DotiHstkBscModel getDotiHstkDetail(DotiHstkBscModel criteria) {
		return dotiHstkRepository.selectDotiHstkDetail(criteria);
	}

	@Transactional
	public void saveDotiHstk(DotiHstkBscModel model) {
		if (StringUtils.isEmpty(model.getDotiHstkId())) {
			dotiHstkRepository.insertDotiHstk(model);
		} else {
			dotiHstkRepository.updateDotiHstk(model);
		}
	}

	@Transactional
	public void deleteDotiHstk(List<DotiHstkBscModel> list) {
		if (list != null) {
			for (DotiHstkBscModel model : list) {
				deleteDotiHstkAnswer(model.getDotiHstkId());
				dotiHstkRepository.deleteDotiHstk(model);
			}
		}
	}

	public List<DotiHstkAnswDtlModel> getDotiHstkAnswerList(DotiHstkBscModel criteria) {
		return dotiHstkRepository.selectDotiHstkAnswerList(criteria);
	}

	@Transactional
	public void saveDotiHstkAnswer(int dotiHstkId, List<DotiHstkAnswDtlModel> list) {
		deleteDotiHstkAnswer(dotiHstkId);

		if (list != null && list.size() > 0) {
			for (DotiHstkAnswDtlModel model : list) {
				dotiHstkRepository.saveDotiHstkAnswer(model);
			}
		}
	}

	protected void deleteDotiHstkAnswer(int dotiHstkId) {
		dotiHstkRepository.deleteDotiHstkAnswer(dotiHstkId);
	}

}
