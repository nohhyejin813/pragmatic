package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.DssActMsnRltnModel;
import com.gchc.ncu.bo.care.repository.ActivityGoalRepository;
import com.gchc.ncu.bo.care.vo.ActivityGoalVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ActivityGoalService {

	private final ActivityGoalRepository goalRepository;

	public List<DssActMsnRltnModel> getActivityGoalList(ActivityGoalVo criteria) {
		return goalRepository.selectActivityGoalList(criteria);
	}

	@Transactional
	public void saveActivityGoal(List<DssActMsnRltnModel> list) {
		if (list != null && list.size() > 0) {
			goalRepository.deleteActivityGoalByCond(list.get(0));

			for (DssActMsnRltnModel model : list) {
				goalRepository.insertActivityGoal(model);
			}
		}
	}

	@Transactional
	public void deleteActivityGoalById(List<DssActMsnRltnModel> list) {
		if (list != null) {
			for (DssActMsnRltnModel model : list) {
				goalRepository.deleteActivityGoalByCond(model);
			}
		}
	}

}
