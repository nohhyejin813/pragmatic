package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.SsngCsttHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.SsngCsttHstkBscModel;
import com.gchc.ncu.bo.care.repository.CsttHstkRepository;
import com.gchc.ncu.bo.care.vo.CsttHstkVo;

@Service
@RequiredArgsConstructor
public class CsttHstkService {

	private final CsttHstkRepository csttHstkRepository;

	public List<SsngCsttHstkBscModel> getContitutionHstkList(CsttHstkVo criteria) {
		return csttHstkRepository.selectContitutionHstkList(criteria);
	}

	public SsngCsttHstkBscModel getContitutionHstkPop(CsttHstkVo criteria) {
		return csttHstkRepository.selectContitutionHstkPop(criteria);
	}

	public List<SsngCsttHstkAnswDtlModel> getCsttHstkAnswerList(SsngCsttHstkAnswDtlModel criteria) {
		return csttHstkRepository.selectCsttHstkAnswerList(criteria);
	}

	@Transactional
	public int saveContitutionHstk(SsngCsttHstkBscModel model) {
		if (StringUtils.isEmpty(model.getHstkId())) {
			csttHstkRepository.insertContitutionBase(model);
		} else {
			csttHstkRepository.updateContitutionBase(model);
		}

		return model.getHstkId();
	}

	@Transactional
	public void saveCsttHstkAnswer(List<SsngCsttHstkAnswDtlModel> list) {
		if (list != null && list.size() > 0) {
			csttHstkRepository.deleteCsttHstkAnswer(list.get(0).getHstkId());
			for (SsngCsttHstkAnswDtlModel model : list) {
				csttHstkRepository.insertCsttHstkAnswer(model);
			}
		}
	}

	@Transactional
	public void deleteCsttHstk(List<SsngCsttHstkBscModel> list) {
		if (list != null) {
			for (SsngCsttHstkBscModel model : list) {
				csttHstkRepository.deleteCsttHstkAnswer(model.getHstkId());
				csttHstkRepository.deleteCsttHstk(model);
			}
		}
	}


}
