package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.NrsnDssAgDtlModel;
import com.gchc.ncu.bo.care.models.NrsnDssBscModel;
import com.gchc.ncu.bo.care.models.NrsnDssExamRltnModel;
import com.gchc.ncu.bo.care.models.NrsnDssMjrDssRltnModel;
import com.gchc.ncu.bo.care.vo.PainDiseaseVo;

@Mapper
public interface PainDiseaseRepository {

	List<NrsnDssBscModel> selectPainDiseaseList(PainDiseaseVo criteria);
	NrsnDssBscModel selectPainDiseaseDetail(NrsnDssBscModel criteria);
	void insertPainDisease(NrsnDssBscModel model);
	void updatePainDisease(NrsnDssBscModel model);
	void deletePainDisease(int nrsnDssId);
	int selectUsedPainDiseaseCount(NrsnDssBscModel model);

	List<NrsnDssAgDtlModel> selectPainDiseaseAgeList(NrsnDssAgDtlModel model);
	void insertPainDiseaseAge(NrsnDssAgDtlModel model);
	void deletePainDiseaseAge(int nrsnDssId);

	List<NrsnDssExamRltnModel> selectPainDiseaseDeptList(NrsnDssExamRltnModel model);
	void insertPainDiseaseDept(NrsnDssExamRltnModel model);
	void deletePainDiseaseDept(int nrsnDssId);

	List<NrsnDssMjrDssRltnModel> selectPainDiseaseMjrList(NrsnDssMjrDssRltnModel model);
	void insertPainDiseaseMjr(NrsnDssMjrDssRltnModel model);
	void deletePainDiseaseMjr(int nrsnDssId);

}
