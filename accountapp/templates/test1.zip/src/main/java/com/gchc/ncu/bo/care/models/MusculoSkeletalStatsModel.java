package com.gchc.ncu.bo.care.models;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MusculoSkeletalStatsModel {

	// Common Field
	private String deptNm;
	private String lineNm;
	private String jobNm;
	private Integer cnt;
	private Double rt;
	private Integer rowTotCnt;
	private Double rowTotRt;
	private String colTotNm;
	private Integer colTotCnt;
	private Double colTotRt;
	private Integer totCnt;
	private Double totRt;

	private Double totAvg;
	private Double totSt;

	private String pivotCd;
	private String pivotLabel;

	private String subTotCd;
	private String subTotLabel;

	// Customize
	// average age
	private Double avg;
	// standard deviation
	private Double st;

	private String muscItmCd;
	private String muscItmNm;

}
