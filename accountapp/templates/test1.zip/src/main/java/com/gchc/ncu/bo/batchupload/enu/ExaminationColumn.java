package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum ExaminationColumn implements BatchUploadColumn {

	CLCO_NM("고객사명", "ClcoNm"),

	CUI_NM("검진센터명", "CuiNm"),

	EXMR_NM("이름", "ExmrNm"),

	BRDT("주민번호", "Brdt"),

	CORP_SPFN("회사지원금", "CorpSpfn"),

	HVEX_CMPL_DT("수검날짜", "HvexCmplDt"),

	MEMBER_ID("MemberId", "Uid")

	;

	String title;

	String field;

	ExaminationColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
