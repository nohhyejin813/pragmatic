package com.gchc.ncu.bo.challenge.auth.controller;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.service.CareCommApiService;
import com.gchc.ncu.bo.challenge.auth.models.AuthBoardModel;
import com.gchc.ncu.bo.challenge.auth.models.AuthBoardSearchModel;
import com.gchc.ncu.bo.challenge.auth.service.AuthBoardService;
import com.gchc.ncu.bo.comm.models.NcuUserDetail;
import com.gchc.ncu.bo.comm.service.CommonService;
import com.gchc.ncu.bo.comm.util.GchcJwtUtil;
import com.gsitm.ustra.java.data.file.FileOperationManager;
import com.gsitm.ustra.java.mvc.data.file.DataToExcelWebResourceConverter;
import com.gsitm.ustra.java.mvc.exception.UstraMvcException;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;

/**
 * 인증게시판관리
 * @FileName : AuthBoardController.java
 * @date : 2023. 04. 28
 * @author : gcjclee2
 * @프로그램 설명 : 인증챌린지 게시판관리
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/bo/challenge/auth/board")
public class AuthBoardController {

	private final AuthBoardService service;

	@Autowired
	private FileOperationManager fileOperationManager;

	private final CareCommApiService apiService;

	@Autowired
	CommonService commonService;

	@GetMapping("/category/list")
	@ApiOperation(value = "카테고리목록", notes = "카테고리목록")
	public List<AuthBoardModel> getCategoryList(@Valid AuthBoardModel model){
		return service.getCategoryList(model);
	}

	@GetMapping("/ono/list")
	@ApiOperation(value = "차수목록", notes = "차수목록")
	public List<AuthBoardModel> getOnoList(@Valid AuthBoardModel model){
		return service.getOnoList(model);
	}

	@GetMapping("/list")
	@ApiOperation(value = "인증게시판목록", notes = "인증게시판목록")
	public List<AuthBoardModel> getAuthBrdList(@Valid AuthBoardSearchModel model) {
		return service.getAuthBrdList(model);
	}

	@GetMapping("/list/popup")
	@ApiOperation(value = "모아보기", notes = "모아보기")
	public List<AuthBoardModel> getAuthListPopup(@Valid AuthBoardSearchModel model) {
		return service.getAuthListPopup(model);
	}

	@GetMapping("/detail")
	@ApiOperation(value = "상세보기", notes = "상세보기")
	public AuthBoardModel getAuthBrdDetail(@Valid AuthBoardSearchModel model) {
		return service.getAuthBrdDetail(model);
	}

	@PostMapping("/replys/add")
	@ApiOperation(value = "댓글 등록", notes = "댓글 등록")
	public AuthBoardModel addAuthBrdReply(@RequestBody @Valid AuthBoardModel in) {
		// 댓글작성자 설정
		if( "1".equals(in.getMngrYn()) && "0".equals(in.getPtnrYn()) ){
			NcuUserDetail userDetail = commonService.getUserDetail(GchcJwtUtil.getUserId());
			in.setUid(userDetail.getMngrId());
		}

		AuthBoardModel model = service.addAuthBrdReply(in);

		if( model == null ){
			throw new UstraMvcException(GchcResponseCode.CANNOT_SAVE_RECORD);
		}
		return model;
	}

	@GetMapping("/replys/list")
	@ApiOperation(value = "댓글 목록", notes = "댓글 목록")
	public RestResult<List<AuthBoardModel>> getAuthBrdReplyList(@Valid AuthBoardModel model) {
		final List<AuthBoardModel> resultList = service.getAuthBrdReplyList(model);
		return GchcRestResult.of(resultList);
	}

	@DeleteMapping("/replys/delete")
	@ApiOperation(value = "댓글 삭제", notes = "댓글 삭제")
	public AuthBoardModel deleteAuthBrdReply(@RequestBody @Valid AuthBoardModel in) {

		AuthBoardModel model = service.deleteAuthBrdReply(in);

		// insert에 실패했을 경우에 Exception 발생
		if( model == null ){
			throw new UstraMvcException(GchcResponseCode.CANNOT_SAVE_RECORD);
		}
		return model;
	}

	@GetMapping("/dcl/list")
	@ApiOperation(value = "신고 목록", notes = "신고 목록")
	public RestResult<List<AuthBoardModel>> getDclList(@Valid AuthBoardModel in) {
		final List<AuthBoardModel> resultList = service.getDclList(in);
		return GchcRestResult.of(resultList);
	}

	@DeleteMapping("/hidden/one/update")
	@ApiOperation(value = "숨김 단건", notes = "숨김 단건")
	public RestResult<Object> updateHiddenOne(@RequestBody @Valid AuthBoardModel model) {
		Integer affectedRows = service.updateHiddenOne(model);
		return GchcRestResult.of(affectedRows, GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/hidden/update")
	@ApiOperation(value = "숨김 다건", notes = "숨김")
	public RestResult<Object> updateHidden(@RequestBody @Valid List<AuthBoardModel> list) {
		Integer affectedRows = service.updateHidden(list);
		return GchcRestResult.of(affectedRows, GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/authority/one/update")
	@ApiOperation(value = "미인증 단건", notes = "미인증 단건")
	public RestResult<Object> updateAuthorityOne(@RequestBody @Valid AuthBoardModel model) {
		Integer affectedRows = service.updateAuthorityOne(model);
		return GchcRestResult.of(affectedRows, GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/authority/update")
	@ApiOperation(value = "미인증 다건", notes = "미인증 다건")
	public RestResult<Object> updateAuthority(@RequestBody @Valid List<AuthBoardModel> list) {
		Integer affectedRows = service.updateAuthority(list);
		return GchcRestResult.of(affectedRows, GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/authority/complete/update")
	@ApiOperation(value = "인증수치변경", notes = "인증수치변경")
	public void updateAuthorityComplete(@RequestBody @Valid List<AuthBoardModel> list) {
		service.updateAuthorityComplete(list);
	}


	@DeleteMapping("/repair/one/update")
	@ApiOperation(value = "복원 단건", notes = "복원 단건")
	public RestResult<Object> updateRepairOne(@RequestBody @Valid AuthBoardModel model) {
		Integer affectedRows = service.updateRepairOne(model);
		return GchcRestResult.of(affectedRows, GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/repair/update")
	@ApiOperation(value = "복원 다건", notes = "복원 다건")
	public RestResult<Object> updateRepair(@RequestBody @Valid List<AuthBoardModel> list) {
		Integer affectedRows = service.updateRepair(list);
		return GchcRestResult.of(affectedRows, GchcResponseCode.SUCCESS);
	}

	@PostMapping("/download_excel")
	@ApiOperation(value = "엑셀다운로드", notes = "엑셀다운로드")
	public ResponseEntity<?> getExcelDownload(@RequestBody @Valid AuthBoardSearchModel model, HttpServletRequest request, HttpServletResponse response){
			return fileOperationManager.convert(DataToExcelWebResourceConverter
					.entityBuilder(Arrays.asList(service.getExcelDownload(model)), model.getDwldInfo().get("dwldPageNm") + ".xlsx", request, response)
					.build());
	}

	@PostMapping("/push")
 	public RestResult<?> sendGuide(@RequestBody List<AuthBoardModel> models) {
		int resultCount = 0;

		for (AuthBoardModel model : models) {
			int postId = model.getPostId();
			String pushType = model.getPushType();

			resultCount += apiService.sendAuthPush(postId, pushType).getBody().get("SUCCESS");
		}

		return GchcRestResult.of(resultCount);
	}

}
