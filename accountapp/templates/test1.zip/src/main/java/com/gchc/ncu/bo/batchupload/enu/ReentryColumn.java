package com.gchc.ncu.bo.batchupload.enu;

import lombok.Getter;

@Getter
public enum ReentryColumn implements BatchUploadColumn {

	AEMP_NM("임직원이름", "AempNm"),

	AEMP_BRDT("임직원생년월일", "AempBrdt"),

	EXIST_AEMP_ID("기존사번", "ExistAempId"),

	NEW_AEMP_ID("신규사번", "NewAempId"),

	PKG_NM("패키지명", "PkgNm"),

	CORP_SPFN_VAL("회사지원금", "CorpSpfnVal"),

	AEMP_REEN_REG_SEQ("MemberID", "AempReenRegSeq")

	;

	private String title;

	private String field;

	ReentryColumn(String title, String field) {

		this.title = title;
		this.field = field;
	}
}
