package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gchc.ncu.bo.care.models.ActMsnBscModel;
import com.gchc.ncu.bo.care.models.GoalStpCntBscModel;
import com.gchc.ncu.bo.care.repository.DailyWalkGoalRepository;
import com.gchc.ncu.bo.care.vo.DailyWalkGoalVo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DailyWalkGoalService {

	private final DailyWalkGoalRepository dailyWalkGoalRepository;

	public List<ActMsnBscModel> getDailyWalkGoalList(DailyWalkGoalVo criteria) {
		return dailyWalkGoalRepository.selectDailyWalkGoalList(criteria);
	}

	@Transactional
	public void saveDailyWalkGoal(List<GoalStpCntBscModel> list) {
		if (list != null) {
			for (GoalStpCntBscModel model : list) {
				dailyWalkGoalRepository.saveDailyWalkGoal(model);
			}
		}
	}

	@Transactional
	public void deleteDailyWalkGoal(List<GoalStpCntBscModel> list) {
		if (list != null) {
			for (GoalStpCntBscModel model : list) {
				dailyWalkGoalRepository.deleteDailyWalkGoal(model);
			}
		}
	}

}
