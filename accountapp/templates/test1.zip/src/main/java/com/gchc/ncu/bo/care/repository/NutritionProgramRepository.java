package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.NtrtPgmBscModel;
import com.gchc.ncu.bo.care.models.NtrtPgmDtlModel;
import com.gchc.ncu.bo.care.vo.NutritionProgramVo;

@Mapper
public interface NutritionProgramRepository {

	List<NtrtPgmBscModel> selectProgramList(NutritionProgramVo criteria);
	NtrtPgmBscModel selectProgramDetail(NtrtPgmBscModel criteria);
	void insertProgram(NtrtPgmBscModel model);
	void updateProgram(NtrtPgmBscModel model);
	void deleteProgram(NtrtPgmBscModel model);

	List<NtrtPgmDtlModel> selectProgramMissionList(NutritionProgramVo criteria);
	NtrtPgmDtlModel selectProgramMissionDetail(NtrtPgmDtlModel criteria);
	void insertProgramMission(NtrtPgmDtlModel model);
	void updateProgramMission(NtrtPgmDtlModel model);
	void deleteProgramMission(NtrtPgmDtlModel model);

	void deleteProgramMissionByNtrtPgmId(int pgmId);

}
