package com.gchc.ncu.bo.batchupload.comm;

import com.gsitm.ustra.java.data.poi.UstraExcelCellInfoModel;
import com.gsitm.ustra.java.data.poi.UstraExcelCellType;
import com.gsitm.ustra.java.data.poi.UstraExcelModel;
import com.gsitm.ustra.java.data.poi.generator.ColoredHeaderUstraExcelCellGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
public class BatchUploadCellGenerator extends ColoredHeaderUstraExcelCellGenerator {

	final static String BODY_STYLE_KEY = "__BODY_STYLE__";
	final static String SPECIAL_HEADER_STYLE_KEY = "__SPECIAL_HEADER_STYLE__";

	List<String> specialHeaderList = new ArrayList<>();

	public BatchUploadCellGenerator() {
		super(IndexedColors.LIGHT_YELLOW.getIndex());
	}

	public BatchUploadCellGenerator(List<String> specialHeaders) {
		super(IndexedColors.LIGHT_YELLOW.getIndex());

		this.specialHeaderList = specialHeaders;
	}

	@Override
	public void init(SXSSFWorkbook workbook, SXSSFSheet sheet) {

		super.init(workbook, sheet);

		addCellStyle(BODY_STYLE_KEY, workbook.createCellStyle());
		addCellStyle(SPECIAL_HEADER_STYLE_KEY, createHeaderStyle(workbook));

		Font font = workbook.createFont();
		font.setFontName("맑은 고딕");
		font.setFontHeight((short)200);

		getCellStyle(HEADER_STYLE_KEY).setAlignment(HorizontalAlignment.LEFT);
		getCellStyle(HEADER_STYLE_KEY).setFont(font);
		getCellStyle(BODY_STYLE_KEY).setFont(font);
		getCellStyle(SPECIAL_HEADER_STYLE_KEY).setAlignment(HorizontalAlignment.LEFT);
		getCellStyle(SPECIAL_HEADER_STYLE_KEY).setFillForegroundColor(IndexedColors.TAN.getIndex());
		getCellStyle(SPECIAL_HEADER_STYLE_KEY).setFont(font);

		sheet.trackAllColumnsForAutoSizing();
	}

	@Override
	public void makeBody(SXSSFWorkbook workbook, SXSSFSheet sheet, UstraExcelModel model) {

		// 바디 헤더
		final List<UstraExcelCellInfoModel> bodyHeader = model.getCellInfoList();
		final Row header = this.createRow(sheet);
		for (int i = 0; i < bodyHeader.size(); i++) {
			UstraExcelCellInfoModel cellInfo = bodyHeader.get(i);
			Cell cell = header.createCell(i);
			cell.setCellValue(cellInfo.getHeader());

			// add style
			if( specialHeaderList.contains(cell.getStringCellValue()) )
				cell.setCellStyle(this.getCellStyle(SPECIAL_HEADER_STYLE_KEY));
			else
				cell.setCellStyle(this.getCellStyle(HEADER_STYLE_KEY));
		}

		// 바디 내용
		final List<Map<String, Object>> body = model.getBody();
		for (int i = 0; i < body.size(); i++) {
			final Row row = this.createRow(sheet);
			final Map<String, Object> data = body.get(i);

			for (int j = 0; j < bodyHeader.size(); j++) {
				UstraExcelCellInfoModel cellInfo = bodyHeader.get(j);
				Object src = data.get(cellInfo.getName());
				Object obj = src;
				try {
					if (cellInfo.getEncoder() != null) {
						obj = cellInfo.getEncoder().convert(src);
					}
				} catch (Exception e) {
					// SPARROW 1490484 EMPTY_CATCH_BLOCK
					LOGGER.error(e.getMessage());
				}

				if (cellInfo.getCellType().equals(UstraExcelCellType.NUMERIC)) {
					Cell cell = row.createCell(j, CellType.NUMERIC);
					cell.setCellValue(Double.parseDouble(nvl(obj)));
					cell.setCellStyle(getCellStyle(BODY_STYLE_KEY));
				} else {
					Cell cell = row.createCell(j);
					cell.setCellValue(nvl(obj));
					cell.setCellStyle(getCellStyle(BODY_STYLE_KEY));
				}
			}
		}
	}

	@Override
	public void customizeSheet(SXSSFWorkbook workbook, SXSSFSheet sheet, UstraExcelModel model) {

		for( int i=0; i<model.getCellInfoList().size(); i++ ) {
			sheet.autoSizeColumn(i);
			sheet.setColumnWidth(i, Math.min(255*256, sheet.getColumnWidth(i) + 1024));
		}
	}
}
