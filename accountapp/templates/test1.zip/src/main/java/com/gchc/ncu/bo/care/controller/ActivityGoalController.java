package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.DssActMsnRltnModel;
import com.gchc.ncu.bo.care.service.ActivityGoalService;
import com.gchc.ncu.bo.care.vo.ActivityGoalVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/activity/goal")
@RequiredArgsConstructor
public class ActivityGoalController {

	private final ActivityGoalService goalService;

	@GetMapping("/list")
	public List<DssActMsnRltnModel> list(@ModelAttribute ActivityGoalVo criteria) {
		return goalService.getActivityGoalList(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid List<DssActMsnRltnModel> list) {
		goalService.saveActivityGoal(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody @Valid List<DssActMsnRltnModel> list) {
		goalService.deleteActivityGoalById(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
