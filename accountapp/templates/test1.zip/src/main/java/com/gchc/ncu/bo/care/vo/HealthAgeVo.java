package com.gchc.ncu.bo.care.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

@Data
@EqualsAndHashCode(callSuper=false)
public class HealthAgeVo extends UstraManagementBaseModel {

	private String staDate;
	private String endDate;
	private String uidNm;
	private String clcoId;

	private Integer dssHzrdRecsId;

}
