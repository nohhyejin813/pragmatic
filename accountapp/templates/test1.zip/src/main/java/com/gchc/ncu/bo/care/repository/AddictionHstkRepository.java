package com.gchc.ncu.bo.care.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gchc.ncu.bo.care.models.PoisHstkAnswDtlModel;
import com.gchc.ncu.bo.care.models.PoisHstkBscModel;
import com.gchc.ncu.bo.care.vo.AddictionHstkVo;

@Mapper
public interface AddictionHstkRepository {

	List<PoisHstkBscModel> selectAddictionHstkList(AddictionHstkVo criteria);
	PoisHstkBscModel selectAddictionHstkDetail(PoisHstkBscModel criteria);
	void insertAddictionHstk(PoisHstkBscModel model);
	void updateAddictionHstk(PoisHstkBscModel model);
	void deleteAddictionHstk(PoisHstkBscModel model);

	List<PoisHstkAnswDtlModel> selectAddictionHstkAnswerList(PoisHstkBscModel criteria);
	void saveAddictionHstkAnswer(PoisHstkAnswDtlModel model);
	void deleteAddictionHstkAnswerByHstkId(int hstkId);

}
