package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.StndBodyBscModel;
import com.gchc.ncu.bo.care.service.DailyStndBodyService;
import com.gchc.ncu.bo.care.vo.DailyStndBodyVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/daily/stnd-body")
@RequiredArgsConstructor
public class DailyStndBodyController {

	private final DailyStndBodyService dailyStndBodyService;

	@GetMapping("/list")
	public List<StndBodyBscModel> list(@ModelAttribute DailyStndBodyVo criteria) {
		return dailyStndBodyService.getDailyStndBodyList(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid List<StndBodyBscModel> list) {
		dailyStndBodyService.saveDailyStndBody(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
