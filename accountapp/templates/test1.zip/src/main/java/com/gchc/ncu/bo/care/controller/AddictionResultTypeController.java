package com.gchc.ncu.bo.care.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gchc.common.exception.GchcResponseCode;
import com.gchc.common.model.GchcRestResult;
import com.gchc.ncu.bo.care.models.PoisRsltDtlModel;
import com.gchc.ncu.bo.care.service.AddictionResultTypeService;
import com.gchc.ncu.bo.care.vo.AddictionResultTypeVo;
import com.gsitm.ustra.java.mvc.rest.model.RestResult;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/bo/care/addiction/result-type")
@RequiredArgsConstructor
public class AddictionResultTypeController {

	private final AddictionResultTypeService AddictionResultTypeService;

	@GetMapping("/list")
	public List<PoisRsltDtlModel> list(@ModelAttribute AddictionResultTypeVo criteria) {
		return AddictionResultTypeService.getAddictionResultTypeList(criteria);
	}

	@GetMapping("/detail")
	public PoisRsltDtlModel detail(@ModelAttribute PoisRsltDtlModel criteria) {
		return AddictionResultTypeService.getAddictionResultTypeDetail(criteria);
	}

	@PostMapping("/save")
	public RestResult<?> save(@RequestBody @Valid PoisRsltDtlModel model) {
		AddictionResultTypeService.saveAddictionResultType(model);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

	@DeleteMapping("/delete")
	public RestResult<?> delete(@RequestBody List<PoisRsltDtlModel> list) {
		AddictionResultTypeService.deleteAddictionResultType(list);
		return GchcRestResult.of(GchcResponseCode.SUCCESS);
	}

}
