package com.gchc.ncu.bo.batchupload.enu;

import java.text.MessageFormat;

public enum BatchMemberUploadError {

	MISSING_INFORMATION(2, "{0}이(가) 누락되었습니다."),

	MISSING_UPDATE_INFORMATION(2, "임직원 정보(사번/4KEY)가 부족합니다."),

	MISSING_GRADE_INFORMATION(2, "등급과 백신등급이 모두 누락되었습니다."),

	MISSING_MOBILE_AND_EMAIL(2, "모바일과 이메일 모두 누락되었습니다."),

	INVALID_INFORMATION(3, "{0}이(가) 잘못되었습니다."),

	INVALID_AEMP_PACKAGE(3, "승인된 임직원 패키지가 아닙니다."),

	INVALID_FAMILY_PACKAGE(3, "승인된 배우자 패키지가 아닙니다."),

	INVALID_MULTI_PACKAGE(3, "승인된 가족 패키지가 아닙니다."),

	INVALID_SPCU_TGT(3, "특검만(지원) 등급은 특수검진 대상자여야 합니다."),

	INVALID_EXTR_MTTR(3, "특수검진 대상인 경우에만 특수물질 등록이 가능합니다."),

	MISSING_SUPPORT_INFO(2, "지원이지만 지원금 또는 패키지가 누락되었습니다."),

	MISSING_FAMILY_SUPPORT_INFO(2, "배우자지원이지만 지원금 또는 패키지가 누락되었습니다."),

	MISSING_FAMILY_PACKAGE_INFO(2, "배우자 지원이지만 패키지가 누락되었습니다."),

	NO_SUPPORT_TNSF(3, "지원금 양도 정책를 사용하지 않는 고객사입니다."),

	NO_SUPPORT_SLCT(3, "지원금 선택 정책을 사용하지 않는 고객사입니다."),

	NO_SUPPORT_MULTI(3, "다중 지원을 사용하지 않는 고객사입니다."),

	DUPLICATED_FAMILY(5, "가족 정보가 중복으로 입력되어 있습니다.")

	;

	int errValue;
	String message;

	BatchMemberUploadError(int value, String message) {

		this.message = message;
		this.errValue = value;
	}

	public int getErrorValue() {

		return this.errValue;
	}

	public String getMessage(Object...args) {

		return MessageFormat.format(this.message, args);
	}
}
