package com.gchc.ncu.bo.care.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

import com.gchc.ncu.bo.care.models.NtrtIndcBscModel;
import com.gchc.ncu.bo.care.models.NtrtIndcDtlModel;
import com.gchc.ncu.bo.care.models.NtrtIngrdBscModel;
import com.gchc.ncu.bo.care.models.NtrtItrstIngrdDtlModel;
import com.gchc.ncu.bo.care.models.NutritionCdModel;
import com.gchc.ncu.bo.care.repository.NutritionStatusRepository;
import com.gchc.ncu.bo.care.vo.NutritionStatusVo;

@Service
@RequiredArgsConstructor
public class NutritionStatusService {

	private final NutritionStatusRepository nutritionStatusRepository;

	public List<NtrtIngrdBscModel> getNutritionStatusList(NutritionStatusVo in) {
		return nutritionStatusRepository.nutritionStatusList(in);
	}

	public NtrtIngrdBscModel getNutritionStatus(NutritionStatusVo in) {
		return nutritionStatusRepository.getNutritionStatus(in);
	}

	public void saveNutritionBsc(NtrtIngrdBscModel model) {

		if(model.getNtrtIngrdId() != null) {
			nutritionStatusRepository.updateNutritionBsc(model);
		} else {
			nutritionStatusRepository.saveNutritionBsc(model);
		}

	}

	@Transactional
	public void deleteNutritionBsc(List<NtrtIngrdBscModel> list) {
		if (list != null) {
			for (NtrtIngrdBscModel model : list) {
				nutritionStatusRepository.deleteNutritionBsc(model);
			}
		}
	}

	public List<NutritionCdModel> getNutritionInterestList() {
		return nutritionStatusRepository.selectNutritionInterestList();
	}

	public void updateNutritionCode(NutritionCdModel model) {
		nutritionStatusRepository.updateNutritionCode(model);
	}

	public List<NtrtItrstIngrdDtlModel> getNtrtItrstIngrdList(NutritionStatusVo in) {
		return nutritionStatusRepository.selectNtrtItrstIngrdList(in);
	}

	public NtrtItrstIngrdDtlModel getNtrtItrstDetail(NtrtItrstIngrdDtlModel model) {
		return nutritionStatusRepository.selectNtrtItrstDetail(model);
	}

	public void saveNutritionItrst(NtrtItrstIngrdDtlModel model) {

		if(model.getFrstRegDtm() != null) {
			nutritionStatusRepository.updateNutritionItrst(model);
		} else {
			nutritionStatusRepository.saveNutritionItrst(model);
		}

	}

	@Transactional
	public void deleteNtrtItrst(List<NtrtItrstIngrdDtlModel> list) {
		if (list != null) {
			for (NtrtItrstIngrdDtlModel model : list) {
				nutritionStatusRepository.deleteNtrtItrst(model);
			}
		}
	}



	public List<NtrtIndcBscModel> getNtrtIndcList(NutritionStatusVo in) {
		return nutritionStatusRepository.selectNtrtIndcList(in);
	}

	public List<NtrtIndcDtlModel> getNtrtIndcDtlList(NutritionStatusVo in) {
		return nutritionStatusRepository.selectNtrtIndcDtlList(in);
	}

	public NtrtIndcBscModel getNtrtIndcDetail(NutritionStatusVo in) {
		return nutritionStatusRepository.selectNtrtIndcDetail(in);
	}

	public int saveNtrtIndcBsc(NtrtIndcBscModel model) {
		int result = 0;

		result = nutritionStatusRepository.overlapAge(model);

		if( result > 0) {
			result = -1;
			return result;
		}

		if(model.getNtrtIndcId() != null) {
			result = nutritionStatusRepository.updateNtrtIndcBsc(model);
		} else {
			result = nutritionStatusRepository.insertNtrtIndcBsc(model);
		}

		return result;

	}

	@Transactional
	public void deleteNtrtIndcBsc(List<NtrtIndcBscModel> list) {
		if (list != null) {
			for (NtrtIndcBscModel model : list) {
				nutritionStatusRepository.deleteNtrtIndcDtl(model);
				nutritionStatusRepository.deleteNtrtIndcBsc(model);
			}
		}
	}

	public void saveNtrtIndcDtl(List<NtrtIndcDtlModel> list) {
		NtrtIndcBscModel nibModel = new NtrtIndcBscModel();

		if (list != null) {
			nibModel.setNtrtIndcId(list.get(0).getNtrtIndcId());
			nutritionStatusRepository.deleteNtrtIndcDtl(nibModel);
			for (NtrtIndcDtlModel model : list) {
				nutritionStatusRepository.insertNtrtIndcDtl(model);
			}
		}

	}
}
