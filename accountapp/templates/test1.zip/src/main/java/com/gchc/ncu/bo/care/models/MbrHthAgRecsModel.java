package com.gchc.ncu.bo.care.models;

import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import com.gsitm.ustra.java.core.utils.UstraMaskingUtils.MaskingType;
import com.gsitm.ustra.java.core.utils.annotation.Masked;
import com.gsitm.ustra.java.management.models.base.UstraManagementBaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MbrHthAgRecsModel extends UstraManagementBaseModel {

	private Integer hthAgRecsId;
	@Masked(MaskingType.ID)
	private String uid;
	private String pfrmDt;
	private Integer srvyAnswId;
	private Integer srvyId;
	private Integer clcoId;
	private Integer hthAg;

	@Masked(MaskingType.NAME)
	private String mbrNm;
	private Integer diffAge;
	private Integer endAg;
	private String clcoNm;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp frstRegDtm;
	private String frstRegrId;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Timestamp lastUpdDtm;
	private String lastUpdrId;

}
